'use server';
import appConfig from '@/lib/app-config';
import { ILocale } from '@/types/common';
import { cookies } from 'next/headers';

// In this example the locale is read from a cookie. You could alternatively
// also read it from a database, backend service, or any other source.
const COOKIE_NAME = 'NEXT_LOCALE';

export async function getUserLocale() {
  return (
    (await cookies()).get(COOKIE_NAME)?.value || appConfig.i18n.defaultLocale
  );
}

export async function setUserLocale(locale: ILocale) {
  (await cookies()).set(COOKIE_NAME, locale);
}
