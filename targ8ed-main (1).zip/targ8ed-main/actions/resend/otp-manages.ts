'use server';

import ChangeEmailOTPTemplate from '@/components/email-templates/change-email-address-template';
import InitialSetupOTPTemplate from '@/components/email-templates/initial-setup-otp-email-template';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { decryptJSON } from '@/convex/utils/encryption';
import requiredEnvVariables from '@/lib/env-variables';
import { render } from '@react-email/render';
import { Resend } from 'resend';

const resend = new Resend(requiredEnvVariables.RESEND_API_KEY);

export const sendInitialSetupOTP = async (args: {
  name: string;
  encryptedData: string;
}) => {
  try {
    const { name = '', encryptedData = '' } = args;

    if (!encryptedData) return false;

    const decryptedOTPData = (await decryptJSON(encryptedData)) as {
      email: string;
      otp: string;
    };

    if (
      !decryptedOTPData ||
      !decryptedOTPData?.email ||
      !decryptedOTPData?.otp
    ) {
      return false;
    }

    const emailHtml = await render(
      InitialSetupOTPTemplate({
        userName: name,
        email: decryptedOTPData?.email,
        otp: decryptedOTPData?.otp,
      })
    );

    const { error } = await resend.emails.send({
      from: `${ROOT_CONFIG.site.name} <no-reply@${requiredEnvVariables.NEXT_PUBLIC_RESEND_DOMAIN}>`,
      to: [decryptedOTPData?.email],
      subject: `Your OTP for initial setup on ${ROOT_CONFIG.site.name}`,
      html: emailHtml,
    });

    if (error) {
      console.error('Email sending error:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.dir(error);
    return false;
  }
};

export const sendEmailChangeOTP = async (args: {
  name: string;
  encryptedData: string;
}) => {
  try {
    const { name = '', encryptedData = '' } = args;

    if (!encryptedData) return false;

    const decryptedOTPData = (await decryptJSON(encryptedData)) as {
      email: string;
      otp: string;
    };

    if (
      !decryptedOTPData ||
      !decryptedOTPData?.email ||
      !decryptedOTPData?.otp
    ) {
      return false;
    }

    const emailHtml = await render(
      ChangeEmailOTPTemplate({
        userName: name,
        email: decryptedOTPData?.email,
        otp: decryptedOTPData?.otp,
      })
    );

    const { error } = await resend.emails.send({
      from: `${ROOT_CONFIG.site.name} <no-reply@${requiredEnvVariables.NEXT_PUBLIC_RESEND_DOMAIN}>`,
      to: [decryptedOTPData?.email],
      subject: `Your OTP for changing email on ${ROOT_CONFIG.site.name}`,
      html: emailHtml,
    });

    if (error) {
      console.error('Email sending error:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.dir(error);
    return false;
  }
};
