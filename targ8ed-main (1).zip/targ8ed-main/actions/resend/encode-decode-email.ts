'use server';
import requiredEnvVariables from '@/lib/env-variables';
import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;

function getDeterministicIV(email: string): Buffer {
  return crypto
    .createHash('sha256')
    .update(email)
    .digest()
    .subarray(0, IV_LENGTH);
}

export async function encryptEmail(email: string): Promise<string | null> {
  try {
    if (
      !requiredEnvVariables.ENCRYPTION_SECRET ||
      requiredEnvVariables.ENCRYPTION_SECRET.length !== 32
    )
      return null;
    const iv = getDeterministicIV(email);
    const cipher = crypto.createCipheriv(
      ALGORITHM,
      Buffer.from(requiredEnvVariables.ENCRYPTION_SECRET),
      iv
    );
    let encrypted = cipher.update(email, 'utf8');
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    const tag = cipher.getAuthTag();
    return Buffer.concat([iv, tag, encrypted]).toString('base64url');
  } catch {
    return null;
  }
}

export async function decryptEmail(encoded: string): Promise<string | null> {
  try {
    if (
      !requiredEnvVariables.ENCRYPTION_SECRET ||
      requiredEnvVariables.ENCRYPTION_SECRET.length !== 32
    )
      return null;
    const buffer = Buffer.from(encoded, 'base64url');
    const iv = buffer.subarray(0, IV_LENGTH);
    const tag = buffer.subarray(IV_LENGTH, IV_LENGTH + 16);
    const encrypted = buffer.subarray(IV_LENGTH + 16);

    const decipher = crypto.createDecipheriv(
      ALGORITHM,
      Buffer.from(requiredEnvVariables.ENCRYPTION_SECRET),
      iv
    );
    decipher.setAuthTag(tag);
    let decrypted = decipher.update(encrypted);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString('utf8');
  } catch (error) {
    console.error('Decryption failed:', error);
    return null;
  }
}
