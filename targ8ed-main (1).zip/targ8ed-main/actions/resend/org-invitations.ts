'use server';

import InviteUserEmailTemplate from '@/components/email-templates/invite-user-email-template';
import { Doc } from '@/convex/_generated/dataModel';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import requiredEnvVariables from '@/lib/env-variables';
import { render } from '@react-email/render';
import { headers } from 'next/headers';
import { Resend } from 'resend';
import { encryptEmail } from './encode-decode-email';

const resend = new Resend(requiredEnvVariables.RESEND_API_KEY);

const getProtocol = async () => {
  const headersList = await headers();

  const serverProtocol = headersList.get('x-forwarded-proto') || '';

  const fallbackProtocol =
    requiredEnvVariables.NODE_ENV === 'production' ? 'https' : 'http';
  return serverProtocol || fallbackProtocol;
};

export const sendInvitationEmail = async (
  email: string,
  token: string,
  organization: Doc<'organizations'>
) => {
  try {
    const encodedEmail = await encryptEmail(email);
    const protocol = await getProtocol();
    const subdomain = organization?.subdomain;
    const mainDomain = requiredEnvVariables?.NEXT_PUBLIC_MAIN_DOMAIN;

    const inviteLink = `${protocol}://${subdomain}.${mainDomain}/invitation?token=${token}&e=${encodedEmail}`;

    const emailHtml = await render(
      InviteUserEmailTemplate({
        organizationName: organization.name,
        inviteLink,
      })
    );

    const { error } = await resend.emails.send({
      from: `${ROOT_CONFIG.site.name} Invitations <invitations@${requiredEnvVariables.NEXT_PUBLIC_RESEND_DOMAIN}>`,
      to: [email],
      subject: `You're invited to join ${organization.name} on ${ROOT_CONFIG.site.name}`,
      html: emailHtml,
    });

    if (error) {
      console.error('Email sending error:', error);
      return false;
    }

    return true;
  } catch {
    return false;
  }
};
