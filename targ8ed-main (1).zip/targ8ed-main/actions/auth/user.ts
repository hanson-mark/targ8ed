'use server';

import { emailZodSchema, nameZodSchema } from '@/convex/validations/common';
import { generateHonoResponse } from '@/hono-app/helpers/response-helpers';
import { handleZodError } from '@/hono-app/middlewares/global-error-handler';
import requiredEnvVariables from '@/lib/env-variables';
import { IClerkApiUser, IClerkError, IClerkIdentityUser } from '@/types/clerk';
import { auth, clerkClient } from '@clerk/nextjs/server';
import { z } from 'zod';

export const createClerkUser = async (userData: {
  email: string;
  name: string;
}) => {
  try {
    // 1. Validate input
    const schema = z.object({
      name: nameZodSchema,
      email: emailZodSchema,
    });

    const parsed = schema.safeParse(userData);
    if (!parsed.success) {
      return handleZodError(parsed.error);
    }

    const { email, name } = parsed.data;
    const authClient = await clerkClient();

    // 2. Check if user already exists
    const existingUsers = await authClient.users.getUserList({
      emailAddress: [email],
    });

    if (existingUsers?.data?.length > 0) {
      const user = existingUsers.data[0];
      return generateHonoResponse({
        success: true,
        message: 'Clerk user already exists.',
        data: {
          id: user.id,
          imageUrl: user.imageUrl,
        },
      });
    }

    // 3. Create new user
    const [firstName = '', ...rest] = name.trim().split(/\s+/);
    const lastName = rest.join(' ');

    const newUser = await authClient.users.createUser({
      emailAddress: [email],
      firstName,
      lastName,
    });

    return generateHonoResponse({
      success: true,
      message: 'Clerk user added successfully.',
      data: {
        id: newUser.id,
        imageUrl: newUser.imageUrl,
      },
    });
  } catch (err) {
    const error = err as IClerkError;
    const clerkError = error?.errors?.[0];

    console.dir(error, { depth: Infinity });

    return generateHonoResponse({
      success: false,
      message: clerkError?.longMessage || 'Failed to add Clerk user.',
      errorSources: clerkError
        ? [
            {
              message: clerkError.longMessage,
              path: clerkError.meta?.paramName,
            },
          ]
        : [],
    });
  }
};

// Gets clerk token for convex validation
export async function getAuthToken() {
  const token = await (await auth())?.getToken({ template: 'convex' });
  return token || undefined;
}

// Gets a list of clerk users by email
export const getClerkUsersByEmail = async (
  email: string
): Promise<IClerkIdentityUser[]> => {
  const authClient = await clerkClient();

  const existingUsers = await authClient.users.getUserList({
    emailAddress: [email],
  });

  const formattedUsers: IClerkIdentityUser[] = (existingUsers?.data || []).map(
    (item) => ({
      id: item.id,
      firstName: item.firstName || null,
      lastName: item.lastName || null,
      imageUrl: item.imageUrl,
      locked: item.locked,
      lastSignInAt: item.lastSignInAt || null,
      emailAddresses:
        item.emailAddresses?.map((emailAddress) => ({
          id: emailAddress?.id,
          emailAddress: emailAddress.emailAddress,
          verification: emailAddress.verification
            ? { status: emailAddress.verification.status }
            : null,
        })) || [],
      externalAccounts:
        item.externalAccounts?.map((extAccount) => ({
          id: extAccount?.id,
          identificationId: extAccount?.identificationId,
          externalId: extAccount?.externalId,
          provider: extAccount.provider,
        })) || [],
    })
  );

  return formattedUsers;
};

// Update clerk user's email
export const updateClerkUserEmail = async (inputs: {
  oldEmail: string;
  newEmail: string;
  name: string;
}) => {
  const oldEmail = (inputs.oldEmail || '').trim().toLowerCase();
  const newEmail = (inputs.newEmail || '').trim().toLowerCase();

  // If same email, nothing to update
  if (oldEmail === newEmail) {
    return generateHonoResponse({
      success: true, // no-op but considered successful
      message: 'Old and new, both email addresses are same',
    });
  }

  try {
    const authClient = await clerkClient();

    // Find users with oldEmail & newEmail
    const usersRes = await fetch(
      `https://api.clerk.com/v1/users?email_address=${oldEmail}&email_address=${newEmail}`,
      {
        headers: {
          Authorization: `Bearer ${requiredEnvVariables.CLERK_SECRET_KEY}`,
        },
      }
    );
    const existingUsers: IClerkApiUser[] = await usersRes.json();

    // Separating oldEmailUser and newEmailUser
    const oldUser = existingUsers?.find((user) =>
      user?.email_addresses?.some((e) => e?.email_address === oldEmail)
    );

    const newUser = existingUsers?.find((user) =>
      user?.email_addresses?.some((e) => e?.email_address === newEmail)
    );

    // Updating user email
    const updateUserEmail = async (emailUser: IClerkApiUser) => {
      const newEmailDataInUser = emailUser?.email_addresses?.filter(
        (eData) => eData?.email_address === newEmail
      );
      const oldEmailDataInUser = emailUser?.email_addresses?.filter(
        (eData) => eData?.email_address === oldEmail
      );
      const externalAccountsWithOldEmail = emailUser?.external_accounts
        ?.filter((eAccount) => eAccount?.email_address === oldEmail)
        ?.map((eAccount) => ({
          id: eAccount?.id,
          externalAccountId: eAccount?.external_account_id,
          emailAddress: eAccount?.email_address,
          userId: emailUser?.id,
        }));

      // If new email data already in user, then updating email data
      if (newEmailDataInUser?.length > 0) {
        await Promise.all(
          newEmailDataInUser?.map((eData) =>
            authClient.emailAddresses.updateEmailAddress(eData?.id, {
              primary: true,
              verified: true,
            })
          )
        );
      }
      // If there no new email data in user, then creating email
      else {
        await authClient.emailAddresses.createEmailAddress({
          userId: emailUser?.id,
          emailAddress: newEmail,
          primary: true,
          verified: true,
        });
      }

      // Deleting external accounts before deleting email
      if (externalAccountsWithOldEmail?.length > 0) {
        await Promise.all(
          externalAccountsWithOldEmail?.map((eAccount) => {
            const splittedId = eAccount?.id?.split('_')?.[1] || '';
            const secondaryExternalAccountId = splittedId
              ? `eas_${splittedId}`
              : eAccount?.id;
            return authClient.users.deleteUserExternalAccount({
              userId: eAccount?.userId,
              externalAccountId:
                eAccount?.externalAccountId || secondaryExternalAccountId,
            });
          })
        );
      }

      // Deleting old emails if any
      if (oldEmailDataInUser?.length > 0) {
        await Promise.all(
          oldEmailDataInUser.map((eData) =>
            authClient.emailAddresses.deleteEmailAddress(eData?.id)
          )
        );
      }
    };

    // If oldEmailUser and newEmailUser is same
    if (newUser?.id && newUser?.id === oldUser?.id) {
      await updateUserEmail(oldUser);
      return generateHonoResponse({
        success: true,
        message: 'Email updated successfully in clerk',
      });
    }

    // If there is any user with newEmailUser then deleting it first
    if (newUser?.id && oldUser?.id && newUser?.id !== oldUser?.id) {
      await authClient.users.deleteUser(newUser?.id);
      await updateUserEmail(oldUser);

      return generateHonoResponse({
        success: true,
        message: 'Email updated successfully in clerk',
      });
    }

    // If only there is old email user
    if (!newUser?.id && oldUser?.id) {
      await updateUserEmail(oldUser);

      return generateHonoResponse({
        success: true,
        message: 'Email updated successfully in clerk',
      });
    }

    if (!newUser?.id && !oldUser?.id) {
      const newUserResponse = await createClerkUser({
        email: newEmail,
        name: inputs?.name,
      });

      return generateHonoResponse({
        success: newUserResponse?.success,
        message: newUserResponse?.success
          ? 'Email updated successfully in clerk'
          : 'Failed to update email in clerk',
      });
    }

    return generateHonoResponse({
      success: false,
      message: 'Failed to update email in clerk',
    });
  } catch (err) {
    const error = err as IClerkError;
    const clerkError = error?.errors?.[0];

    console.dir(error, { depth: Infinity });

    return generateHonoResponse({
      success: false,
      message: clerkError?.longMessage || 'Failed to update email in clerk',
      errorSources: clerkError
        ? [
            {
              message: clerkError.longMessage,
              path: clerkError.meta?.paramName,
            },
          ]
        : [],
    });
  }
};

// Handles unblocking clerk user who blocked by brute force protection
export const unblockBruteForceBlockedUser = async (clerk_user_id: string) => {
  const authClient = await clerkClient();

  const response = await authClient.users.unlockUser(clerk_user_id);
  return response ? true : false;
};

export const deleteClerkUser = async (email: string) => {
  try {
    // 1. Validate input
    const parsed = emailZodSchema.safeParse(email);
    if (!parsed.success) {
      return handleZodError(parsed.error);
    }

    const parsedEmail = parsed.data;
    const authClient = await clerkClient();

    // 2. Check if user already exists
    const existingUsers = await authClient.users.getUserList({
      emailAddress: [parsedEmail],
    });

    if (existingUsers?.data?.length > 0) {
      await Promise.all(
        existingUsers?.data?.map((user) =>
          authClient.users.deleteUser(user?.id)
        )
      );

      return generateHonoResponse({
        success: true,
        message: 'Clerk users deleted successfully',
      });
    } else {
      return generateHonoResponse({
        success: false,
        message: 'No clerk user exists',
      });
    }
  } catch (err) {
    const error = err as IClerkError;
    const clerkError = error?.errors?.[0];

    console.dir(error, { depth: Infinity });

    return generateHonoResponse({
      success: false,
      message: clerkError?.longMessage || 'Failed to add Clerk user.',
      errorSources: clerkError
        ? [
            {
              message: clerkError.longMessage,
              path: clerkError.meta?.paramName,
            },
          ]
        : [],
    });
  }
};
