import { Label } from '@/components/ui/label';
import { themeColorOptions } from '@/convex/constants/theme';
import { IThemeColor } from '@/convex/types/theme';
import { cn } from '@/lib/utils';
import ToggleButton from '../toggle-button';

interface IProps {
  label: string;
  selected: string;
  onSelect: (themeColor: IThemeColor) => void;
  disabled?: boolean;
}

const ThemeColorInput = ({
  label,
  selected,
  onSelect,
  disabled = false,
}: IProps) => {
  return (
    <div className="space-y-1 flex-col flex w-full items-start">
      <Label className="mb-2 font-semibold">{label}</Label>
      <div className="flex flex-wrap gap-2">
        {themeColorOptions.map((item) => {
          const isSelected = selected === item.id;
          return (
            <ToggleButton
              key={item.id}
              isSelected={isSelected}
              onClick={() => !disabled && onSelect(item.id)}
              disabled={disabled}
            >
              <span
                className={cn(
                  'w-5 h-5 rounded-full bg-primary border',
                  item.id
                )}
              />
              <span className="text-xs">{item.label}</span>
            </ToggleButton>
          );
        })}
      </div>
    </div>
  );
};

export default ThemeColorInput;
