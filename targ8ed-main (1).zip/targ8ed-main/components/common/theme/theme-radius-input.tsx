'use client';

import { Label } from '@/components/ui/label';
import { themeBorderRadiusOptions } from '@/convex/constants/theme';
import { IThemeBorderRadius } from '@/convex/types/theme';
import ToggleButton from '../toggle-button';

interface IProps {
  label: string;
  selected: string;
  onSelect: (radius: IThemeBorderRadius) => void;
  disabled?: boolean;
}

const ThemeRadiusInput = ({
  label,
  selected,
  onSelect,
  disabled = false,
}: IProps) => {
  return (
    <div className="space-y-1 flex-col flex w-full items-start">
      <Label className="mb-2 font-semibold">{label}</Label>
      <div className="flex flex-wrap gap-2">
        {themeBorderRadiusOptions.map((item) => {
          const isSelected = selected === item.id;
          return (
            <ToggleButton
              key={item.id}
              isSelected={isSelected}
              onClick={() => !disabled && onSelect(item.id)}
              disabled={disabled}
            >
              {item.id === 'radius-default' ? item.label : `${item.label} rem`}
            </ToggleButton>
          );
        })}
      </div>
    </div>
  );
};

export default ThemeRadiusInput;
