'use client';

import { Label } from '@/components/ui/label';
import { themeModeOptions } from '@/convex/constants/theme';
import { IThemeMode } from '@/convex/types/theme';
import { Moon, Sun } from 'lucide-react';
import ToggleButton from '../toggle-button';

interface IProps {
  label?: string;
  selected: IThemeMode;
  onSelect: (mode: IThemeMode) => void;
  disabled?: boolean;
}

const ThemeModeInput = ({
  label = 'Theme Mode',
  selected,
  onSelect,
  disabled = false,
}: IProps) => {
  const modes = themeModeOptions.map((item) => ({
    ...item,
    icon:
      item.id === 'light' ? (
        <Sun className="w-4 h-4" />
      ) : (
        <Moon className="w-4 h-4" />
      ),
  }));

  return (
    <div className="space-y-1 flex-col flex w-full items-start">
      <Label className="mb-2 font-semibold">{label}</Label>
      <div className="flex gap-2">
        {modes.map((mode) => {
          const isSelected = selected === mode.id;
          return (
            <ToggleButton
              key={mode.id}
              isSelected={isSelected}
              onClick={() => !disabled && onSelect(mode.id as IThemeMode)}
              disabled={disabled}
            >
              {mode.icon}
              {mode.label}
            </ToggleButton>
          );
        })}
      </div>
    </div>
  );
};

export default ThemeModeInput;
