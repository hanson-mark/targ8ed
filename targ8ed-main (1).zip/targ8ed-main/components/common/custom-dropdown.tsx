'use client';

import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { Check, ChevronsUpDown } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';

interface IOption {
  label: string;
  value: string;
}

interface CustomDropdownProps {
  value: string | null;
  onSelect: (value: string) => void;
  options: IOption[];
  placeholder?: string;
  disabled?: boolean;
  noOptionsMessage?: string;
  classNames?: {
    main?: string;
    button?: string;
  };
}

const CustomDropdown = ({
  value,
  onSelect,
  options,
  placeholder = 'Select option...',
  disabled = false,
  noOptionsMessage = 'No options available',
  classNames,
}: CustomDropdownProps) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [triggerWidth, setTriggerWidth] = useState<number>();

  const selected = options.find((opt) => opt.value === value);

  const updateWidth = useCallback(() => {
    if (buttonRef.current) {
      setTriggerWidth(buttonRef.current.offsetWidth);
    }
  }, []);

  useEffect(() => {
    updateWidth();
    const resizeObserver = new ResizeObserver(updateWidth);
    if (buttonRef.current) resizeObserver.observe(buttonRef.current);

    window.addEventListener('resize', updateWidth);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateWidth);
    };
  }, [updateWidth]);

  return (
    <div className={cn('flex flex-col w-full relative', classNames?.main)}>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            ref={buttonRef}
            disabled={disabled}
            variant="outline"
            className={cn(
              'justify-between text-sm h-10 w-full capitalize',
              {
                'text-primary/70 hover:text-primary/50 hover:bg-transparent':
                  !selected?.label,
              },
              classNames?.button
            )}
            type="button"
          >
            {selected?.label || placeholder}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </DropdownMenuTrigger>

        <DropdownMenuContent
          style={{ width: triggerWidth }}
          align="start"
          className="max-h-60 overflow-y-auto"
        >
          {options.length === 0 ? (
            <DropdownMenuItem disabled className="text-muted-foreground">
              {noOptionsMessage}
            </DropdownMenuItem>
          ) : (
            options.map((option) => (
              <DropdownMenuItem
                key={option.value}
                disabled={disabled}
                onSelect={() => onSelect(option.value)}
                className="cursor-pointer capitalize"
              >
                <Check
                  className={cn(
                    'mr-2 h-4 w-4',
                    option.value === value ? 'opacity-100' : 'opacity-0'
                  )}
                />
                {option.label}
              </DropdownMenuItem>
            ))
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default CustomDropdown;
