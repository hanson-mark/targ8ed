import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import {
  IConvexErrorResponse,
  IConvexResponse,
} from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useFileUpload, { IUseFileUploadProps } from '@/hooks/use-file-upload';
import { cn } from '@/lib/utils';
import { UploadIcon, UserIcon } from 'lucide-react';
import Image from 'next/image';
import React, { useRef } from 'react';
import toast from 'react-hot-toast';

interface IProps {
  showUploadButton?: boolean;
  imageURL: string;
  imageAlt: string;
  className?: string;
  isImageIdUpdating: boolean;
  onUpdateImageId: (
    id: Id<'_storage'>
  ) => Promise<IConvexErrorResponse | IConvexResponse<unknown>>;
  fileUploaderProps?: IUseFileUploadProps;
}

const ProfileImageWithUploader = ({
  showUploadButton = true,
  imageURL,
  imageAlt,
  className,
  isImageIdUpdating,
  onUpdateImageId,
  fileUploaderProps,
}: IProps) => {
  // Destructuring
  const allowedFileTypes = fileUploaderProps?.allowedFileTypes || [
    'image/png',
    'image/jpeg',
    'image/jpg',
  ];
  // File upload reference & Mutation hooks
  const fileUploadInputRef = useRef<HTMLInputElement | null>(null);
  const { isUploading, uploadFile, previewUrl, toastId } =
    useFileUpload(fileUploaderProps);

  const isImageUploading = isImageIdUpdating || isUploading;

  const profileImage = isImageUploading && previewUrl ? previewUrl : imageURL;

  const { mutate: removeFile } = useConvexMutation(
    api.functions.file.removeFile
  );

  // File upload handler
  const onFileUploadClick = () => {
    if (fileUploadInputRef.current) {
      fileUploadInputRef.current.click();
    }
  };

  // File upload input change handler
  const onFileUploadChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = e.target.files?.[0];
      if (!file) return;
      const storageId = await uploadFile(file);

      // ✅ Reset input value so same file triggers onChange again
      e.target.value = '';

      if (storageId) {
        toast.loading('Updating image...', { id: toastId });
        const res = await onUpdateImageId(storageId);

        if (res?.success) {
          toast.success(res?.message || 'Image updated successfully', {
            id: toastId,
          });
        } else {
          toast.error(res?.message || 'Failed to update image', {
            id: toastId,
          });
          await removeFile({ storageId });
        }
      }
    } catch (error) {
      console.log({ error });
    }
  };

  return (
    <div className="flex gap-3 items-center">
      <div
        className={cn(
          'relative w-14 h-14 flex justify-center items-center border rounded-full bg-muted overflow-hidden',
          className
        )}
      >
        {profileImage ? (
          <Image
            src={profileImage}
            fill
            className="object-cover"
            alt={imageAlt}
          />
        ) : (
          <UserIcon className="size-7" />
        )}

        {/* Uploading Overlay Spinner */}
        {(isUploading || isImageIdUpdating) && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center z-10">
            <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          </div>
        )}
      </div>

      {showUploadButton && (
        <>
          <input
            ref={fileUploadInputRef}
            type="file"
            name="profile-image"
            className="hidden"
            accept={allowedFileTypes ? allowedFileTypes.join(',') : 'image/*'}
            onChange={onFileUploadChange}
            multiple={false}
          />

          <div>
            <Button
              disabled={isUploading || isImageIdUpdating}
              type="button"
              variant={'outline'}
              className="gap-2"
              onClick={onFileUploadClick}
            >
              <UploadIcon className="h-4 w-4" /> Upload
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export default ProfileImageWithUploader;
