'use client';
import { setUserLocale } from '@/actions/i18n/locale-manager';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ILocale } from '@/types/common';
import { useLocale, useTranslations } from 'next-intl';
import { useTransition } from 'react';

const LanguageSwitcher = () => {
  const [isPending, startTransition] = useTransition();
  const t = useTranslations('LocaleSwitcher');
  const locale = useLocale();

  const onChange = (value: string) => {
    const locale = value as ILocale;
    startTransition(() => {
      setUserLocale(locale);
    });
  };

  const languages = [
    {
      value: 'en',
      label: t('en'),
    },
    {
      value: 'ro',
      label: t('ro'),
    },
  ];

  return (
    <div className="relative">
      <Select
        disabled={isPending}
        defaultValue={locale}
        onValueChange={(value) => onChange(value)}
      >
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder="Select a language" />
        </SelectTrigger>
        <SelectContent>
          <SelectGroup>
            {languages.map((language) => (
              <SelectItem key={language.value} value={language.value}>
                {language.label}
              </SelectItem>
            ))}
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  );
};

export default LanguageSwitcher;
