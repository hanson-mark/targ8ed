import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

interface IProps {
  id?: string;
  size?: 'sm' | 'md' | 'lg';
  checked?: boolean;
  defaultChecked?: boolean;
  required?: boolean;
  onCheckedChange?(checked: boolean): void;
  className?: string;
  label: string;
  labels?: { checked?: string; unchecked?: string };
  description?: string | ReactNode;
}

const CustomSwitch = ({
  className,
  label,
  labels,
  description,
  size = 'md',
  ...props
}: IProps) => {
  return (
    <div className="flex items-start space-x-2">
      <Switch
        {...(props || {})}
        className={cn(
          'cursor-pointer disabled:cursor-not-allowed',
          {
            '': size === 'sm',
            'h-5 w-9 [&_span]:size-4 [&_span]:data-[state=checked]:translate-x-[calc(100%+1px)] [&_span]:data-[state=unchecked]:translate-x-[1px]':
              size === 'md',
            'h-6 w-[42px] [&_span]:size-5 [&_span]:data-[state=checked]:translate-x-[calc(100%-1px)] [&_span]:data-[state=unchecked]:translate-x-[1px]':
              size === 'lg',
          },
          className
        )}
      />
      <div className="space-y-1 mt-0.5">
        {label || labels?.checked || labels?.unchecked ? (
          <Label htmlFor="airplane-mode" className="font-medium">
            {labels?.[props?.checked === true ? 'checked' : 'unchecked'] ||
              label}
          </Label>
        ) : null}
        {description ? (
          <p className="text-sm text-secondary-foreground font-light">
            {description}
          </p>
        ) : null}
      </div>
    </div>
  );
};

export default CustomSwitch;
