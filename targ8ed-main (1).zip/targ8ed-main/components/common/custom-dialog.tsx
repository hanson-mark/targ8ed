import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { ReactNode, RefObject } from 'react';
import { ScrollArea } from '../ui/scroll-area';

interface IProps {
  dialogRef?: RefObject<HTMLDivElement | null>;
  isOpen: boolean;
  onOpenChange: (state: boolean) => void;

  title: ReactNode;
  description?: ReactNode;

  includeScrollbar?: boolean;
  children: ReactNode;

  classNames?: {
    title?: string;
    content?: string;
  };
}

const CustomDialog = ({
  dialogRef,

  isOpen,
  onOpenChange,

  title,
  description,

  includeScrollbar,
  children,
  classNames,
}: IProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent
        {...(dialogRef ? { ref: dialogRef } : {})}
        id="dialog-content"
        className={cn(
          'p-7 gap-y-6',
          includeScrollbar ? 'pr-4.5' : '',
          classNames?.content
        )}
      >
        <div className="grid gap-y-3 px-1">
          <DialogHeader>
            <DialogTitle
              className={cn('text-xl capitalize', classNames?.title)}
            >
              {title}
            </DialogTitle>
            <DialogDescription className={!description ? 'sr-only' : ''}>
              {description || title}
            </DialogDescription>
          </DialogHeader>
          {!includeScrollbar ? (
            children
          ) : (
            <ScrollArea
              type="auto"
              className="h-full max-h-[calc(100vh-200px)] w-full pr-2.5"
            >
              {children}
            </ScrollArea>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CustomDialog;
