'use client';

import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { CheckIcon, CopyIcon } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

interface ICopyElementProps {
  value: string;
  className?: string;
}

interface ICopyFieldProps extends ICopyElementProps {
  label: string;
}

export const CopyField = ({ label, value, className }: ICopyFieldProps) => {
  const [copied, setCopied] = useState(false);
  const [maxWidth, setMaxWidth] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  // Calculate max-width of the value area dynamically
  useEffect(() => {
    const calculateWidth = () => {
      if (containerRef.current && labelRef.current) {
        const containerWidth = containerRef.current.offsetWidth;
        const labelWidth = labelRef.current.offsetWidth;
        // Subtract label and some spacing (10 for gap, 40 for padding and icon)
        const calculated = containerWidth - labelWidth - 60;
        setMaxWidth(calculated > 0 ? calculated : 0);
      }
    };

    calculateWidth();
    window.addEventListener('resize', calculateWidth);
    return () => window.removeEventListener('resize', calculateWidth);
  }, []);

  return (
    <div
      className={cn(
        'text-sm font-light flex items-center gap-2 flex-wrap w-full',
        className
      )}
      ref={containerRef}
    >
      <span ref={labelRef} className="whitespace-nowrap">
        {label}:
      </span>
      <div className="bg-muted rounded inline-flex items-center gap-1 min-w-0 max-w-full">
        <TooltipProvider delayDuration={100}>
          <Tooltip>
            <TooltipTrigger asChild>
              <span
                className="pl-2 py-1 text-sm truncate whitespace-nowrap overflow-hidden text-ellipsis cursor-default"
                style={{ maxWidth: maxWidth || '100%' }}
              >
                {value}
              </span>
            </TooltipTrigger>
            <TooltipContent>{value}</TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <TooltipProvider delayDuration={100}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="hover:text-primary rounded-l-none h-7 w-7 px-0"
                onClick={handleCopy}
              >
                {copied ? (
                  <CheckIcon className="w-4 h-4 text-primary transition" />
                ) : (
                  <CopyIcon className="w-4 h-4" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent className="text-xs">
              {copied ? 'Copied!' : 'Copy'}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
};

export const CopyButton = ({ value, className }: ICopyElementProps) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <TooltipProvider delayDuration={100}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            type="button"
            variant="secondary"
            size="icon"
            className={cn(
              'hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80',
              className
            )}
            onClick={handleCopy}
          >
            {copied ? (
              <CheckIcon className="w-4 h-4 text-primary transition" />
            ) : (
              <CopyIcon className="w-4 h-4" />
            )}
          </Button>
        </TooltipTrigger>
        <TooltipContent className="text-xs">
          {copied ? 'Copied!' : 'Copy'}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
