'use client';

import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { ILucideIconName } from '@/types/dashboard-layout';
import { useVirtualizer } from '@tanstack/react-virtual';
import debounce from 'lodash/debounce';
import * as AllIcons from 'lucide-react';
import { LucideProps, Search, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';

interface Props {
  value?: ILucideIconName;
  onChange?: (iconName: ILucideIconName) => void;
}

const ICON_ENTRIES = Object.entries(AllIcons.icons);

const LucideIconLibrary = ({ value, onChange }: Props) => {
  const [isLoading, setIsLoading] = useState(false);

  const [search, setSearch] = useState('');
  const [filteredIcons, setFilteredIcons] = useState(ICON_ENTRIES);

  const debouncedFilter = useMemo(
    () =>
      debounce((query: string) => {
        setIsLoading(true);
        const filtered = ICON_ENTRIES.filter(([name]) =>
          name.toLowerCase().includes(query.toLowerCase())
        );
        setFilteredIcons(filtered);
        setTimeout(() => setIsLoading(false), 100); // allow render cycle
      }, 300),
    []
  );

  const handleSearchChange = (value: string) => {
    setSearch(value);
    debouncedFilter(value);
  };

  const clearSearch = () => {
    setSearch('');
    setFilteredIcons(ICON_ENTRIES);
  };

  const parentRef = useRef<HTMLDivElement>(null);

  const rowVirtualizer = useVirtualizer({
    count: Math.ceil(filteredIcons.length / 6),
    getScrollElement: () => parentRef.current,
    estimateSize: () => 50,
    overscan: 5,
  });

  // Apply initial search and filter based on `value`
  useEffect(() => {
    if (value) {
      setSearch(value);
      const filtered = ICON_ENTRIES.filter(([name]) =>
        name.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredIcons(filtered);
    } else {
      setSearch('');
      setFilteredIcons(ICON_ENTRIES);
    }
  }, [value]);

  const itemsPerRow = 6;
  const calculatedItemsHeight = rowVirtualizer.getTotalSize();

  return (
    <div className="w-full">
      {/* Styled input with bottom border (separator) */}
      <div className="relative border rounded-t border-b border-border">
        <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search icons..."
          value={search}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="text-sm pl-8 pr-10 border-none shadow-none focus-visible:ring-0 focus-visible:ring-offset-0 !h-10"
        />
        {search && (
          <button
            onClick={clearSearch}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground cursor-pointer"
            type="button"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Icon selection grid */}
      <div
        ref={parentRef}
        className="h-32 overflow-y-auto border border-border border-t-transparent rounded-b-md p-2 relative scrollbar scrollbar-thumb-muted-foreground scrollbar-track-transparent"
      >
        <div
          style={{
            height: `${calculatedItemsHeight < 100 ? 100 : calculatedItemsHeight}px`,
            position: 'relative',
          }}
        >
          {isLoading ? (
            <div className="flex justify-center items-center h-32">
              <div className="w-5 h-5 border-2 border-muted border-t-transparent rounded-full animate-spin" />
            </div>
          ) : filteredIcons.length === 0 ? (
            <div className="flex items-center gap-1 justify-center h-full text-sm text-muted-foreground">
              No icons found with{' '}
              <span className="font-bold">{`"${search}"`}</span>
            </div>
          ) : (
            rowVirtualizer.getVirtualItems().map((virtualRow) => {
              const rowIcons = filteredIcons.slice(
                virtualRow.index * itemsPerRow,
                (virtualRow.index + 1) * itemsPerRow
              );

              return (
                <div
                  key={virtualRow.key}
                  className="grid grid-cols-6 gap-2 absolute left-0 right-0"
                  style={{
                    transform: `translateY(${virtualRow.start}px)`,
                    top: 0,
                  }}
                >
                  {rowIcons.map(([name, Icon]) => {
                    const isSelected = name === value;
                    const IconComponent = Icon as React.FC<LucideProps>;

                    return (
                      <button
                        key={name}
                        type="button"
                        onClick={
                          onChange
                            ? () => onChange(name as ILucideIconName)
                            : undefined
                        }
                        className={cn(
                          'flex items-center justify-center rounded-md p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-all cursor-pointer',
                          isSelected &&
                            'bg-primary text-primary-foreground hover:bg-primary/90'
                        )}
                      >
                        <IconComponent className="w-5 h-5" />
                      </button>
                    );
                  })}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default LucideIconLibrary;
