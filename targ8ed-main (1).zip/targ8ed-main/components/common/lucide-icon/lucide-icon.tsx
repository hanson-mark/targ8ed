import { ILucideIconName } from '@/types/dashboard-layout';
import * as AllIcons from 'lucide-react';

interface IProps {
  name: ILucideIconName;
  className?: string;
}

const LucideIcon = ({ name, className }: IProps) => {
  const Icon = (AllIcons[name] ||
    AllIcons['Home']) as React.FC<AllIcons.LucideProps>;
  return <Icon className={className} />;
};

export default LucideIcon;
