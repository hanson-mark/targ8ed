import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ReactNode } from 'react';

interface ToggleButtonProps {
  isSelected?: boolean;
  className?: string;
  onClick?: () => void;
  children: ReactNode;
  disabled?: boolean;
}

const ToggleButton = ({
  isSelected = false,
  className,
  onClick,
  children,
  disabled = false,
}: ToggleButtonProps) => {
  return (
    <Button
      disabled={disabled}
      size="sm"
      type="button"
      variant={isSelected ? 'outline' : 'ghost'}
      onClick={onClick}
      className={cn(
        'px-2 flex items-center gap-1 border border-transparent text-xs',
        isSelected && 'border-border bg-accent',
        className
      )}
    >
      {children}
    </Button>
  );
};

export default ToggleButton;
