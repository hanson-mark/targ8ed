'use client';

import { Button, buttonVariants } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { type VariantProps } from 'class-variance-authority';
import React, { ReactNode } from 'react';

const ButtonWithTooltip = ({
  tooltipContent,
  className,
  children,
  ...props
}: React.ComponentProps<'button'> &
  VariantProps<typeof buttonVariants> & {
    tooltipContent: ReactNode;
    asChild?: boolean;
  }) => {
  return (
    <TooltipProvider delayDuration={100}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button className={cn(className)} {...props}>
            {children}
          </Button>
        </TooltipTrigger>
        <TooltipContent className="text-xs z-[61]">
          {tooltipContent}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default ButtonWithTooltip;
