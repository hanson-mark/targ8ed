import { Skeleton } from '@/components/ui/skeleton';
import { ReactNode } from 'react';

interface IProps {
  children?: ReactNode;
}

const DashboardLoader = ({ children }: IProps) => {
  return (
    <div className="fixed inset-0 z-[200] flex h-screen w-full bg-white">
      {/* Sidebar Skeleton */}
      <aside className="hidden md:block w-64 p-4 border-r border-gray-200 bg-muted/40">
        <Skeleton className="h-10 w-32 mb-6" />
        <div className="space-y-4">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-8 w-3/4" />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-6 space-y-7 bg-background">
        {/* Header Skeleton */}
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>

        {/* Optional Page-specific skeletons */}
        {children ? (
          <div>{children}</div>
        ) : (
          <div className="space-y-4">
            <Skeleton className="h-6 w-1/2" />
            <Skeleton className="h-48 w-full rounded-xl" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Skeleton className="h-32 w-full rounded-xl" />
              <Skeleton className="h-32 w-full rounded-xl" />
              <Skeleton className="h-32 w-full rounded-xl" />
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default DashboardLoader;
