'use client';

import { cn } from '@/lib/utils';
import { ReactNode } from 'react';
import DashboardLoader from './dashboard-loader';

interface IMinimalVariant {
  variant: 'minimal';
  message?: string;
  className?: string;
}

interface IOtherVariant {
  variant: 'inline' | 'screen';
  title?: string;
  message?: string;
  className?: string;
}

interface IDashboardVariant {
  variant: 'dashboard';
  children?: ReactNode;
}

type IProps = IMinimalVariant | IOtherVariant | IDashboardVariant;

const Loader = (props: IProps) => {
  const defaultMessage = 'Please wait while we prepare everything for you.';
  const isMinimal = props.variant === 'minimal';
  const isInline = props.variant === 'inline';
  const isScreen = props.variant === 'screen';
  const isDashboard = props.variant === 'dashboard';

  if (isDashboard) {
    return <DashboardLoader>{props?.children}</DashboardLoader>;
  }

  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        'fixed flex items-center justify-center p-3 sm:p-6 z-[200]',
        {
          'w-full h-full bg-muted': isInline,
          'fixed top-0 left-0 z-[200] min-h-screen min-w-screen w-full bg-muted':
            isScreen,
          'w-full h-full bg-transparent': isMinimal,
        },
        props.className
      )}
    >
      {isMinimal ? (
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
            <svg
              className="w-6 h-6 text-primary animate-spin"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8v8H4z"
              ></path>
            </svg>
          </div>
          <p className="text-muted-foreground text-sm sm:text-base">
            {props.message || defaultMessage}
          </p>
        </div>
      ) : (
        <div className="bg-background rounded-2xl shadow-xl p-5 sm:p-7 md:p-8 max-w-md w-full text-center space-y-4 animate-pulse">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
            <svg
              className="w-8 h-8 text-primary animate-spin"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8v8H4z"
              ></path>
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-foreground">
            {props.title || 'Loading...'}
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base">
            {props.message || defaultMessage}
          </p>
        </div>
      )}
    </div>
  );
};

export default Loader;
