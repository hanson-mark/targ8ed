import { Skeleton } from '@/components/ui/skeleton';

const DataTableLoader = () => {
  return (
    <div className="space-y-7">
      {/* Top Controls: Search & Buttons */}
      <div className="flex justify-between items-center">
        {/* Search Box */}
        <Skeleton className="h-10 w-64" />

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
      </div>

      {/* Table Skeleton */}
      <div className="space-y-3 border rounded-md p-4">
        {/* Table Header */}
        <div className="grid grid-cols-4 gap-4">
          <Skeleton className="h-7 w-full col-span-1" />
          <Skeleton className="h-7 w-full col-span-1" />
          <Skeleton className="h-7 w-full col-span-1" />
          <Skeleton className="h-7 w-full col-span-1" />
        </div>

        {/* Table Rows */}
        {[...Array(6)].map((_, idx) => (
          <div key={idx} className="grid grid-cols-4 gap-4">
            <Skeleton className="h-9 w-full col-span-1" />
            <Skeleton className="h-9 w-full col-span-1" />
            <Skeleton className="h-9 w-full col-span-1" />
            <Skeleton className="h-9 w-full col-span-1" />
          </div>
        ))}
      </div>

      {/* Pagination Skeleton */}
      <div className="flex items-center justify-between mt-4">
        <Skeleton className="h-8 w-24" />
        <div className="flex gap-2">
          <Skeleton className="h-8 w-8 rounded-md" />
          <Skeleton className="h-8 w-8 rounded-md" />
          <Skeleton className="h-8 w-8 rounded-md" />
        </div>
        <Skeleton className="h-8 w-24" />
      </div>
    </div>
  );
};

export default DataTableLoader;
