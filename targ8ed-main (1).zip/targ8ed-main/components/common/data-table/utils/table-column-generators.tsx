import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import {
  ITableActionDropdownColumnConfig,
  ITableCheckboxSelectColumnConfig,
  ITableSortableTextColumnConfig,
} from '@/types/data-table';
import { ColumnDef } from '@tanstack/react-table';
import {
  ChevronDownIcon,
  ChevronsUpDownIcon,
  ChevronUpIcon,
} from 'lucide-react';
import { DataTableActionDropdown } from '..';

export const getCheckboxSelectColumnConfig = <T extends object>({
  columnId,
  onAllCheckedChange,
  onRowCheckedChange,
}: ITableCheckboxSelectColumnConfig): ColumnDef<T> => {
  return {
    id: columnId,
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && 'indeterminate')
        }
        onCheckedChange={(value) => {
          table.toggleAllPageRowsSelected(!!value);

          if (onAllCheckedChange) {
            onAllCheckedChange(value);
          }
        }}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => {
          row.toggleSelected(!!value);

          if (onRowCheckedChange) {
            onRowCheckedChange(value);
          }
        }}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  };
};

export const getSortableTextColumnConfig = <T extends object>({
  accessorKey,
  headerTitle,
  enableSorting = false,
  enableHiding = false,
  formatter,
  casing = 'none',
}: ITableSortableTextColumnConfig<T>): ColumnDef<T> => {
  return {
    accessorKey: accessorKey as string,
    ...(enableHiding ? { enableHiding } : {}),
    ...(enableSorting ? { enableSorting } : {}),
    ...(!enableSorting
      ? {
          header: () => {
            return <div className="px-1">{headerTitle}</div>;
          },
        }
      : {
          header: ({ column }) => {
            const isSorted = column.getIsSorted();
            return (
              <Button
                variant="ghost"
                onClick={() => column.toggleSorting(isSorted === 'asc')}
              >
                {headerTitle}
                {isSorted === 'asc' ? (
                  <ChevronUpIcon />
                ) : isSorted === 'desc' ? (
                  <ChevronDownIcon />
                ) : (
                  <ChevronsUpDownIcon className="opacity-50" />
                )}
              </Button>
            );
          },
        }),
    cell: ({ row }) => {
      const value = row.getValue(accessorKey as string);

      const casingClass =
        casing === 'capitalize' || casing === 'lowercase' ? casing : '';
      return (
        <div className={cn('px-1', casingClass)}>
          {typeof formatter == 'function'
            ? formatter(value, row)
            : (value || '')?.toString()}
        </div>
      );
    },
  };
};

export const getActionDropdownColumnConfig = <T extends object>({
  headerTitle,
  menuItems,
}: ITableActionDropdownColumnConfig<T>): ColumnDef<T> => {
  return {
    id: 'actions',
    ...(headerTitle ? { header: headerTitle } : {}),
    enableHiding: false,
    cell: ({ row }) => {
      const rowData = row.original;

      return <DataTableActionDropdown items={menuItems(rowData) || []} />;
    },
  };
};
