'use client';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import {
  IDataTableActionDropdownProps,
  IDataTableColumnsProps,
  IDataTableConvexPaginationOldProps,
  IDataTablePaginationProps,
  IDataTableProps,
  IDataTableSearchableInputProps,
  ISimpleDataTableProps,
} from '@/types/data-table';
import { flexRender } from '@tanstack/react-table';
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronsLeftIcon,
  ChevronsRightIcon,
  ListFilterIcon,
  MoreHorizontalIcon,
} from 'lucide-react';
import Link from 'next/link';
import { Dispatch, SetStateAction } from 'react';
import LucideIcon from '../lucide-icon/lucide-icon';

export const DataTableSearchableInput = <T,>({
  table,
  filterableColumn,
}: IDataTableSearchableInputProps<T>) => {
  return (
    filterableColumn && (
      <Input
        placeholder={`Search ${String(filterableColumn)}...`}
        value={
          (table
            .getColumn(filterableColumn as string)
            ?.getFilterValue() as string) ?? ''
        }
        onChange={(event) =>
          table
            .getColumn(filterableColumn as string)
            ?.setFilterValue(event.target.value)
        }
        className="w-52"
      />
    )
  );
};

export const DataTableColumnsSelector = <T,>({
  table,
}: IDataTableColumnsProps<T>) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline">
          <ListFilterIcon /> Columns
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {table
          .getAllColumns()
          .filter((column: { getCanHide: () => boolean }) =>
            column.getCanHide()
          )
          .map(
            (column: {
              id: string;
              getIsVisible: () => boolean;
              toggleVisibility: (value: boolean) => void;
            }) => (
              <DropdownMenuCheckboxItem
                key={column.id}
                className="capitalize"
                checked={column.getIsVisible()}
                onCheckedChange={(value) => column.toggleVisibility(!!value)}
              >
                {column.id}
              </DropdownMenuCheckboxItem>
            )
          )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export const DataTable = <T,>({ table, columns }: IDataTableProps<T>) => {
  return (
    <div className="rounded border">
      <Table>
        <TableHeader>
          {table.getHeaderGroups().map((headerGroup) => (
            <TableRow key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <TableHead key={header.id} className="font-semibold">
                  {header.isPlaceholder
                    ? null
                    : flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )}
                </TableHead>
              ))}
            </TableRow>
          ))}
        </TableHeader>
        <TableBody>
          {table.getRowModel().rows.length ? (
            table.getRowModel().rows.map((row) => (
              <TableRow
                key={row.id}
                data-state={row.getIsSelected() && 'selected'}
              >
                {row.getVisibleCells().map((cell) => (
                  <TableCell key={cell.id}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={columns.length} className="h-24 text-center">
                No results found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export const DataTablePagination = <T,>({
  table,
}: IDataTablePaginationProps<T>) => {
  return (
    <div className="flex items-center justify-between space-x-4 py-4">
      <div className="text-sm text-muted-foreground">
        {table.getFilteredSelectedRowModel().rows.length} of{' '}
        {table.getFilteredRowModel().rows.length} row(s) selected.
      </div>

      <div className="flex items-center gap-x-6">
        {/* Rows per page dropdown */}
        <div className="flex items-center space-x-2">
          <span className="text-sm">Rows per page:</span>
          <Select
            value={String(table.getState().pagination.pageSize)}
            onValueChange={(value) => table.setPageSize(Number(value))}
          >
            <SelectTrigger className="!h-8 min-w-[65px] cursor-pointer">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[5, 10, 20, 50, 100].map((size) => (
                <SelectItem key={size} value={String(size)}>
                  {size}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Pagination Controls */}
        <div className="flex gap-2 items-center">
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.setPageIndex(0)}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronsLeftIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
          >
            <ChevronLeftIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
          >
            <ChevronRightIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
            disabled={!table.getCanNextPage()}
          >
            <ChevronsRightIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export const DataTableConvexPagination = ({
  table,
  handleNextPage,
  handlePrevPage,
  handleFirstPage,
  limit,
  handleLimitChange,
  isLastPage,
  hasPrevPage,
}: IDataTableConvexPaginationOldProps) => {
  return (
    <div className="flex items-center justify-between space-x-4 py-4">
      <div className="text-sm text-muted-foreground">
        {table.getFilteredSelectedRowModel().rows.length} of{' '}
        {table.getFilteredRowModel().rows.length} row(s) selected.
      </div>

      <div className="flex items-center space-x-2">
        <span className="text-sm">Rows per page:</span>
        <Select
          value={String(limit)}
          onValueChange={(value) => handleLimitChange(Number(value))}
        >
          <SelectTrigger className="!h-8 min-w-[65px] cursor-pointer">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {[5, 10, 20, 50, 100].map((size) => (
              <SelectItem key={size} value={String(size)}>
                {size}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={handleFirstPage}
          disabled={!hasPrevPage}
        >
          <ChevronsLeftIcon className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevPage}
          disabled={!hasPrevPage}
        >
          <ChevronLeftIcon className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleNextPage}
          disabled={isLastPage}
        >
          <ChevronRightIcon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export const DataTableActionDropdown = ({
  items,
}: IDataTableActionDropdownProps) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-8 w-8 p-0">
          <span className="sr-only">Open menu</span>
          <MoreHorizontalIcon />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="p-2 min-w-36 space-y-1">
        {!items || items?.length < 1 ? (
          <DropdownMenuItem disabled>No menu items available</DropdownMenuItem>
        ) : (
          items?.map((item) =>
            item?.type === 'link' ? (
              <DropdownMenuItem key={item?.id} asChild>
                <Link
                  href={item?.href}
                  rel={
                    item.target === '_blank' ? 'noopener noreferrer' : undefined
                  }
                  target={item.target}
                >
                  <LucideIcon name={item?.icon || 'SquareMenuIcon'} />{' '}
                  {item?.label}
                </Link>
              </DropdownMenuItem>
            ) : item?.type === 'button' ? (
              <DropdownMenuItem
                key={item?.id}
                onClick={() =>
                  item?.onClick
                    ? setTimeout(() => item?.onClick(), 100)
                    : undefined
                }
              >
                <LucideIcon name={item?.icon || 'SquareMenuIcon'} />{' '}
                {item?.label}
              </DropdownMenuItem>
            ) : item?.type === 'component' && item?.renderer ? (
              <DropdownMenuItem key={item?.id} asChild>
                {item?.renderer()}
              </DropdownMenuItem>
            ) : item?.type === 'separator' ? (
              <DropdownMenuSeparator key={item?.id} />
            ) : null
          )
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export function SimpleDataTable<T>({
  data,
  columns,
  keyField,
  emptyMessage = 'No results found.',
  className,
}: ISimpleDataTableProps<T>) {
  return (
    <div className={`rounded border ${className ?? ''}`}>
      <Table>
        <TableHeader>
          <TableRow>
            {columns.map((col, i) => (
              <TableHead key={i} className={cn(`py-3`, col.className)}>
                {col.header}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data?.length ? (
            data.map((row) => (
              <TableRow key={String(row[keyField])}>
                {columns.map((col, i) => (
                  <TableCell key={i}>{col.cell(row)}</TableCell>
                ))}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={columns.length} className="h-24 text-center">
                {emptyMessage}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}

export const SimpleDataTableColumnsSelector = ({
  allColumns,
  activeColumns,
  setActiveColumns,
}: {
  allColumns: string[];
  activeColumns: string[];
  setActiveColumns: Dispatch<SetStateAction<string[]>>;
}) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline">
          <ListFilterIcon /> Columns
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {allColumns.map((column) => (
          <DropdownMenuCheckboxItem
            key={column}
            className="capitalize"
            checked={activeColumns?.includes(column)}
            onCheckedChange={() =>
              setActiveColumns((prev) =>
                prev?.includes(column)
                  ? prev?.filter((item) => item !== column)
                  : [...prev, column]
              )
            }
          >
            {column}
          </DropdownMenuCheckboxItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
