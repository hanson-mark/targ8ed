'use client';

import { Input } from '@/components/ui/input';
import { debounce } from 'lodash';
import {
  Dispatch,
  SetStateAction,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

interface IProps {
  disabled?: boolean;
  className?: string;
  placeholder?: string;
  debounceDelay?: number;
  setDebouncedSearch: Dispatch<SetStateAction<string>>;
}

const DebouncedSearchInput = ({
  disabled,
  className = '',
  placeholder = 'Search...',
  debounceDelay = 600,
  setDebouncedSearch,
}: IProps) => {
  const [inputValue, setInputValue] = useState('');

  const onChange = useCallback(
    (value: string) => {
      setDebouncedSearch(value);
    },
    [setDebouncedSearch]
  );

  const debouncedChangeHandler = useMemo(
    () =>
      debounce((value: string) => {
        onChange(value.trim().toLowerCase());
      }, debounceDelay),
    [onChange, debounceDelay]
  );

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const value = e.target.value;
      setInputValue(value);
      debouncedChangeHandler(value);
    },
    [debouncedChangeHandler]
  );

  const clearInput = () => {
    setInputValue('');
    debouncedChangeHandler('');
  };

  // Cancel debounce on unmount
  useEffect(() => {
    return () => {
      debouncedChangeHandler.cancel();
    };
  }, [debouncedChangeHandler]);

  return (
    <div className={`relative ${className}`}>
      <Input
        disabled={disabled}
        type="text"
        placeholder={placeholder}
        value={inputValue}
        onChange={handleChange}
        className="w-full pr-10 text-sm"
      />
      {inputValue && (
        <button
          type="button"
          onClick={clearInput}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition cursor-pointer"
        >
          &#10005;
        </button>
      )}
    </div>
  );
};

export default DebouncedSearchInput;
