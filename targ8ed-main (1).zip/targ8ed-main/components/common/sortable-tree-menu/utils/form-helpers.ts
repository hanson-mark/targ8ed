import { Doc, Id } from '@/convex/_generated/dataModel';
import { ISidebarTreeItemType } from '@/convex/types/convex-types';
import { addTreeItemZodSchema } from '@/convex/validations/common';
import { ITreeItem } from '@/types/sortable-tree-menu';
import { z } from 'zod';

export const getFormattedTreeItemFormData = (props: {
  applicationModules: Doc<'applicationModules'>[];
  isUpdate: boolean;
  type: ISidebarTreeItemType;
  defaultValues?: ITreeItem;
}): z.infer<typeof addTreeItemZodSchema> => {
  const { applicationModules, isUpdate, type, defaultValues } = props;
  const moduleMap = new Map(applicationModules.map((mod) => [mod._id, mod]));

  // If updating existing item
  if (isUpdate && defaultValues) {
    const { type: itemType, label, icon, collapsed } = defaultValues;
    const resolvedModuleId =
      'moduleId' in defaultValues
        ? moduleMap.get(defaultValues?.moduleId as Id<'applicationModules'>)
            ?._id || ''
        : '';

    switch (itemType) {
      case 'link':
        return { type: itemType, label, icon, moduleId: resolvedModuleId };
      case 'split-button':
        return {
          type: itemType,
          label,
          icon,
          moduleId: resolvedModuleId,
          expanded: !(collapsed || false),
        };
      case 'separator':
        return { type: itemType };

      default:
        return { type: itemType, label, icon };
    }
  }

  // If creating a new item
  const itemType = isUpdate ? defaultValues?.type : type;

  if (itemType === 'group' || itemType === 'separator') {
    return { type: itemType, label: '' };
  }

  return {
    type: itemType as Exclude<ISidebarTreeItemType, 'group' | 'separator'>,
    label: '',
    icon: '',
    moduleId: '',
    ...(itemType === 'split-button' ? { expanded: true } : {}),
  };
};
