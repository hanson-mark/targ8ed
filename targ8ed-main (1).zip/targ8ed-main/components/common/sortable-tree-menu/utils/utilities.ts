import type { Modifier, UniqueIdentifier } from '@dnd-kit/core';
import { arrayMove } from '@dnd-kit/sortable';

import { IConvexTreeLinkItem } from '@/convex/types/convex-types';
import type { IFlattenedItem, ITreeItem } from '@/types/sortable-tree-menu';

export const iOS = /iPad|iPhone|iPod/.test(navigator.platform);

function getDragDepth(offset: number, indentationWidth: number) {
  return Math.round(offset / indentationWidth);
}

export function getProjection(
  items: IFlattenedItem[],
  activeId: UniqueIdentifier,
  overId: UniqueIdentifier,
  dragOffset: number,
  indentationWidth: number
) {
  const overItemIndex = items.findIndex(({ id }) => id === overId);
  const activeItemIndex = items.findIndex(({ id }) => id === activeId);
  const activeItem = items[activeItemIndex];
  const newItems = arrayMove(items, activeItemIndex, overItemIndex);
  const previousItem = newItems[overItemIndex - 1];
  const nextItem = newItems[overItemIndex + 1];
  const dragDepth = getDragDepth(dragOffset, indentationWidth);
  const projectedDepth = activeItem.depth + dragDepth;
  const maxDepth = getMaxDepth({
    previousItem,
  });
  const minDepth = getMinDepth({ nextItem });
  let depth = projectedDepth;

  if (projectedDepth >= maxDepth) {
    depth = maxDepth;
  } else if (projectedDepth < minDepth) {
    depth = minDepth;
  }

  return { depth, maxDepth, minDepth, parentId: getParentId() };

  function getParentId() {
    if (depth === 0 || !previousItem) {
      return null;
    }

    if (depth === previousItem.depth) {
      return previousItem.parentId;
    }

    if (depth > previousItem.depth) {
      return previousItem.id;
    }

    const newParent = newItems
      .slice(0, overItemIndex)
      .reverse()
      .find((item) => item.depth === depth)?.parentId;

    return newParent ?? null;
  }
}

function getMaxDepth({ previousItem }: { previousItem: IFlattenedItem }) {
  if (previousItem) {
    return previousItem.depth + 1;
  }

  return 0;
}

function getMinDepth({ nextItem }: { nextItem: IFlattenedItem }) {
  if (nextItem) {
    return nextItem.depth;
  }

  return 0;
}

function flatten(
  items: ITreeItem[],
  parentId: UniqueIdentifier | null = null,
  depth = 0
): IFlattenedItem[] {
  return items.reduce<IFlattenedItem[]>((acc, item, index) => {
    return [
      ...acc,
      { ...item, parentId, depth, index },
      ...flatten(item.children as ITreeItem[], item.id, depth + 1),
    ];
  }, []);
}

export function flattenTree(items: ITreeItem[]): IFlattenedItem[] {
  return flatten(items);
}

export function buildTree(flattenedItems: IFlattenedItem[]): ITreeItem[] {
  const root: ITreeItem = {
    id: 'root',
    type: 'group',
    label: 'Root',
    icon: 'MenuSquareIcon',
    children: [],
  };
  const nodes: Record<string, ITreeItem> = { [root.id]: root };
  const items = flattenedItems.map((item) => ({ ...item, children: [] }));

  for (const item of items) {
    const { id, children, ...res } = item;
    const parentId = item.parentId ?? root.id;
    const parent = nodes[parentId] ?? findItem(items, parentId);

    nodes[id] = { id, children, ...(res ?? {}) };
    parent.children.push(item as IConvexTreeLinkItem);
  }

  return root.children as ITreeItem[];
}

export function findItem(items: ITreeItem[], itemId: UniqueIdentifier) {
  return items.find(({ id }) => id === itemId);
}

export function findItemDeep(
  items: ITreeItem[],
  itemId: UniqueIdentifier
): ITreeItem | undefined {
  for (const item of items) {
    const { id, children } = item;

    if (id === itemId) {
      return item;
    }

    if (children.length) {
      const child = findItemDeep(children as ITreeItem[], itemId);

      if (child) {
        return child;
      }
    }
  }

  return undefined;
}

export function removeItem(items: ITreeItem[], id: UniqueIdentifier) {
  const newItems = [];

  for (const item of items) {
    if (item.id === id) {
      continue;
    }

    if (item.children.length) {
      item.children = removeItem(
        item.children as ITreeItem[],
        id
      ) as IConvexTreeLinkItem[];
    }

    newItems.push(item);
  }

  return newItems;
}

export function setProperty<T extends keyof ITreeItem>(
  items: ITreeItem[],
  id: UniqueIdentifier,
  property: T,
  setter: (value: ITreeItem[T]) => ITreeItem[T]
): ITreeItem[] {
  const finalItems = items.map((item) => {
    if (item.id === id) {
      return { ...item, [property]: setter(item[property]) };
    }

    return {
      ...item,
      children: item.children.length
        ? setProperty(item.children as ITreeItem[], id, property, setter)
        : [],
    };
  });
  return finalItems as ITreeItem[];
}

function countChildren(items: ITreeItem[], count = 0): number {
  return items.reduce((acc, { children }) => {
    if (children.length) {
      return countChildren(children as ITreeItem[], acc + 1);
    }

    return acc + 1;
  }, count);
}

export function getChildCount(items: ITreeItem[], id: UniqueIdentifier) {
  const item = findItemDeep(items, id);

  return item ? countChildren(item.children as ITreeItem[]) : 0;
}

export function removeChildrenOf(
  items: IFlattenedItem[],
  ids: UniqueIdentifier[]
) {
  const excludeParentIds = [...ids];

  return items.filter((item) => {
    if (item.parentId && excludeParentIds.includes(item.parentId)) {
      if (item.children.length) {
        excludeParentIds.push(item.id);
      }
      return false;
    }

    return true;
  });
}

export const adjustTranslate: Modifier = ({ transform }) => {
  return {
    ...transform,
    y: transform.y - 25,
  };
};

export const handleAddTreeItem = (
  parentId: UniqueIdentifier,
  newItem: ITreeItem,
  items: ITreeItem[]
) => {
  if (parentId === 'root') {
    return [...(items || []), newItem];
  }
  const updatedTree = setProperty(items, parentId, 'children', (children) => [
    ...children,
    newItem as IConvexTreeLinkItem,
  ]);

  return updatedTree;
};

export const handleUpdateTreeItem = (
  itemId: UniqueIdentifier,
  updatedItem: Partial<ITreeItem>,
  items: ITreeItem[]
): ITreeItem[] => {
  // Update the item properties in the tree
  const updatedTree = items.map((item) => {
    // If the item id matches, merge the updated properties
    if (item.id === itemId) {
      return { ...item, ...updatedItem, id: itemId };
    }

    // If item has children, recursively update
    if (item.children.length > 0) {
      return {
        ...item,
        children: handleUpdateTreeItem(
          itemId,
          updatedItem,
          item.children as ITreeItem[]
        ),
      };
    }

    return item;
  });

  return updatedTree as ITreeItem[];
};
