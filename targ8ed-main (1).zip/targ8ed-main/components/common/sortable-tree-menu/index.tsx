import { Doc } from '@/convex/_generated/dataModel';
import { IApplication } from '@/convex/types/convex-types';
import { cn } from '@/lib/utils';
import { ITreeItem } from '@/types/sortable-tree-menu';
import { cloneDeep } from 'lodash';
import { PenIcon } from 'lucide-react';
import { useState } from 'react';
import ButtonWithTooltip from '../button-with-tooltip';
import UpdateSidebarDialog from './elements/dialogs/update-sidebar-dialog';
import PreviewSidebar from './elements/preview-sidebar';
import { ISortableTreeProps } from './elements/sortable-tree';

export interface ISortableTreeMenuProps
  extends Omit<ISortableTreeProps, 'items' | 'setItems' | 'onAddItem'> {
  title: string;
  subtitle?: string;
  initialItems: ITreeItem[];
  applicationData?: IApplication;
  applicationModules?: Doc<'applicationModules'>[];
  hasUpdateSidebarAccess?: boolean;
  onSave: (items: ITreeItem[], onSuccess?: () => void) => void;
}

const SortableTreeMenu = ({
  initialItems,
  onSave,
  title,
  subtitle,
  applicationData,
  applicationModules,
  hasUpdateSidebarAccess,
  ...props
}: ISortableTreeMenuProps) => {
  const [isUpdating, setIsUpdating] = useState(false);

  return (
    <div className={'w-80'}>
      <div className="mb-3 space-y-1">
        <div className="flex justify-between items-center">
          <h1 className="text-lg font-medium">{title}</h1>
          {hasUpdateSidebarAccess && (
            <div className="flex gap-2 items-center">
              <ButtonWithTooltip
                disabled={props?.disabled}
                variant={'default'}
                size={'sm'}
                className="h-9 "
                tooltipContent={'Update the sidebar'}
                onClick={() => setIsUpdating((prev) => !prev)}
              >
                <PenIcon /> Update{' '}
              </ButtonWithTooltip>
            </div>
          )}
        </div>
        {subtitle ? (
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      <div
        className={cn(
          'min-h-96 overflow-y-auto w-full mb-10 p-2 scrollbar-thin scrollbar-thumb-muted-foreground'
        )}
      >
        <PreviewSidebar
          sidebarItems={(applicationData?.sidebar || []) as ITreeItem[]}
          applicationData={applicationData}
        />
      </div>

      <UpdateSidebarDialog
        {...{
          isOpen: isUpdating,
          setIsOpen: setIsUpdating,
          onSave,
          title,
          subtitle,
          applicationData,
          applicationModules,
          initialItems: cloneDeep(initialItems || applicationData?.sidebar),
          ...props,
        }}
      />
    </div>
  );
};

export default SortableTreeMenu;
