const NoTreeItems = () => {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-gray-500">
      <p className="mb-4 text-sm">No menu item created yet.</p>
    </div>
  );
};

export default NoTreeItems;
