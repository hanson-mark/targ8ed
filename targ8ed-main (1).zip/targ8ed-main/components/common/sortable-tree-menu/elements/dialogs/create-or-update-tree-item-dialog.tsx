'use client';

import CustomDialog from '@/components/common/custom-dialog';
import FormDropdown from '@/components/form/form-dropdown';
import FormInput from '@/components/form/form-input';
import FormLucideIconPicker from '@/components/form/form-lucide-icon-picker';
import FormSwitch from '@/components/form/form-switch';
import FormToggleButtons from '@/components/form/form-toggle-buttons';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { treeItemTypes } from '@/convex/constants/common';
import { ISidebarTreeItemType } from '@/convex/types/convex-types';
import { addTreeItemZodSchema } from '@/convex/validations/common';
import useZodForm from '@/hooks/use-zod-form';
import { ILucideIconName } from '@/types/dashboard-layout';
import { ITreeItem } from '@/types/sortable-tree-menu';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { getFormattedTreeItemFormData } from '../../utils/form-helpers';

interface ICommonProps {
  isOpen: boolean;
  applicationId: Id<'applications'>;
  type: ISidebarTreeItemType;
  hrefPrefix?: string;
  applicationModules: Doc<'applicationModules'>[];
  onOpenChange: Dispatch<SetStateAction<boolean>>;
  onFormSubmit: (values: ITreeItem, type: ISidebarTreeItemType) => void;
}

interface ICreateProps extends ICommonProps {
  isUpdate: false;
}
interface IUpdateProps extends ICommonProps {
  isUpdate: true;
  defaultValues: ITreeItem;
}

const CreateOrUpdateTreeItemDialog = (props: ICreateProps | IUpdateProps) => {
  // Destructuring
  const { isOpen, isUpdate, onFormSubmit, onOpenChange } = props;
  const defaultValues = (props as IUpdateProps)?.defaultValues;

  type ITreeItemFormValues = z.infer<typeof addTreeItemZodSchema>;

  const formMethods = useZodForm(addTreeItemZodSchema, {
    defaultValues: {
      type: 'group',
      label: '',
      icon: undefined,
      moduleId: '',
    },
  });

  const itemType = formMethods.watch('type');
  const isGroup = itemType === 'group';

  const handleOpenChange = (state: boolean) => {
    formMethods.reset();
    onOpenChange(state);
  };

  const onSubmit = (values: ITreeItemFormValues) => {
    const newItem = {
      id: isUpdate && defaultValues?.id ? defaultValues.id : uuidv4(),
      type: values?.type,
      label: values.label,
      icon: values.icon as ILucideIconName,
      ...('moduleId' in values &&
      (values?.type === 'link' || values?.type === 'split-button')
        ? { moduleId: values.moduleId as Id<'applicationModules'> }
        : {}),
      ...(values?.type === 'split-button'
        ? { collapsed: !(values?.expanded || false) }
        : {}),
      children: isUpdate ? defaultValues?.children || [] : [],
    };

    onFormSubmit(newItem as ITreeItem, values?.type);
    handleOpenChange(false);
  };

  useEffect(() => {
    if (isOpen) {
      formMethods.reset(
        getFormattedTreeItemFormData({
          applicationModules: props?.applicationModules || [],
          isUpdate,
          type: props?.type,
          defaultValues,
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, isUpdate, defaultValues, props?.applicationModules, props?.type]);

  return (
    <CustomDialog
      isOpen={isOpen}
      onOpenChange={handleOpenChange}
      title={
        itemType === 'separator'
          ? isUpdate
            ? 'Update Separator'
            : 'Add Separator'
          : isUpdate
            ? `Update ${isGroup ? 'Group' : 'Menu Item'}`
            : `Add ${isGroup ? 'Group' : 'Menu Item'}`
      }
      description={
        itemType === 'separator'
          ? 'A separator visually separates groups of items in the menu. No icon or label is required.'
          : isUpdate
            ? `Update details for the selected menu ${(isGroup ? 'Group' : 'Item')?.toLowerCase()}.`
            : `Enter details to add a new menu ${(isGroup ? 'Group' : 'Item')?.toLowerCase()}.`
      }
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-4 pb-6 ">
            {itemType === 'separator' && (
              <div className="rounded-xl border bg-muted/40 px-4 py-5 shadow-sm">
                <div className="space-y-3 text-center">
                  <p className="text-sm text-muted-foreground">
                    A separator helps visually divide sidebar sections.
                  </p>

                  <div className="relative">
                    <div className="absolute left-0 right-0 top-1/2 transform -translate-y-1/2">
                      <div className="mx-auto w-2/3 border-t border-muted-foreground" />
                    </div>
                    <p className="text-xs text-muted-foreground bg-muted px-2 inline-block relative z-10">
                      Preview
                    </p>
                  </div>

                  <p className="text-xs text-muted-foreground">
                    No label, icon, or link is needed.
                  </p>
                </div>
              </div>
            )}

            {/* Only show toggle buttons when not updating and not a separator */}
            {itemType !== 'group' && itemType !== 'separator' && (
              <FormToggleButtons
                name="type"
                label="Choose Menu Item Type"
                classNames={{
                  button: 'capitalize h-8',
                  group:
                    'max-w-[230px] flex flex-wrap gap-1.5 justify-between items-center border rounded-md px-1.5 py-1',
                }}
                options={treeItemTypes
                  ?.filter((item) => item !== 'group' && item !== 'separator')
                  ?.map((item) => ({
                    label: item,
                    value: item,
                  }))}
                onClick={(option) => {
                  const isSeparator = option?.value === 'separator';
                  if (isSeparator) {
                    formMethods.setValue('label', '');
                  }

                  const isSplitButton = option?.value === 'split-button';
                  if (isSplitButton) {
                    formMethods.setValue('expanded', true);
                  }
                }}
              />
            )}

            {/* Only show icon input when applicable */}
            {itemType && itemType !== 'separator' && itemType !== 'group' && (
              <FormLucideIconPicker
                name="icon"
                label="Icon"
                placeholder="Select an icon"
              />
            )}

            {/* Label only for non-separator */}
            {itemType !== 'separator' && (
              <FormInput
                name="label"
                label="Label"
                placeholder={'Enter label'}
              />
            )}

            {/* Module, only for link or split-button */}
            {itemType === 'link' || itemType === 'split-button' ? (
              <FormDropdown
                name="moduleId"
                label="Module (Link)"
                options={(props?.applicationModules || [])?.map((item) => ({
                  value: item?._id,
                  label: `${item?.name} - "${item?.link}"`,
                }))}
              />
            ) : null}

            {/* expanded only for split-button */}
            {itemType === 'split-button' ? (
              <FormSwitch
                name="expanded"
                label="Expanded"
                labels={{
                  checked: 'Expanded',
                  unchecked: 'Collapsed',
                }}
                description={
                  <span className="">
                    Expanded by default — use the toggle to make it collapsed
                    initially if preferred.
                  </span>
                }
              />
            ) : null}
          </div>
          <DialogFooter>
            <Button type="submit">
              {itemType === 'separator'
                ? isUpdate
                  ? 'Update Separator'
                  : 'Add Separator'
                : isGroup
                  ? isUpdate
                    ? 'Update Group'
                    : 'Add Group'
                  : isUpdate
                    ? 'Update Menu Item'
                    : 'Add Menu Item'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateOrUpdateTreeItemDialog;
