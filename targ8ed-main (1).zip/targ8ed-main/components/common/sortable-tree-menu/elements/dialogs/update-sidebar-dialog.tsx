import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import CustomDialog from '@/components/common/custom-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { ISidebarTreeItemType } from '@/convex/types/convex-types';
import { cn } from '@/lib/utils';
import { ITreeItem } from '@/types/sortable-tree-menu';
import { UniqueIdentifier } from '@dnd-kit/core';
import { EyeIcon, PenIcon, PlusIcon, SaveIcon } from 'lucide-react';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ISortableTreeMenuProps } from '../..';
import { handleAddTreeItem, handleUpdateTreeItem } from '../../utils/utilities';
import PreviewSidebar from '../preview-sidebar';
import SortableTree from '../sortable-tree';
import CreateOrUpdateTreeItemDialog from './create-or-update-tree-item-dialog';
import PreviewSidebarInDialog from './preview-sidebar-in-dialog';

interface IProps extends ISortableTreeMenuProps {
  isOpen: boolean;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
}

const UpdateSidebarDialog = ({
  isOpen,
  setIsOpen,

  title,
  subtitle,
  applicationData,
  initialItems,
  onSave,
  applicationModules,
  ...props
}: IProps) => {
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [showDialog, setShowDialog] = useState(false);

  const [items, setItems] = useState<ITreeItem[]>([]);
  const [itemType, setItemType] = useState<ISidebarTreeItemType | undefined>();

  const [selectedParentId, setSelectedParentId] =
    useState<UniqueIdentifier | null>(null);
  const [selectedUpdateItem, setSelectedUpdateItem] =
    useState<ITreeItem | null>(null);

  const onCloseDialog = () => {
    setIsOpen(false);

    setIsPreviewing(false);
    setShowDialog(false);

    setItems([]);
    setItemType(undefined);

    setSelectedParentId(null);
    setSelectedUpdateItem(null);
  };

  const handleAdd = (
    values: ITreeItem,
    type: ISidebarTreeItemType,
    modulesMap: Map<Id<'applicationModules'>, Doc<'applicationModules'>>
  ) => {
    const commonItems = {
      id: uuidv4(),
      type,
      label: values.label,
      children: [],
    };
    const newItem =
      type === 'group' || type === 'separator'
        ? commonItems
        : type === 'submenu'
          ? { ...commonItems, icon: values.icon || 'PlusIcon' }
          : {
              ...commonItems,
              icon: values.icon || 'PlusIcon',
              ...('moduleId' in values &&
              (values?.type === 'link' || values?.type === 'split-button')
                ? {
                    moduleId: values.moduleId,
                    module: modulesMap.get(
                      values.moduleId as Id<'applicationModules'>
                    ),
                  }
                : {}),
            };

    if (selectedParentId) {
      const updatedItems = handleAddTreeItem(
        selectedParentId,
        newItem as ITreeItem,
        items
      );

      setItems(updatedItems);
    }
  };

  const handleUpdate = (
    updatedItem: ITreeItem,
    modulesMap: Map<Id<'applicationModules'>, Doc<'applicationModules'>>
  ) => {
    const preparedItem = {
      ...updatedItem,
      ...('moduleId' in updatedItem &&
      (updatedItem?.type === 'link' || updatedItem?.type === 'split-button')
        ? {
            moduleId: updatedItem.moduleId,
            module: modulesMap.get(
              updatedItem.moduleId as Id<'applicationModules'>
            ),
          }
        : {}),
    };

    if (selectedUpdateItem?.id) {
      const updatedItems = handleUpdateTreeItem(
        selectedUpdateItem.id,
        preparedItem,
        items
      );

      setItems(updatedItems);
    }
  };

  const handleCreateOrUpdateItemFormSubmit = (
    item: ITreeItem,
    type: ISidebarTreeItemType
  ) => {
    const modulesMap = new Map(
      (applicationModules || []).map((module) => [module._id, module])
    );
    if (selectedUpdateItem) {
      handleUpdate(item, modulesMap);
    } else {
      handleAdd(item, type, modulesMap);
    }
    setShowDialog(false);
    setSelectedUpdateItem(null);
    setSelectedParentId(null);
  };

  useEffect(() => {
    if (isOpen) {
      setItems(() => initialItems);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  return (
    <CustomDialog
      isOpen={isOpen}
      onOpenChange={onCloseDialog}
      title={'Update Sidebar Menu'}
      description={`Update sidebar menu`}
      classNames={{
        content: 'p-6',
      }}
    >
      <div className="mb-3 space-y-1">
        <div className="w-full flex flex-wrap gap-2 justify-between items-center">
          <div className="flex items-center gap-1 text-lg font-medium">
            {title}
            {isPreviewing ? (
              <span className="">
                <Badge className="text-xs py-[1px] px-1.5 rounded-full">
                  Previewing
                </Badge>
              </span>
            ) : (
              ''
            )}
          </div>
          <div className="flex gap-2 items-center">
            {!isPreviewing && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button disabled={props?.disabled}>
                    <PlusIcon /> Add Item
                  </Button>
                </DropdownMenuTrigger>

                <DropdownMenuContent
                  align="start"
                  className="max-h-60 overflow-y-auto"
                >
                  {(['group', 'submenu', 'separator'] as const).map((key) => (
                    <DropdownMenuItem
                      key={key}
                      onSelect={() => {
                        setItemType(key);
                        setSelectedParentId('root');
                        setSelectedUpdateItem(null);
                        setShowDialog(true);
                      }}
                      className="cursor-pointer capitalize text-sm"
                    >
                      <PlusIcon /> Add {key === 'submenu' ? 'Menu Item' : key}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
        {subtitle ? (
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      <ScrollArea type="always" className="max-h-[calc(100vh-300px)]">
        <div
          className={cn(
            'min-h-96 overflow-y-auto w-full p-2 pr-3 scrollbar-thin scrollbar-thumb-muted-foreground',
            isPreviewing
              ? 'w-64 2xs:w-80 mx-auto'
              : ' bg-sidebar border border-border/70'
          )}
        >
          {isPreviewing ? (
            <PreviewSidebar
              sidebarItems={items}
              applicationData={applicationData}
            />
          ) : (
            <>
              <SortableTree
                {...props}
                items={items}
                setItems={setItems}
                onAddItem={(parent) => {
                  setSelectedParentId(parent?.id);
                  setSelectedUpdateItem(null);
                  setShowDialog(true);
                  setItemType(parent?.type === 'group' ? 'submenu' : 'link');
                }}
                onUpdateItem={(item) => {
                  setSelectedUpdateItem(item);
                  setSelectedParentId(null);
                  setShowDialog(true);
                }}
              />

              <CreateOrUpdateTreeItemDialog
                applicationModules={applicationModules || []}
                hrefPrefix={props?.hrefPrefix}
                applicationId={applicationData?._id as Id<'applications'>}
                type={itemType!}
                isOpen={showDialog}
                onOpenChange={(open) => {
                  if (!open) {
                    setSelectedParentId(null);
                    setSelectedUpdateItem(null);
                  }
                  setShowDialog(open);
                }}
                onFormSubmit={handleCreateOrUpdateItemFormSubmit}
                isUpdate={!!selectedUpdateItem}
                defaultValues={selectedUpdateItem!}
              />
            </>
          )}
        </div>
      </ScrollArea>

      <div className="flex gap-2 justify-end items-center">
        <ButtonWithTooltip
          disabled={props?.disabled}
          variant={'outline'}
          size={'sm'}
          className="h-9 "
          tooltipContent={
            isPreviewing ? 'Update the sidebar' : 'Preview the sidebar'
          }
          onClick={() => setIsPreviewing((prev) => !prev)}
        >
          {isPreviewing ? (
            <>
              <PenIcon /> Update{' '}
            </>
          ) : (
            <>
              <EyeIcon /> Preview{' '}
            </>
          )}
        </ButtonWithTooltip>
        {onSave && (
          <ButtonWithTooltip
            disabled={props?.disabled}
            variant={'default'}
            size={'sm'}
            className="h-9 "
            tooltipContent="Update the sidebar"
            onClick={onSave ? () => onSave(items, onCloseDialog) : undefined}
          >
            <SaveIcon /> Update Sidebar
          </ButtonWithTooltip>
        )}
      </div>
      <PreviewSidebarInDialog
        isOpen={isPreviewing}
        setIsOpen={setIsPreviewing}
        applicationData={applicationData!}
        initialItems={items}
      />
    </CustomDialog>
  );
};

export default UpdateSidebarDialog;
