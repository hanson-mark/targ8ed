import CustomDialog from '@/components/common/custom-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { IApplication } from '@/convex/types/convex-types';
import { cn } from '@/lib/utils';
import { ITreeItem } from '@/types/sortable-tree-menu';
import { ArrowLeftIcon } from 'lucide-react';
import { Dispatch, SetStateAction } from 'react';
import PreviewSidebar from '../preview-sidebar';

interface IProps {
  isOpen: boolean;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  applicationData: IApplication;
  initialItems: ITreeItem[];
}

const PreviewSidebarInDialog = ({
  isOpen,
  setIsOpen,

  applicationData,
  initialItems,
}: IProps) => {
  const onClose = () => {
    setIsOpen(false);
  };

  return (
    <CustomDialog
      isOpen={isOpen}
      onOpenChange={onClose}
      title={
        <>
          Previewing Sidebar{' '}
          <Badge className="text-xs rounded-full"> Draft</Badge>
        </>
      }
      classNames={{
        content: 'p-6',
      }}
    >
      <ScrollArea type="always" className="max-h-[calc(100vh-250px)]">
        <div
          className={cn(
            'min-h-96 overflow-y-auto p-2 pr-3 scrollbar-thin scrollbar-thumb-muted-foreground w-64 2xs:w-80 mx-auto'
          )}
        >
          <PreviewSidebar
            sidebarItems={initialItems}
            applicationData={applicationData}
          />
        </div>
      </ScrollArea>

      <div className="flex gap-2 justify-end items-center">
        <Button onClick={onClose}>
          <ArrowLeftIcon /> Back to update
        </Button>
      </div>
    </CustomDialog>
  );
};

export default PreviewSidebarInDialog;
