import SelectedHeaderItem from '@/components/layouts/dashboard-layout/elements/app-sidebar-header/selected-header-item';
import { AppSidebarMenu } from '@/components/layouts/dashboard-layout/elements/app-sidebar-menu';
import { IApplication, IUserApplication } from '@/convex/types/convex-types';
import {
  generateApplicationSidebar,
  userApplicationToSwitcherItem,
} from '@/lib/data-formatters/sidebar-formatter';
import { ITreeItem } from '@/types/sortable-tree-menu';

interface IProps {
  sidebarItems: ITreeItem[];
  applicationData?: IApplication;
}

const PreviewSidebar = ({ sidebarItems, applicationData }: IProps) => {
  const applicationSidebarData = generateApplicationSidebar(
    (sidebarItems || []) as ITreeItem[]
  );

  return (
    <div className="w-full bg-sidebar border border-border/70 min-h-screen px-2 py-3">
      <SelectedHeaderItem
        selectedItem={userApplicationToSwitcherItem(
          applicationData as IUserApplication
        )}
        totalItemsCount={0}
        hideSwitcherIcon={true}
        className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground cursor-pointer focus-visible:ring-0 mb-1"
      />
      <AppSidebarMenu isPreview groupedMenu={applicationSidebarData} />
    </div>
  );
};

export default PreviewSidebar;
