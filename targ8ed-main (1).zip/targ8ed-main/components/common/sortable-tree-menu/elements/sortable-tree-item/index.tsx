import type { UniqueIdentifier } from '@dnd-kit/core';
import { AnimateLayoutChanges, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { CSSProperties } from 'react';

import { IOnAddTreeItem } from '@/types/sortable-tree-menu';
import { iOS } from '../../utils/utilities';
import { TreeItem, ITreeItemProps as TreeItemProps } from './tree-item';

interface IProps extends TreeItemProps {
  id: UniqueIdentifier;
  hrefPrefix?: string;
  disabled?: boolean;
  onAddItem: IOnAddTreeItem;
}

const animateLayoutChanges: AnimateLayoutChanges = ({
  isSorting,
  wasDragging,
}) => (isSorting || wasDragging ? false : true);

function SortableTreeItem({ id, depth, disabled, ...props }: IProps) {
  const isDisabled = disabled;

  const {
    attributes,
    isDragging,
    isSorting,
    listeners,
    setDraggableNodeRef,
    setDroppableNodeRef,
    transform,
    transition,
  } = useSortable({
    id,
    disabled: isDisabled,
    animateLayoutChanges,
  });
  const style: CSSProperties = {
    opacity: isDisabled ? 0.5 : 1,
    cursor: isDisabled ? 'not-allowed' : undefined,
    transform: CSS.Translate.toString(transform),
    transition,
  };
  return (
    <TreeItem
      ref={setDraggableNodeRef}
      wrapperRef={setDroppableNodeRef}
      style={style}
      depth={depth}
      ghost={isDragging}
      disableSelection={iOS}
      disableInteraction={isSorting || isDisabled}
      handleProps={
        isDisabled
          ? undefined // 👈 no drag handle
          : {
              ...attributes,
              ...listeners,
            }
      }
      {...props}
    />
  );
}
export default SortableTreeItem;
