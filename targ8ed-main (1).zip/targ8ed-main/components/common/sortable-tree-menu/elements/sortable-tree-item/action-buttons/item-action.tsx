import { cn } from '@/lib/utils';
import React, {
  CSSProperties,
  forwardRef,
  isValidElement,
  ReactElement,
} from 'react';

export interface Props extends React.HTMLAttributes<HTMLButtonElement> {
  cursor?: CSSProperties['cursor'];
}

const ItemAction = forwardRef<HTMLButtonElement, Props>(
  ({ className, cursor, style, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        {...props}
        tabIndex={0}
        className={cn(
          'flex w-[12px] px-[10px] py-[10px] items-center justify-center shrink-0',
          'touch-none cursor-pointer appearance-none outline-none',
          'rounded-[5px] bg-transparent tap-highlight-transparent',
          'hover:bg-[rgba(0,0,0,0.05)]',
          'active:bg-[rgba(0,0,0,0.05)]',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[--dnd-focused-outline-color] focus-visible:ring-offset-0',
          className
        )}
        style={
          {
            ...style,
            cursor,
          } as CSSProperties
        }
      >
        {React.Children.map(children, (child) => {
          if (isValidElement(child) && child.type === 'svg') {
            const svg = child as ReactElement<{ className?: string }>;
            return React.cloneElement(svg, {
              className: cn(
                'flex-shrink-0 m-auto h-full overflow-visible',
                svg.props?.className
              ),
            });
          }
          return child;
        })}
      </button>
    );
  }
);

ItemAction.displayName = 'ItemAction';
export default ItemAction;
