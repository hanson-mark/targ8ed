import ItemAction, { Props as ActionProps } from './item-action';

function AddItem(props: ActionProps) {
  return (
    <ItemAction {...props} className="flex justify-center items-center">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="15"
        height="15"
        viewBox="0 0 24 24"
        stroke="currentColor"
        className="lucide lucide-plus-icon lucide-plus text-muted-foreground"
        fill="none"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M5 12h14" />
        <path d="M12 5v14" />
      </svg>
    </ItemAction>
  );
}
export default AddItem;
