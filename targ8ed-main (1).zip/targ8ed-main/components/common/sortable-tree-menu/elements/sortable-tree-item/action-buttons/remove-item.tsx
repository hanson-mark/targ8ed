import ItemAction, { Props as ActionProps } from './item-action';

function RemoveItem(props: ActionProps) {
  return (
    <ItemAction {...props}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="14"
        height="14"
        viewBox="0 0 24 24"
        stroke="currentColor"
        fill="none"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="lucide lucide-x-icon lucide-x text-muted-foreground"
      >
        <path d="M18 6 6 18" />
        <path d="m6 6 12 12" />
      </svg>
    </ItemAction>
  );
}
export default RemoveItem;
