import React, { forwardRef, HTMLAttributes } from 'react';

import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import { cn } from '@/lib/utils';
import { IOnAddTreeItem, ITreeItem } from '@/types/sortable-tree-menu';
import AddItem from './action-buttons/add-item';
import CollapseItem from './action-buttons/collapse-item';
import RemoveItem from './action-buttons/remove-item';
import UpdateItem from './action-buttons/update-item';
import styles from './treeitem.module.css';

export interface ITreeItemProps
  extends Omit<HTMLAttributes<HTMLLIElement>, 'id'> {
  hrefPrefix?: string;
  childCount?: number;
  clone?: boolean;
  collapsed?: boolean;
  depth: number;
  disableInteraction?: boolean;
  disableSelection?: boolean;
  ghost?: boolean;
  handleProps?: React.HTMLAttributes<HTMLButtonElement>;
  indicator?: boolean;
  indentationWidth: number;
  item: ITreeItem;
  onCollapse?(): void;
  onRemove?(): void;
  onUpdateItem?(value: ITreeItem): void;
  onAddItem: IOnAddTreeItem;
  wrapperRef?(node: HTMLLIElement): void;
}

export const TreeItem = forwardRef<HTMLDivElement, ITreeItemProps>(
  (
    {
      childCount,
      clone,
      depth,
      disableSelection,
      disableInteraction,
      ghost,
      handleProps,
      indicator,
      collapsed,
      indentationWidth,
      onCollapse,
      onRemove,
      onAddItem,
      onUpdateItem,
      style,
      item,
      wrapperRef,
      hrefPrefix,
      ...props
    },
    ref
  ) => {
    const finalHrefPrefix = hrefPrefix || '';
    return (
      <li
        className={cn(
          styles.Wrapper,
          clone && styles.clone,
          ghost && styles.ghost,
          indicator && styles.indicator,
          disableSelection && styles.disableSelection,
          disableInteraction && styles.disableInteraction
        )}
        ref={wrapperRef}
        style={
          {
            '--spacing': `${indentationWidth * depth}px`,
          } as React.CSSProperties
        }
        {...props}
      >
        <div
          className={cn(
            styles.TreeItem,
            'relative flex items-center justify-between gap-[8px] rounded-md border bg-background px-[12px] !py-[6px] text-foreground transition-colors',
            ghost && indicator && 'bg-primary/50 border-primary',
            ghost && indicator && 'before:bg-primary before:border-primary',
            'hover:bg-accent hover:text-accent-foreground'
          )}
          ref={ref}
          style={style}
        >
          {/* Left section: Icon + Label + Collapse */}
          <div className="flex items-center gap-[8px] flex-1 overflow-hidden min-h-[40px]">
            <span
              {...handleProps}
              className="flex items-center gap-[8px] overflow-hidden"
            >
              {item?.type !== 'group' && item?.icon && (
                <LucideIcon
                  name={item?.icon}
                  className="w-[16px] h-[16px] self-start mt-[4px] shrink-0 text-muted-foreground cursor-grab active:cursor-grabbing"
                />
              )}
              <span className="grid">
                <span
                  className={cn(
                    styles.Text,
                    'truncate text-sm font-medium cursor-grab active:cursor-grabbing'
                  )}
                >
                  {item?.type === 'separator' ? 'Separator' : item?.label}
                </span>

                {item?.type === 'link' || item?.type === 'split-button' ? (
                  <span className="flex gap-[4px] text-[10px]">
                    <span className="capitalize text-muted-foreground font-bold shrink-0">
                      {item?.type}:
                    </span>{' '}
                    <span className=" text-muted-foreground/90 break-all">
                      {finalHrefPrefix +
                        ('module' in item ? item?.module?.link : '')}
                    </span>
                  </span>
                ) : (
                  <div className="text-[10px] capitalize font-bold text-muted-foreground">
                    {/* <span className="px-[6px] py-[2px] rounded-full bg-primary text-background">
                      {item?.type}
                    </span> */}{' '}
                    {item?.type}
                  </div>
                )}
              </span>
            </span>
            {onCollapse && item?.type !== 'group' && (
              <CollapseItem
                onCollapse={onCollapse}
                className={cn(
                  'self-start text-muted-foreground',
                  styles.Collapse,
                  collapsed && styles.collapsed
                )}
              />
            )}
            <span {...handleProps} className="flex-1 min-h-[40] cursor-grab" />
          </div>

          {/* Right section: Remove, Add, Handle */}
          <div className="flex items-center gap-[2px] shrink-0">
            {item?.type !== 'separator' && (
              <>
                {onAddItem && <AddItem onClick={() => onAddItem(item)} />}
                {onUpdateItem && (
                  <UpdateItem onClick={() => onUpdateItem(item)} />
                )}
              </>
            )}
            {!clone && onRemove && <RemoveItem onClick={onRemove} />}
          </div>

          {/* Clone badge */}
          {clone && childCount && childCount > 1 && (
            <span
              className={cn(
                styles.Count,
                'absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs font-medium text-primary-foreground'
              )}
            >
              {childCount}
            </span>
          )}
        </div>
      </li>
    );
  }
);

TreeItem.displayName = 'TreeItem';
