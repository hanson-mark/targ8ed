import { cn } from '@/lib/utils';
import { AppWindowIcon, BuildingIcon, UserIcon } from 'lucide-react';
import Image from 'next/image';

interface IProps {
  imageURL: string;
  iconSize: 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 14;
  iconType?: 'application' | 'organization' | 'user';
}

const ProfileImage = ({ imageURL, iconSize, iconType }: IProps) => {
  const icons = {
    application: AppWindowIcon,
    organization: BuildingIcon,
    user: UserIcon,
  };
  const Icon = iconType ? icons?.[iconType] || icons?.user : icons?.user;
  return (
    <div
      className={cn(
        'relative shrink-0 w-8 h-8 rounded-full border flex justify-center items-center overflow-hidden',
        {
          'w-5 h-5': iconSize === 5,
          'w-6 h-6': iconSize === 6,
          'w-7 h-7': iconSize === 7,
          'w-8 h-8': iconSize === 8,
          'w-9 h-9': iconSize === 9,
          'w-10 h-10': iconSize === 10,
          'w-11 h-11': iconSize === 11,
          'w-12 h-12': iconSize === 12,
          'w-14 h-14': iconSize === 14,
        }
      )}
    >
      {imageURL ? (
        <Image
          fill
          src={imageURL}
          className="object-cover"
          alt={iconType || '' + ' image'}
        />
      ) : (
        <Icon
          className={cn({
            'w-3 h-3': iconSize === 5,
            'w-4 h-4': iconSize === 6,
            'w-5 h-5': iconSize === 7,
            'w-6 h-6': iconSize === 8,
            'w-7 h-7': iconSize === 9,
            'w-8 h-8': iconSize === 10,
            'w-9 h-9': iconSize === 11,
            'w-10 h-10': iconSize === 12,
            'w-12 h-12': iconSize === 14,
          })}
        />
      )}
    </div>
  );
};

export default ProfileImage;
