import { cn } from '@/lib/utils';
import { Badge } from '../ui/badge';

interface IProps {
  status: string;
}

const StatusBadge = ({ status }: IProps) => {
  const successStatuses = ['active', 'enabled', 'accepted'];
  const errorStatuses = ['inactive', 'disabled', 'expired'];

  const finalStatus = status?.toLowerCase();

  return (
    <Badge
      className={cn(
        'rounded-full text-[10px] uppercase',
        successStatuses.includes(finalStatus)
          ? 'bg-green-600'
          : errorStatuses.includes(finalStatus)
            ? 'bg-red-500'
            : 'bg-yellow-600'
      )}
    >
      {status as string}
    </Badge>
  );
};

export default StatusBadge;
