'use client';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { ILucideIconName } from '@/types/dashboard-layout';
import { debounce } from 'lodash';
import { CheckIcon, MoreHorizontal } from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useEffect, useRef, useState } from 'react';
import LucideIcon from './lucide-icon/lucide-icon';

interface ITabItem {
  label: string;
  value: string;
  icon?: ILucideIconName;
  disabled?: boolean;
  content: React.ReactNode;
}

interface ICustomTabsProps {
  defaultValue: string;
  onTabChange?: (value: string) => void;
  tabItems: ITabItem[];
  classNames?: {
    content?: string;
  };
}

const CustomTabs = ({
  defaultValue,
  onTabChange,
  tabItems,
  classNames,
}: ICustomTabsProps) => {
  // Available tab keys
  const tabKeys = tabItems?.map((item) => item?.value);

  // Getting validated active tab key
  const getValidatedTab = useCallback(
    (activeTabFromQuery: string) => {
      const validatedCurrentTab = tabKeys.includes(activeTabFromQuery)
        ? activeTabFromQuery
        : tabKeys.includes(defaultValue)
          ? defaultValue
          : tabItems?.[0]?.value;
      return validatedCurrentTab;
    },
    [tabKeys, defaultValue, tabItems]
  );

  // router & search params hook
  const router = useRouter();
  const searchParams = useSearchParams();
  const currentTabFromQuery = searchParams.get('tab') || defaultValue;
  const [activeTab, setActiveTab] = useState(
    getValidatedTab(currentTabFromQuery)
  );

  const [visibleCount, setVisibleCount] = useState(tabItems.length);
  const containerRef = useRef<HTMLUListElement>(null);
  const tabRefs = useRef<(HTMLLIElement | null)[]>([]);

  const handleTabClick = (value: string, disabled?: boolean) => {
    if (disabled) return;
    setActiveTab(value);

    const params = new URLSearchParams(Array.from(searchParams.entries()));
    params.set('tab', value);
    router.replace(`?${params.toString()}`);

    onTabChange?.(value);
  };

  const updateVisibleTabs = useCallback(() => {
    if (!containerRef.current) return;

    const containerWidth = containerRef.current.offsetWidth;
    const moreButtonWidth = 100;

    let usedWidth = 0;
    let count = 0;

    for (let i = 0; i < tabItems.length; i++) {
      const tabEl = tabRefs.current[i];
      if (!tabEl) continue;

      const width = tabEl.offsetWidth;

      if (usedWidth + width + moreButtonWidth > containerWidth) break;

      usedWidth += width;
      count++;
    }

    setVisibleCount(count);
  }, [tabItems]);

  const triggerUpdate = useCallback(() => {
    requestAnimationFrame(() => {
      updateVisibleTabs();
    });
  }, [updateVisibleTabs]);

  useEffect(() => {
    const handleResize = () => triggerUpdate();
    const debouncedResize = debounce(handleResize, 100); // 100ms debounce
    window.addEventListener('resize', debouncedResize);
    return () => window.removeEventListener('resize', debouncedResize);
  }, [triggerUpdate]);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver(triggerUpdate);
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [triggerUpdate]);

  useEffect(() => {
    const currentTabFromQuery = searchParams.get('tab') || defaultValue;
    const validatedTab = getValidatedTab(currentTabFromQuery);

    if (activeTab !== validatedTab) {
      setActiveTab(validatedTab);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [defaultValue, searchParams]);

  const visibleTabs = tabItems.slice(0, visibleCount);
  const overflowTabs = tabItems.slice(visibleCount);

  return (
    <div>
      {/* Tab Header */}
      <div className="text-sm font-medium text-center text-foreground border-b border-border">
        <ul ref={containerRef} className="flex -mb-px overflow-hidden relative">
          {
            // ! [DO_NOT_UPDATE - START ] Hidden full tabs for measurement
          }
          <div className="absolute top-0 left-0 opacity-0 pointer-events-none -z-10 flex">
            {tabItems.map((tab, index) => (
              <li
                key={tab.value}
                ref={(el) => {
                  if (el) {
                    tabRefs.current[index] = el;
                  }
                }}
                className="me-2 whitespace-nowrap"
              >
                <button
                  type="button"
                  className="inline-flex p-3 pb-2.5 border-b-2 rounded-t-lg items-center gap-1.5"
                >
                  {tab.icon && (
                    <LucideIcon name={tab.icon} className="w-5 h-5" />
                  )}
                  {tab.label}
                </button>
              </li>
            ))}
          </div>
          {
            // ! [DO_NOT_UPDATE - END ] Hidden full tabs for measurement
          }

          {/* Visible Tabs */}
          {visibleTabs.map((tab) => (
            <li key={tab.value} className="me-2 whitespace-nowrap">
              <button
                type="button"
                onClick={() => handleTabClick(tab.value, tab.disabled)}
                disabled={tab.disabled}
                className={cn(
                  'inline-flex gap-1.5 p-3 pb-2.5 border-b-2 rounded-t-lg transition-colors duration-200 cursor-pointer hover:bg-muted/50',
                  tab.disabled
                    ? 'text-gray-400 cursor-not-allowed dark:text-foreground'
                    : activeTab === tab.value
                      ? 'text-primary border-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground '
                )}
              >
                {tab?.icon ? (
                  <LucideIcon name={tab?.icon} className="w-5 h-5" />
                ) : null}{' '}
                {tab.label}
              </button>
            </li>
          ))}

          {/* Dropdown for overflow */}
          {overflowTabs.length > 0 && (
            <li className="me-2 whitespace-nowrap">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    className="inline-block p-3 pb-2.5 border-b-2 border-transparent rounded-t-lg text-muted-foreground hover:text-foreground hover:border-muted cursor-pointer focus-visible:outline-0"
                  >
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {overflowTabs.map((tab) => (
                    <DropdownMenuItem
                      key={tab.value}
                      disabled={tab.disabled}
                      onClick={() => handleTabClick(tab.value, tab.disabled)}
                      className={cn(
                        'flex items-center gap-2',
                        'hover:bg-accent hover:text-accent-foreground',
                        {
                          'text-primary hover:text-primary':
                            tab.value === activeTab,
                        }
                      )}
                    >
                      {tab.icon && (
                        <LucideIcon name={tab.icon} className="w-4 h-4" />
                      )}
                      <span>{tab.label}</span>
                      {tab.value === activeTab && (
                        <CheckIcon className="ml-auto h-4 w-4 text-primary" />
                      )}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </li>
          )}
        </ul>
      </div>

      {/* Tab Content */}
      <div className={cn('mt-4', classNames?.content)}>
        {tabItems.map(
          (tab) =>
            tab.value === activeTab && (
              <div key={tab.value} className="animate-fade-in">
                {tab.content}
              </div>
            )
        )}
      </div>
    </div>
  );
};

export default CustomTabs;
