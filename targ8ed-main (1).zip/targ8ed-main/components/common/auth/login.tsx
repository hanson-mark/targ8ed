import { SignIn } from '@clerk/nextjs';

const LoginWithClerk = () => {
  return (
    <div className="min-h-screen min-w-screen flex justify-center items-center">
      <SignIn />
    </div>
  );
};

export default LoginWithClerk;
