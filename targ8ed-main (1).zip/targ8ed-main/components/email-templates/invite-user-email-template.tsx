import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import {
  Body,
  Container,
  Head,
  Hr,
  Html,
  Link,
  Preview,
  Text,
} from '@react-email/components';
import { CSSProperties } from 'react';

interface InviteEmailProps {
  organizationName: string;
  inviteLink: string;
}

export const InviteUserEmailTemplate = ({
  organizationName,
  inviteLink,
}: InviteEmailProps) => {
  return (
    <Html>
      <Head />
      <Preview>
        You&apos;ve been invited to join {organizationName} on{' '}
        {ROOT_CONFIG.site.name}
      </Preview>
      <Body style={styles.body}>
        <Container style={styles.container}>
          <Text style={styles.heading}>
            🎉 You&apos;re invited to <strong>{organizationName}</strong> on{' '}
            <strong>{ROOT_CONFIG.site.name}</strong>!
          </Text>

          <Text style={styles.text}>
            You&apos;ve been invited to collaborate with{' '}
            <strong>{organizationName}</strong>. Click the button below to
            accept the invitation and complete your account setup.
          </Text>

          <Link href={inviteLink} style={styles.button}>
            Accept Invitation
          </Link>

          <Hr style={styles.hr} />

          <Text style={styles.subtext}>
            Or copy and paste this link into your browser:
            <br />
            <Link href={inviteLink} style={styles.link}>
              {inviteLink}
            </Link>
          </Text>

          <Text style={styles.expiry}>
            ⏳ This invitation will expire in 48 hours.
          </Text>
        </Container>
      </Body>
    </Html>
  );
};

export default InviteUserEmailTemplate;

const styles: { [key: string]: CSSProperties } = {
  body: {
    backgroundColor: '#f9fafb',
    fontFamily: 'Arial, sans-serif',
    padding: '40px 0',
  },
  container: {
    backgroundColor: '#ffffff',
    padding: '30px',
    borderRadius: '8px',
    maxWidth: '600px',
    margin: '0 auto',
    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
  },
  heading: {
    fontSize: '20px',
    marginBottom: '20px',
    color: '#111827',
  },
  text: {
    fontSize: '16px',
    marginBottom: '24px',
    color: '#374151',
    lineHeight: '1.5',
  },
  button: {
    display: 'inline-block',
    padding: '12px 24px',
    backgroundColor: '#4f46e5',
    color: '#ffffff',
    borderRadius: '6px',
    textDecoration: 'none',
    fontWeight: 'bold',
    fontSize: '16px',
  },
  hr: {
    margin: '30px 0',
    border: 'none',
    borderTop: '1px solid #e5e7eb',
  },
  subtext: {
    fontSize: '14px',
    color: '#6b7280',
  },
  link: {
    wordBreak: 'break-all',
    color: '#4f46e5',
    textDecoration: 'underline',
    fontSize: '14px',
  },
  expiry: {
    fontSize: '12px',
    marginTop: '24px',
    color: '#9ca3af',
  },
};
