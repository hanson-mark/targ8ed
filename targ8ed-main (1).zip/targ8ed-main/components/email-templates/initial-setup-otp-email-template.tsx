import { Body, Container, Head, Hr, Html, Text } from '@react-email/components';
import { CSSProperties } from 'react';

interface InitialSetupOTPProps {
  userName: string;
  email: string;
  otp: string;
}

export const InitialSetupOTPTemplate = ({
  userName,
  email,
  otp,
}: InitialSetupOTPProps) => {
  return (
    <Html>
      <Head />
      <Body style={styles.body}>
        <Container style={styles.container}>
          <Text style={styles.heading}>🚀 Initial Setup Verification</Text>

          <Text style={styles.text}>
            Hi <strong>{userName}</strong>, you are creating the first account
            for <strong>{email}</strong>.
          </Text>

          <Text style={styles.otp}>Your verification code (OTP) is:</Text>

          <Text style={styles.otpCode}>{otp}</Text>

          <Hr style={styles.hr} />

          <Text style={styles.subtext}>
            Enter this code in the app to confirm your initial setup and finish
            creating your account.
            <br />
            If you didn’t request this, you can ignore this email.
          </Text>

          <Text style={styles.expiry}>
            ⏳ This OTP will expire in 5 minutes.
          </Text>
        </Container>
      </Body>
    </Html>
  );
};

export default InitialSetupOTPTemplate;

const styles: { [key: string]: CSSProperties } = {
  body: {
    backgroundColor: '#f9fafb',
    fontFamily: 'Arial, sans-serif',
    padding: '40px 0',
  },
  container: {
    backgroundColor: '#ffffff',
    padding: '30px',
    borderRadius: '8px',
    maxWidth: '600px',
    margin: '0 auto',
    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
  },
  heading: {
    fontSize: '20px',
    marginBottom: '20px',
    color: '#111827',
  },
  text: {
    fontSize: '16px',
    marginBottom: '24px',
    color: '#374151',
    lineHeight: '1.5',
  },
  otp: {
    fontSize: '16px',
    marginBottom: '12px',
    color: '#374151',
  },
  otpCode: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#4f46e5',
    marginBottom: '24px',
  },
  hr: {
    margin: '30px 0',
    border: 'none',
    borderTop: '1px solid #e5e7eb',
  },
  subtext: {
    fontSize: '14px',
    color: '#6b7280',
    lineHeight: '1.4',
  },
  expiry: {
    fontSize: '12px',
    marginTop: '24px',
    color: '#9ca3af',
  },
};
