'use client';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { addMetadataCustom } from '@/lib/common';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { defaultMetaData } from '@/lib/default-data/meta-data';
import useSubdomainStore, { ICurrentOrgUser } from '@/stores/subdomainStore';
import { useAuth } from '@clerk/nextjs';
import { Preloaded, usePreloadedQuery } from 'convex/react';
import { isEqual } from 'lodash';
import { ReactNode, useEffect } from 'react';
import Loader from '../common/loaders/loader';
import UnauthorizedWarning from '../common/unauthorized-warning';

interface IProps {
  children: ReactNode;
  subdomain?: string;
  preloadedCurrentUser: Preloaded<
    typeof api.functions.apps.global.users.index.readCurrentUserDetails
  >;
}

const CurrentUserProvider = ({
  children,
  subdomain,
  preloadedCurrentUser,
}: IProps) => {
  // Clerk user
  const { isLoaded, signOut, userId } = useAuth();

  // Fetching current user data from convex
  const currentUserResponse = usePreloadedQuery(preloadedCurrentUser);
  const currentUser =
    currentUserResponse?.success == true
      ? currentUserResponse?.data
      : undefined;

  // Zustand store
  const { tempEmail, userConfig, setUserConfig } = useSubdomainStore();

  // Updating zustand store
  useEffect(() => {
    if (currentUser) {
      const storedAt = Date.now();

      const applications = (currentUser?.applications || []).map((item) => ({
        ...item,
        sidebar: item.sidebar || [],
      }));

      const updatedOrgConfig: ICurrentOrgUser = {
        ...currentUser,
        applications,
        storedAt,
      };

      if (!isEqual(userConfig, updatedOrgConfig)) {
        setUserConfig(updatedOrgConfig);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser]);

  useEffect(() => {
    if (userConfig?.organization) {
      const mainTitle =
        userConfig?.organization?.name || defaultMetaData?.title;

      addMetadataCustom(
        userConfig?.organization?.image ||
          getConvexImageURL(
            userConfig?.organization?.imageId as Id<'_storage'>
          ) ||
          '',
        {
          ...defaultMetaData,
          title: mainTitle,
          description:
            userConfig?.organization?.description ||
            defaultMetaData?.description,
        }
      );
    }
  }, [subdomain, userConfig?.organization]);

  if (!isLoaded) {
    return <Loader variant="dashboard" />;
  }

  if (tempEmail) {
    return (
      <Loader
        variant="screen"
        title="Changing email, please wait..."
        message="We’re updating your email address. This might take a few seconds."
      />
    );
  }

  if (!currentUser && userId) {
    return (
      <UnauthorizedWarning
        message={`Invalid link or you do not belong to this organization, or you don't have permission to access this page. Try logging out and using a different account.`}
        buttonText="Logout"
        onButtonClick={() => signOut()}
      />
    );
  }

  if (!currentUser || !userId) {
    return <UnauthorizedWarning />;
  }

  if (currentUser?.organization?.status !== 'active') {
    return (
      <UnauthorizedWarning
        title="Organization is not active"
        message={`The organization you're trying to access is currently not active. Please contact your administrator for more information.`}
      />
    );
  }

  return <div>{children}</div>;
};

export default CurrentUserProvider;
