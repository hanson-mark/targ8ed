import { themeColorsWithDarkLight } from '@/convex/constants/theme';
import { ClerkProvider } from '@clerk/nextjs';
import { NextIntlClientProvider } from 'next-intl';
import { ReactNode } from 'react';
import ConvexClientProvider from './convex-client-provider';
import { ThemeProvider } from './theme-provider';

const RootClientProvider = ({ children }: { children: ReactNode }) => {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="theme-default"
      themes={themeColorsWithDarkLight}
      disableTransitionOnChange
    >
      <NextIntlClientProvider>
        <ClerkProvider>
          <ConvexClientProvider>{children}</ConvexClientProvider>
        </ClerkProvider>
      </NextIntlClientProvider>
    </ThemeProvider>
  );
};

export default RootClientProvider;
