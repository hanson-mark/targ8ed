'use client';

import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { ArrowLeftIcon, MenuIcon, XIcon } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ReactNode, useState } from 'react';
import useThemeConfig from '../dashboard-layout/hooks/use-theme-config';

interface IMenuItem {
  id: string;
  label: string;
  href: string;
}

interface IProps {
  children: ReactNode;
  menuTitle: string;
  subdomainURL: string;
  menuItems: IMenuItem[];
}

const OrgDashboardLayout = ({
  children,
  menuTitle,
  subdomainURL,
  menuItems,
}: IProps) => {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  // Theme configuration
  useThemeConfig();

  return (
    <div className="flex flex-col h-screen px-4 sm:px-6 py-5 space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <Button variant={'ghost'} className="-ml-3" asChild>
            <Link href="/">
              <ArrowLeftIcon /> Exit from {menuTitle}
            </Link>
          </Button>
          <h2 className="text-2xl font-semibold">{menuTitle}</h2>
          <Link
            href="/"
            className="inline-block text-sm text-muted-foreground hover:bg-secondary -ml-1 p-1 rounded"
          >
            {subdomainURL}
          </Link>
        </div>

        {/* Burger Menu Icon on mobile */}
        <button
          className="sm:hidden p-2 rounded hover:bg-muted cursor-pointer"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? (
            <XIcon className="h-5 w-5" />
          ) : (
            <MenuIcon className="h-5 w-5" />
          )}
        </button>
      </div>

      <Separator />

      {/* Main layout */}
      <div className="flex flex-1 gap-3 overflow-hidden">
        {/* Sidebar */}
        <div
          className={cn(
            'fixed inset-y-0 left-0 z-50 w-64 shrink-0 bg-background px-4 py-5 border-r transition-transform transform sm:relative sm:translate-x-0 sm:w-48 sm:p-0 sm:border-none',
            menuOpen ? 'translate-x-0' : '-translate-x-full'
          )}
        >
          <ScrollArea className="h-full">
            <div className="space-y-2">
              {menuItems.map((item) => {
                const isActive = pathname.includes(item?.href);
                return (
                  <Button
                    asChild
                    key={item.id}
                    variant={isActive ? 'secondary' : 'ghost'}
                    className={cn(
                      'w-full justify-start font-medium',
                      isActive && 'text-primary'
                    )}
                    onClick={() => setMenuOpen(false)} // close on click
                  >
                    <Link href={item.href}>{item.label}</Link>
                  </Button>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Overlay for mobile sidebar */}
        {menuOpen && (
          <div
            className="fixed inset-0 z-40 bg-black/30 sm:hidden"
            onClick={() => setMenuOpen(false)}
          />
        )}

        {/* Main content */}
        <div className="flex-1 px-1 pr-2 z-0 overflow-auto">{children}</div>
      </div>
    </div>
  );
};

export default OrgDashboardLayout;
