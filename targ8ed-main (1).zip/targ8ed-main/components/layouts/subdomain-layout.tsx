'use client';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { addMetadataCustom } from '@/lib/common';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { defaultMetaData } from '@/lib/default-data/meta-data';
import { ReactNode, useEffect } from 'react';

interface IProps {
  children: ReactNode;
  organization: Doc<'organizations'>;
}

const SubdomainLayout = ({ children, organization }: IProps) => {
  useEffect(() => {
    addMetadataCustom(
      organization?.image ||
        getConvexImageURL(organization?.imageId as Id<'_storage'>) ||
        '',
      {
        ...defaultMetaData,
        title: organization?.name || defaultMetaData?.title,
        description: organization?.description || defaultMetaData?.description,
      }
    );
  }, [organization]);

  return children;
};

export default SubdomainLayout;
