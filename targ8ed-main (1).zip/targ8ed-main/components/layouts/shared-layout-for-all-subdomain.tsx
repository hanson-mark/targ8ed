import { getAuthToken } from '@/actions/auth/user';
import CurrentUserProvider from '@/components/providers/current-user-provider';
import { api } from '@/convex/_generated/api';
import { getSubDomainInServer } from '@/lib/app-config';
import { auth } from '@clerk/nextjs/server';
import { preloadQuery } from 'convex/nextjs';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const SharedLayoutForAllSubdomains = async ({ children }: IProps) => {
  const currentOrgSubdomain = await getSubDomainInServer();

  const { userId, redirectToSignIn } = await auth();

  // Getting the auth token
  const token = await getAuthToken();
  if (!token || !userId) {
    redirectToSignIn();
    return;
  }

  // Get current user data
  const preloadedCurrentUser = await preloadQuery(
    api.functions.apps.global.users.index.readCurrentUserDetails,
    { currentOrgSubdomain, inputs: {} },
    { token }
  );

  return (
    <CurrentUserProvider
      preloadedCurrentUser={preloadedCurrentUser}
      subdomain={currentOrgSubdomain}
    >
      {children}
    </CurrentUserProvider>
  );
};

export default SharedLayoutForAllSubdomains;
