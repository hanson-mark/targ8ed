'use client';
import { api } from '@/convex/_generated/api';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { Preloaded, usePreloadedQuery } from 'convex/react';
import { ReactNode, useEffect, useMemo } from 'react';
import UnauthorizedWarning from '../common/unauthorized-warning';
import DashboardLayout from './dashboard-layout';
import useThemeConfig from './dashboard-layout/hooks/use-theme-config';

interface IProps {
  children: ReactNode;
  preloadedUserApplication: Preloaded<
    typeof api.functions.apps.global.applications.userApplications.readUserApplicationByKey
  >;
}

const ApplicationDashboardLayout = ({
  children,
  preloadedUserApplication,
}: IProps) => {
  // Preloaded application
  const applicationResult = usePreloadedQuery(preloadedUserApplication);
  const application =
    'data' in applicationResult ? applicationResult?.data : undefined;

  // Store
  const { setRoles } = useUserRolesStore();

  // Roles memorizing
  const userRoles = useMemo(() => application?.roles || [], [application]);

  useEffect(() => {
    if (userRoles) {
      setRoles(userRoles || []);
    }
  }, [userRoles, setRoles]);

  // Subdomain store
  const { userConfig } = useSubdomainStore();

  // Theme configuration
  useThemeConfig();

  if (!applicationResult) {
    return <UnauthorizedWarning />;
  }

  if (!('data' in applicationResult) || !application) {
    return (
      <UnauthorizedWarning
        message={
          applicationResult?.message ||
          "You don't have permission to access this page."
        }
      />
    );
  }

  return (
    <DashboardLayout
      type="subdomain-application"
      userConfig={userConfig}
      application={application}
    >
      {children}
    </DashboardLayout>
  );
};

export default ApplicationDashboardLayout;
