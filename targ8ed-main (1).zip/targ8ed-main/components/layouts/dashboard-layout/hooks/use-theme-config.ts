import {
  themeBorderRadiuses,
  themeBorderRadiusName,
} from '@/convex/constants/theme';
import { IThemeBorderRadius } from '@/convex/types/theme';
import useSubdomainStore from '@/stores/subdomainStore';
import { setCookie } from 'cookies-next/client';
import { useTheme } from 'next-themes';
import { useEffect, useMemo } from 'react';

const useThemeConfig = () => {
  const { theme, setTheme } = useTheme();
  const { userConfig } = useSubdomainStore();

  const orgTheme = useMemo(
    () => ({
      color: userConfig?.organization?.themeColor,
      mode: userConfig?.organization?.themeMode,
      borderRadius: userConfig?.organization?.themeBorderRadius,
    }),
    [userConfig]
  );

  const orgThemeName = useMemo(() => {
    if (!orgTheme.color) return '';
    return orgTheme.mode === 'dark' ? `${orgTheme.color}_dark` : orgTheme.color;
  }, [orgTheme]);
  // Checking and setting theme
  useEffect(() => {
    if (orgThemeName && theme && orgThemeName !== theme) {
      setTheme(orgThemeName);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgThemeName, theme]);

  // Checking border radius class
  useEffect(() => {
    const radius = orgTheme?.borderRadius;
    if (!radius) return;

    const html = document.querySelector('html');
    if (!html) return;

    const currentRadiusClass = [...html.classList].find((cName) =>
      themeBorderRadiuses.includes(cName as IThemeBorderRadius)
    );

    if (currentRadiusClass !== radius) {
      if (currentRadiusClass) html.classList.remove(currentRadiusClass);
      html.classList.add(radius);
    }

    setCookie(themeBorderRadiusName, radius, {
      maxAge: 60 * 60 * 24 * 30, // 30 days in seconds
    });
  }, [orgTheme?.borderRadius]);

  return { themeName: orgThemeName, orgTheme };
};

export default useThemeConfig;
