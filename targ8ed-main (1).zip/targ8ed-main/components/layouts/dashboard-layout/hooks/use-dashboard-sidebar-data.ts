import {
  getSelectedSidebarMenuItem,
  getSidebarData,
} from '@/lib/data-formatters/sidebar-formatter';
import {
  IGlobalLayoutProps,
  IOrgApplicationLayoutProps,
  IOrgLayoutProps,
} from '@/types/dashboard-layout';
import { usePathname } from 'next/navigation';
import { useMemo } from 'react';

type IProps =
  | Omit<IGlobalLayoutProps, 'children'>
  | Omit<IOrgLayoutProps, 'children'>
  | Omit<IOrgApplicationLayoutProps, 'children'>;

const useDashboardSidebarData = (props: IProps) => {
  const pathname = usePathname();

  const sidebarData = useMemo(() => getSidebarData({ ...props }), [props]);

  const selectedHeaderItem = useMemo(() => {
    return sidebarData?.headerSwitcherItems?.find((item) =>
      pathname.startsWith(item.link || '')
    );
  }, [pathname, sidebarData?.headerSwitcherItems]);

  const selectedMenuItem = useMemo(() => {
    return getSelectedSidebarMenuItem(sidebarData?.groupedMenu || [], pathname);
  }, [pathname, sidebarData?.groupedMenu]);

  return {
    sidebarData,
    selectedHeaderItem,
    selectedMenuItem,
  };
};

export default useDashboardSidebarData;
