import { ICurrentOrgUser } from '@/stores/subdomainStore';
import { IDashboardLayoutType } from '@/types/dashboard-layout';
import { useAuth, useUser } from '@clerk/nextjs';

export const useDashboardAccessControl = (
  type: IDashboardLayoutType,
  userConfig: ICurrentOrgUser | null
) => {
  // Stores
  const { signOut } = useAuth();
  const { isSignedIn, isLoaded: isAuthLoaded } = useUser();

  // Checking loader needs to show or not
  const isLoading = !isAuthLoaded;

  //  Warning checks
  const globalUserStatus =
    userConfig && 'globalUser' in userConfig && userConfig?.globalUser?.status;
  const isUserInactive =
    userConfig?.status === 'inactive' || globalUserStatus === 'inactive';

  // Checking organization access

  const hasOrgAccess = !!(
    userConfig &&
    'organization' in userConfig &&
    userConfig.organization
  );

  const hasAnyWarning = !isSignedIn || isUserInactive || !hasOrgAccess;

  // Warning Content
  let warningContent: {
    title: string;
    message: string;
    buttonText?: string;
    onButtonClick?: () => void;
  } | null = null;

  if (isUserInactive) {
    const isGloballyInactive = globalUserStatus === 'inactive';
    warningContent = {
      title: 'Account Inactive',
      message: `Your account has been deactivated ${isGloballyInactive ? 'for all organizations' : 'for this organization'}. Please contact support.`,
    };
  } else if (!hasOrgAccess && userConfig) {
    warningContent = {
      title: 'Organization Access Required',
      message:
        'You do not have access to this organization. Please check your invitation or contact an organization admin. Or, log in to different account',
      buttonText: 'Logout',
      onButtonClick: () => signOut(),
    };
  } else if (!userConfig) {
    warningContent = {
      title: 'Access denied',
      message: 'You do not have access to this page or feature',
    };
  }

  return {
    isLoading,
    hasAnyWarning,
    warningContent,
  };
};
