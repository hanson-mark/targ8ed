import { useContext } from 'react';
import { DashboardLayoutContext } from '..';

const useDashboardLayoutContext = () => {
  const contextData = useContext(DashboardLayoutContext);
  return contextData!;
};

export default useDashboardLayoutContext;
