'use client';
import { AppSidebar } from '@/components/layouts/dashboard-layout/elements/app-sidebar';

import NotFound from '@/app/not-found';
import { Separator } from '@/components/ui/separator';
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import {
  IDashboardLayoutContext,
  IGlobalLayoutProps,
  IOrgApplicationLayoutProps,
  IOrgLayoutProps,
} from '@/types/dashboard-layout';
import { createContext } from 'react';
import Loader from '../../common/loaders/loader';
import UnauthorizedWarning from '../../common/unauthorized-warning';
import AppBreadcrumb from './elements/app-breadcrumb';
import { useDashboardAccessControl } from './hooks/use-dashboard-access-control';
import useDashboardSidebarData from './hooks/use-dashboard-sidebar-data';
import useThemeConfig from './hooks/use-theme-config';

// Context
export const DashboardLayoutContext = createContext<
  IDashboardLayoutContext | undefined
>(undefined);

// Component
type IProps = IGlobalLayoutProps | IOrgLayoutProps | IOrgApplicationLayoutProps;
const DashboardLayout = (props: IProps) => {
  const { children, userConfig, type } = props;

  // Theme configuration
  useThemeConfig();

  // Access control
  const { isLoading, hasAnyWarning, warningContent } =
    useDashboardAccessControl(type, userConfig);

  // Generating sidebar
  const { sidebarData, selectedHeaderItem, selectedMenuItem } =
    useDashboardSidebarData(props);

  if (isLoading) {
    return <Loader variant="dashboard" />;
  }

  if (!sidebarData) {
    return <NotFound />;
  }

  if (hasAnyWarning) {
    return <UnauthorizedWarning {...warningContent} />;
  }

  return (
    <DashboardLayoutContext.Provider
      value={{
        ...sidebarData,
        selectedHeaderItem,
        selectedMenuItem,
      }}
    >
      <SidebarProvider>
        <AppSidebar userConfig={props?.userConfig} />
        <SidebarInset>
          <header className="sticky top-0 flex shrink-0 items-center gap-2 border-b bg-background p-4 z-50">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <AppBreadcrumb />
          </header>
          <div className="flex flex-1 flex-col gap-4 p-4">{children}</div>
        </SidebarInset>
      </SidebarProvider>
    </DashboardLayoutContext.Provider>
  );
};

export default DashboardLayout;
