'use client';
import { AppSidebarUser } from '@/components/layouts/dashboard-layout/elements/app-sidebar-user';
import { Sidebar, SidebarFooter } from '@/components/ui/sidebar';
import { ICurrentOrgUser } from '@/stores/subdomainStore';
import * as React from 'react';
import useDashboardLayoutContext from '../hooks/use-dashboard-layout-context';
import AppSidebarHeader from './app-sidebar-header';
import { AppSidebarMenu } from './app-sidebar-menu';

interface IProps extends React.ComponentProps<typeof Sidebar> {
  userConfig: ICurrentOrgUser | null;
}

export function AppSidebar({ userConfig, ...props }: IProps) {
  const { groupedMenu, selectedHeaderItem } = useDashboardLayoutContext();

  return (
    <Sidebar variant="inset" {...props}>
      <AppSidebarHeader />
      <AppSidebarMenu
        homePageURL={selectedHeaderItem?.link || '/'}
        groupedMenu={groupedMenu}
      />
      <SidebarFooter>
        <AppSidebarUser userConfig={userConfig} />
      </SidebarFooter>
    </Sidebar>
  );
}
