import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import { SidebarMenuButton } from '@/components/ui/sidebar';
import { cn } from '@/lib/utils';
import {
  ISidebarHeaderSwitcherItem,
  ISidebarHomePage,
} from '@/types/dashboard-layout';
import { ChevronsUpDownIcon } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import React from 'react';

interface IProps extends React.ComponentPropsWithoutRef<'button'> {
  totalItemsCount: number;
  hideSwitcherIcon?: boolean;
  selectedItem: ISidebarHomePage | ISidebarHeaderSwitcherItem;
}

const SelectedHeaderItem = React.forwardRef<HTMLButtonElement, IProps>(
  (
    { selectedItem, totalItemsCount, className, hideSwitcherIcon, ...rest },
    ref
  ) => {
    const isLink =
      'type' in selectedItem
        ? selectedItem?.type === 'link' && selectedItem?.link
        : selectedItem?.link;

    const content = (
      <>
        <div
          className={cn(
            'relative flex aspect-square size-8 items-center justify-center rounded-lg text-sidebar-primary-foreground',
            !selectedItem?.image ? 'bg-sidebar-primary' : ''
          )}
        >
          {selectedItem?.image ? (
            <Image
              fill
              src={selectedItem?.image}
              className="object-cover"
              alt={selectedItem?.title}
            />
          ) : (
            <LucideIcon name={selectedItem?.icon} className="size-4" />
          )}
        </div>
        <div className="flex flex-col gap-0.5 leading-none">
          <span
            className={cn(
              'font-semibold truncate',
              hideSwitcherIcon
                ? 'max-w-[214px] md:max-w-[164px]'
                : 'max-w-[190px] md:max-w-[144px]'
            )}
          >
            {selectedItem?.title}
          </span>
          <span
            className={cn(
              'text-sm truncate',
              hideSwitcherIcon
                ? 'max-w-[214px] md:max-w-[164px]'
                : 'max-w-[190px] md:max-w-[144px]'
            )}
          >
            {selectedItem?.subtitle}
          </span>
        </div>
        {!hideSwitcherIcon && <ChevronsUpDownIcon className="ml-auto" />}
      </>
    );

    if (isLink && totalItemsCount <= 1) {
      return (
        <SidebarMenuButton asChild size="lg" className={className}>
          <Link href={selectedItem.link || '/'}>{content}</Link>
        </SidebarMenuButton>
      );
    }

    return (
      <SidebarMenuButton size="lg" className={className} ref={ref} {...rest}>
        {content}
      </SidebarMenuButton>
    );
  }
);

SelectedHeaderItem.displayName = 'SelectedHeaderItem';
export default SelectedHeaderItem;
