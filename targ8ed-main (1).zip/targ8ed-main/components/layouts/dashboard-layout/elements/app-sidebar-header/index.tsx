'use client';

import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import { cn } from '@/lib/utils';
import { CheckIcon } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import useDashboardLayoutContext from '../../hooks/use-dashboard-layout-context';
import SelectedHeaderItem from './selected-header-item';

const AppSidebarHeader = () => {
  const { isGlobal, homePage, headerSwitcherItems, selectedHeaderItem } =
    useDashboardLayoutContext();

  const headerItemsLength = (headerSwitcherItems || [])?.length;

  return (
    <SidebarHeader>
      <SidebarMenu>
        <SidebarMenuItem>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <SelectedHeaderItem
                selectedItem={
                  isGlobal ? homePage : selectedHeaderItem || homePage
                }
                totalItemsCount={headerItemsLength || 0}
                hideSwitcherIcon={isGlobal ? true : headerItemsLength === 1}
                className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground cursor-pointer focus-visible:ring-0"
              />
            </DropdownMenuTrigger>

            {headerItemsLength > 0 ? (
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] "
                align="start"
              >
                {/* Applications  */}
                <p className="px-2 text-xs font-medium text-muted-foreground">
                  Applications
                </p>
                {headerSwitcherItems.map((item) => (
                  <DropdownMenuItem
                    asChild
                    key={item.id}
                    // onSelect={() => setSelectedItem(item)}
                    className="cursor-pointer"
                  >
                    <Link
                      href={
                        item?.id === selectedHeaderItem?.id
                          ? '#'
                          : item?.link || '#'
                      }
                    >
                      <div
                        className={cn(
                          'relative flex aspect-square size-8 items-center justify-center rounded-lg overflow-hidden',
                          !item?.image ? 'bg-sidebar-primary' : ''
                        )}
                      >
                        {item?.image ? (
                          <Image
                            fill
                            src={item?.image}
                            className="object-cover"
                            alt={item?.title}
                          />
                        ) : (
                          <LucideIcon
                            name={item?.icon}
                            className="size-4 text-white"
                          />
                        )}
                      </div>
                      <div className="flex flex-col gap-0.5 leading-none">
                        <span
                          className={cn(
                            'font-semibold truncate w-[214px] md:w-[164px]'
                          )}
                        >
                          {item?.title}
                        </span>
                        <span
                          className={cn(
                            'text-sm truncate w-[214px] md:w-[164px]'
                          )}
                        >
                          {item?.subtitle}
                        </span>
                      </div>
                      {item?.id === selectedHeaderItem?.id && (
                        <CheckIcon className="ml-auto" />
                      )}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            ) : null}
          </DropdownMenu>
        </SidebarMenuItem>
      </SidebarMenu>
    </SidebarHeader>
  );
};

export default AppSidebarHeader;
