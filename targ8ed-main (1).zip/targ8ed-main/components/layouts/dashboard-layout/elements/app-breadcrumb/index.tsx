'use client';

import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Fragment } from 'react';
import useDashboardLayoutContext from '../../hooks/use-dashboard-layout-context';

const AppBreadcrumb = () => {
  const pathname = usePathname();

  const { homePage, selectedHeaderItem, groupedMenu } =
    useDashboardLayoutContext();

  if (!homePage) return null;

  const applicationHomePage = {
    title: selectedHeaderItem?.title,
    link: selectedHeaderItem?.link,
  };
  const sidebarMenuItem = groupedMenu
    ?.map((item) =>
      pathname.startsWith(item?.link as string) &&
      applicationHomePage?.link !== item?.link
        ? item
        : null
    )
    ?.filter(Boolean)[0];

  const breadcrumbData = [applicationHomePage, sidebarMenuItem];

  return (
    <Breadcrumb>
      <BreadcrumbList>
        {breadcrumbData?.map((item, index) => {
          const isCurrentPage = index === breadcrumbData?.length - 1;
          const isParentPage = index < breadcrumbData?.length - 1;
          return (
            <Fragment key={index}>
              <BreadcrumbItem className="hidden md:block">
                {isParentPage ? (
                  <BreadcrumbLink asChild>
                    <Link href={item?.link || '#'}>{item?.title}</Link>
                  </BreadcrumbLink>
                ) : isCurrentPage ? (
                  <BreadcrumbPage>{item?.title}</BreadcrumbPage>
                ) : null}
              </BreadcrumbItem>
              {!isCurrentPage && (
                <BreadcrumbSeparator className="hidden md:block" />
              )}
            </Fragment>
          );
        })}
      </BreadcrumbList>
    </Breadcrumb>
  );
};

export default AppBreadcrumb;
