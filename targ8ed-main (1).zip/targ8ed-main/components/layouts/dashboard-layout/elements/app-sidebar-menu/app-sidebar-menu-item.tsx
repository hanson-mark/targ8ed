import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Separator } from '@/components/ui/separator';
import {
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
} from '@/components/ui/sidebar';
import { cn } from '@/lib/utils';
import { ISdebarGroupItem } from '@/types/dashboard-layout';
import Link from 'next/link';

interface IProps {
  item: ISdebarGroupItem;
  isPreview?: boolean;
  pathname: string;
  homePageURL?: string;
  depth: number;
}

const AppSidebarMenuItem = ({
  item,
  pathname,
  homePageURL,
  depth,
  isPreview = false,
}: IProps) => {
  const isActive =
    item?.link != homePageURL
      ? pathname === item?.link ||
        (item?.link && pathname.startsWith(item.link + '/'))
      : pathname === item?.link;
  const hasChildren = item?.items?.length > 0;

  const collapsibleButton = hasChildren && (
    <LucideIcon
      name="ChevronRight"
      className={cn('ml-auto transition-transform duration-200 ', {
        'group-data-[state=open]/collapsible-00:rotate-90': depth === 0,
        'group-data-[state=open]/collapsible-01:rotate-90': depth === 1,
        'group-data-[state=open]/collapsible-02:rotate-90': depth === 2,
        'group-data-[state=open]/collapsible-03:rotate-90': depth === 3,
      })}
    />
  );
  const content = (
    <>
      {item?.icon && <LucideIcon name={item.icon} />}
      <span>{item.title}</span>
      {item?.type !== 'split-button' && collapsibleButton}
    </>
  );

  return (
    <Collapsible
      key={item?.id}
      asChild
      defaultOpen={item?.isOpen || !!isActive}
    >
      <SidebarMenuItem
        className={cn({
          'group/collapsible-00': depth === 0,
          'group/collapsible-01': depth === 1,
          'group/collapsible-02': depth === 2,
          'group/collapsible-03': depth === 3,
        })}
      >
        {item?.type === 'link' || item?.type === 'submenu' ? (
          <CollapsibleTrigger asChild>
            <SidebarMenuButton
              asChild
              tooltip={item?.title}
              isActive={!!isActive}
            >
              {item?.link ? (
                <Link href={isPreview ? '#' : item?.link}>{content}</Link>
              ) : (
                <div className="cursor-pointer">{content}</div>
              )}
            </SidebarMenuButton>
          </CollapsibleTrigger>
        ) : item?.type === 'split-button' ? (
          <SidebarMenuButton
            asChild
            tooltip={item?.title}
            isActive={!!isActive}
            className={cn(
              'hover:bg-transparent data-[state=open]:hover:bg-transparent',
              'hover:text-inherit data-[state=open]:hover:text-inherit'
            )}
          >
            <div className="!p-0 !gap-0">
              <Link
                href={isPreview ? '#' : item?.link || '#'}
                className={cn(
                  'p-2 flex w-full items-center gap-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground overflow-hidden rounded-md text-left outline-hidden [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 text-sm',
                  hasChildren ? 'rounded-r-none hover:rounded-r-md pr-0' : ''
                  // "data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground  "
                )}
              >
                {content}
              </Link>
              <Separator orientation="vertical" />
              {hasChildren && (
                <CollapsibleTrigger className="hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded-md p-2 group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! [&>svg]:size-4 [&>svg]:shrink-0 cursor-pointer">
                  {collapsibleButton}
                </CollapsibleTrigger>
              )}
            </div>
          </SidebarMenuButton>
        ) : item?.type === 'separator' ? (
          <Separator />
        ) : null}

        {hasChildren && (
          <CollapsibleContent>
            <SidebarMenuSub>
              {item.items.map((child) => (
                <AppSidebarMenuItem
                  key={child.id}
                  item={child}
                  pathname={pathname}
                  isPreview={isPreview}
                  depth={depth + 1}
                />
              ))}
            </SidebarMenuSub>
          </CollapsibleContent>
        )}
      </SidebarMenuItem>
    </Collapsible>
  );
};

export default AppSidebarMenuItem;
