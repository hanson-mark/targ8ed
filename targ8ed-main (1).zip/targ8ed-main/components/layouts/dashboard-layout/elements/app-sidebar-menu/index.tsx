'use client';

import {
  SidebarContent,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
} from '@/components/ui/sidebar';
import { ISdebarGroupItem } from '@/types/dashboard-layout';
import { usePathname } from 'next/navigation';
import AppSidebarMenuItem from './app-sidebar-menu-item';

interface IProps {
  isPreview?: boolean;
  homePageURL?: string;
  groupedMenu: ISdebarGroupItem[];
}

export function AppSidebarMenu({
  isPreview,
  homePageURL,
  groupedMenu,
}: IProps) {
  const pathname = usePathname();

  const generateMenu = (groupedItem: ISdebarGroupItem) => {
    if (groupedItem?.type !== 'group') {
      return (
        <SidebarMenu key={`menu-${groupedItem?.id}`}>
          <AppSidebarMenuItem
            key={groupedItem.title}
            isPreview={isPreview}
            item={groupedItem}
            pathname={pathname}
            homePageURL={homePageURL}
            depth={0}
          />
        </SidebarMenu>
      );
    }
    return (
      <SidebarMenu key={`menu-${groupedItem?.id}`}>
        {groupedItem?.items?.map((menuItem) => (
          <AppSidebarMenuItem
            key={menuItem.title}
            item={menuItem}
            pathname={pathname}
            depth={0}
          />
        ))}
      </SidebarMenu>
    );
  };
  return (
    <SidebarContent className="gap-0">
      {groupedMenu?.map((groupedItem) =>
        groupedItem?.type === 'group' ? (
          <SidebarGroup key={groupedItem?.id}>
            {groupedItem?.title && (
              <SidebarGroupLabel>{groupedItem?.title}</SidebarGroupLabel>
            )}
            {generateMenu(groupedItem)}
          </SidebarGroup>
        ) : (
          <SidebarGroup key={groupedItem?.id} className="pt-0 pb-1">
            {generateMenu(groupedItem)}
          </SidebarGroup>
        )
      )}
    </SidebarContent>
  );
}
