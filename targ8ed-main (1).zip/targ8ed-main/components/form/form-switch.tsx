'use client';

import CustomSwitch from '@/components/common/custom-switch'; // adjust the path if needed
import { cn } from '@/lib/utils';
import { get } from 'lodash';
import { ReactNode } from 'react';
import { Controller, useFormContext } from 'react-hook-form';

interface IFormSwitchProps {
  name: string;
  label: string;
  labels?: { checked?: string; unchecked?: string };
  description?: string | ReactNode;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  required?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}

const FormSwitch = ({
  name,
  label,
  labels,
  description,
  className,
  size = 'md',
  disabled,
  required,
  onCheckedChange,
}: IFormSwitchProps) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();
  const errorMessage = get(errors, name)?.message;

  return (
    <Controller
      name={name}
      disabled={disabled}
      control={control}
      render={({ field: { value, onChange, ...fieldProps } }) => (
        <div className={cn('flex flex-col space-y-1.5', className)}>
          <CustomSwitch
            {...fieldProps}
            size={size}
            checked={!!value}
            onCheckedChange={(checked) => {
              onChange(checked);
              onCheckedChange?.(checked);
            }}
            required={required}
            label={label}
            labels={labels}
            description={description}
            className={cn(errorMessage && 'border border-destructive')}
          />
          {errorMessage && (
            <p className="text-sm font-medium text-destructive">
              {`${errorMessage}`}
            </p>
          )}
        </div>
      )}
    />
  );
};

export default FormSwitch;
