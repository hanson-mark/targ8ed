'use client';

import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { api } from '@/convex/_generated/api';
import { applicationKeyZodSchema } from '@/convex/validations/common';
import { cn } from '@/lib/utils';
import useSubdomainStore from '@/stores/subdomainStore';
import { useConvex } from 'convex/react';
import { debounce, get } from 'lodash';
import { CheckCircle2Icon, Loader2Icon, XCircleIcon } from 'lucide-react';
import {
  ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Controller, useFormContext } from 'react-hook-form';

interface IProps {
  inputName: string;
  finalName: string;
  label?: string;
  placeholder?: string;
  className?: string;
}

export const FormCheckApplicationKeyInput = ({
  inputName,
  finalName,
  label,
  placeholder,
  className,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const hasMounted = useRef(false);
  const [showMessage, setShowMessage] = useState(false);
  const [serverSuccessMessage, setServerSuccessMessage] = useState('');
  const [serverErrorMessage, setServerErrorMessage] = useState('');
  const [isChecking, setIsChecking] = useState(false); // 👈 New state

  const convexRequest = useConvex();

  const {
    control,
    setValue,
    watch,
    formState: { errors },
  } = useFormContext();

  const validKey = watch(finalName);
  const inputValue = watch(inputName);
  const errorMessage = get(errors, inputName)?.message as string | undefined;

  const debouncedCheckAvailability = useMemo(
    () =>
      debounce(async (value: string) => {
        setValue(finalName, '', { shouldValidate: true });
        setShowMessage(true);
        setServerErrorMessage('');
        setServerSuccessMessage('');
        setIsChecking(true); // 👈 Set loading true

        const result = applicationKeyZodSchema.safeParse(value);
        if (!result?.success) {
          setServerErrorMessage(result?.error?.issues?.[0]?.message || '');
          setIsChecking(false); // 👈 Set loading false
          return;
        }

        const keyInput = result?.data;

        try {
          const res = await convexRequest.query(
            api.functions.apps.global.applications.index.readKeyAvailability,
            { currentOrgId, inputs: { key: keyInput } }
          );

          if ('data' in res && res?.success === true) {
            setValue(finalName, keyInput, { shouldValidate: true });
            setServerSuccessMessage(res?.message || '');
          } else {
            setValue(finalName, '', { shouldValidate: true });
            setServerErrorMessage(res?.message || '');
          }
        } catch {
          setValue(finalName, '', { shouldValidate: true });
        } finally {
          setIsChecking(false); // 👈 Set loading false
        }
      }, 800),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [convexRequest, setValue, finalName]
  );

  const checkAvailability = useCallback(
    (value: string) => debouncedCheckAvailability(value),
    [debouncedCheckAvailability]
  );

  useEffect(() => {
    if (!hasMounted.current) {
      hasMounted.current = true;
      return;
    }

    if (!inputValue) {
      setValue(finalName, '', { shouldValidate: true });
      setShowMessage(false);
      setIsChecking(false);
      return;
    }

    if (!errorMessage) {
      checkAvailability(inputValue);
    } else {
      setValue(finalName, '', { shouldValidate: true });
      setShowMessage(false);
      setIsChecking(false);
    }
  }, [inputValue, checkAvailability, errorMessage, finalName, setValue]);

  const onInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setValue(inputName, value, { shouldValidate: true });
    setValue(finalName, '', { shouldValidate: true });
    setShowMessage(false);
    setServerErrorMessage('');
    setIsChecking(false); // reset loading state when user types
  };

  const isKeyAvailable =
    showMessage &&
    !isChecking &&
    !errorMessage &&
    !serverErrorMessage &&
    validKey;

  return (
    <Controller
      name={inputName}
      control={control}
      render={() => (
        <div className={cn('flex flex-col space-y-1', className)}>
          {label && (
            <Label
              htmlFor={inputName}
              className={cn('text-sm font-semibold', {
                'text-destructive': !isChecking && errorMessage,
              })}
            >
              {label}
            </Label>
          )}

          <div className="relative">
            <Input
              id={inputName}
              value={inputValue}
              placeholder={placeholder}
              className={cn(
                'pr-10 h-10 text-sm',
                errorMessage && 'border-destructive'
              )}
              onChange={onInputChange}
            />
          </div>

          {(showMessage || errorMessage) && (
            <div className="flex items-center space-x-1 pt-1 min-h-5">
              {isChecking ? (
                <>
                  <Loader2Icon className="size-4 animate-spin text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    Checking availability…
                  </p>
                </>
              ) : isKeyAvailable ? (
                <>
                  <CheckCircle2Icon className="size-4 text-green-500" />
                  <p className="text-sm text-green-600">
                    {serverSuccessMessage || 'Key is available!'}
                  </p>
                </>
              ) : (
                <>
                  <XCircleIcon className="size-4 text-destructive" />
                  <p className="text-sm text-destructive">
                    {errorMessage
                      ? errorMessage
                      : serverErrorMessage || 'Key is not available.'}
                  </p>
                </>
              )}
            </div>
          )}
        </div>
      )}
    />
  );
};

export default FormCheckApplicationKeyInput;
