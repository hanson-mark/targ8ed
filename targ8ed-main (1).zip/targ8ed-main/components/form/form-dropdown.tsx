'use client';

import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { get } from 'lodash';
import { Check, ChevronsUpDown } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Controller, useFormContext } from 'react-hook-form';

interface IOption {
  label: string;
  value: string;
}

interface IProps {
  disabled?: boolean;
  name: string;
  label?: string;
  placeholder?: string;
  noOptionsMessage?: string;
  options: IOption[];
  onSelect?: (value: string) => void;
  classNames?: {
    main?: string;
    label?: string;
    button?: string;
    errorMessage?: string;
  };
}

const FormDropdown = ({
  disabled,
  name,
  label,
  placeholder = 'Select option...',
  noOptionsMessage = 'No options available',
  options,
  onSelect,
  classNames,
}: IProps) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();

  const errorMessage = get(errors, name)?.message;
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [triggerWidth, setTriggerWidth] = useState<number>();

  const updateWidth = useCallback(() => {
    if (buttonRef.current) {
      setTriggerWidth(buttonRef.current.offsetWidth);
    }
  }, []);

  useEffect(() => {
    updateWidth();
    const resizeObserver = new ResizeObserver(updateWidth);
    if (buttonRef.current) resizeObserver.observe(buttonRef.current);

    window.addEventListener('resize', updateWidth);
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateWidth);
    };
  }, [updateWidth]);

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => {
        const selected = options.find((opt) => opt.value === field.value);

        return (
          <div
            className={cn('flex flex-col w-full relative', classNames?.main)}
          >
            {label && (
              <Label
                className={cn(
                  'mb-1 font-semibold',
                  errorMessage && 'text-destructive',
                  classNames?.label
                )}
              >
                {label}
              </Label>
            )}

            {disabled ? (
              <Button
                ref={buttonRef}
                disabled
                variant="outline"
                className={cn(
                  'justify-between text-sm h-10 w-full mb-1 mt-0.5',
                  {
                    'border-destructive': errorMessage,
                    'text-primary/50 hover:text-primary/50': !selected?.label,
                  },
                  classNames?.button
                )}
                type="button"
              >
                {selected?.label || placeholder}
                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
              </Button>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    ref={buttonRef}
                    variant="outline"
                    className={cn(
                      'justify-between text-sm h-10 w-full mb-1 mt-0.5',
                      {
                        'border-destructive': errorMessage,
                        'text-primary/70 hover:text-primary/50 hover:!bg-transparent':
                          !selected?.label,
                      },
                      classNames?.button
                    )}
                    type="button"
                  >
                    {selected?.label || placeholder}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </DropdownMenuTrigger>

                <DropdownMenuContent
                  style={{ width: triggerWidth }}
                  align="start"
                  className="max-h-60 overflow-y-auto"
                >
                  {options.length === 0 ? (
                    <DropdownMenuItem
                      disabled
                      className="text-muted-foreground"
                    >
                      {noOptionsMessage || 'No options available'}
                    </DropdownMenuItem>
                  ) : (
                    options.map((option) => (
                      <DropdownMenuItem
                        key={option.value}
                        disabled={disabled}
                        onSelect={() => {
                          if (disabled) return;
                          field.onChange(option.value);
                          onSelect?.(option.value);
                        }}
                        className="cursor-pointer"
                      >
                        <Check
                          className={cn(
                            'mr-2 h-4 w-4',
                            option.value === field.value
                              ? 'opacity-100'
                              : 'opacity-0'
                          )}
                        />
                        {option.label}
                      </DropdownMenuItem>
                    ))
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            {errorMessage && (
              <p
                className={cn(
                  'text-sm font-medium text-destructive mt-1',
                  classNames?.errorMessage
                )}
              >
                {`${errorMessage}`}
              </p>
            )}
          </div>
        );
      }}
    />
  );
};

export default FormDropdown;
