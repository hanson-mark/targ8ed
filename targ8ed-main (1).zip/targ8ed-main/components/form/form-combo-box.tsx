'use client';

import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { debounce, get } from 'lodash';
import { Check, ChevronsUpDown, SearchIcon } from 'lucide-react';
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import Loader from '../common/loaders/loader';

interface IOption {
  label: string;
  value: string;
}

interface IProps {
  disabled?: boolean;
  name: string;
  label?: string;
  placeholder?: string;
  options: IOption[];
  classNames?: {
    main?: string;
    label?: string;
    button?: string;
    errorMessage?: string;
  };
  isSearching?: boolean;
  onSearch?: (value: string) => void;
  searchInputDebounceDelay?: number;
  onSelect?: (value: string) => void;
}

const FormComboBox = ({
  disabled,
  name,
  label,
  placeholder = 'Select option...',
  options,
  classNames,
  isSearching,
  onSearch,
  searchInputDebounceDelay,
  onSelect,
}: IProps) => {
  const {
    control,
    getValues,
    setValue,
    formState: { errors },
  } = useFormContext();

  const errorMessage = get(errors, name)?.message;
  const [open, setOpen] = useState(false);
  const [triggerWidth, setTriggerWidth] = useState<number>();
  const buttonRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const updateWidth = useCallback(() => {
    if (buttonRef.current) {
      setTriggerWidth(buttonRef.current.offsetWidth);
    }
  }, []);

  const handleClickOutside = (e: MouseEvent) => {
    if (
      buttonRef.current &&
      !buttonRef.current.contains(e.target as Node) &&
      dropdownRef.current &&
      !dropdownRef.current.contains(e.target as Node)
    ) {
      setOpen(false);
    }
  };

  const debouncedOnSearch = useMemo(
    () =>
      debounce((query: string) => {
        onSearch?.(query);
      }, searchInputDebounceDelay ?? 300),
    [onSearch, searchInputDebounceDelay]
  );

  useLayoutEffect(() => {
    updateWidth();

    const resizeObserver = new ResizeObserver(updateWidth);
    if (buttonRef.current) {
      resizeObserver.observe(buttonRef.current);
    }

    window.addEventListener('resize', updateWidth);
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateWidth);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [updateWidth]);

  useEffect(() => {
    if (isSearching) return;
    const selectedValue = getValues(name);

    const selected = options.find((opt) => opt.value === selectedValue);
    if (!selected) {
      setValue(name, '');
    }
  }, [getValues, isSearching, name, options, setValue]);

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => {
        const selected = options.find((opt) => opt.value === field.value);

        return (
          <div
            className={cn('flex flex-col w-full relative', classNames?.main)} // 👈 must have 'relative'
          >
            {label && (
              <Label
                className={cn(
                  'mb-1 font-semibold',
                  errorMessage && 'text-destructive',
                  classNames?.label
                )}
              >
                {label}
              </Label>
            )}

            <Button
              ref={buttonRef}
              disabled={disabled}
              variant="outline"
              role="combobox"
              aria-expanded={open}
              className={cn(
                'justify-between text-sm h-10 w-full mb-1 mt-0.5',
                {
                  'border-destructive': errorMessage,
                  'text-primary/50 hover:text-primary/50': !selected?.label,
                },
                classNames?.button
              )}
              onClick={!disabled ? () => setOpen((prev) => !prev) : undefined}
              type="button"
            >
              {selected?.label
                ? selected?.label
                : isSearching
                  ? 'Loading...'
                  : placeholder}
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>

            {open && (
              <div
                ref={dropdownRef}
                className="absolute top-full left-0 z-50 mt-0 rounded-md border border-input bg-popover text-popover-foreground shadow-md overflow-y-auto"
                style={{ width: triggerWidth }}
              >
                <Command>
                  <div
                    className="flex items-center border-b px-3"
                    cmdk-input-wrapper=""
                  >
                    <SearchIcon className="mr-2 h-4 w-4 shrink-0 opacity-50" />
                    <input
                      type="text"
                      placeholder="Search..."
                      onChange={(e) => debouncedOnSearch(e.target.value)}
                      className="flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
                    />
                  </div>

                  <CommandList className="max-h-40">
                    <CommandEmpty>
                      {isSearching ? (
                        <Loader
                          variant="minimal"
                          message="Searching options..."
                          className=""
                        />
                      ) : (
                        'No option found.'
                      )}
                    </CommandEmpty>
                    <CommandGroup>
                      {isSearching
                        ? null
                        : options.map((option) => (
                            <CommandItem
                              key={option.value}
                              value={option.value}
                              className="cursor-pointer"
                              onSelect={() => {
                                field.onChange(option.value);
                                if (onSelect) onSelect(option.value);
                                setOpen(false);
                              }}
                              onMouseDown={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                              }}
                            >
                              <Check
                                className={cn(
                                  'h-4 w-4',
                                  option.value === field.value
                                    ? 'opacity-100'
                                    : 'opacity-0'
                                )}
                              />
                              {option.label}
                            </CommandItem>
                          ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </div>
            )}

            {errorMessage && (
              <p
                className={cn(
                  'text-sm font-medium text-destructive',
                  classNames?.errorMessage
                )}
              >
                {`${errorMessage}`}
              </p>
            )}
          </div>
        );
      }}
    />
  );
};

export default FormComboBox;
