import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { get } from 'lodash';
import { EyeIcon, EyeOffIcon } from 'lucide-react';
import { ReactNode, useState } from 'react';
import { Controller, useFormContext } from 'react-hook-form';

interface IProps {
  disabled?: boolean;
  autoFocus?: boolean;
  name: string;
  type?: 'text' | 'number' | 'email' | 'password';
  label?: string | ReactNode;
  description?: string | ReactNode;
  suffix?: string | ReactNode;
  prefix?: string | ReactNode;
  placeholder?: string;
  classNames?: {
    main?: string;
    label?: string;
    input?: string;
    errorMessage?: string;
  };
  min?: number;
  max?: number;
  onChange?: (value: string) => void;
}

const FormInput = ({
  disabled,
  autoFocus,
  name,
  label,
  description,
  prefix,
  suffix,
  type = 'text', // Default type to 'text'
  placeholder,
  classNames,
  min,
  max,
  onChange,
}: IProps) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();
  const errorMessage = get(errors, name)?.message;

  // State to toggle password visibility
  const [showPassword, setShowPassword] = useState(false);

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => (
        <div
          className={cn(
            'space-y-0.5 justify-start flex-col flex w-full items-start',
            classNames?.main
          )}
        >
          {label ? (
            <Label
              className={cn(
                'mb-1 font-semibold',
                errorMessage && 'text-destructive',
                classNames?.label
              )}
              htmlFor={name}
            >
              {label}
            </Label>
          ) : null}

          <div className="relative w-full mt-0.5 flex items-center gap-1">
            {prefix && (
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm pointer-events-none">
                {prefix}
              </div>
            )}

            <Input
              disabled={disabled}
              autoFocus={autoFocus}
              type={
                type === 'password'
                  ? showPassword
                    ? 'text'
                    : 'password'
                  : type
              }
              placeholder={placeholder || ''}
              className={cn(
                'text-sm focus-visible:ring-1 h-10',
                prefix && 'pl-10', // space for prefix
                errorMessage &&
                  'border-destructive focus-visible:ring-muted-foreground',
                classNames?.input
              )}
              {...{
                ...field,
                min,
                max,
                onChange: (e) => {
                  const value =
                    type === 'number'
                      ? parseFloat(e.target.value)
                      : e.target.value;
                  field.onChange(value);
                  onChange?.(e.target.value || '');
                },
              }}
            />

            {type === 'password' && (
              <Button
                tabIndex={-1}
                type="button"
                variant="ghost"
                size={'sm'}
                className={cn(
                  'absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent',
                  disabled && 'hidden'
                )}
                onClick={() => setShowPassword((prev) => !prev)}
                disabled={disabled}
              >
                {!showPassword ? (
                  <EyeIcon className="size-5" />
                ) : (
                  <EyeOffIcon className="size-5" />
                )}
                <span className="sr-only">
                  {showPassword ? 'Hide' : 'Show'}
                </span>
              </Button>
            )}

            {suffix && <div className="h-full">{suffix}</div>}
          </div>
          {description ? (
            <span className="text-xs text-muted-foreground">{description}</span>
          ) : null}

          {errorMessage ? (
            <p
              className={cn(
                'text-sm font-medium text-destructive',
                classNames?.errorMessage
              )}
            >
              {`${errorMessage}`}
            </p>
          ) : null}
        </div>
      )}
    />
  );
};

export default FormInput;
