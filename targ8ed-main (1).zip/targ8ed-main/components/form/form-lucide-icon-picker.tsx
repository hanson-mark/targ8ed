'use client';

import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { ILucideIconName } from '@/types/dashboard-layout';
import { get } from 'lodash';
import { ChevronsUpDown } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import LucideIcon from '../common/lucide-icon/lucide-icon';
import LucideIconLibrary from '../common/lucide-icon/lucide-icon-library';

interface IProps {
  name: string;
  label?: string;
  placeholder?: string;
  disabled?: boolean;
  classNames?: {
    main?: string;
    label?: string;
    button?: string;
    errorMessage?: string;
  };
}

const FormLucideIconPicker = ({
  name,
  label,
  placeholder = 'Pick an icon...',
  disabled,
  classNames,
}: IProps) => {
  const {
    control,
    setValue,
    formState: { errors },
  } = useFormContext();

  const errorMessage = get(errors, name)?.message;
  const [open, setOpen] = useState(false);
  const [triggerWidth, setTriggerWidth] = useState<number>();
  const buttonRef = useRef<HTMLButtonElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const updateWidth = useCallback(() => {
    if (buttonRef.current) {
      setTriggerWidth(buttonRef.current.offsetWidth);
    }
  }, []);

  const handleClickOutside = (e: MouseEvent) => {
    if (
      buttonRef.current &&
      !buttonRef.current.contains(e.target as Node) &&
      dropdownRef.current &&
      !dropdownRef.current.contains(e.target as Node)
    ) {
      setOpen(false);
    }
  };

  useEffect(() => {
    updateWidth();

    const resizeObserver = new ResizeObserver(updateWidth);
    if (buttonRef.current) {
      resizeObserver.observe(buttonRef.current);
    }

    window.addEventListener('resize', updateWidth);
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateWidth);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [updateWidth]);

  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => {
        const formIconName = field?.value as ILucideIconName;

        return (
          <div
            className={cn('flex flex-col w-full relative', classNames?.main)} // 👈 must have 'relative'
          >
            {label && (
              <Label
                className={cn(
                  'mb-1 font-semibold',
                  errorMessage && 'text-destructive',
                  classNames?.label
                )}
              >
                {label}
              </Label>
            )}

            <Button
              ref={buttonRef}
              disabled={disabled}
              variant="outline"
              className={cn(
                'justify-between text-sm h-10 w-full mb-1 mt-0.5',
                {
                  'border-destructive': errorMessage,
                  'text-primary/50 hover:text-primary/50': !field.value,
                },
                classNames?.button
              )}
              onClick={!disabled ? () => setOpen((prev) => !prev) : undefined}
              type="button"
            >
              <div className="flex items-center gap-2">
                {formIconName && (
                  <LucideIcon name={formIconName} className="h-4 w-4" />
                )}
                {field.value || placeholder}
              </div>
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>

            {open && (
              <div
                ref={dropdownRef}
                className="absolute top-full left-0 z-50 mt-0 rounded-md shadow-md bg-background"
                style={{ width: triggerWidth }}
              >
                <LucideIconLibrary
                  value={formIconName}
                  onChange={(iconName) => {
                    field.onChange(iconName);
                    setValue(name, iconName);
                    setOpen(false);
                  }}
                />
              </div>
            )}

            {errorMessage && (
              <p
                className={cn(
                  'text-sm font-medium text-destructive',
                  classNames?.errorMessage
                )}
              >
                {`${errorMessage}`}
              </p>
            )}
          </div>
        );
      }}
    />
  );
};

export default FormLucideIconPicker;
