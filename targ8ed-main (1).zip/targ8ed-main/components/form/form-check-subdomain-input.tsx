'use client';

import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { api } from '@/convex/_generated/api';
import { subdomainZodSchema } from '@/convex/validations/common';
import { cn } from '@/lib/utils';
import { useConvex } from 'convex/react';
import { debounce, get } from 'lodash';
import { CheckCircle2Icon, Loader2Icon, XCircleIcon } from 'lucide-react';
import {
  ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Controller, useFormContext } from 'react-hook-form';

interface IProps {
  inputName: string;
  finalName: string;
  label?: string;
  placeholder?: string;
  className?: string;
}

export const FormCheckSubdomainInput = ({
  inputName,
  finalName,
  label,
  placeholder,
  className,
}: IProps) => {
  const hasMounted = useRef(false);
  const [showMessage, setShowMessage] = useState(false);
  const [serverErrorMessage, setServerErrorMessage] = useState('');
  const [isChecking, setIsChecking] = useState(false); // ✅

  const convexRequest = useConvex();

  const {
    control,
    setValue,
    watch,
    formState: { errors },
  } = useFormContext();

  const validSubdomain = watch(finalName);
  const inputValue = watch(inputName);
  const errorMessage = get(errors, inputName)?.message as string | undefined;

  const debouncedCheckAvailability = useMemo(
    () =>
      debounce(async (value: string) => {
        setIsChecking(true); // ✅
        setValue(finalName, '', { shouldValidate: true });
        setShowMessage(true);
        setServerErrorMessage('');

        const result = subdomainZodSchema.safeParse(value);
        if (!result.success) {
          setServerErrorMessage(result.error.issues?.[0]?.message || '');
          setIsChecking(false); // ✅
          return;
        }

        const subdomainInput = result.data;

        try {
          const response = await convexRequest.query(
            api.functions.apps.global.organizations.index
              .readSubdomainAvailability,
            { subdomain: subdomainInput }
          );

          if (response.success && response.data) {
            setValue(finalName, subdomainInput, { shouldValidate: true });
          } else {
            setValue(finalName, '', { shouldValidate: true });
            setServerErrorMessage('Subdomain is not available.');
          }
        } catch {
          setValue(finalName, '', { shouldValidate: true });
          setServerErrorMessage('Something went wrong.');
        } finally {
          setIsChecking(false); // ✅
        }
      }, 800),
    [convexRequest, setValue, finalName]
  );

  const checkAvailability = useCallback(
    (value: string) => debouncedCheckAvailability(value),
    [debouncedCheckAvailability]
  );

  useEffect(() => {
    if (!hasMounted.current) {
      hasMounted.current = true;
      return;
    }

    if (!inputValue) {
      setValue(finalName, '', { shouldValidate: true });
      setShowMessage(false);
      return;
    }

    if (!errorMessage) {
      checkAvailability(inputValue);
    } else {
      setValue(finalName, '', { shouldValidate: true });
      setShowMessage(false);
    }
  }, [inputValue, checkAvailability, errorMessage, finalName, setValue]);

  const onInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    setValue(inputName, value, { shouldValidate: true });
    setValue(finalName, '', { shouldValidate: true });
    setShowMessage(false);
    setServerErrorMessage('');
  };

  const isSubdomainAvailable =
    showMessage &&
    !isChecking &&
    !errorMessage &&
    !serverErrorMessage &&
    validSubdomain;

  return (
    <Controller
      name={inputName}
      control={control}
      render={() => (
        <div className={cn('flex flex-col space-y-1', className)}>
          {label && (
            <Label
              htmlFor={inputName}
              className={cn('text-sm font-semibold', {
                'text-destructive': !isChecking && errorMessage,
              })}
            >
              {label}
            </Label>
          )}

          <div className="relative">
            <Input
              id={inputName}
              value={inputValue}
              placeholder={placeholder}
              className={cn(
                'pr-10 h-10 text-sm',
                errorMessage && 'border-destructive'
              )}
              onChange={onInputChange}
            />
          </div>

          {(showMessage || errorMessage) && (
            <div className="flex items-center space-x-1 pt-1 min-h-5">
              {isChecking ? (
                <>
                  <Loader2Icon className="size-4 animate-spin text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">
                    Checking availability…
                  </p>
                </>
              ) : isSubdomainAvailable ? (
                <>
                  <CheckCircle2Icon className="size-4 text-green-500" />
                  <p className="text-sm text-green-600">
                    Subdomain is available!
                  </p>
                </>
              ) : (
                <>
                  <XCircleIcon className="size-4 text-destructive" />
                  <p className="text-sm text-destructive">
                    {errorMessage
                      ? errorMessage
                      : serverErrorMessage || 'Subdomain is not available.'}
                  </p>
                </>
              )}
            </div>
          )}
        </div>
      )}
    />
  );
};

export default FormCheckSubdomainInput;
