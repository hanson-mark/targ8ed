import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { get } from 'lodash';
import { ReactNode } from 'react';
import { Controller, useFormContext } from 'react-hook-form';

interface IProps {
  disabled?: boolean;
  autoFocus?: boolean;
  name: string;
  label?: string | ReactNode;
  prefix?: string | ReactNode;
  placeholder?: string;
  classNames?: {
    main?: string;
    label?: string;
    input?: string;
    errorMessage?: string;
  };
  min?: number;
  max?: number;
  rows?: number; // for Textarea rows
  onChange?: (value: string) => void;
}

const FormTextarea = ({
  disabled,
  autoFocus,
  name,
  label,
  prefix,
  placeholder,
  classNames,
  min,
  max,
  rows = 3, // Default to 3 rows
  onChange,
}: IProps) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();
  const errorMessage = get(errors, name)?.message;

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => (
        <div
          className={cn(
            'space-y-0.5 justify-start flex-col flex w-full items-start',
            classNames?.main
          )}
        >
          {label ? (
            <Label
              className={cn(
                'mb-1 font-semibold',
                errorMessage && 'text-destructive',
                classNames?.label
              )}
              htmlFor={name}
            >
              {label}
            </Label>
          ) : null}

          <div className="relative w-full mt-0.5">
            {prefix && (
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm pointer-events-none">
                {prefix}
              </div>
            )}

            <Textarea
              disabled={disabled}
              autoFocus={autoFocus}
              placeholder={placeholder || ''}
              rows={rows}
              className={cn(
                'text-sm focus-visible:ring-1',
                prefix && 'pl-10', // space for prefix
                errorMessage &&
                  'border-destructive focus-visible:ring-muted-foreground',
                classNames?.input
              )}
              {...{
                ...field,
                min,
                max,
                onChange: (e) => {
                  const value = e.target.value;
                  field.onChange(value);
                  onChange?.(value);
                },
              }}
            />
          </div>

          {errorMessage ? (
            <p
              className={cn(
                'text-sm font-medium text-destructive',
                classNames?.errorMessage
              )}
            >
              {`${errorMessage}`}
            </p>
          ) : null}
        </div>
      )}
    />
  );
};

export default FormTextarea;
