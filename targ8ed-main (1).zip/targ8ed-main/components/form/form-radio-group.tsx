'use client';

import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { cn } from '@/lib/utils';
import { get } from 'lodash';
import { Controller, useFormContext } from 'react-hook-form';

interface IOption {
  label: string;
  value: string;
}

interface IProps {
  name: string;
  label?: string;
  options: IOption[];
  disabled?: boolean;
  direction?: 'row' | 'column'; // new prop
  classNames?: {
    main?: string;
    label?: string;
    itemWrapper?: string;
    errorMessage?: string;
  };
}

const FormRadioGroup = ({
  name,
  label,
  options,
  disabled,
  direction = 'column',
  classNames,
}: IProps) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();

  const errorMessage = get(errors, name)?.message;

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => (
        <div className={cn('flex flex-col w-full', classNames?.main)}>
          {label && (
            <Label
              className={cn(
                'mb-2 font-semibold',
                errorMessage && 'text-destructive',
                classNames?.label
              )}
            >
              {label}
            </Label>
          )}

          <RadioGroup
            onValueChange={field.onChange}
            value={field.value}
            defaultValue={field.value}
            className={cn(
              'gap-2',
              direction === 'row' ? 'flex flex-row flex-wrap' : 'flex flex-col'
            )}
            disabled={disabled}
          >
            {options.map((option) => (
              <div
                key={option.value}
                className={cn(
                  'flex items-center space-x-2',
                  classNames?.itemWrapper
                )}
              >
                <RadioGroupItem
                  id={`${name}-${option.value}`}
                  value={option.value}
                  disabled={disabled}
                />
                <Label
                  htmlFor={`${name}-${option.value}`}
                  className={cn(
                    'capitalize cursor-pointer select-none',
                    disabled && 'cursor-not-allowed'
                  )}
                >
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>

          {errorMessage && (
            <p
              className={cn(
                'text-sm font-medium text-destructive mt-1',
                classNames?.errorMessage
              )}
            >
              {`${errorMessage}`}
            </p>
          )}
        </div>
      )}
    />
  );
};

export default FormRadioGroup;
