'use client';

import ToggleButton from '@/components/common/toggle-button';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { get } from 'lodash';
import { Controller, useFormContext } from 'react-hook-form';

interface IOption {
  label: string;
  value: string;
}

interface IProps {
  disabled?: boolean;
  name: string;
  label?: string;
  options: IOption[];
  onClick?: (option: IOption) => void;
  classNames?: {
    main?: string;
    label?: string;
    group?: string;
    errorMessage?: string;
    button?: string;
  };
}

const FormToggleButtons = ({
  disabled,
  name,
  label,
  options,
  onClick,
  classNames,
}: IProps) => {
  const {
    control,
    formState: { errors },
  } = useFormContext();

  const errorMessage = get(errors, name)?.message;

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => (
        <div className={cn('flex flex-col w-full', classNames?.main)}>
          {label && (
            <Label
              className={cn(
                'mb-2 font-semibold',
                errorMessage && 'text-destructive',
                classNames?.label
              )}
            >
              {label}
            </Label>
          )}

          <div className={cn('flex flex-wrap gap-2', classNames?.group)}>
            {options.map((option) => {
              const isSelected = field.value === option.value;
              return (
                <ToggleButton
                  key={option.value}
                  isSelected={isSelected}
                  onClick={() => {
                    if (!disabled) {
                      field.onChange(option.value);
                      if (onClick) {
                        onClick(option);
                      }
                    }
                  }}
                  disabled={disabled}
                  className={classNames?.button}
                >
                  {option.label}
                </ToggleButton>
              );
            })}
          </div>

          {errorMessage && (
            <p
              className={cn(
                'text-sm font-medium text-destructive mt-1',
                classNames?.errorMessage
              )}
            >
              {`${errorMessage}`}
            </p>
          )}
        </div>
      )}
    />
  );
};

export default FormToggleButtons;
