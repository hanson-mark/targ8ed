'use client';

import { checkPermission } from '@/lib/data-formatters/permissions';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
  fnNames: string[];
}

const PermissionGuard = ({ children, fnNames }: IProps): ReactNode => {
  const { permissions } = useUserRolesStore();

  const hasPermission = checkPermission(permissions || [], fnNames);

  if (!hasPermission) {
    return null;
  }

  return children;
};

export default PermissionGuard;
