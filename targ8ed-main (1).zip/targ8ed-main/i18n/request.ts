import { getUserLocale } from '@/actions/i18n/locale-manager';
import appConfig from '@/lib/app-config';
import merge from 'deepmerge';
import { getRequestConfig } from 'next-intl/server';

export default getRequestConfig(async () => {
  const locale = await getUserLocale();
  const messages = (await import(`../messages/${locale}.json`)).default;

  if (locale !== appConfig.i18n.defaultLocale) {
    const defaultMessages = (
      await import(`../messages/${appConfig.i18n.defaultLocale}.json`)
    ).default;
    return {
      locale,
      messages: merge(defaultMessages, messages),
    };
  }

  return {
    locale,
    messages: (await import(`../messages/${locale}.json`)).default,
  };
});
