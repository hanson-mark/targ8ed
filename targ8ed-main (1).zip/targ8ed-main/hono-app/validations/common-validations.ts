import { emailZodSchema } from '@/convex/validations/common';

import {
  DEFAULT_PAGE_LIMIT,
  DEFAULT_SORT_ORDER,
} from '@/lib/default-data/default-pagination';
import { z } from '@hono/zod-openapi';

// * Hono request params schema
export const getIdParamsZodSchema = (
  paramName: string,
  defaultValue?: string
) => {
  return z.object({
    [paramName]: z.string().openapi({
      param: {
        name: paramName,
        in: 'path',
        required: true,
      },
      required: [paramName],
      ...(defaultValue ? { default: defaultValue } : {}),
    }),
  });
};

// * Hono request query schema
export const getIdQueryZodSchema = (
  paramName: string,
  defaultValue?: string
) => {
  return z.object({
    [paramName]: z.string().openapi({
      param: {
        name: paramName,
        in: 'query',
        required: true,
      },
      required: [paramName],
      ...(defaultValue ? { default: defaultValue } : {}),
    }),
  });
};
export const emailQueryZodSchema = z.object({
  email: emailZodSchema.openapi({
    param: {
      name: 'email',
      in: 'query',
      required: true,
      example: 'abc@example.xyz',
    },
  }),
});

export const paginationQueryZodSchema = z.object({
  cursor: z.string().optional().openapi({
    description: 'Cursor for fetching the next batch',
  }),
  limit: z
    .string()
    .optional()
    .default(DEFAULT_PAGE_LIMIT)
    .refine((val) => /^\d+$/.test(val) && parseInt(val, 10) > 0, {
      message: 'Limit must be a positive number',
    })
    .openapi({
      description: 'Number of items per page',
      default: DEFAULT_PAGE_LIMIT,
    }),
  sortOrder: z.enum(['asc', 'desc']).default('asc').openapi({
    description: 'Sort order',
    default: DEFAULT_SORT_ORDER,
  }),
});

// * Convex doc zod schema
export const convexDocZodSchema = z.object({
  _id: z.string(),
  _creationTime: z.number(),
});

// * Hono response zod schema
export const responseMetaZodSchema = paginationQueryZodSchema.extend({
  limit: z.coerce
    .number()
    .optional()
    .default(Number(DEFAULT_PAGE_LIMIT))
    .openapi({
      description: 'Number of items per page',
      default: Number(DEFAULT_PAGE_LIMIT),
    }),
  isLastPage: z.boolean().openapi({
    description: 'Indicating that it is last page',
    default: false,
  }),
});

export const successResponseZodSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  data: z.any().optional(),
});

export const errorResponseZodSchema = z.object({
  success: z.boolean().default(false),
  message: z.string(),
  errorSources: z
    .array(
      z.object({
        path: z.string(),
        message: z.string(),
      })
    )
    .optional(),
  stack: z.string().optional(),
});
