import { z } from 'zod';

export const clerkUser = z.object({
  created_at: z.string(),
  email: z.string(),
  email_verified: z.boolean().optional(),
  identities: z.array(
    z.object({
      connection: z.string(),
      provider: z.string(),
      user_id: z.string(),
      isSocial: z.boolean().optional(),
    })
  ),
  name: z.string(),
  nickname: z.string(),
  picture: z.string(),
  updated_at: z.string(),
  user_id: z.string(),
  blocked: z.boolean().optional(),
  last_ip: z.string(),
  last_login: z.string(),
  logins_count: z.coerce.number(),
});
