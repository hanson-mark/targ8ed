import { createHonoRouter } from '@/hono-app/helpers/app-helpers';
import UserHandlers from './users.handlers';
import UserRoutes from './users.routes';

const UsersRouter = createHonoRouter()
  .openapi(UserRoutes.clerkUsersByEmail, UserHandlers.clerkUsersByEmail)
  .openapi(
    UserRoutes.unblockClerkBruteForceBlockedUser,
    UserHandlers.unblockClerkBruteForceBlockedUser
  );

export default UsersRouter;
