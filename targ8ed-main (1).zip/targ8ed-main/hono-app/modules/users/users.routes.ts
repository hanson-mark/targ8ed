import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import {
  getOpenApiErrorResponses,
  openApiJsonResponse,
} from '@/hono-app/helpers/response-helpers';
import {
  emailQueryZodSchema,
  getIdQueryZodSchema,
  successResponseZodSchema,
} from '@/hono-app/validations/common-validations';
import { createRoute, z } from '@hono/zod-openapi';

const tags = ['Users'];

const clerkUsersByEmail = createRoute({
  method: 'get',
  path: '/clerk-users-by-email',
  tags,
  request: {
    query: emailQueryZodSchema,
  },
  responses: {
    [HttpStatusCodes.OK]: openApiJsonResponse(
      successResponseZodSchema.extend({
        data: z.array(z.any()),
      }),
      'Get All Clerk Users with email'
    ),
    ...getOpenApiErrorResponses({}, ['INTERNAL_SERVER_ERROR', 'UNAUTHORIZED']),
  },
});

const unblockClerkBruteForceBlockedUser = createRoute({
  method: 'patch',
  path: '/unblock-brute-force-blocked-user',
  tags,
  request: {
    query: getIdQueryZodSchema('clerk_user_id'),
  },
  responses: {
    [HttpStatusCodes.OK]: openApiJsonResponse(
      successResponseZodSchema.extend({
        data: z.boolean().optional(),
      }),
      'Get All Users'
    ),
    ...getOpenApiErrorResponses({}, ['INTERNAL_SERVER_ERROR', 'UNAUTHORIZED']),
  },
});

const UserRoutes = {
  clerkUsersByEmail,
  unblockClerkBruteForceBlockedUser,
};

export default UserRoutes;
