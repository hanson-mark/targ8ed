import UserRoutes from './users.routes';

export type IClerkUsersByEmail = typeof UserRoutes.clerkUsersByEmail;
export type IUnblockBruteForceBlockedUser =
  typeof UserRoutes.unblockClerkBruteForceBlockedUser;
