import {
  getAuthToken,
  getClerkUsersByEmail,
  unblockBruteForceBlockedUser,
} from '@/actions/auth/user';
import { api } from '@/convex/_generated/api';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import AppError from '@/hono-app/helpers/app-error';
import { catchAsync } from '@/hono-app/helpers/catch-async';
import { getSubDomainInServer } from '@/lib/app-config';
import { fetchQuery } from 'convex/nextjs';
import {
  IClerkUsersByEmail,
  IUnblockBruteForceBlockedUser,
} from './users.interfaces';

// Handles retrieving clerk users by email
const clerkUsersByEmail = catchAsync<IClerkUsersByEmail>(async (c) => {
  const validQuery = c.req.valid('query');
  const { email } = validQuery;

  const currentOrgSubdomain = await getSubDomainInServer();

  if (!currentOrgSubdomain) {
    throw new AppError(HttpStatusCodes.BAD_REQUEST, 'Invalid request');
  }

  const token = await getAuthToken();

  const result = await fetchQuery(
    api.functions.apps.global.users.index.readCurrentUserDetails,
    { currentOrgSubdomain, inputs: {} },
    { token }
  );

  const user = 'data' in result ? result.data : undefined;

  if (!user?._id) {
    throw new AppError(HttpStatusCodes.UNAUTHORIZED, 'You are not allowed');
  }

  const clerkUsers = await getClerkUsersByEmail(email);

  return c.json(
    {
      success: true,
      message: 'Users retrieved successfully',
      data: clerkUsers || [],
    },
    HttpStatusCodes.OK
  );
});

// Handles unblocking clerk user who blocked for brute force
const unblockClerkBruteForceBlockedUser =
  catchAsync<IUnblockBruteForceBlockedUser>(async (c) => {
    const validQuery = c.req.valid('query');
    const { clerk_user_id } = validQuery;

    const currentOrgSubdomain = await getSubDomainInServer();

    if (!currentOrgSubdomain) {
      throw new AppError(HttpStatusCodes.BAD_REQUEST, 'Invalid request');
    }

    const token = await getAuthToken();
    const result = await fetchQuery(
      api.functions.apps.global.users.index.readCurrentUserDetails,
      { currentOrgSubdomain, inputs: {} },
      { token }
    );

    const hasAccessInGlobalApplication =
      result &&
      'data' in result &&
      result?.data?.applications?.some(
        (item) => item?.key === APPLICATION_KEYS.global
      );

    if (!hasAccessInGlobalApplication) {
      throw new AppError(HttpStatusCodes.UNAUTHORIZED, 'You are not allowed');
    }

    const response = await unblockBruteForceBlockedUser(clerk_user_id);

    return c.json(
      {
        success: true,
        message: 'Unblocked the brute force blocked user',
        data: response,
      },
      HttpStatusCodes.OK
    );
  });

// Grouping all user-related handlers together for export
const UserHandlers = {
  clerkUsersByEmail,
  unblockClerkBruteForceBlockedUser,
};

export default UserHandlers;
