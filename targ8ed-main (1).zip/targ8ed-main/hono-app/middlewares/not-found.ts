import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import type { NotFoundHandler } from 'hono';

const notFound: NotFoundHandler = (c) => {
  return c.json(
    { message: `Route not found - ${c.req.path}` },
    HttpStatusCodes.NOT_FOUND
  );
};

export default notFound;
