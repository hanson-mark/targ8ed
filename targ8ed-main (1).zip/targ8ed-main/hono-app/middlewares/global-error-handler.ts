import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import { sendHonoResponse } from '@/hono-app/helpers/response-helpers';
import requiredEnvVariables from '@/lib/env-variables';
import { IErrorResponse } from '@/types/hono';
import type { ErrorHandler } from 'hono';
import type { StatusCode } from 'hono/utils/http-status';
import { ZodError } from 'zod';

// Handles zod error
export const handleZodError = (error: ZodError): IErrorResponse => {
  const stack = error?.stack || '';

  const issues = error?.issues ?? [];

  // Get all invalid field paths
  const fieldNames = issues.map(
    (item) => item?.path?.[item?.path?.length - 1] as string
  );

  // Deduplicate field names
  const uniqueFields = Array.from(new Set(fieldNames));

  // Compose summary message
  let message = 'Invalid input';

  if (issues.length === 1) {
    message = issues[0].message;
  } else if (uniqueFields.length === 1) {
    message = `Invalid input in '${uniqueFields[0]}' field.`;
  } else if (uniqueFields.length === 2) {
    message = `Invalid inputs in '${uniqueFields[0]}' and '${uniqueFields[1]}' fields.`;
  } else if (uniqueFields.length > 2) {
    message = `Invalid inputs in '${uniqueFields[0]}', '${uniqueFields[1]}', and ${uniqueFields.length - 2} more fields.`;
  }

  // Detailed sources
  const errorSources = issues.map((item) => ({
    path: item?.path?.[item?.path?.length - 1] as string,
    message: item?.message as string,
  }));

  return {
    success: false,
    message,
    stack,
    errorSources,
    statusCode: HttpStatusCodes.BAD_REQUEST,
  };
};

// Handles malformed JSON error (Invalid JSON formats)
export const handleMalformedJsonError = (error: Error): IErrorResponse => {
  const stack = error?.stack || '';
  const message = 'Invalid JSON in request body';

  return {
    success: false,
    message,
    stack,
    errorSources: [
      {
        path: 'body',
        message:
          'Ensure the request body is valid JSON and has the correct Content-Type header (application/json)',
      },
    ],
    statusCode: HttpStatusCodes.BAD_REQUEST,
  };
};

// Handles convex error
export const handleConvexValidatorError = (error: Error): IErrorResponse => {
  const fullMessage = error?.message || '';

  // Extract parts using regex or string parsing
  const pathMatch = fullMessage.match(/Path: (.+)/);
  const path = pathMatch?.[1]?.trim().replace('.', '') || '';

  const formattedMessage = `Invalid input: '${path}' must match expected format.`;

  return {
    success: false,
    message: formattedMessage,
    errorSources: [
      {
        path,
        message: formattedMessage,
      },
    ],
    stack: error.stack,
    statusCode: HttpStatusCodes.BAD_REQUEST,
  };
};

// Handles convex runtime error
export const handleUncaughtError = (error: Error) => {
  const stack = error?.stack || '';
  const message = error?.message || 'Uncaught server error';

  // Match: Uncaught Error: <actual message>
  const match = message.match(/Uncaught Error:\s*(.+)/);
  const extractedMessage = match?.[1]?.trim() || 'Something went wrong';

  return {
    success: false,
    statusCode: 400,
    message: extractedMessage,
    stack,
    errorSources: [
      {
        path: '',
        message: extractedMessage,
      },
    ],
  };
};

// Global error handler
const globalErrorHandler: ErrorHandler = (error, c) => {
  const NODE_ENV = c.env?.NODE_ENV || requiredEnvVariables?.NODE_ENV;

  const currentStatus =
    'status' in error
      ? error.status
      : 'statusCode' in error
        ? error?.statusCode
        : c.newResponse(null).status;
  const statusCode =
    currentStatus !== HttpStatusCodes.OK
      ? (currentStatus as StatusCode)
      : HttpStatusCodes.INTERNAL_SERVER_ERROR;

  const stack = NODE_ENV === 'production' ? undefined : error?.stack || '';
  const message = error?.message || 'An unexpected error occurred';
  const errorSources = [{ path: '', message }];

  // * Zod validation error
  if (error instanceof ZodError) {
    const formattedResponse = handleZodError(error);
    return sendHonoResponse(c, { ...formattedResponse, stack });
  }
  // * Invalid JSON format validation
  else if (message?.includes('Malformed JSON')) {
    const formattedResponse = handleMalformedJsonError(error);
    return sendHonoResponse(c, { ...formattedResponse, stack });
  }
  // * Convex validator error
  else if (message?.includes('ArgumentValidationError')) {
    const formattedResponse = handleConvexValidatorError(error);
    return sendHonoResponse(c, { ...formattedResponse, stack });
  }
  // * Uncaught Error handler
  else if (message?.includes('Uncaught Error:')) {
    const formattedResponse = handleUncaughtError(error);
    return sendHonoResponse(c, { ...formattedResponse, stack });
  }
  // * Other validations
  else {
    return sendHonoResponse(c, {
      success: false,
      statusCode,
      message,
      stack,
      errorSources,
    });
  }
};

export default globalErrorHandler;
