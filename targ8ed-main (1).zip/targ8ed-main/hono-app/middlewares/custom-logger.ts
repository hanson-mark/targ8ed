import logger from '@/lib/logger';
import { IHonoAppBindings } from '@/types/hono';
import { MiddlewareHandler } from 'hono';

// Custom Logger Middleware
const customLogger: MiddlewareHandler<IHonoAppBindings> = async (c, next) => {
  try {
    const { method, path } = c.req; // Get HTTP method and path
    const startTime = performance.now(); // Record the start time

    // Attach logger function to `c.var`
    c.set('logger', logger);

    // Log incoming request details
    console.log(`<-- ${method} ${path}`);

    // Proceed to the next middleware or route handler
    await next();

    // Get response status code
    const statusCode = c.res.status;

    const color =
      statusCode >= 100 && statusCode < 200
        ? '\x1b[36m' // Cyan for 1xx (Informational)
        : statusCode >= 200 && statusCode < 300
          ? '\x1b[32m' // Green for 2xx (Success)
          : statusCode >= 300 && statusCode < 400
            ? '\x1b[33m' // Yellow for 3xx (Redirection)
            : statusCode >= 400 && statusCode < 500
              ? '\x1b[31m' // Red for 4xx (Client Errors)
              : '\x1b[35m'; // Magenta for 5xx (Server Errors)

    // Calculate response duration
    const duration = performance.now() - startTime;

    // Log the response details
    console.log(
      `--> ${method} ${path} ${color}${statusCode}\x1b[0m ${duration.toFixed(
        0
      )}ms`
    );
  } catch (error) {
    throw error;
  }
};

export default customLogger;
