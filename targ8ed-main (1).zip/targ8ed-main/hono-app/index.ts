import { createHonoApp } from '@/hono-app/helpers/app-helpers';
import { handle } from 'hono/vercel';
import UsersRouter from './modules/users';
// Creating the hono app
const honoApp = createHonoApp();

// Mounting or configuring routes
honoApp.route('/users', UsersRouter);

// Handlers for next js api
export const GET = handle(honoApp);
export const POST = handle(honoApp);
export const PUT = handle(honoApp);
export const PATCH = handle(honoApp);
export const DELETE = handle(honoApp);

export default honoApp;
