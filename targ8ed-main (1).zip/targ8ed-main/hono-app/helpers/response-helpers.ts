import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import { IHttpErrorStatusCode } from '@/types/common';
import { IHonoResponse } from '@/types/hono';
import { Context } from 'hono';
import { ContentfulStatusCode } from 'hono/utils/http-status';
import { ZodSchema } from 'zod';
import { errorResponseZodSchema } from '../validations/common-validations';

// Generate response function
export const generateHonoResponse = <T>({
  success,
  message,
  data,
  meta,
  errorSources,
  stack,
}: Omit<IHonoResponse<T>, 'statusCode'> & { stack?: string }): Omit<
  IHonoResponse<T>,
  'statusCode'
> & { stack?: string } => {
  const isSuccess = success || false;

  return {
    success: isSuccess,
    message,
    data: isSuccess ? data : undefined,
    meta: isSuccess ? meta : undefined,
    errorSources: isSuccess ? undefined : errorSources,
    stack: isSuccess ? undefined : stack,
  };
};

// Send response function for Hono
export const sendHonoResponse = <T>(
  c: Context,
  responseData: IHonoResponse<T> & { stack?: string }
) => {
  const statusCode = responseData.statusCode || 200;
  const response = generateHonoResponse(responseData);

  // Sending response
  return c.json(response, statusCode as ContentfulStatusCode);
};

// Open API JSON response
export const openApiJsonRequestBody = <T extends ZodSchema>(schema: T) => {
  return {
    content: {
      'application/json': {
        schema: schema,
      },
    },
  };
};

// Open API JSON response
export const openApiJsonResponse = <T extends ZodSchema>(
  schema: T,
  description: string
) => {
  return {
    content: {
      'application/json': {
        schema,
      },
    },
    description,
  };
};

// Adjusted getOpenApiErrorResponses function
export const getOpenApiErrorResponses = (
  customMessages: Partial<Record<keyof IHttpErrorStatusCode, string>> = {},
  errorSelections: (keyof IHttpErrorStatusCode)[] = []
) => {
  // Default error messages
  const defaultMessages: Record<keyof IHttpErrorStatusCode, string> = {
    UNAUTHORIZED: 'You are not allowed',
    INTERNAL_SERVER_ERROR: 'Internal server error',
    NOT_FOUND: 'Item not found',
    BAD_REQUEST: 'An unexpected error occurred',
  };

  // Merge customMessages with defaultMessages
  const mergedMessages = { ...defaultMessages, ...customMessages };

  // Define a helper function to filter responses based on the "errorSelections" parameter
  const getResponseForStatusCode = (statusCode: keyof IHttpErrorStatusCode) => {
    if (errorSelections.length > 0 && !errorSelections.includes(statusCode)) {
      return null;
    }
    return {
      [HttpStatusCodes[statusCode]]: openApiJsonResponse(
        errorResponseZodSchema,
        mergedMessages[statusCode]
      ),
    };
  };

  // Collect all responses based on the "errorSelections" parameter
  const responses = [
    getResponseForStatusCode('UNAUTHORIZED'),
    getResponseForStatusCode('INTERNAL_SERVER_ERROR'),
    getResponseForStatusCode('NOT_FOUND'),
  ];

  // Filter out any null values (if any status code was excluded based on the "errorSelections" parameter)
  return responses
    .filter((response) => response !== null)
    .reduce((acc, response) => {
      return { ...acc, ...response };
    }, {});
};
