import type { IHonoRouteHandler } from '@/types/hono';
import { RouteConfig } from '@hono/zod-openapi';
import { Context, Next } from 'hono';

export const catchAsync = <T extends RouteConfig>(
  handler: IHonoRouteHandler<T>
): IHonoRouteHandler<T> => {
  return (async (c: Context, next: Next) => {
    try {
      const result = await handler(c, next);
      return result;
    } catch (error) {
      throw error;
    }
  }) as unknown as IHonoRouteHandler<T>;
};
