import customLogger from '@/hono-app/middlewares/custom-logger';
import globalErrorHandler from '@/hono-app/middlewares/global-error-handler';
import notFound from '@/hono-app/middlewares/not-found';
import packageJSON from '@/package.json';
import { IHonoAppBindings, IHonoAppOpenAPI } from '@/types/hono';
import { OpenAPIHono } from '@hono/zod-openapi';
import { apiReference } from '@scalar/hono-api-reference';

// Configures the Open API
export const configureOpenAPI = (honoApp: IHonoAppOpenAPI) => {
  // For generating doc data
  honoApp.doc('/doc', {
    openapi: '3.0.0',
    info: {
      version: packageJSON.version,
      title: 'My API',
    },
  });

  // For generating the Actual documentation
  honoApp.get(
    '/reference',
    apiReference({
      layout: 'classic',
      url: '/api/doc',
      defaultHttpClient: {
        targetKey: 'js',
        clientKey: 'fetch',
      },
    })
  );
};

// Creates a route
export const createHonoRouter = () => {
  const app = new OpenAPIHono<IHonoAppBindings>({
    strict: false,
    defaultHook: (result, c) => {
      if (!result.success) {
        return globalErrorHandler(result?.error, c);
      }
    },
  });
  return app;
};

// Creates the app
export const createHonoApp = () => {
  const honoApp = createHonoRouter().basePath('/api');

  // Middlewares
  honoApp.onError(globalErrorHandler);
  honoApp.notFound(notFound);
  honoApp.use(customLogger);

  // Configuring the Oen API
  configureOpenAPI(honoApp);

  return honoApp;
};
