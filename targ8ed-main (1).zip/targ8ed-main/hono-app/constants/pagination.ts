export const defaultSortOrders = ['asc', 'desc'] as const;
