import {
  themeBorderRadiusMap,
  themeColorMap,
  themeModeMap,
} from '../constants/theme';

export type IThemeColor = keyof typeof themeColorMap;
export type IThemeMode = keyof typeof themeModeMap;
export type IThemeBorderRadius = keyof typeof themeBorderRadiusMap;
