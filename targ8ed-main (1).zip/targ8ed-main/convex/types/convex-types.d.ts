import { z } from 'zod';
import { Doc, Id } from '../_generated/dataModel';
import { MutationCtx, QueryCtx } from '../_generated/server';
import { permissionMethods, treeItemTypes } from '../constants/common';
import { convexResponseMetaZodSchema } from '../validations/common';

export type IConvexCtx = QueryCtx | MutationCtx;

export type IConvexResponseMeta = z.infer<typeof convexResponseMetaZodSchema>;
export interface IConvexResponse<T = undefined> {
  success: true;
  message: string;
  statusCode?: number;
  data?: T;
  meta?: IConvexResponseMeta;
  errorSources?: IConvexErrorSource[];
}

export interface IConvexErrorSource {
  path: string;
  message: string;
}

export type IConvexErrorResponse = Omit<
  IConvexResponse,
  'data' | 'meta' | 'success'
> & { success: false };

// Data types
export type IUser = Doc<'users'>;

export type IOrganization = Doc<'organizations'>;
export interface IOrgApplication extends Doc<'organizationApplications'> {
  application?: Omit<Doc<'applications'>, 'sidebar'> & { sidebar: undefined };
  organization?: Doc<'organizations'>;
}

export interface IOrgUser extends Doc<'organizationUsers'> {
  globalUser?: Doc<'users'>;
  organization?: Doc<'organizations'>;
}

export type IInvitation = Doc<'orgUserInvitations'>;

export interface IApplication extends Doc<'applications'> {
  sidebar: IConvexSidebarTreeItem[];
}

export interface ICurrentApplication extends IApplication {
  roles: IRole[];
}

export interface IUserApplication extends IApplication {
  roles: Id<'roles'>[] | Doc<'roles'>[];
  userId: Id<'users'>;
  organizationId: Id<'organizations'>;
}

export type IPermission = Doc<'permissions'>;
export type IPermissionMethod = (typeof permissionMethods)[number];
export interface IRole extends Doc<'roles'> {
  permissions: IPermission[];
}

export type ISidebarTreeItemType = (typeof treeItemTypes)[number];

interface ITreeItemCommon {
  id: string;
  type: ISidebarTreeItemType;
  label: string;
  children: (IConvexTreeSubmenuItem | IConvexTreeLinkItem)[];
  collapsed?: boolean;
}

export interface IConvexTreeGroupItem extends ITreeItemCommon {
  type: 'group';
}

export interface IConvexTreeSubmenuItem extends ITreeItemCommon {
  type: 'submenu';
  icon: string;
}

export interface IConvexTreeLinkItem extends ITreeItemCommon {
  type: 'link';
  icon: string;
  isDeleted?: boolean;
  moduleId: Id<'applicationModules'>;
  module?: Doc<'applicationModules'>;
}

export interface IConvexTreeSplitButtonItem extends ITreeItemCommon {
  type: 'split-button';
  icon: string;
  isDeleted?: boolean;
  moduleId: Id<'applicationModules'>;
  module?: Doc<'applicationModules'>;
}

export interface IConvexTreeSeparatorItem extends ITreeItemCommon {
  type: 'separator';
  icon: undefined;
}

export type IConvexSidebarTreeItem =
  | IConvexTreeGroupItem
  | IConvexTreeSubmenuItem
  | IConvexTreeLinkItem
  | IConvexTreeSplitButtonItem
  | IConvexTreeSeparatorItem;
