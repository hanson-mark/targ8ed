import { PropertyValidators } from 'convex/values';
import { z } from 'zod';
import { IConvexCtx } from '../../types/convex-types';
import { handleConvexZodError } from '../errorHandlers';
import { generateConvexErrorResponse } from '../generateResponse';

export const convexPublicMiddleware = <
  IArgs extends PropertyValidators,
  ISchema extends z.ZodTypeAny | undefined,
  ICtx extends IConvexCtx,
  IReturn,
>(config: {
  args: IArgs;
  zodSchema: ISchema;
  handler: (
    ctx: ICtx,
    args: ISchema extends z.ZodTypeAny ? z.infer<ISchema> : object
  ) => IReturn | Promise<IReturn>;
}) => {
  const { args: argsFields, zodSchema, handler } = config;
  return {
    args: argsFields,
    handler: async (
      ctx: ICtx,
      args: unknown
    ): Promise<IReturn | ReturnType<typeof generateConvexErrorResponse>> => {
      // Step 1: Zod validation if schema is provided
      if (zodSchema) {
        const result = zodSchema.safeParse(args);

        if (!result.success) {
          const zodError = handleConvexZodError(result.error);
          return zodError;
        }
        return handler(
          ctx,
          result.data as ISchema extends z.ZodTypeAny
            ? z.infer<ISchema>
            : object
        );
      }

      // Step 2: No schema, pass args as-is
      return handler(
        ctx,
        args as ISchema extends z.ZodTypeAny ? z.infer<ISchema> : object
      );
    },
  };
};
