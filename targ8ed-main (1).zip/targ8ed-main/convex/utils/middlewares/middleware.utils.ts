import { Id } from '../../_generated/dataModel';
import { MutationCtx, QueryCtx } from '../../_generated/server';
import {
  getApplicationRoles,
  getPermissionByPermissionKey,
} from '../../functions/apps/global/applications/applications.utils';
import { generateConvexErrorResponse } from '../generateResponse';
import HttpStatusCodes from '../httpStatusCode';

interface ICheckUserAccessToApplication {
  ctx: QueryCtx | MutationCtx;
  applicationKey: string;
  currentOrgId: Id<'organizations'>;
  permissionKey: string;
  currentUserId: Id<'users'>;
}

interface ICheckUserAccessToOrganization {
  ctx: QueryCtx | MutationCtx;
  currentUserId: Id<'users'>;
  currentOrgId?: Id<'organizations'>;
  currentOrgSubdomain?: string;
}

// Check application user's access
export const checkUserAccessToApplicationOrError = async ({
  ctx,
  applicationKey,
  currentOrgId,
  currentUserId,
  permissionKey,
}: ICheckUserAccessToApplication) => {
  if (!permissionKey || !applicationKey) {
    const missingKeys = [
      ...(!permissionKey ? ['permissionKey'] : []),
      ...(!applicationKey ? ['applicationKey'] : []),
    ].join(' and ');
    return generateConvexErrorResponse(
      HttpStatusCodes.BAD_REQUEST,
      `Missing required options: ${missingKeys}`
    );
  }

  const application = await ctx.db
    .query('applications')
    .withIndex('by_key', (q) => q.eq('key', applicationKey))
    .first();

  if (!application) {
    return generateConvexErrorResponse(
      HttpStatusCodes.BAD_REQUEST,
      `Application with key '${applicationKey}' was not found.`
    );
  }

  const userApplication = await ctx.db
    .query('userApplications')
    .withIndex('by_user_organization_application', (q) =>
      q
        .eq('userId', currentUserId)
        .eq('organizationId', currentOrgId)
        .eq('applicationId', application?._id)
    )
    .first();

  if (!userApplication) {
    return generateConvexErrorResponse(
      HttpStatusCodes.FORBIDDEN,
      `Access denied: You do not have access to the application '${applicationKey}'.`
    );
  }

  const roles = await getApplicationRoles(ctx, userApplication?.applicationId);
  const rolesMap = new Map(roles?.map((role) => [role?._id, role]));

  const userRoles = userApplication?.roles?.map((roleId) =>
    rolesMap.get(roleId)
  );
  const isAdmin = userRoles?.some((role) => role?.isAdminRole);
  const userPermissions = userRoles
    ?.flatMap((item) => item?.permissions || [])
    ?.filter((p): p is Id<'permissions'> => typeof p === 'string');

  const permission = await getPermissionByPermissionKey(
    ctx,
    permissionKey,
    application?._id
  );

  if (!permission) {
    return generateConvexErrorResponse(
      HttpStatusCodes.BAD_REQUEST,
      `Permission key "${permissionKey}" not found in application "${application?.name || applicationKey}"`
    );
  }

  const isPermissionGranted =
    permission !== null && userPermissions
      ? userPermissions.includes(permission._id)
      : false;

  const hasPermission = isAdmin || isPermissionGranted;

  if (!hasPermission) {
    return generateConvexErrorResponse(
      HttpStatusCodes.FORBIDDEN,
      'You do not have permission'
    );
  }

  return { ...userApplication, key: application?.key, isAdmin };
};

// Check organization user's access
export const checkUserAccessToOrganizationOrError = async ({
  ctx,
  currentUserId,
  currentOrgId,
  currentOrgSubdomain,
}: ICheckUserAccessToOrganization) => {
  const refinedSubdomain =
    currentOrgSubdomain && (currentOrgSubdomain || '')?.length > 0
      ? currentOrgSubdomain
      : undefined;

  const orgId =
    currentOrgId && currentOrgId?.length > 0 ? currentOrgId : undefined;

  if (!refinedSubdomain && !orgId) {
    return generateConvexErrorResponse(
      HttpStatusCodes.BAD_REQUEST,
      `Invalid request: Either 'organizationId' or 'subdomain' must be provided in arguments.`
    );
  }

  const organization =
    orgId && orgId?.length > 0
      ? await ctx.db.get(orgId)
      : await ctx.db
          .query('organizations')
          .withIndex('by_subdomain', (q) =>
            q.eq('subdomain', refinedSubdomain as string)
          )
          .first();

  if (!organization) {
    return generateConvexErrorResponse(
      HttpStatusCodes.BAD_REQUEST,
      'Invalid request for the action. Organization not found'
    );
  }

  const orgUser = await ctx.db
    .query('organizationUsers')
    .withIndex('by_user_organization', (q) =>
      q
        .eq('userId', currentUserId as Id<'users'>)
        .eq('organizationId', organization._id)
    )
    .first();

  if (!orgUser) {
    return generateConvexErrorResponse(
      HttpStatusCodes.FORBIDDEN,
      `Access denied: You are not a member of the selected organization.`
    );
  }

  return {
    organization,
    orgUser,
  };
};
