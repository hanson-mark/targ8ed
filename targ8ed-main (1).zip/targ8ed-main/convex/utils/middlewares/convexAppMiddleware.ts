import { PropertyValidators, v } from 'convex/values';
import { z } from 'zod';
import { Doc, Id } from '../../_generated/dataModel';
import { getCurrentUser } from '../../functions/apps/global/users/users.utils';
import { IConvexCtx } from '../../types/convex-types';
import { orgIdZodSchema } from '../../validations/common';
import { handleConvexZodError } from '../errorHandlers';
import { generateConvexErrorResponse } from '../generateResponse';
import HttpStatusCodes from '../httpStatusCode';
import {
  checkUserAccessToApplicationOrError,
  checkUserAccessToOrganizationOrError,
} from './middleware.utils';

type IAccessType = 'org-admin' | 'org-user';

interface IMiddlewareCurrentUser extends Doc<'users'> {
  organization: Doc<'organizations'>;
  orgUser: Doc<'organizationUsers'>;
  appUser: Doc<'userApplications'> & { key: string; isAdmin?: boolean };
}

interface IMiddlewareOptions {
  accessTypes?: IAccessType | IAccessType[];
  permissionKey: string;
  applicationKey: string;
}

const notAuthorized = (isLoggedIn?: boolean) => {
  return generateConvexErrorResponse(
    isLoggedIn ? HttpStatusCodes.FORBIDDEN : HttpStatusCodes.UNAUTHORIZED,
    isLoggedIn
      ? 'You are not authorized to perform this action.'
      : 'Authentication required. Please log in to continue.'
  );
};

export const convexAppMiddleware = <
  IArgs extends PropertyValidators,
  ISchema extends z.ZodTypeAny,
  ICtx extends IConvexCtx,
  IReturn,
>(config: {
  inputs: IArgs;
  zodSchema: ISchema;
  options: IMiddlewareOptions;
  handler: (
    ctx: ICtx,
    inputs: z.infer<ISchema>,
    currentUser: IMiddlewareCurrentUser
  ) => Promise<IReturn>;
}) => {
  const { inputs, zodSchema, options, handler } = config;

  // Step 1: Formatting initial arguments and zod validation schema
  // Convert access types to array for easier handling
  const accessTypes = options?.accessTypes || ['org-user'];
  const accessList = Array.isArray(accessTypes) ? accessTypes : [accessTypes];

  // Formatting the arguments fields for the middleware
  const formattedArgsFields = {
    currentOrgId: v.id('organizations'),
    inputs: v.object(inputs),
  };

  // Formatting zod schema
  const formattedZodSchema = z.object({
    currentOrgId: orgIdZodSchema,
    inputs: zodSchema,
  });

  return {
    args: formattedArgsFields,
    handler: async (
      ctx: ICtx,
      args: unknown
    ): Promise<IReturn | ReturnType<typeof generateConvexErrorResponse>> => {
      // Step 2: Validating arguments via zod
      const zodResult = formattedZodSchema.safeParse(args);
      if (!zodResult.success) {
        const zodError = handleConvexZodError(zodResult.error);
        return zodError;
      }

      // Step 3: Auth Check
      const user: Doc<'users'> | undefined = await getCurrentUser(ctx);

      if (!user || !user?._id || user.status !== 'active') {
        return notAuthorized();
      }

      // Organization-related checks
      const orgAccessResult = await checkUserAccessToOrganizationOrError({
        ctx,
        currentUserId: user._id,
        currentOrgId: (args as { currentOrgId: Id<'organizations'> })
          ?.currentOrgId,
      });

      // Returning error if no userId found
      if ('message' in orgAccessResult) {
        return orgAccessResult;
      }

      const isAuthorized =
        (accessList.includes('org-admin') &&
          orgAccessResult?.orgUser.isOrgAdmin) ||
        (accessList.includes('org-user') && orgAccessResult?.orgUser._id);

      if (!isAuthorized) {
        return notAuthorized(true);
      }

      const applicationUserResult = await checkUserAccessToApplicationOrError({
        ctx,
        currentUserId: user._id,
        permissionKey: options.permissionKey,
        applicationKey: options.applicationKey,
        currentOrgId: (args as { currentOrgId: Id<'organizations'> })
          ?.currentOrgId,
      });

      // Returning error if no userId found
      if (!('userId' in applicationUserResult)) {
        return applicationUserResult;
      }

      const currentUser: IMiddlewareCurrentUser = {
        ...user,
        organization: orgAccessResult?.organization,
        orgUser: orgAccessResult?.orgUser,
        appUser: applicationUserResult,
      };

      // Step 4: Calling handler
      return handler(ctx, zodResult.data.inputs || {}, currentUser);
    },
  };
};
