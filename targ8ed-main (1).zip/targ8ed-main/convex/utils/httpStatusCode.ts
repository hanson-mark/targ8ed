import httpStatus from 'http-status';

const HttpStatusCodes = httpStatus;

export default HttpStatusCodes;
