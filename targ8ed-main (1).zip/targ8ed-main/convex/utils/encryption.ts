// utils/encryption.ts

const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

const ALGORITHM = { name: 'AES-GCM', length: 256 };

// ⚠️ Store this in Convex env vars: npx convex env set ENCRYPTION_SECRET <base64key>
// Generate once: crypto.getRandomValues(new Uint8Array(32)) and base64 encode it
const SECRET_KEY_BASE64 = process.env.ENCRYPTION_SECRET!;

async function getKey(): Promise<CryptoKey> {
  const rawKey = Uint8Array.from(atob(SECRET_KEY_BASE64), (c) =>
    c.charCodeAt(0)
  );
  return crypto.subtle.importKey('raw', rawKey, ALGORITHM, false, [
    'encrypt',
    'decrypt',
  ]);
}

export async function encryptJSON(
  data: Record<string, unknown>
): Promise<string> {
  const key = await getKey();
  const iv = crypto.getRandomValues(new Uint8Array(12)); // 96-bit IV recommended for AES-GCM
  const encoded = textEncoder.encode(JSON.stringify(data));

  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    encoded
  );

  // Pack iv + ciphertext into base64 string
  const combined = new Uint8Array(iv.length + ciphertext.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(ciphertext), iv.length);

  return btoa(String.fromCharCode(...combined));
}

export async function decryptJSON<T = unknown>(encrypted: string): Promise<T> {
  const key = await getKey();
  const combined = Uint8Array.from(atob(encrypted), (c) => c.charCodeAt(0));

  const iv = combined.slice(0, 12);
  const ciphertext = combined.slice(12);

  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    ciphertext
  );

  return JSON.parse(textDecoder.decode(decrypted)) as T;
}
