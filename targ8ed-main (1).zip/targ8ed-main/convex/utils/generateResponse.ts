import {
  IConvexErrorResponse,
  IConvexErrorSource,
  IConvexResponse,
  IConvexResponseMeta,
} from '../types/convex-types';

export const generateConvexErrorResponse = (
  statusCode: number,
  message: string,
  errorSources?: IConvexErrorSource[]
): IConvexErrorResponse => {
  const response: IConvexErrorResponse = {
    success: false,
    statusCode,
    message,
    errorSources,
  };
  if (errorSources && Array.isArray(errorSources) && errorSources?.length) {
    return response;
  } else {
    return {
      ...response,
      errorSources: [{ message, path: '' }],
    };
  }
};

export const generateConvexSuccessResponse = <T>(
  statusCode: number,
  message: string,
  data: T,
  meta?: IConvexResponseMeta
): IConvexResponse<T> => {
  return {
    success: true,
    statusCode,
    message,
    data,
    meta,
  };
};
