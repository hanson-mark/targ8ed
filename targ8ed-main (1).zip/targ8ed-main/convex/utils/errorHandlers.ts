import { ZodError } from 'zod';
import { IConvexErrorResponse } from '../types/convex-types';
import { generateConvexErrorResponse } from './generateResponse';
import HttpStatusCodes from './httpStatusCode';

// Handles zod error
export const handleConvexZodError = (error: ZodError): IConvexErrorResponse => {
  const issues = error?.issues ?? [];

  // Get all invalid field paths
  const fieldNames = issues.map(
    (item) => item?.path?.[item?.path?.length - 1] as string
  );

  // Deduplicate field names
  const uniqueFields = Array.from(new Set(fieldNames));

  // Compose summary message
  let message = 'Invalid input';

  if (issues.length === 1) {
    message = issues[0].message;
  } else if (uniqueFields.length === 1) {
    message = `Invalid input in '${uniqueFields[0]}' field.`;
  } else if (uniqueFields.length === 2) {
    message = `Invalid inputs in '${uniqueFields[0]}' and '${uniqueFields[1]}' fields.`;
  } else if (uniqueFields.length > 2) {
    message = `Invalid inputs in '${uniqueFields[0]}', '${uniqueFields[1]}', and ${uniqueFields.length - 2} more fields.`;
  }

  // Detailed sources
  const errorSources = issues.map((item) => ({
    path: item?.path?.join('.') || '',
    message: item?.message as string,
  }));

  return generateConvexErrorResponse(
    HttpStatusCodes.BAD_REQUEST,
    message,
    errorSources
  );
};
