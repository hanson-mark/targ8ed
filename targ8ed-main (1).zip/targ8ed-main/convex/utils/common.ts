import { Id } from '../_generated/dataModel';
import { MutationCtx, QueryCtx } from '../_generated/server';

export const getFormattedImageURL = async (
  ctx: MutationCtx | QueryCtx,
  imageId?: Id<'_storage'>,
  fallbackImageURL?: string
) => {
  const imageURL =
    imageId && imageId?.length > 2
      ? await ctx.storage.getUrl(imageId)
      : fallbackImageURL || '';

  return imageURL || '';
};

export const removeFileFromStorage = async <ICtx extends MutationCtx>(
  ctx: ICtx,
  imageId?: Id<'_storage'>
) => {
  if (imageId && imageId?.length > 2) {
    try {
      await ctx.storage.delete(imageId);
      return;
    } catch {
      return;
    }
  }
};
