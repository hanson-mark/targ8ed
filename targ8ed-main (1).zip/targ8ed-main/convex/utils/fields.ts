import { v } from 'convex/values';

export const statusField = v.union(v.literal('active'), v.literal('inactive'));

export const orgUserRoleField = v.union(v.literal('admin'), v.literal('user'));
export const themeColorField = v.union(
  v.literal('theme-default'),
  v.literal('theme-red'),
  v.literal('theme-rose'),
  v.literal('theme-orange'),
  v.literal('theme-green'),
  v.literal('theme-blue'),
  v.literal('theme-yellow'),
  v.literal('theme-violet')
);
export const themeModeField = v.union(v.literal('light'), v.literal('dark'));
export const themeBorderRadiusField = v.union(
  v.literal('radius-default'),
  v.literal('radius-0'),
  v.literal('radius-30'),
  v.literal('radius-50'),
  v.literal('radius-75'),
  v.literal('radius-100')
);

export const permissionMethodField = v.union(
  v.literal('create'),
  v.literal('read'),
  v.literal('update'),
  v.literal('delete')
);

export const assignedApplicationsField = v.array(
  v.object({ applicationId: v.id('applications'), roleId: v.id('roles') })
);

export const deletionTrackerChecksField = v.array(
  v.object({
    name: v.string(),
    isDone: v.boolean(),
  })
);
