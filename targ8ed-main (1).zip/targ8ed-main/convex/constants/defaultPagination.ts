export const DEFAULT_PAGE_LIMIT = 20;
export const DEFAULT_SORT_ORDER = 'asc';
