export const APPLICATION_KEY_MIN_LENGTH = 3;
export const APPLICATION_KEY_MAX_LENGTH = 15;

export const RESERVED_APPLICATION_KEY = [
  'users',
  'applications',
  'organizations',
  'settings',
  'profile',
  'billing',
];

export const APPLICATION_KEYS = {
  global: 'global', //! ⚠️ DO NOT CHANGE IT. This key is critical for the framework.
  quickNote: 'quickNote',
} as const;
