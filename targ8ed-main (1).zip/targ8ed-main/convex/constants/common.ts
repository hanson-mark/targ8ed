export const DEFAULT_STATUS = ['active', 'inactive'] as const;
export const orgUserRoles = ['admin', 'user'] as const;
export const treeItemTypes = [
  'group',
  'submenu',
  'link',
  'split-button',
  'separator',
] as const;
export const invitationStatues = ['pending', 'expired'] as const;
export const permissionMethods = [
  'create',
  'read',
  'update',
  'delete',
] as const;
export const lastOpenedApplicationKeyName = 'mft_last_opened_app';
