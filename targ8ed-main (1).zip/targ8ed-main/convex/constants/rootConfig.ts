import { APPLICATION_KEYS } from './applicationKey';

const SITE_NAME = 'Targ8ed' as const;
export const ROOT_CONFIG = {
  site: {
    name: SITE_NAME, // Change this to your site’s name
    title: `${SITE_NAME} - Multi-tenant SaaS Starter Kit`, // Page title
    description: `${SITE_NAME} is a multi-tenant SaaS starter kit built with Next.js.`, // Meta description
  },
  org: {
    initialName: 'Global Org',
    subdomain: 'global' as const, //! ⚠️ DO NOT CHANGE IT. This subdomain is critical for the framework.
    description: 'The root organization for all tenants',
  },
  application: {
    initialName: 'Global App',
    key: APPLICATION_KEYS?.global, //! ⚠️ DO NOT CHANGE IT. This key is critical for the framework.
    description: 'The root application for all tenants',
  },
};
