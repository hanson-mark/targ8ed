import { IThemeBorderRadius, IThemeColor, IThemeMode } from '../types/theme';

// Theme Color Map & Options
export const themeColorMap = {
  'theme-default': { id: 'theme-default', label: 'Default' },
  'theme-red': { id: 'theme-red', label: 'Red' },
  'theme-rose': { id: 'theme-rose', label: 'Rose' },
  'theme-orange': { id: 'theme-orange', label: 'Orange' },
  'theme-green': { id: 'theme-green', label: 'Green' },
  'theme-blue': { id: 'theme-blue', label: 'Blue' },
  'theme-yellow': { id: 'theme-yellow', label: 'Yellow' },
  'theme-violet': { id: 'theme-violet', label: 'Violet' },
} as const;

export const themeColorOptions = Object.values(themeColorMap);
export const themeColors = Object.keys(themeColorMap) as [IThemeColor];

// Theme names for next-themes
export const themeColorsWithDarkLight = themeColors?.reduce((arr, color) => {
  return [...(arr || []), color, `${color}_dark`];
}, [] as string[]);

// Theme Modes Map & Options
export const themeModeMap = {
  light: { id: 'light', label: 'Light' },
  dark: { id: 'dark', label: 'Dark' },
};

export const themeModeOptions = Object.values(themeModeMap);
export const themeModes = Object.keys(themeModeMap) as [IThemeMode];

// Theme Border Radius Map & Options
export const themeBorderRadiusMap = {
  'radius-default': { id: 'radius-default', label: 'Default' },
  'radius-0': { id: 'radius-0', label: '0' },
  'radius-30': { id: 'radius-30', label: '0.3' },
  'radius-50': { id: 'radius-50', label: '0.5' },
  'radius-75': { id: 'radius-75', label: '0.75' },
  'radius-100': { id: 'radius-100', label: '1' },
} as const;

export const themeBorderRadiusOptions = Object.values(themeBorderRadiusMap);
export const themeBorderRadiuses = Object.keys(themeBorderRadiusMap) as [
  IThemeBorderRadius,
];

export const themeBorderRadiusName = 'mtf_border_radius';
