import { v } from 'convex/values';
import { z } from 'zod';
import { Id } from '../../../_generated/dataModel';
import { mutation, query } from '../../../_generated/server';
import { APPLICATION_KEYS } from '../../../constants/applicationKey';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../utils/generateResponse';
import HttpStatusCodes from '../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../utils/middlewares/convexAppMiddleware';

// Middleware options
const applicationKey = APPLICATION_KEYS.quickNote;

// Functions
export const createNote = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createNote' },
    inputs: {
      title: v.string(),
      content: v.string(),
    },
    zodSchema: z.object({
      title: z.string().min(3, 'Minimum 3 character is required'),
      content: z.string().min(3, 'Minimum 3 character is required'),
    }),
    handler: async (ctx, args, currentUser) => {
      const noteId = await ctx.db.insert('quickNote', {
        title: args.title,
        content: args.content,
        userId: currentUser?._id,
        organizationId: currentUser?.organization?._id,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Added the note',
        noteId
      );
    },
  })
);

export const readAllNotes = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readAllNotes' },
    inputs: {},
    zodSchema: z.object({}),
    handler: async (ctx, args, currentUser) => {
      const notes = await ctx.db
        .query('quickNote')
        .withIndex('by_organization_userId', (q) =>
          q
            .eq('organizationId', currentUser?.organization?._id)
            .eq('userId', currentUser?._id)
        )
        .collect();

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved notes successfully',
        notes
      );
    },
  })
);

export const updateNote = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateNote' },
    inputs: {
      noteId: v.id('quickNote'),
      title: v.string(),
      content: v.string(),
    },
    zodSchema: z.object({
      title: z.string().min(3, 'Minimum 3 character is required'),
      content: z.string().min(3, 'Minimum 3 character is required'),
      noteId: z.string() as unknown as z.ZodType<Id<'quickNote'>>,
    }),
    handler: async (ctx, args) => {
      const existingNote = await ctx.db.get(args.noteId);
      if (!existingNote) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Note not found'
        );
      }

      await ctx.db.patch(args.noteId, {
        title: args.title,
        content: args.content,
        updatedAt: Date.now(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Note updated successfully',
        args?.noteId
      );
    },
  })
);

export const deleteNote = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteNote' },
    inputs: { noteId: v.id('quickNote') },
    zodSchema: z.object({
      noteId: z.string() as unknown as z.ZodType<Id<'quickNote'>>,
    }),
    handler: async (ctx, args) => {
      const note = await ctx.db.get(args.noteId);
      if (!note) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Note not found'
        );
      }

      await ctx.db.delete(args.noteId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Note deleted successfully',
        true
      );
    },
  })
);
