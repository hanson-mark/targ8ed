import { v } from 'convex/values';
import { internal } from '../../../../_generated/api';
import {
  internalAction,
  internalMutation,
} from '../../../../_generated/server';

const argsFields = {
  organizationId: v.id('organizations'),
  trackerId: v.id('deletionTracker'),
};

// Internal Mutation: Removes relationship with organization while removing organization
export const removeOrgRelations = internalMutation({
  args: { organizationId: v.id('organizations') },
  handler: async (ctx, args) => {
    // Step-00: Preparing required data
    const orgInternalAPI =
      internal.functions.apps.global.organizations.internal;
    // Schedular functions object
    const schedularFNs = {
      orgApplications: orgInternalAPI.removeAllOrgApplications,
      orgUserApplications: orgInternalAPI.removeAllOrgUserApplications,
      orgInvitations: orgInternalAPI.removeAllOrgInvitations,
      orgUsers: orgInternalAPI.removeAllOrgUsers,
      orgApplicationData: orgInternalAPI.removeAllOrgApplicationData,
    } as const;

    // Step-01: Start Tracking Deletion with scheduling
    const schedularFnsWithTrackers = await Promise.all(
      Object.keys(schedularFNs)?.map(async (fnName) => ({
        fnName: fnName as keyof typeof schedularFNs,
        trackingId: await ctx.runMutation(
          internal.functions.deletionTracker.createTracker,
          { groupKey: args?.organizationId, name: fnName }
        ),
      }))
    );

    await Promise.all(
      schedularFnsWithTrackers.map((item, index) =>
        ctx.scheduler.runAfter(10 + index * 100, schedularFNs[item?.fnName], {
          ...args,
          trackerId: item?.trackingId,
        })
      )
    );

    // Step-07: Removing organization
    await ctx.scheduler.runAfter(
      2000,
      orgInternalAPI.checkDeletionTrackerAndRemoveOrg,
      {
        organizationId: args?.organizationId,
      }
    );
  },
});

export const removeAllOrgApplications = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const orgApplications = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q.eq('organizationId', args?.organizationId)
        )
        .collect();

      const orgAppIDs = orgApplications?.map((item) => item?._id);
      // Removes all org applications
      await Promise.all(orgAppIDs?.map((orgAppID) => ctx.db.delete(orgAppID)));

      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllOrgUserApplications = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const userApplications = await ctx.db
        .query('userApplications')
        .withIndex('by_organization_application', (q) =>
          q.eq('organizationId', args.organizationId)
        )
        .collect();
      const userAppIDs = userApplications?.map((item) => item?._id);
      // Removes user applications
      await Promise.all(
        userAppIDs?.map((userAppID) => ctx.db.delete(userAppID))
      );

      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllOrgInvitations = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const orgInvitations = await ctx.db
        .query('orgUserInvitations')
        .withIndex('by_organizationId_email', (q) =>
          q.eq('organizationId', args?.organizationId)
        )
        .collect();
      // Removes all org user invitations
      await Promise.all(
        orgInvitations?.map((item) => ctx.db.delete(item?._id))
      );

      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllOrgUsers = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const orgUsers = await ctx.db
        .query('organizationUsers')
        .withIndex('by_organization_isOrgAdmin', (q) =>
          q.eq('organizationId', args?.organizationId)
        )
        .collect();
      const orgUserIDs = orgUsers?.map((item) => item?._id);

      // Removes all org users
      await Promise.all(
        orgUserIDs?.map((orgUserID) => ctx.db.delete(orgUserID))
      );

      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllOrgApplicationData = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const quickNotes = await ctx.db
        .query('quickNote')
        .withIndex('by_organization_userId', (q) =>
          q.eq('organizationId', args?.organizationId)
        )
        .collect();
      await Promise.all(quickNotes.map((item) => ctx.db.delete(item?._id)));

      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(internal.functions.deletionTracker.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeOrg = internalMutation({
  args: {
    organizationId: v.id('organizations'),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args?.organizationId);
  },
});

export const checkDeletionTrackerAndRemoveOrg = internalAction({
  args: {
    organizationId: v.id('organizations'),
  },
  handler: async (ctx, args) => {
    const sleep = (ms: number) =>
      new Promise((resolve) => setTimeout(resolve, ms));

    const getTrackersData = async () => {
      const trackersData = await ctx.runQuery(
        internal.functions.deletionTracker.getTrackersByKey,
        { groupKey: args?.organizationId }
      );

      return trackersData;
    };

    let retries = 0;
    const MAX_RETRIES = 60; // 5 minutes ( 60 * 5000 milliseconds)
    while (retries < MAX_RETRIES) {
      const trackersData = await getTrackersData();
      const isAllDone = trackersData?.every((item) => item?.status === 'done');

      if (isAllDone) {
        await ctx.runMutation(
          internal.functions.apps.global.organizations.internal.removeOrg,
          { organizationId: args?.organizationId }
        );
        await ctx.runMutation(
          internal.functions.deletionTracker.removeTrackers,
          { groupKey: args?.organizationId }
        );
        break;
      }

      retries++;
      await sleep(5000);
    }
  },
});
