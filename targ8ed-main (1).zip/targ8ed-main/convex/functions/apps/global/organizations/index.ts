import { v } from 'convex/values';
import { z } from 'zod';
import { internal } from '../../../../_generated/api';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { DEFAULT_STATUS } from '../../../../constants/common';
import { DEFAULT_PAGE_LIMIT } from '../../../../constants/defaultPagination';
import { ROOT_CONFIG } from '../../../../constants/rootConfig';
import {
  themeBorderRadiuses,
  themeColors,
  themeModes,
} from '../../../../constants/theme';
import {
  getFormattedImageURL,
  removeFileFromStorage,
} from '../../../../utils/common';
import {
  statusField,
  themeBorderRadiusField,
  themeColorField,
  themeModeField,
} from '../../../../utils/fields';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import { convexPublicMiddleware } from '../../../../utils/middlewares/convexPublicMiddleware';
import {
  convexPaginationQueryZodSchema,
  descriptionZodSchema,
  nameZodSchema,
  orgIdZodSchema,
  storageIdZodSchema,
  subdomainZodSchema,
} from '../../../../validations/common';
import { getOrgBySubDomainOrError } from './organizations.utils';
import {
  updateOrganizationNameByOrgAdminZodSchema,
  updateOrganizationNameZodSchema,
} from './organizations.validations';

const applicationKey = APPLICATION_KEYS.global;

// Query: Checks subdomain availability
export const readSubdomainAvailability = query(
  convexPublicMiddleware({
    args: { subdomain: v.string() },
    zodSchema: z.object({ subdomain: subdomainZodSchema }),
    handler: async (ctx, { subdomain }) => {
      const orgResult = await getOrgBySubDomainOrError(ctx, subdomain);

      const isAvailable = '_id' in orgResult ? false : true;

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        isAvailable ? 'Subdomain is not available' : 'Subdomain is available',
        isAvailable
      );
    },
  })
);

// Mutation: Create a organization
export const createOrganization = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createOrganization' },
    inputs: {
      name: v.string(),
      description: v.string(),
      subdomain: v.string(),
    },
    zodSchema: z.object({
      name: nameZodSchema,
      description: descriptionZodSchema,
      subdomain: subdomainZodSchema,
    }),
    handler: async (ctx, args, currentUser) => {
      const userId = currentUser?._id;

      if (!userId) {
        return generateConvexErrorResponse(
          HttpStatusCodes.UNAUTHORIZED,
          'You are unauthorized'
        );
      }

      const existing = await getOrgBySubDomainOrError(ctx, args?.subdomain);

      if ('_id' in existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'Subdomain already exists'
        );
      }

      const organizationId = await ctx.db.insert('organizations', {
        name: args?.name,
        description: args?.description,
        subdomain: args?.subdomain,

        // Theme
        themeColor: 'theme-default',
        themeMode: 'light',
        themeBorderRadius: 'radius-default',

        createdBy: currentUser?._id,
        status: 'active',
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Added organization successfully',
        organizationId
      );
    },
  })
);

// Query: Retrieving organization details
export const readOrganizationDetails = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readOrganizationDetails' },
    inputs: { organizationId: v.id('organizations') },
    zodSchema: z.object({ organizationId: orgIdZodSchema }),
    handler: async (ctx, { organizationId }) => {
      const organization = await ctx.db.get(organizationId);

      if (!organization) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Organization not found'
        );
      }

      const formattedOrg = {
        ...organization,
        image: await getFormattedImageURL(ctx, organization?.imageId, ''),
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Organizations retrieved successfully',
        formattedOrg
      );
    },
  })
);

// Query: Retrieve organization data by subdomain
export const readOrganizationDetailsBySubdomain = query(
  convexPublicMiddleware({
    args: { subdomain: v.string() },
    zodSchema: z.object({ subdomain: subdomainZodSchema }),
    handler: async (ctx, { subdomain }) => {
      const orgResult = await getOrgBySubDomainOrError(ctx, subdomain);

      if (!('_id' in orgResult)) {
        return orgResult;
      }

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Organization retrieved successfully.',
        orgResult
      );
    },
  })
);

// Query: Organizations retrieving
export const readOrganizations = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readOrganizations' },
    inputs: {
      limit: v.number(),
      cursor: v.optional(v.string()),
      sortOrder: v.union(v.literal('asc'), v.literal('desc')),
      search: v.optional(v.string()),
    },
    zodSchema: convexPaginationQueryZodSchema,
    handler: async (ctx, args) => {
      let organizationsQuery;
      const limit = args?.limit || DEFAULT_PAGE_LIMIT;

      if (args?.search) {
        organizationsQuery = ctx.db
          .query('organizations')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', args?.search || '')
          );
      } else {
        organizationsQuery = ctx.db
          .query('organizations')
          .order(args.sortOrder);
      }

      const result = await organizationsQuery.paginate({
        numItems: args.limit,
        cursor: args.cursor || null,
      });

      const meta = {
        limit,
        cursor: result?.continueCursor,
        sortOrder: args?.sortOrder,
        isLastPage: result?.isDone,
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved users successfully',
        result?.page,
        meta
      );
    },
  })
);

// Mutation: Update organization image id
export const updateOrganizationImageId = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateOrganizationImageId' },
    inputs: {
      organizationId: v.id('organizations'),
      imageId: v.id('_storage'),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      imageId: storageIdZodSchema,
    }),
    handler: async (ctx, { organizationId, imageId }) => {
      const existingOrg = await ctx.db.get(organizationId);

      if (existingOrg?.imageId) {
        await removeFileFromStorage(ctx, existingOrg?.imageId);
      }

      await ctx.db.patch(organizationId, {
        imageId: imageId,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Uploaded organization logo successfully',
        organizationId
      );
    },
  })
);

// Mutation: Update organization image id, accessible only by a org admin.
export const updateOrganizationImageIdByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { imageId: v.id('_storage') },
    zodSchema: z.object({ imageId: storageIdZodSchema }),
    handler: async (ctx, { imageId }, currentUser) => {
      const organizationId = currentUser.organization._id;
      const existingOrg = await ctx.db.get(organizationId);

      if (existingOrg?.imageId) {
        await removeFileFromStorage(ctx, existingOrg?.imageId);
      }

      await ctx.db.patch(organizationId, {
        imageId: imageId,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Uploaded organization logo successfully',
        organizationId
      );
    },
  })
);

// Mutation: Updates name or description of organization
export const updateOrganizationNameOrDescription = mutation(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'updateOrganizationNameOrDescription',
    },
    inputs: {
      organizationId: v.id('organizations'),
      name: v.optional(v.string()),
      description: v.optional(v.string()),
    },
    zodSchema: updateOrganizationNameZodSchema,
    handler: async (ctx, { organizationId, name, description }) => {
      const data = {
        ...(name ? { name } : {}),
        ...(description ? { description } : {}),
      };

      const hasUpdatableFields = Object.keys(data)?.length > 0;

      if (!hasUpdatableFields) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'Please enter name or description'
        );
      }

      await ctx.db.patch(organizationId, {
        ...data,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        `Successfully updated the field ${Object.keys(data)?.join(' and ')}`,
        organizationId
      );
    },
  })
);

// Mutation: Updates name or description of organization, accessible only by a org admin.
export const updateOrganizationNameOrDescriptionByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      name: v.optional(v.string()),
      description: v.optional(v.string()),
    },
    zodSchema: updateOrganizationNameByOrgAdminZodSchema,
    handler: async (ctx, { name, description }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const data = {
        ...(name ? { name } : {}),
        ...(description ? { description } : {}),
      };

      const hasUpdatableFields = Object.keys(data)?.length > 0;

      if (!hasUpdatableFields) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'Please enter name or description'
        );
      }

      await ctx.db.patch(organizationId, {
        ...data,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        `Successfully updated the field ${Object.keys(data)?.join(' and ')}`,
        organizationId
      );
    },
  })
);

// Mutation: Changes organization status
export const updateOrganizationStatus = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateOrganizationStatus' },
    inputs: { organizationId: v.id('organizations'), status: statusField },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      status: z.enum(DEFAULT_STATUS),
    }),
    handler: async (ctx, { organizationId, status }) => {
      const orgData = await ctx.db.get(organizationId);

      if (orgData?.subdomain === ROOT_CONFIG.org.subdomain) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          "You can't change status of root organization"
        );
      }

      await ctx.db.patch(organizationId, {
        status,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Changed organization status successfully',
        organizationId
      );
    },
  })
);

// Mutation: Changes the theme of an organization
export const updateOrgThemeConfig = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateOrgThemeConfig' },
    inputs: {
      organizationId: v.id('organizations'),
      themeColor: themeColorField,
      themeMode: themeModeField,
      themeBorderRadius: themeBorderRadiusField,
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      themeColor: z.enum(themeColors),
      themeMode: z.enum(themeModes),
      themeBorderRadius: z.enum(themeBorderRadiuses),
    }),
    handler: async (ctx, args) => {
      const orgId = args?.organizationId;

      await ctx.db.patch(orgId, {
        themeColor: args.themeColor,
        themeMode: args.themeMode,
        themeBorderRadius: args.themeBorderRadius,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Changed theme successfully',
        orgId
      );
    },
  })
);

// Mutation: Changes the theme of an organization, accessible only by a org admin.
export const updateOrgThemeConfigByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      themeColor: themeColorField,
      themeMode: themeModeField,
      themeBorderRadius: themeBorderRadiusField,
    },
    zodSchema: z.object({
      themeColor: z.enum(themeColors),
      themeMode: z.enum(themeModes),
      themeBorderRadius: z.enum(themeBorderRadiuses),
    }),
    handler: async (ctx, args, currentUser) => {
      const orgId = currentUser?.organization?._id;

      await ctx.db.patch(orgId, {
        themeColor: args.themeColor,
        themeMode: args.themeMode,
        themeBorderRadius: args.themeBorderRadius,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Changed theme successfully',
        orgId
      );
    },
  })
);

// Mutation: Removes an organization
export const deleteOrganization = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteOrganization' },
    inputs: { organizationId: v.id('organizations') },
    zodSchema: z.object({ organizationId: orgIdZodSchema }),
    handler: async (ctx, { organizationId }) => {
      const existing = await ctx.db.get(organizationId);

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'No organization found to delete'
        );
      }

      if (existing?.subdomain === ROOT_CONFIG.org.subdomain) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'You can not delete the root organization'
        );
      }

      // Updating organization's "isDeleting" flag
      await ctx.db.patch(organizationId, { isDeleting: true });

      // Running internal mutation to delete org & it's relationships
      await ctx.runMutation(
        internal.functions.apps.global.organizations.internal
          .removeOrgRelations,
        { organizationId }
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        "Removed the organization and it's relations",
        true
      );
    },
  })
);
