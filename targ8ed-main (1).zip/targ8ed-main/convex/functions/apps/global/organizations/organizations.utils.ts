import { Doc, Id } from '../../../../_generated/dataModel';
import { MutationCtx, QueryCtx } from '../../../../_generated/server';
import { IConvexErrorResponse } from '../../../../types/convex-types';
import { getFormattedImageURL } from '../../../../utils/common';
import { generateConvexErrorResponse } from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';

export const getOrgBySubDomainOrError = async (
  ctx: QueryCtx | MutationCtx,
  subdomain: string
): Promise<Doc<'organizations'> | IConvexErrorResponse> => {
  const organization = await ctx.db
    .query('organizations')
    .withIndex('by_subdomain', (q) => q.eq('subdomain', subdomain))
    .first();

  if (!organization) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'No organization found'
    );
  }

  const formattedOrg = {
    ...organization,
    image: await getFormattedImageURL(ctx, organization?.imageId, ''),
  };

  return formattedOrg;
};

export const getUserOrganizationList = async (
  ctx: QueryCtx | MutationCtx,
  userId: Id<'users'>
) => {
  const userInOrganizations = await ctx.db
    .query('organizationUsers')
    .withIndex('by_user_organization', (q) => q.eq('userId', userId))
    .collect();

  const orgIds = userInOrganizations.map((orgUser) => orgUser.organizationId);

  const organizations = await Promise.all(
    orgIds.map((orgId) => ctx.db.get(orgId))
  );

  // Build a Map for quick lookup
  const orgMap = new Map(
    organizations.filter(Boolean).map((org) => [org!._id, org])
  );

  const globalUser = await ctx.db.get(userId);

  const organizationList = userInOrganizations.map((orgUser) => ({
    ...orgUser,
    status: globalUser?.status === 'active' ? orgUser?.status : 'inactive',
    organization: orgMap.get(orgUser.organizationId)!,
  }));

  return organizationList;
};
