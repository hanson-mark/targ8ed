import { z } from 'zod';
import {
  descriptionZodSchema,
  nameZodSchema,
  orgIdZodSchema,
} from '../../../../validations/common';

export const updateOrganizationNameZodSchema = z
  .object({
    organizationId: orgIdZodSchema,
    name: z.string().optional(),
    description: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    const { name, description } = data;

    if (!name && !description) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['name'],
      });
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['description'],
      });
    }

    if (name) {
      const result = nameZodSchema.safeParse(name);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['name'] });
        });
      }
    }

    if (description) {
      const result = descriptionZodSchema.safeParse(description);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['description'] });
        });
      }
    }
  });

export const updateOrganizationNameByOrgAdminZodSchema = z
  .object({
    name: z.string().optional(),
    description: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    const { name, description } = data;

    if (!name && !description) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['name'],
      });
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['description'],
      });
    }

    if (name) {
      const result = nameZodSchema.safeParse(name);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['name'] });
        });
      }
    }

    if (description) {
      const result = descriptionZodSchema.safeParse(description);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['description'] });
        });
      }
    }
  });
