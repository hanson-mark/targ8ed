import { v } from 'convex/values';
import { z } from 'zod';
import { mutation, query } from '../../../../_generated/server';
import { ROOT_CONFIG } from '../../../../constants/rootConfig';
import {
  IConvexTreeLinkItem,
  IPermissionMethod,
} from '../../../../types/convex-types';
import { encryptJSON } from '../../../../utils/encryption';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexPublicMiddleware } from '../../../../utils/middlewares/convexPublicMiddleware';
import {
  applicationKeyZodSchema,
  descriptionZodSchema,
  emailZodSchema,
  nameZodSchema,
  otpZodSchema,
  subdomainZodSchema,
} from '../../../../validations/common';
import { getFormattedSidebarDataWithModules } from '../applications/applications.utils';
import { GLOBAL_APPLICATION_INITIAL_DATA } from './constants.initialSetup';
import {
  generateSidebarForInitialSetup,
  IInitialSetupSidebar,
} from './utils.initialSetup';

export const checkHasInitialSetup = query({
  handler: async (ctx) => {
    const rootOrg = await ctx.db
      .query('organizations')
      .withIndex('by_subdomain', (q) =>
        q.eq('subdomain', ROOT_CONFIG.org.subdomain)
      )
      .first();

    if (!rootOrg?._id) {
      return {
        hasInitialSetup: false,
      };
    }

    const rootApplication = await ctx.db
      .query('applications')
      .withIndex('by_key', (q) => q.eq('key', ROOT_CONFIG.application.key))
      .first();

    if (!rootApplication?._id) {
      return {
        hasInitialSetup: false,
      };
    }

    const randomFirstUser = await ctx.db.query('users').first();
    if (!randomFirstUser?._id) {
      return {
        hasInitialSetup: false,
      };
    }

    return {
      hasInitialSetup: true,
    };
  },
});

export const generateOtpToVerifyEmailForInitialSetup = mutation(
  convexPublicMiddleware({
    args: { email: v.string() },
    zodSchema: z.object({
      email: emailZodSchema,
    }),
    handler: async (ctx, args) => {
      // Checking existing
      const existingOTPRequest = await ctx.db
        .query('otps')
        .withIndex('by_email_purpose', (q) =>
          q.eq('email', args?.email).eq('purpose', 'initial_setup')
        )
        .first();

      if (existingOTPRequest?._id) {
        await ctx.db.delete(existingOTPRequest?._id);
      }

      const existingUser = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', args?.email))
        .first();

      if (existingUser?._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'The email you are trying to use, already exist in the database.'
        );
      }

      const otpExpiresAt = new Date().getTime() + 5 * 60 * 1000;
      const sixDigitOTP = Math.floor(
        100000 + Math.random() * 900000
      ).toString();

      // Creating in convex
      await ctx.db.insert('otps', {
        email: args?.email,
        purpose: 'initial_setup',
        otp: sixDigitOTP,
        expiresAt: otpExpiresAt,
      });

      const encryptedObj = await encryptJSON({
        email: args?.email,
        otp: sixDigitOTP,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Verification code has been generated successfully',
        encryptedObj
      );
    },
  })
);

export const startInitialSetup = mutation(
  convexPublicMiddleware({
    args: {
      userName: v.string(),
      userEmail: v.string(),
      otp: v.string(),

      organizationName: v.string(),
      organizationSubdomain: v.string(),
      organizationDescription: v.string(),

      applicationName: v.string(),
      applicationKey: v.string(),
      applicationDescription: v.string(),
    },
    zodSchema: z.object({
      userName: nameZodSchema,
      userEmail: emailZodSchema,
      otp: otpZodSchema,

      organizationName: nameZodSchema,
      organizationSubdomain: subdomainZodSchema,
      organizationDescription: descriptionZodSchema,

      applicationName: nameZodSchema,
      applicationKey: applicationKeyZodSchema,
      applicationDescription: descriptionZodSchema,
    }),
    handler: async (ctx, args) => {
      // Checking existing OTP request
      const existingOTPRequest = await ctx.db
        .query('otps')
        .withIndex('by_email_purpose', (q) =>
          q.eq('email', args?.userEmail).eq('purpose', 'initial_setup')
        )
        .first();

      if (!existingOTPRequest?._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'OTP request not found.'
        );
      }

      if (args.otp?.trim() !== existingOTPRequest?.otp) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The OTP you entered is invalid'
        );
      }

      if (existingOTPRequest?.expiresAt < new Date().getTime()) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The OTP has been expired. Please resend OTP.'
        );
      }

      if (existingOTPRequest?.email !== args?.userEmail?.trim()) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'You are requesting with non verified email address. Please try with verifying.'
        );
      }

      // Check organization
      const existingOrg = await ctx.db
        .query('organizations')
        .withIndex('by_subdomain', (q) =>
          q.eq('subdomain', args?.organizationSubdomain)
        )
        .first();

      if (
        existingOrg?._id &&
        existingOrg?.subdomain === args?.organizationSubdomain
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'Global organization already exists.'
        );
      }

      // Creating organization
      const organizationId = await ctx.db.insert('organizations', {
        name: args?.organizationName,
        subdomain: args?.organizationSubdomain,
        description: args?.organizationDescription,

        // Theme
        themeColor: 'theme-default',
        themeMode: 'light',
        themeBorderRadius: 'radius-default',

        status: 'active',
      });

      // Check application
      const existingApplication = await ctx.db
        .query('applications')
        .withIndex('by_key', (q) => q.eq('key', args?.applicationKey))
        .first();

      if (
        existingApplication?._id &&
        existingApplication?.key === args?.applicationKey
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'Global application already exists.'
        );
      }

      // Creating application
      const applicationId = await ctx.db.insert('applications', {
        name: args.applicationName,
        key: args.applicationKey,
        description: args.organizationDescription,

        sidebar: [],
        isActive: true,
      });
      const applicationData = await ctx.db.get(applicationId);

      if (!applicationData) {
        return generateConvexErrorResponse(
          HttpStatusCodes.INTERNAL_SERVER_ERROR,
          'Application creation issue'
        );
      }

      // Assigning application to organization
      await ctx.db.insert('organizationApplications', {
        organizationId,
        applicationId,
        name: applicationData?.name,
        description: applicationData?.description,
        isActive: true,
      });

      // Creating application modules
      for (const appModule of GLOBAL_APPLICATION_INITIAL_DATA.modules) {
        await ctx.db.insert('applicationModules', {
          name: appModule.name,
          description: appModule.description,
          link: appModule.link,
          applicationId: applicationId,
        });
      }

      // Fetch modules
      const appModules = await ctx.db
        .query('applicationModules')
        .withIndex('by_application_link', (q) =>
          q.eq('applicationId', applicationId)
        )
        .collect();

      // Generate new sidebar
      const sidebar = generateSidebarForInitialSetup(
        GLOBAL_APPLICATION_INITIAL_DATA?.sidebar || [],
        appModules || []
      );

      // Update sidebar into application
      await ctx.db.patch(applicationId, {
        sidebar: sidebar,
        updatedAt: new Date().getTime(),
      });

      // Create permissions
      for (const appPermission of GLOBAL_APPLICATION_INITIAL_DATA.permissions) {
        await ctx.db.insert('permissions', {
          name: appPermission.name,
          description: appPermission.description,
          key: appPermission.key,
          method: appPermission.method as IPermissionMethod,
          applicationId: applicationId,
        });
      }

      // Create role
      const roleId = await ctx.db.insert('roles', {
        name: 'Admin',
        description: 'This is an admin role of the global application',
        isAdminRole: true,
        applicationId: applicationId,
        permissions: [],
      });

      // Check user
      const existingUser = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', args?.userEmail))
        .first();

      if (existingUser?._id && existingUser?.email === args?.userEmail) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'User already exists.'
        );
      }

      // Create user
      const userId = await ctx.db.insert('users', {
        name: args?.userName,
        email: args?.userEmail,
        image: '',
        status: 'active',
      });

      // Create org user
      await ctx.db.insert('organizationUsers', {
        userId,
        organizationId,
        isOrgAdmin: true,
        status: 'active',
      });

      // Create application user
      await ctx.db.insert('userApplications', {
        userId,
        applicationId,
        organizationId,
        roles: [roleId],
        isActive: true,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Initial setup completed successfully',
        applicationId
      );
    },
  })
);

export const generateGlobalApplicationInitialData = query({
  handler: async (ctx) => {
    const application = await ctx.db
      .query('applications')
      .withIndex('by_key', (q) => q.eq('key', ROOT_CONFIG.application.key))
      .first();

    if (!application?._id) {
      return { modules: [], sidebar: [], permissions: [] };
    }

    const tempAppModules = await ctx.db
      .query('applicationModules')
      .withIndex('by_application_link', (q) =>
        q.eq('applicationId', application?._id)
      )
      .collect();

    const appModules = tempAppModules?.map((item) => ({
      name: item?.name,
      description: item?.description,
      link: item?.link,
    }));

    const tempSidebar = getFormattedSidebarDataWithModules(
      application?.sidebar || [],
      tempAppModules
    );
    const formatSidebarInitialData = (
      items: IConvexTreeLinkItem[]
    ): IInitialSetupSidebar[] => {
      const childSidebarData = items.map((item) => ({
        id: item.id,
        label: item.label,
        type: item.type,
        icon: item.icon ?? undefined,
        moduleLink: item.module?.link ?? undefined,
        children: formatSidebarInitialData(
          (item.children ?? []) as IConvexTreeLinkItem[]
        ),
      }));
      return childSidebarData as IInitialSetupSidebar[];
    };

    const sidebar = formatSidebarInitialData(
      tempSidebar as IConvexTreeLinkItem[]
    );

    const tempAppPermissions = await ctx.db
      .query('permissions')
      .withIndex('by_application_key', (q) =>
        q.eq('applicationId', application?._id)
      )
      .collect();

    const appPermissions = tempAppPermissions?.map((item) => ({
      name: item?.name,
      key: item?.key,
      method: item?.method,
      description: item?.description,
    }));

    return { modules: appModules, permissions: appPermissions, sidebar };
  },
});
