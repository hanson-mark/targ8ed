import { Doc } from '../../../../_generated/dataModel';
import { IConvexSidebarTreeItem } from '../../../../types/convex-types';

export type IInitialSetupSidebar = {
  children: IInitialSetupSidebar[];
  icon: string;
  id: string;
  label: string;
  moduleLink: string;
  type: string;
};

// Generate sidebar for initial setup
export const generateSidebarForInitialSetup = (
  sidebarData: IInitialSetupSidebar[],
  applicationModules: Doc<'applicationModules'>[]
) => {
  const moduleMap = new Map(
    applicationModules?.map((item) => [item?.link, item])
  );
  const getFormattedItems = (
    items: IInitialSetupSidebar[]
  ): IConvexSidebarTreeItem[] => {
    return items
      ?.map((item) => {
        const appModule = moduleMap.get(item?.moduleLink);
        if (!appModule) return null;

        return {
          children: getFormattedItems(item?.children),
          id: item?.id,
          icon: item?.icon,
          label: item?.label,
          type: item?.type,
          moduleId: appModule?._id,
        };
      })
      .filter(Boolean) as IConvexSidebarTreeItem[];
  };

  const formattedData = getFormattedItems(sidebarData);

  return formattedData;
};
