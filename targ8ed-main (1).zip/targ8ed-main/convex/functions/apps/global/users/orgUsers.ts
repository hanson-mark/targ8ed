import { v } from 'convex/values';
import { z } from 'zod';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { DEFAULT_STATUS } from '../../../../constants/common';
import { DEFAULT_PAGE_LIMIT } from '../../../../constants/defaultPagination';
import { statusField } from '../../../../utils/fields';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import {
  convexPaginationQueryZodSchema,
  orgIdZodSchema,
  userIdZodSchema,
} from '../../../../validations/common';
import { getUserOrganizationList } from '../organizations/organizations.utils';
import { getOrgUserOrError } from './users.utils';

// Middleware options
const applicationKey = APPLICATION_KEYS.global;

// ====================== [ Functions ] ======================
// Query: Gets list of organizations by user
export const readUserOrgList = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readUserOrgList' },
    inputs: { userId: v.id('users') },
    zodSchema: z.object({ userId: userIdZodSchema }),
    handler: async (ctx, inputs) => {
      const organizationList = await getUserOrganizationList(
        ctx,
        inputs?.userId
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved organization list by user id',
        organizationList
      );
    },
  })
);

// Query: Gets list of available organizations where user can be added
export const readAvailableOrgListToAddUser = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readAvailableOrgListToAddUser' },
    inputs: { userId: v.id('users'), search: v.optional(v.string()) },
    zodSchema: z.object({
      userId: userIdZodSchema,
      search: z.string().optional(),
    }),
    handler: async (ctx, inputs) => {
      const userInOrganizations = await ctx.db
        .query('organizationUsers')
        .withIndex('by_user_organization', (q) =>
          q.eq('userId', inputs?.userId)
        )
        .collect();
      const userOrgIDs = userInOrganizations?.map(
        (item) => item?.organizationId
      );

      let allOrganizationsQuery;
      if (inputs?.search) {
        allOrganizationsQuery = ctx.db
          .query('organizations')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', inputs?.search || '')
          );
      } else {
        allOrganizationsQuery = ctx.db.query('organizations');
      }

      // All organizations
      const allOrganizations = await allOrganizationsQuery.collect();

      // Available organizations
      const availableOrgs = allOrganizations?.filter(
        (item) => !userOrgIDs.includes(item?._id)
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved available organizations for user',
        availableOrgs
      );
    },
  })
);

export const readUsersToAddToOrganization = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readUsersToAddToOrganization' },
    inputs: {
      organizationId: v.id('organizations'),
      search: v.optional(v.string()),

      limit: v.number(),
      cursor: v.optional(v.string()),
      sortOrder: v.union(v.literal('asc'), v.literal('desc')),
    },
    zodSchema: convexPaginationQueryZodSchema.extend({
      organizationId: orgIdZodSchema,
      search: z.string().optional(),
    }),
    handler: async (ctx, inputs) => {
      const { organizationId, search } = inputs;

      const limit = inputs?.limit || DEFAULT_PAGE_LIMIT;

      // Get all users in the organization
      const orgUsers = await ctx.db
        .query('organizationUsers')
        .withIndex('by_organization_isOrgAdmin', (q) =>
          q.eq('organizationId', organizationId)
        )
        .collect();

      const orgUserIds = orgUsers.map((user) => user.userId);

      // Get all users not in the organization
      let usersQuery;
      if (search) {
        usersQuery = ctx.db
          .query('users')
          .withSearchIndex('search_by_name', (q) => q.search('name', search));
      } else {
        usersQuery = ctx.db.query('users').order(inputs.sortOrder);
      }

      const result = await usersQuery.paginate({
        numItems: limit,
        cursor: inputs.cursor || null,
      });

      const usersWithOrgData = result?.page?.map((u) =>
        orgUserIds.includes(u._id)
          ? { ...u, isInOrganization: true }
          : { ...u, isInOrganization: false }
      );

      const meta = {
        limit,
        cursor: result?.continueCursor,
        sortOrder: inputs?.sortOrder,
        isLastPage: result?.isDone,
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved users to add to organization for checking before adding',
        usersWithOrgData,
        meta
      );
    },
  })
);

// Mutation: User organization related queries & mutations
export const createOrgUser = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createOrgUser' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, { userId, organizationId }, currentUser) => {
      // Checking that user already exist or not
      const existing = await ctx.db
        .query('organizationUsers')
        .withIndex('by_user_organization', (q) =>
          q.eq('userId', userId).eq('organizationId', organizationId)
        )
        .first();

      if (existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'User already exists in this organization'
        );
      }

      const isAnyUser = await ctx.db
        .query('organizationUsers')
        .withIndex('by_organization_isOrgAdmin', (q) =>
          q.eq('organizationId', organizationId)
        )
        .first();

      // If there is no user in the org then first user of the org will be org admin
      const shouldBeAdmin = !isAnyUser;

      // Inserting
      await ctx.db.insert('organizationUsers', {
        userId,
        organizationId,
        isOrgAdmin: shouldBeAdmin,
        status: 'active',
        addedBy: currentUser?._id,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Successfully connected user to the organization',
        userId
      );
    },
  })
);

// Query: Get details of a user in an organization
export const readOrgUserDetails = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readOrgUserDetails' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, { userId, organizationId }) => {
      const orgUserResult = await getOrgUserOrError(
        ctx,
        { userId, organizationId },
        true
      );

      if (!('_id' in orgUserResult)) {
        return orgUserResult;
      }

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved user details',
        orgUserResult
      );
    },
  })
);

// Query: Get details of a user in an organization, accessible only by a org admin.
export const readOrgUserDetailsByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { userId: v.id('users') },
    zodSchema: z.object({ userId: userIdZodSchema }),
    handler: async (ctx, { userId }, currentUser) => {
      const organizationId = currentUser?.organization?._id;

      const orgUserResult = await getOrgUserOrError(
        ctx,
        { userId, organizationId },
        true
      );

      if (!('_id' in orgUserResult)) {
        return orgUserResult;
      }

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved user details',
        orgUserResult
      );
    },
  })
);

// Query: Get all users in an organization
export const readOrgUsers = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readOrgUsers' },
    inputs: { organizationId: v.id('organizations') },
    zodSchema: z.object({ organizationId: orgIdZodSchema }),
    handler: async (ctx, { organizationId }) => {
      const orgUsers = await ctx.db
        .query('organizationUsers')
        .withIndex('by_organization_isOrgAdmin', (q) =>
          q.eq('organizationId', organizationId)
        )
        .collect();

      const orgUsersWithUserData = await Promise.all(
        orgUsers.map(async (orgUser) => {
          const globalUser = await ctx.db.get(orgUser.userId);
          return {
            ...orgUser,
            globalUser: globalUser!,
          };
        })
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved organization users',
        orgUsersWithUserData
      );
    },
  })
);

// Query: Get all users in an organization, accessible only by a org admin.
export const readOrgUsersByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {},
    zodSchema: z.object({}),
    handler: async (ctx, {}, currentUser) => {
      const orgUsers = await ctx.db
        .query('organizationUsers')
        .withIndex('by_organization_isOrgAdmin', (q) =>
          q.eq('organizationId', currentUser.organization._id)
        )
        .collect();

      const orgUsersWithUserData = await Promise.all(
        orgUsers.map(async (orgUser) => {
          const globalUser = await ctx.db.get(orgUser.userId);
          return {
            ...orgUser,
            globalUser: globalUser!,
          };
        })
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved organization users',
        orgUsersWithUserData
      );
    },
  })
);

// Mutation: Organization user status
export const updateOrgUserStatus = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateOrgUserStatus' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
      status: statusField,
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
      status: z.enum(DEFAULT_STATUS),
    }),
    handler: async (ctx, { organizationId, userId, status }) => {
      const orgUser = await getOrgUserOrError(
        ctx,
        { userId, organizationId },
        true
      );

      if (!orgUser || !('globalUser' in orgUser)) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User not found in the organization'
        );
      }

      const isGloballyInactive = orgUser?.globalUser?.status === 'inactive';
      if (isGloballyInactive) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          "User is inactive globally, you can't change status"
        );
      }

      const orgUserId = orgUser._id;

      // Update the status of the user in the organization
      await ctx.db.patch(orgUserId, {
        status: status,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        "Successfully updated organization's user role",
        userId
      );
    },
  })
);

// Mutation: Organization user status, accessible only by a org admin.
export const updateOrgUserStatusByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      status: statusField,
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      status: z.enum(DEFAULT_STATUS),
    }),
    handler: async (ctx, { userId, status }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const orgUser = await getOrgUserOrError(
        ctx,
        { userId, organizationId },
        true
      );

      if (!orgUser || !('globalUser' in orgUser)) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User not found in the organization'
        );
      }

      const isGloballyInactive = orgUser?.globalUser?.status === 'inactive';
      if (isGloballyInactive) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          "User is inactive globally, you can't change status"
        );
      }

      const orgUserId = orgUser._id;

      // Update the status of the user in the organization
      await ctx.db.patch(orgUserId, {
        status: status,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        "Successfully updated organization's user role",
        userId
      );
    },
  })
);

// Mutation: Organization user role
export const updateOrgAdminAccess = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateOrgAdminAccess' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
      isOrgAdmin: v.boolean(),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
      isOrgAdmin: z.boolean(),
    }),
    handler: async (ctx, { userId, organizationId, isOrgAdmin }) => {
      const orgUserResult = await getOrgUserOrError(
        ctx,
        { organizationId, userId },
        false
      );

      if (!('_id' in orgUserResult)) {
        return orgUserResult;
      }

      // If trying to remove admin role, ensure not the last one
      if (orgUserResult.isOrgAdmin && !isOrgAdmin) {
        const orgAdmins = await ctx.db
          .query('organizationUsers')
          .withIndex('by_organization_isOrgAdmin', (q) =>
            q.eq('organizationId', organizationId).eq('isOrgAdmin', true)
          )
          .collect();

        if (orgAdmins.length === 1) {
          return generateConvexErrorResponse(
            HttpStatusCodes.CONFLICT,
            'At least one admin is required in an organization.'
          );
        }
      }

      // Update isOrgAdmin role in organization
      const orgUserId = orgUserResult._id;
      await ctx.db.patch(orgUserId, {
        isOrgAdmin,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed organization user role',
        userId
      );
    },
  })
);

// Mutation: Organization user role, accessible only by a org admin.
export const updateOrgAdminAccessByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      isOrgAdmin: v.boolean(),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      isOrgAdmin: z.boolean(),
    }),
    handler: async (ctx, { userId, isOrgAdmin }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const orgUserResult = await getOrgUserOrError(
        ctx,
        { organizationId, userId },
        false
      );

      if (!('_id' in orgUserResult)) {
        return orgUserResult;
      }

      // If trying to remove admin role, ensure not the last one
      if (orgUserResult.isOrgAdmin && !isOrgAdmin) {
        const orgAdmins = await ctx.db
          .query('organizationUsers')
          .withIndex('by_organization_isOrgAdmin', (q) =>
            q.eq('organizationId', organizationId).eq('isOrgAdmin', true)
          )
          .collect();

        if (orgAdmins.length === 1) {
          return generateConvexErrorResponse(
            HttpStatusCodes.CONFLICT,
            'At least one admin is required in an organization.'
          );
        }
      }

      // Update isOrgAdmin role in organization
      const orgUserId = orgUserResult._id;
      await ctx.db.patch(orgUserId, {
        isOrgAdmin,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed organization user role',
        userId
      );
    },
  })
);

// Mutation: Remove a user from organization
export const deleteUserFromOrg = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteUserFromOrg' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, args, currentUser) => {
      // Ids
      const { userId, organizationId } = args;

      const orgUser = await getOrgUserOrError(
        ctx,
        { userId, organizationId },
        false
      );

      if (!('_id' in orgUser)) {
        return orgUser;
      }

      const orgAdmins = orgUser?.isOrgAdmin
        ? await ctx.db
            .query('organizationUsers')
            .withIndex('by_organization_isOrgAdmin', (q) =>
              q.eq('organizationId', args.organizationId).eq('isOrgAdmin', true)
            )
            .collect()
        : undefined;

      if (orgAdmins && orgAdmins?.length === 1) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'At least one admin is required in an organization.'
        );
      }

      if (currentUser?._id === orgUser?.userId) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'You can not remove yourself.'
        );
      }

      // Retrieving org user's application list
      const userApplications = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', orgUser?.userId)
            .eq('organizationId', orgUser?.organizationId)
        )
        .collect();

      // Delete all userApplications
      await Promise.all(
        userApplications.map((application) => ctx.db.delete(application._id))
      );

      // Finally, delete the organizationUser record
      const orgUserId = orgUser._id;
      await ctx.db.delete(orgUserId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Successfully removed the user',
        true
      );
    },
  })
);

// Mutation: Remove a user from organization, accessible only by a org admin.
export const deleteUserFromOrgByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { userId: v.id('users') },
    zodSchema: z.object({ userId: userIdZodSchema }),
    handler: async (ctx, { userId }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const orgUser = await getOrgUserOrError(
        ctx,
        { userId, organizationId },
        false
      );

      if (!('_id' in orgUser)) {
        return orgUser;
      }

      const orgAdmins = orgUser?.isOrgAdmin
        ? await ctx.db
            .query('organizationUsers')
            .withIndex('by_organization_isOrgAdmin', (q) =>
              q.eq('organizationId', organizationId).eq('isOrgAdmin', true)
            )
            .collect()
        : undefined;

      if (orgAdmins && orgAdmins?.length === 1) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'At least one admin is required in an organization.'
        );
      }

      if (currentUser?._id === orgUser?.userId) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'You can not remove yourself.'
        );
      }

      // Retrieving org user's application list
      const userApplications = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', orgUser?.userId)
            .eq('organizationId', orgUser?.organizationId)
        )
        .collect();

      // Delete all userApplications
      await Promise.all(
        userApplications.map((application) => ctx.db.delete(application._id))
      );

      // Finally, delete the organizationUser record
      const orgUserId = orgUser._id;
      await ctx.db.delete(orgUserId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Successfully removed the user',
        true
      );
    },
  })
);
