import { v } from 'convex/values';
import { internal } from '../../../../_generated/api';
import {
  internalAction,
  internalMutation,
} from '../../../../_generated/server';

const argsFields = {
  userId: v.id('users'),
  trackerId: v.id('deletionTracker'),
};

const userInternalAPI = internal.functions.apps.global.users.internal;
const trackerInternalAPI = internal.functions.deletionTracker;

// Internal Mutation: Removes relationship with user while removing user
export const removeUserRelations = internalMutation({
  args: { userId: v.id('users') },
  handler: async (ctx, args) => {
    // Schedular functions object
    const schedularFNs = {
      orgUser: userInternalAPI.removeAllOrgUsers,
      userApplications: userInternalAPI.removeAllUserApplications,
      orgApplicationData: userInternalAPI.removeAllOrgApplicationData,
    } as const;

    // Step-01: Start Tracking Deletion with scheduling
    const schedularFnsWithTrackers = await Promise.all(
      Object.keys(schedularFNs)?.map(async (fnName) => ({
        fnName: fnName as keyof typeof schedularFNs,
        trackingId: await ctx.runMutation(trackerInternalAPI.createTracker, {
          groupKey: args?.userId,
          name: fnName,
        }),
      }))
    );

    await Promise.all(
      schedularFnsWithTrackers.map((item, index) =>
        ctx.scheduler.runAfter(10 + index * 100, schedularFNs[item?.fnName], {
          ...args,
          trackerId: item?.trackingId,
        })
      )
    );

    // Step-07: Removing organization
    await ctx.scheduler.runAfter(
      2000,
      userInternalAPI.checkDeletionTrackerAndRemoveUser,
      {
        userId: args?.userId,
      }
    );
  },
});

export const removeAllOrgUsers = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const orgUsers = await ctx.db
        .query('organizationUsers')
        .withIndex('by_user_organization', (q) => q.eq('userId', args?.userId))
        .collect();

      const orgUserIDs = orgUsers?.map((item) => item?._id);
      // Removes all org users
      await Promise.all(
        orgUserIDs?.map((orgUserID) => ctx.db.delete(orgUserID))
      );

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllUserApplications = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const userApplications = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q.eq('userId', args.userId)
        )
        .collect();
      const userAppIDs = userApplications?.map((item) => item?._id);
      // Removes user applications
      await Promise.all(
        userAppIDs?.map((userAppID) => ctx.db.delete(userAppID))
      );

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllOrgApplicationData = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const quickNotes = await ctx.db
        .query('quickNote')
        .withIndex('by_userId', (q) => q.eq('userId', args?.userId))
        .collect();
      await Promise.all(quickNotes.map((item) => ctx.db.delete(item?._id)));

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeUser = internalMutation({
  args: {
    userId: v.id('users'),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args?.userId);
  },
});

export const checkDeletionTrackerAndRemoveUser = internalAction({
  args: {
    userId: v.id('users'),
  },
  handler: async (ctx, args) => {
    const sleep = (ms: number) =>
      new Promise((resolve) => setTimeout(resolve, ms));

    const getTrackersData = async () => {
      const trackersData = await ctx.runQuery(
        trackerInternalAPI.getTrackersByKey,
        { groupKey: args?.userId }
      );

      return trackersData;
    };

    let retries = 0;
    const MAX_RETRIES = 60; // 5 minutes ( 60 * 5000 milliseconds)
    while (retries < MAX_RETRIES) {
      const trackersData = await getTrackersData();
      const isAllDone = trackersData?.every((item) => item?.status === 'done');

      if (isAllDone) {
        await ctx.runMutation(userInternalAPI.removeUser, {
          userId: args?.userId,
        });
        await ctx.runMutation(trackerInternalAPI.removeTrackers, {
          groupKey: args?.userId,
        });
        break;
      }

      retries++;
      await sleep(5000);
    }
  },
});
