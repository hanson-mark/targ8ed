import { Doc, Id } from '../../../../_generated/dataModel';
import { MutationCtx, QueryCtx } from '../../../../_generated/server';
import { IConvexErrorResponse, IOrgUser } from '../../../../types/convex-types';
import { getFormattedImageURL } from '../../../../utils/common';
import { generateConvexErrorResponse } from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';

interface IOrgAndUserId {
  organizationId: Id<'organizations'>;
  userId: Id<'users'>;
}

export const getOrgUserStatus = (
  user: Doc<'users'>,
  orgUser: Doc<'organizationUsers'>
) => {
  return user?.status === 'active' ? orgUser?.status : 'inactive';
};

export const getOrgUserOrError = async (
  ctx: QueryCtx | MutationCtx,
  { organizationId, userId }: IOrgAndUserId,
  withDetails: boolean = true
): Promise<IOrgUser | IConvexErrorResponse> => {
  // Fetch the organization user record
  const orgUser = await ctx.db
    .query('organizationUsers')
    .withIndex('by_user_organization', (q) =>
      q.eq('userId', userId).eq('organizationId', organizationId)
    )
    .first();

  if (!orgUser) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'User does not belong to this organization'
    );
  }

  if (!withDetails) {
    return {
      ...orgUser,
      globalUser: undefined,
      organization: undefined,
    };
  }

  const user = await ctx.db.get(userId);
  if (!user) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'User not found'
    );
  }

  const organization = await ctx.db.get(organizationId);
  if (!organization) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'Organization not found'
    );
  }

  return {
    ...orgUser,
    status: getOrgUserStatus(user, orgUser),
    globalUser: user,
    organization,
  };
};

export const getCurrentUser = async (
  ctx: QueryCtx | MutationCtx
): Promise<Doc<'users'> | undefined> => {
  const authUser = await ctx.auth.getUserIdentity();

  const email = authUser?.email;

  if (!email) {
    return undefined;
  }

  const userData = await ctx.db
    .query('users')
    .withIndex('by_email', (q) => q.eq('email', email))
    .first();

  const imageURL = await getFormattedImageURL(
    ctx,
    userData?.imageId as Id<'_storage'>,
    userData?.image
  );

  return userData
    ? {
        ...userData,
        image: imageURL || userData?.image || authUser?.pictureUrl || '',
      }
    : undefined;
};
