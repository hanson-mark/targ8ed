import { v } from 'convex/values';
import { z } from 'zod';
import { internal } from '../../../../_generated/api';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { DEFAULT_STATUS } from '../../../../constants/common';
import { DEFAULT_PAGE_LIMIT } from '../../../../constants/defaultPagination';
import {
  getFormattedImageURL,
  removeFileFromStorage,
} from '../../../../utils/common';
import { statusField } from '../../../../utils/fields';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import { getUserApplicationList } from '../applications/applications.utils';

import { encryptJSON } from '../../../../utils/encryption';
import {
  convexPaginationQueryZodSchema,
  emailZodSchema,
  nameZodSchema,
  otpZodSchema,
  storageIdZodSchema,
  userIdZodSchema,
} from '../../../../validations/common';
import { getOrgUserStatus } from './users.utils';

// Middleware options
const applicationKey = APPLICATION_KEYS.global;

// ====================== [ Functions ] ======================
// Mutation: Create a new user (only accessible by Global Application Admin)
export const createUser = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createUser' },
    inputs: {
      name: v.string(),
      email: v.string(),
    },
    zodSchema: z.object({ name: nameZodSchema, email: emailZodSchema }),
    handler: async (ctx, inputs, currentUser) => {
      const emailInput = inputs.email?.trim()?.toLowerCase();

      // Check if a user with the same email already exists
      const existing = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', emailInput))
        .unique();

      if (existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'User with this email already exists'
        );
      }

      // Insert new user into the database
      const userId = await ctx.db.insert('users', {
        name: inputs.name || '',
        email: emailInput,
        image: '',
        createdBy: currentUser?._id,
        status: 'active',
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Successfully added the user',
        userId
      );
    },
  })
);

// Query: Retrieve current logged-in user data
export const readCurrentUserDetails = query(
  convexOrgMiddleware({
    inputs: {},
    options: { accessTypes: ['org-user'] },
    zodSchema: z.object({}),
    handler: async (ctx, inputs, currentUser) => {
      const formattedCurrentUser = {
        ...currentUser,
        image: await getFormattedImageURL(
          ctx,
          currentUser?.imageId,
          currentUser?.image
        ),
      };

      // Retrieving all the applications where user have access
      const userApplications = await getUserApplicationList({
        ctx,
        userId: currentUser?._id,
        organizationId: currentUser?.organization?._id,
        returnOnlyActiveApps: true,
        includeRoles: false,
        hideSidebar: true,
      });

      const finalOrgUserData = {
        ...currentUser?.orgUser,
        status: getOrgUserStatus(currentUser, currentUser?.orgUser),
        globalUser: formattedCurrentUser,
        organization: currentUser?.organization,
        applications: userApplications || [],
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'User retrieved successfully',
        finalOrgUserData
      );
    },
  })
);

// Query: Retrieve a single user by user ID
export const readUserDetails = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readUserDetails' },
    inputs: { userId: v.id('users') },
    zodSchema: z.object({ userId: userIdZodSchema }),
    handler: async (ctx, { userId }) => {
      // Get user data by ID
      const user = await ctx.db.get(userId);

      if (!user) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User not found'
        );
      }

      const formattedUser = {
        ...user,
        image: await getFormattedImageURL(ctx, user?.imageId, user?.image),
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'User retrieved successfully',
        formattedUser
      );
    },
  })
);

// Query: Retrieve all users with pagination
export const readUsers = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readUsers' },
    inputs: {
      limit: v.number(),
      cursor: v.optional(v.string()),
      sortOrder: v.union(v.literal('asc'), v.literal('desc')),
    },
    zodSchema: convexPaginationQueryZodSchema,
    handler: async (ctx, inputs) => {
      const limit = inputs?.limit || DEFAULT_PAGE_LIMIT;

      // Fetch paginated users data
      const result = await ctx.db
        .query('users')
        .order(inputs.sortOrder)
        .paginate({ numItems: limit, cursor: inputs.cursor || null });

      const meta = {
        limit,
        cursor: result?.continueCursor,
        sortOrder: inputs?.sortOrder,
        isLastPage: result?.isDone,
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved users successfully',
        result?.page,
        meta
      );
    },
  })
);

// Query: Retrieve a single user by email
export const readUserDetailsByEmail = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readUserDetailsByEmail' },
    inputs: { email: v.string() },
    zodSchema: z.object({ email: emailZodSchema }),
    handler: async (ctx, inputs) => {
      const emailInput = inputs.email?.trim()?.toLowerCase();

      // Get user data by email
      const user = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', emailInput))
        .first();

      if (!user) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User not found'
        );
      }

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'User retrieved successfully',
        user
      );
    },
  })
);

// Query: Retrieve a single user by email, accessible only by a org admin.
export const readUserDetailsByEmailByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { email: v.string() },
    zodSchema: z.object({ email: emailZodSchema }),
    handler: async (ctx, inputs) => {
      const emailInput = inputs.email?.trim()?.toLowerCase();

      // Get user data by email
      const user = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', emailInput))
        .first();

      if (!user) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User not found'
        );
      }

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'User retrieved successfully',
        user
      );
    },
  })
);

// Mutation: Update a user's imageId
export const updateUserImageId = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateUserImageId' },
    inputs: {
      userId: v.id('users'),
      imageId: v.id('_storage'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      imageId: storageIdZodSchema,
    }),
    handler: async (ctx, inputs, currentUser) => {
      const userId = inputs?.userId;
      const isCurrentUser = currentUser?._id === userId;

      // Gets user data by ID
      const userData = isCurrentUser ? currentUser : await ctx.db.get(userId);

      // Deleting existing image Id
      const existingImageId = userData?.imageId;
      if (existingImageId) {
        await removeFileFromStorage(ctx, existingImageId);
      }

      // Update user's image id
      await ctx.db.patch(userId, {
        imageId: inputs.imageId,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Image uploaded successfully.',
        true
      );
    },
  })
);

// Mutation: Update a user's imageId by the current user
export const updateUserImageIdByUser = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-user'] },
    inputs: { imageId: v.id('_storage') },
    zodSchema: z.object({ imageId: storageIdZodSchema }),
    handler: async (ctx, inputs, currentUser) => {
      const userId = currentUser?._id;
      const isCurrentUser = currentUser?._id === userId;

      // Gets user data by ID
      const userData = isCurrentUser ? currentUser : await ctx.db.get(userId);

      // Deleting existing image Id
      const existingImageId = userData?.imageId;
      if (existingImageId) {
        await removeFileFromStorage(ctx, existingImageId);
      }

      // Update user's image id
      await ctx.db.patch(userId, {
        imageId: inputs.imageId,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Image uploaded successfully.',
        true
      );
    },
  })
);

// Mutation: Update a user's name
export const updateUserName = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateUserName' },
    inputs: {
      userId: v.id('users'),
      name: v.string(),
    },
    zodSchema: z.object({ userId: userIdZodSchema, name: nameZodSchema }),
    handler: async (ctx, inputs) => {
      const userId = inputs?.userId;

      // Update user's name
      await ctx.db.patch(userId, {
        name: inputs.name,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Name updated successfully.',
        userId
      );
    },
  })
);

// Mutation: Update a user's name by the current user
export const updateUserNameByUser = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-user'] },
    inputs: { name: v.string() },
    zodSchema: z.object({ name: nameZodSchema }),
    handler: async (ctx, inputs, currentUser) => {
      const userId = currentUser?._id;

      // Update user's name
      await ctx.db.patch(userId, {
        name: inputs.name,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Name updated successfully.',
        userId
      );
    },
  })
);

// Mutation: Update a user's email
export const updateUserEmail = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateUserEmail' },
    inputs: {
      userId: v.id('users'),
      email: v.string(),
    },
    zodSchema: z.object({ userId: userIdZodSchema, email: emailZodSchema }),
    handler: async (ctx, inputs) => {
      const userId = inputs?.userId;
      const newEmail = inputs.email.trim().toLowerCase();

      // Checking that is there any account associated with new email
      const checkedUserByEmail = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', newEmail))
        .first();

      if (checkedUserByEmail && userId !== checkedUserByEmail._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The email address is already in use by another account.'
        );
      }

      // Update user's email
      await ctx.db.patch(userId, { email: newEmail });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Email updated successfully.',
        userId
      );
    },
  })
);

// Mutation: Request to update a user's email by the current user
export const updateUserEmailRequestByUser = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-user'] },
    inputs: { newEmail: v.string() },
    zodSchema: z.object({ newEmail: emailZodSchema }),
    handler: async (ctx, inputs, currentUser) => {
      const userId = currentUser?._id;
      const newEmail = inputs.newEmail.trim().toLowerCase();

      // Checking that is there any account associated with new email
      const checkedUserByEmail = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', newEmail))
        .first();

      if (checkedUserByEmail && userId !== checkedUserByEmail._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The email address is already in use by another account.'
        );
      }

      if (userId === checkedUserByEmail?._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'This is your current email address.'
        );
      }

      const checkExistingOTPRequest = await ctx.db
        .query('otps')
        .withIndex('by_userId_purpose', (q) =>
          q.eq('userId', userId).eq('purpose', 'email_change')
        )
        .first();

      if (checkExistingOTPRequest) {
        await ctx.db.delete(checkExistingOTPRequest._id);
      }

      const otpExpiresAt = new Date().getTime() + 5 * 60 * 1000;
      const sixDigitOTP = Math.floor(
        100000 + Math.random() * 900000
      ).toString();

      const newOTPRequestId = await ctx.db.insert('otps', {
        userId,
        email: newEmail,
        purpose: 'email_change',
        expiresAt: otpExpiresAt,
        otp: sixDigitOTP,
      });

      const newOTPRequestData = await ctx.db.get(newOTPRequestId);
      const encryptedObj = await encryptJSON({
        email: newOTPRequestData?.email,
        otp: newOTPRequestData?.otp,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Email update request created successfully.',
        encryptedObj
      );
    },
  })
);

// Mutation: Request to update a user's email by the current user
export const updateUserEmailConfirmByUser = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-user'] },
    inputs: { newEmail: v.string(), otp: v.string() },
    zodSchema: z.object({
      newEmail: emailZodSchema,
      otp: otpZodSchema,
    }),
    handler: async (ctx, inputs, currentUser) => {
      const userId = currentUser?._id;
      const newEmail = inputs.newEmail.trim().toLowerCase();
      const otp = inputs.otp.trim().toLowerCase();

      // Checking that is there any account associated with new email
      const checkedUserByEmail = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', newEmail))
        .first();

      if (checkedUserByEmail && userId !== checkedUserByEmail._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The email address is already in use by another account.'
        );
      }

      if (userId === checkedUserByEmail?._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'This is your current email address.'
        );
      }

      const checkExistingOTPRequest = await ctx.db
        .query('otps')
        .withIndex('by_userId_purpose', (q) =>
          q.eq('userId', userId).eq('purpose', 'email_change')
        )
        .first();

      if (
        !checkExistingOTPRequest ||
        (checkExistingOTPRequest && checkExistingOTPRequest?.otp !== otp)
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The OTP you entered is invalid'
        );
      }

      if (
        checkExistingOTPRequest &&
        checkExistingOTPRequest?.expiresAt < new Date().getTime()
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The OTP has been expired. Please resend OTP.'
        );
      }

      if (
        checkExistingOTPRequest &&
        checkExistingOTPRequest?.email !== newEmail
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'You are requesting with non verified email address. Please try with verifying.'
        );
      }

      // Updating user email
      await ctx.db.patch(userId, {
        email: newEmail,
      });

      // Deleting the OTP request
      await ctx.db.delete(checkExistingOTPRequest._id);

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Email updated successfully.',
        userId
      );
    },
  })
);

// Mutation: Change a user's global status (active/inactive)
export const updateUserStatus = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateUserStatus' },
    inputs: {
      userId: v.id('users'),
      status: statusField,
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      status: z.enum(DEFAULT_STATUS),
    }),
    handler: async (ctx, inputs, currentUser) => {
      const userId = inputs?.userId;

      if (currentUser?._id === userId) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          "You can't change your status"
        );
      }

      // Update user's status
      await ctx.db.patch(userId, {
        status: inputs.status,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Updated user status successfully',
        userId
      );
    },
  })
);

// Mutation: Removes an user
export const deleteUser = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteUser' },
    inputs: { userId: v.id('users') },
    zodSchema: z.object({ userId: userIdZodSchema }),
    handler: async (ctx, inputs, currentUser) => {
      const existing = await ctx.db.get(inputs?.userId);

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'No user found to delete'
        );
      }

      if (existing?._id === currentUser?._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'You can not delete yourself'
        );
      }

      // Updating user's "isDeleting" flag
      await ctx.db.patch(inputs?.userId, { isDeleting: true });

      // Running internal mutation to delete user & it's relationships
      await ctx.runMutation(
        internal.functions.apps.global.users.internal.removeUserRelations,
        { userId: inputs?.userId }
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        "Removed the user and it's relations",
        true
      );
    },
  })
);
