import { v } from 'convex/values';
import { z } from 'zod';
import { Id } from '../../../../_generated/dataModel';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { invitationStatues } from '../../../../constants/common';
import { assignedApplicationsField } from '../../../../utils/fields';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import { convexPublicMiddleware } from '../../../../utils/middlewares/convexPublicMiddleware';
import {
  applicationIdZodSchema,
  emailZodSchema,
  invitationIdZodSchema,
  nameZodSchema,
  orgIdZodSchema,
  roleIdZodSchema,
  subdomainZodSchema,
} from '../../../../validations/common';
import {
  assignUserToApplication,
  getApplicationIDsToApplicationRolesMap,
  getAvailableAssignedApplications,
  getOrgApplicationList,
} from '../applications/applications.utils';
import { getOrgBySubDomainOrError } from '../organizations/organizations.utils';

const applicationKey = APPLICATION_KEYS.global;

// Query: Retrieve available applications to invite user
export const readAvailableApplicationsToInviteUser = query(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'readAvailableApplicationsToInviteUser',
    },
    inputs: { organizationId: v.id('organizations') },
    zodSchema: z.object({ organizationId: orgIdZodSchema }),
    handler: async (ctx, args) => {
      // Step-1: Retrieving all the applications of the organization
      const orgApplicationList = await getOrgApplicationList(
        ctx,
        args?.organizationId
      );
      const applicationIDs = orgApplicationList?.map(
        (item) => item?.applicationId
      );

      // Step-2: Retrieving roles for each application & building a Map
      const applicationsRolesMap = await getApplicationIDsToApplicationRolesMap(
        ctx,
        applicationIDs
      );

      // Step-3: Formatting final available application list with adding roles
      const finalList = orgApplicationList?.map((item) => ({
        ...item,
        roles: applicationsRolesMap.get(item?.applicationId) || [],
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved available applications for inviting user',
        finalList
      );
    },
  })
);

// Query: Retrieve available applications to invite user, accessible only by a org admin.
export const readAvailableApplicationsToInviteUserByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {},
    zodSchema: z.object({}),
    handler: async (ctx, {}, currentUser) => {
      // Step-1: Retrieving all the applications of the organization
      const orgApplicationList = await getOrgApplicationList(
        ctx,
        currentUser?.organization._id
      );
      const applicationIDs = orgApplicationList?.map(
        (item) => item?.applicationId
      );

      // Step-2: Retrieving roles for each application & building a Map
      const applicationsRolesMap = await getApplicationIDsToApplicationRolesMap(
        ctx,
        applicationIDs
      );

      // Step-3: Formatting final available application list with adding roles
      const finalList = orgApplicationList?.map((item) => ({
        ...item,
        roles: applicationsRolesMap.get(item?.applicationId) || [],
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved available applications for inviting user',
        finalList
      );
    },
  })
);

// Mutation: Inviting user to organization for joining
export const createInvitation = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createInvitation' },
    inputs: {
      name: v.string(),
      email: v.string(),
      organizationId: v.id('organizations'),
      assignedApplications: assignedApplicationsField,
    },
    zodSchema: z.object({
      name: nameZodSchema,
      email: emailZodSchema,
      organizationId: orgIdZodSchema,
      assignedApplications: z.array(
        z.object({
          applicationId: applicationIdZodSchema,
          roleId: roleIdZodSchema,
        })
      ),
    }),
    handler: async (ctx, args, currentUser) => {
      // Step-01: Checking user in organization
      const globalUser = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', args?.email))
        .first();
      const orgUser = globalUser
        ? await ctx.db
            .query('organizationUsers')
            .withIndex('by_user_organization', (q) =>
              q
                .eq('userId', globalUser?._id)
                .eq('organizationId', args?.organizationId)
            )
            .first()
        : undefined;

      if (orgUser) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'User already exist in the organization'
        );
      }

      // Step-02: Checking that already have an invitation to the organization
      const existingInvitation = await ctx.db
        .query('orgUserInvitations')
        .withIndex('by_organizationId_email', (q) =>
          q.eq('organizationId', args.organizationId).eq('email', args.email)
        )
        .first();

      if (existingInvitation) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'This user already have an invitation to the organization'
        );
      }

      // Step-03: Collecting available application IDs
      const finalAssignedApplications = await getAvailableAssignedApplications(
        ctx,
        args?.organizationId,
        args?.assignedApplications
      );

      // Step-04: Creating token & sending invitation
      const invitationToken = crypto.randomUUID();
      const invitationExpiresAt =
        new Date().getTime() + 2 * 24 * 60 * 60 * 1000;
      const invitationId = await ctx.db.insert('orgUserInvitations', {
        name: args.name,
        email: args.email,
        organizationId: args.organizationId,
        token: invitationToken,
        assignedApplications: finalAssignedApplications || [],
        invitedBy: currentUser?._id,
        expiresAt: invitationExpiresAt,
      });

      // Step-05: Getting invitation
      const invitationData = await ctx.db.get(invitationId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Invitation created successfully',
        invitationData
      );
    },
  })
);

// Mutation: Inviting user to organization for joining, accessible only by a org admin.
export const createInvitationByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      name: v.string(),
      email: v.string(),
      assignedApplications: assignedApplicationsField,
    },
    zodSchema: z.object({
      name: nameZodSchema,
      email: emailZodSchema,
      assignedApplications: z.array(
        z.object({
          applicationId: applicationIdZodSchema,
          roleId: roleIdZodSchema,
        })
      ),
    }),
    handler: async (ctx, args, currentUser) => {
      // Step-01: Checking user in organization
      const globalUser = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', args?.email))
        .first();
      const orgUser = globalUser
        ? await ctx.db
            .query('organizationUsers')
            .withIndex('by_user_organization', (q) =>
              q
                .eq('userId', globalUser?._id)
                .eq('organizationId', currentUser.organization._id)
            )
            .first()
        : undefined;

      if (orgUser) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'User already exist in the organization'
        );
      }

      // Step-02: Checking that already have an invitation to the organization
      const existingInvitation = await ctx.db
        .query('orgUserInvitations')
        .withIndex('by_organizationId_email', (q) =>
          q
            .eq('organizationId', currentUser.organization._id)
            .eq('email', args.email)
        )
        .first();

      if (existingInvitation) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'This user already have an invitation to the organization'
        );
      }

      // Step-03: Collecting available application IDs
      const finalAssignedApplications = await getAvailableAssignedApplications(
        ctx,
        currentUser.organization._id,
        args?.assignedApplications
      );

      // Step-04: Creating token & sending invitation
      const invitationToken = crypto.randomUUID();
      const invitationExpiresAt =
        new Date().getTime() + 2 * 24 * 60 * 60 * 1000;
      const invitationId = await ctx.db.insert('orgUserInvitations', {
        name: args.name,
        email: args.email,
        organizationId: currentUser.organization._id,
        token: invitationToken,
        assignedApplications: finalAssignedApplications || [],
        invitedBy: currentUser?._id,
        expiresAt: invitationExpiresAt,
      });

      // Step-05: Getting invitation
      const invitationData = await ctx.db.get(invitationId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Invitation created successfully',
        invitationData
      );
    },
  })
);

// Mutation: Re-inviting user to organization for joining
export const createReInvitation = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createReInvitation' },
    inputs: {
      invitationId: v.id('orgUserInvitations'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      invitationId: invitationIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, args, currentUser) => {
      // Step-01: Checking that already have an invitation to the organization
      const existing = await ctx.db.get(args?.invitationId);

      if (!existing || existing?.organizationId !== args?.organizationId) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'No invitation found'
        );
      }

      // Step-02: Creating token & sending invitation
      const invitationToken = crypto.randomUUID();
      const invitationExpiresAt =
        new Date().getTime() + 2 * 24 * 60 * 60 * 1000;
      await ctx.db.patch(existing?._id, {
        organizationId: args.organizationId,
        token: invitationToken,
        invitedBy: currentUser?._id,
        expiresAt: invitationExpiresAt,
      });

      // Getting invitation
      const invitationData = await ctx.db.get(existing?._id);

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Re-invitation created successfully',
        invitationData
      );
    },
  })
);

// Mutation: Re-inviting user to organization for joining, accessible only by a org admin.
export const createReInvitationByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { invitationId: v.id('orgUserInvitations') },
    zodSchema: z.object({ invitationId: invitationIdZodSchema }),
    handler: async (ctx, args, currentUser) => {
      // Step-01: Checking that already have an invitation to the organization
      const existing = await ctx.db.get(args?.invitationId);

      if (
        !existing ||
        existing?.organizationId !== currentUser.organization._id
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'No invitation found'
        );
      }

      // Step-02: Creating token & sending invitation
      const invitationToken = crypto.randomUUID();
      const invitationExpiresAt =
        new Date().getTime() + 2 * 24 * 60 * 60 * 1000;
      await ctx.db.patch(existing?._id, {
        organizationId: currentUser.organization._id,
        token: invitationToken,
        invitedBy: currentUser?._id,
        expiresAt: invitationExpiresAt,
      });

      // Getting invitation
      const invitationData = await ctx.db.get(existing?._id);

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Re-invitation created successfully',
        invitationData
      );
    },
  })
);

// Mutation: Accept invitation
export const updateInvitationStatusToAccepted = mutation(
  convexPublicMiddleware({
    args: {
      invitationId: v.id('orgUserInvitations'),
      organizationId: v.id('organizations'),
      email: v.string(),
      token: v.string(),
    },
    zodSchema: z.object({
      invitationId: invitationIdZodSchema,
      organizationId: orgIdZodSchema,
      email: emailZodSchema,
      token: z
        .string({ required_error: 'Token is required' })
        .min(10, 'Invalid token'),
    }),
    handler: async (ctx, args) => {
      const now = Date.now();

      // Step-01: Find invitation by organizationId and email
      const invitation = await ctx.db
        .query('orgUserInvitations')
        .withIndex('by_organizationId_email', (q) =>
          q.eq('organizationId', args.organizationId).eq('email', args.email)
        )
        .first();

      // Step-02: Validate invitation
      if (!invitation || invitation.token !== args.token) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The invitation link is invalid.'
        );
      }

      if (invitation.expiresAt < now) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'This invitation link has expired.'
        );
      }

      // Step-03: Check if user already exists globally and in org
      const globalUser = await ctx.db
        .query('users')
        .withIndex('by_email', (q) => q.eq('email', args.email))
        .first();

      let userId = globalUser?._id;

      let orgUserId = userId
        ? (
            await ctx.db
              .query('organizationUsers')
              .withIndex('by_user_organization', (q) =>
                q
                  .eq('userId', userId as Id<'users'>)
                  .eq('organizationId', args.organizationId)
              )
              .first()
          )?._id
        : undefined;

      // Step-04: Create global user if needed
      if (!userId) {
        userId = await ctx.db.insert('users', {
          email: args.email,
          name: invitation.name,
          image: '',
          status: 'active',
        });
      }

      // Step-05: Create organization user if needed, then assign applications
      // Fn to validate & assigning applications to user
      const validateAndAssign = async () => {
        const finalAssignedApplications =
          await getAvailableAssignedApplications(
            ctx,
            invitation?.organizationId,
            invitation?.assignedApplications
          );

        const invitedApplications = await Promise.all(
          finalAssignedApplications?.map((item) =>
            assignUserToApplication(
              ctx,
              userId,
              args.organizationId,
              item?.applicationId,
              item.roleId
            )
          )
        );

        return invitedApplications;
      };

      // Create organization user if needed
      if (!orgUserId) {
        orgUserId = await ctx.db.insert('organizationUsers', {
          organizationId: args.organizationId,
          userId,
          status: 'active',
        });

        await validateAndAssign();
      } else {
        await validateAndAssign();
      }

      // Step-06: Delete invitation
      await ctx.db.delete(invitation._id);

      // Step-07: Return success response
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'You have accepted the invitation',
        invitation._id
      );
    },
  })
);

// Query: Validate invitation
export const readInvitationDetails = query(
  convexPublicMiddleware({
    args: {
      subdomain: v.string(),
      email: v.string(),
      token: v.string(),
    },
    zodSchema: z.object({
      subdomain: subdomainZodSchema,
      email: emailZodSchema,
      token: z
        .string({ required_error: 'Token is required' })
        .min(10, 'Invalid token'),
    }),
    handler: async (ctx, args) => {
      const now = Date.now();

      const organizationRes = await getOrgBySubDomainOrError(
        ctx,
        args.subdomain
      );
      if (!('_id' in organizationRes)) {
        return organizationRes;
      }

      const invitation = await ctx.db
        .query('orgUserInvitations')
        .withIndex('by_organizationId_email', (q) =>
          q.eq('organizationId', organizationRes?._id).eq('email', args?.email)
        )
        .first();

      if (!invitation || invitation?.token !== args?.token) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The invitation link may be broken, expired, or already used. Try to login if you already accepted the invitation.'
        );
      }

      if (invitation?.expiresAt < now) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'This invitation link has expired. Please request a new invitation to join the organization.'
        );
      }

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'The invitation has been successfully validated. You can now proceed to join the organization.',
        { ...invitation, organization: organizationRes }
      );
    },
  })
);
// Query: Getting invitation list
export const readInvitations = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readInvitations' },
    inputs: {
      organizationId: v.id('organizations'),
      search: v.optional(v.string()),
      status: v.optional(v.union(v.literal('pending'), v.literal('expired'))),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      search: z.string().optional(),
      status: z.enum(invitationStatues).optional(),
    }),
    handler: async (ctx, args) => {
      const now = Date.now();

      const queryPrefix = ctx.db.query('orgUserInvitations');
      let listQuery;

      switch (args.status) {
        case 'pending':
          listQuery = queryPrefix.withIndex(
            'by_organizationId_expiresAt',
            (q) =>
              q.eq('organizationId', args.organizationId).gt('expiresAt', now)
          );
          break;

        case 'expired':
          listQuery = queryPrefix.withIndex(
            'by_organizationId_expiresAt',
            (q) =>
              q.eq('organizationId', args.organizationId).lt('expiresAt', now)
          );
          break;

        default:
          if (args?.search) {
            listQuery = queryPrefix.withSearchIndex('search_by_email', (q) =>
              q.search('email', args?.search || '')
            );
          } else {
            listQuery = queryPrefix.withIndex(
              'by_organizationId_expiresAt',
              (q) => q.eq('organizationId', args.organizationId)
            );
          }
      }

      const list = await listQuery.collect();

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved invitation list',
        list
      );
    },
  })
);

// Query: Getting invitation list, accessible only by a org admin.
export const readInvitationsByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      search: v.optional(v.string()),
      status: v.optional(v.union(v.literal('pending'), v.literal('expired'))),
    },
    zodSchema: z.object({
      search: z.string().optional(),
      status: z.enum(invitationStatues).optional(),
    }),
    handler: async (ctx, args, currentUser) => {
      const now = Date.now();

      const queryPrefix = ctx.db.query('orgUserInvitations');
      let listQuery;

      switch (args.status) {
        case 'pending':
          listQuery = queryPrefix.withIndex(
            'by_organizationId_expiresAt',
            (q) =>
              q
                .eq('organizationId', currentUser?.organization?._id)
                .gt('expiresAt', now)
          );
          break;

        case 'expired':
          listQuery = queryPrefix.withIndex(
            'by_organizationId_expiresAt',
            (q) =>
              q
                .eq('organizationId', currentUser?.organization?._id)
                .lt('expiresAt', now)
          );
          break;

        default:
          if (args?.search) {
            listQuery = queryPrefix.withSearchIndex('search_by_email', (q) =>
              q.search('email', args?.search || '')
            );
          } else {
            listQuery = queryPrefix.withIndex(
              'by_organizationId_expiresAt',
              (q) => q.eq('organizationId', currentUser?.organization?._id)
            );
          }
      }

      const list = await listQuery.collect();

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved invitation list',
        list
      );
    },
  })
);

// Mutation: Remove invitation
export const deleteInvitation = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteInvitation' },
    inputs: {
      invitationId: v.id('orgUserInvitations'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      invitationId: invitationIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, { invitationId, organizationId }) => {
      const existingInvitation = await ctx.db.get(invitationId);

      if (
        !existingInvitation ||
        existingInvitation?.organizationId !== organizationId
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'No invitation found'
        );
      }

      // Removing invitation
      await ctx.db.delete(invitationId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Invitation deleted successfully',
        true
      );
    },
  })
);

// Mutation: Remove invitation, accessible only by a org admin.
export const deleteInvitationByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { invitationId: v.id('orgUserInvitations') },
    zodSchema: z.object({ invitationId: invitationIdZodSchema }),
    handler: async (ctx, { invitationId }, currentUser) => {
      const organizationId = currentUser.organization._id;
      const existingInvitation = await ctx.db.get(invitationId);

      if (
        !existingInvitation ||
        existingInvitation?.organizationId !== organizationId
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'No invitation found'
        );
      }

      // Removing invitation
      await ctx.db.delete(invitationId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Invitation deleted successfully',
        true
      );
    },
  })
);
