import { v } from 'convex/values';
import { z } from 'zod';
import { mutation } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import {
  applicationIdZodSchema,
  appModuleIdZodSchema,
  descriptionZodSchema,
  nameZodSchema,
  treeItemLinkZodSchema,
} from '../../../../validations/common';

const applicationKey = APPLICATION_KEYS.global;

// Mutation: Creates an application module
export const createApplicationModule = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createApplicationModule' },
    inputs: {
      applicationId: v.id('applications'),
      name: v.string(),
      description: v.string(),
      link: v.string(),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      name: nameZodSchema,
      description: descriptionZodSchema,
      link: treeItemLinkZodSchema,
    }),
    handler: async (
      ctx,
      { applicationId, link, name, description },
      currentUser
    ) => {
      const existing = await ctx.db
        .query('applicationModules')
        .withIndex('by_application_link', (q) =>
          q.eq('applicationId', applicationId).eq('link', link)
        )
        .first();

      if (existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'A module with the link already exits.'
        );
      }

      const moduleId = await ctx.db.insert('applicationModules', {
        applicationId: applicationId,
        name: name,
        description: description,
        link: link,
        addedBy: currentUser?._id,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Successfully added the module',
        moduleId
      );
    },
  })
);

// Mutation: Updates an application module
export const updateApplicationModule = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateApplicationModule' },
    inputs: {
      moduleId: v.id('applicationModules'),
      name: v.optional(v.string()),
      description: v.optional(v.string()),
      link: v.optional(v.string()),
    },
    zodSchema: z.object({
      moduleId: appModuleIdZodSchema,
      name: nameZodSchema.optional(),
      description: descriptionZodSchema.optional(),
      link: treeItemLinkZodSchema.optional(),
    }),
    handler: async (ctx, inputs) => {
      const existing = await ctx.db.get(inputs?.moduleId);

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application module not found'
        );
      }

      const moduleId = await ctx.db.patch(inputs?.moduleId, {
        ...(inputs?.name ? { name: inputs?.name } : {}),
        ...(inputs?.description ? { description: inputs?.description } : {}),
        ...(inputs?.link ? { link: inputs?.link } : {}),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Successfully added the module',
        moduleId
      );
    },
  })
);

// Mutation: Deletes an application module
export const deleteApplicationModule = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteApplicationModule' },
    inputs: { moduleId: v.id('applicationModules') },
    zodSchema: z.object({ moduleId: appModuleIdZodSchema }),
    handler: async (ctx, { moduleId }) => {
      const existing = await ctx.db.get(moduleId);

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application module not found'
        );
      }

      await ctx.db.delete(moduleId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Removed the application module successfully.',
        true
      );
    },
  })
);
