import { v } from 'convex/values';
import { internal } from '../../../../_generated/api';
import {
  internalAction,
  internalMutation,
} from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';

const argsFields = {
  applicationId: v.id('applications'),
  trackerId: v.id('deletionTracker'),
};

const appInternalAPI = internal.functions.apps.global.applications.internal;
const trackerInternalAPI = internal.functions.deletionTracker;

// Internal Mutation: Removes relationship with application while removing application
export const removeAppRelations = internalMutation({
  args: { applicationId: v.id('applications') },
  handler: async (ctx, args) => {
    // Schedular functions object
    const schedularFNs = {
      orgApplications: appInternalAPI.removeAllOrgApplications,
      userApplications: appInternalAPI.removeAllUserApplications,
      applicationRoles: appInternalAPI.removeAllApplicationRoles,
      applicationPermissions: appInternalAPI.removeAllApplicationPermissions,
      applicationData: appInternalAPI.removeApplicationData,
    } as const;

    // Step-01: Start Tracking Deletion with scheduling
    const schedularFnsWithTrackers = await Promise.all(
      Object.keys(schedularFNs)?.map(async (fnName) => ({
        fnName: fnName as keyof typeof schedularFNs,
        trackingId: await ctx.runMutation(trackerInternalAPI.createTracker, {
          groupKey: args?.applicationId,
          name: fnName,
        }),
      }))
    );

    await Promise.all(
      schedularFnsWithTrackers.map((item, index) =>
        ctx.scheduler.runAfter(10 + index * 100, schedularFNs[item?.fnName], {
          ...args,
          trackerId: item?.trackingId,
        })
      )
    );

    // Step-07: Removing organization
    await ctx.scheduler.runAfter(
      2000,
      appInternalAPI.checkDeletionTrackerAndRemoveApplication,
      {
        applicationId: args?.applicationId,
      }
    );
  },
});

export const removeAllOrgApplications = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const orgApplications = await ctx.db
        .query('organizationApplications')
        .withIndex('by_application', (q) =>
          q.eq('applicationId', args?.applicationId)
        )
        .collect();

      const orgAppIDs = orgApplications?.map((item) => item?._id);
      // Removes all org applications
      await Promise.all(orgAppIDs?.map((orgAppID) => ctx.db.delete(orgAppID)));

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllUserApplications = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const userApplications = await ctx.db
        .query('userApplications')
        .withIndex('by_application', (q) =>
          q.eq('applicationId', args.applicationId)
        )
        .collect();
      const userAppIDs = userApplications?.map((item) => item?._id);
      // Removes user applications
      await Promise.all(
        userAppIDs?.map((userAppID) => ctx.db.delete(userAppID))
      );

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllApplicationRoles = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const roles = await ctx.db
        .query('roles')
        .withIndex('by_application_role', (q) =>
          q.eq('applicationId', args.applicationId)
        )
        .collect();
      const roleIDs = roles?.map((item) => item?._id);
      // Removes user applications
      await Promise.all(roleIDs?.map((roleID) => ctx.db.delete(roleID)));

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeAllApplicationPermissions = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const permissions = await ctx.db
        .query('permissions')
        .withIndex('by_application_key', (q) =>
          q.eq('applicationId', args.applicationId)
        )
        .collect();
      const permissionIDs = permissions?.map((item) => item?._id);
      // Removes user applications
      await Promise.all(
        permissionIDs?.map((permissionID) => ctx.db.delete(permissionID))
      );

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeApplicationData = internalMutation({
  args: argsFields,
  handler: async (ctx, args) => {
    try {
      const application = await ctx.db.get(args?.applicationId);

      if (!application || !application?.key) return;
      switch (application?.key) {
        // For quick note application deletion
        case APPLICATION_KEYS.quickNote:
          const allQuickNotes = await ctx.db
            .query(APPLICATION_KEYS.quickNote)
            .collect();

          await Promise.all(
            allQuickNotes.map((item) => ctx.db.delete(item?._id))
          );
          break;

        default:
          break;
      }

      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'done',
      });
    } catch {
      // Updating tracker data
      await ctx.runMutation(trackerInternalAPI.changeStatus, {
        trackerId: args?.trackerId,
        status: 'error',
      });
    }
  },
});

export const removeApplication = internalMutation({
  args: {
    applicationId: v.id('applications'),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args?.applicationId);
  },
});

export const checkDeletionTrackerAndRemoveApplication = internalAction({
  args: {
    applicationId: v.id('applications'),
  },
  handler: async (ctx, args) => {
    const sleep = (ms: number) =>
      new Promise((resolve) => setTimeout(resolve, ms));

    const getTrackersData = async () => {
      const trackersData = await ctx.runQuery(
        trackerInternalAPI.getTrackersByKey,
        { groupKey: args?.applicationId }
      );

      return trackersData;
    };

    let retries = 0;
    const MAX_RETRIES = 60; // 5 minutes ( 60 * 5000 milliseconds)
    while (retries < MAX_RETRIES) {
      const trackersData = await getTrackersData();
      const isAllDone = trackersData?.every((item) => item?.status === 'done');

      if (isAllDone) {
        await ctx.runMutation(appInternalAPI.removeApplication, {
          applicationId: args?.applicationId,
        });
        await ctx.runMutation(trackerInternalAPI.removeTrackers, {
          groupKey: args?.applicationId,
        });
        break;
      }

      retries++;
      await sleep(5000);
    }
  },
});
