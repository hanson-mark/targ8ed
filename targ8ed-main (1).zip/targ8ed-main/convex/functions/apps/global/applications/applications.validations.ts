import { z } from 'zod';
import { permissionMethods } from '../../../../constants/common';
import {
  applicationIdZodSchema,
  descriptionZodSchema,
  nameZodSchema,
  orgIdZodSchema,
  permissionIdZodSchema,
} from '../../../../validations/common';

export const updateApplicationNameOrDescriptionZodSchema = z
  .object({
    applicationId: applicationIdZodSchema,
    name: z.string().optional(),
    description: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    const { name, description } = data;

    if (!name && !description) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['name'],
      });
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['description'],
      });
    }

    if (name) {
      const result = nameZodSchema.safeParse(name);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['name'] });
        });
      }
    }

    if (description) {
      const result = descriptionZodSchema.safeParse(description);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['description'] });
        });
      }
    }
  });

export const updateOrgApplicationNameOrDescriptionZodSchema = z
  .object({
    applicationId: applicationIdZodSchema,
    name: z.string().optional(),
    description: z.string().optional(),
    organizationId: orgIdZodSchema,
  })
  .superRefine((data, ctx) => {
    const { name, description } = data;

    if (!name && !description) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['name'],
      });
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['description'],
      });
    }

    if (name) {
      const result = nameZodSchema.safeParse(name);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['name'] });
        });
      }
    }

    if (description) {
      const result = descriptionZodSchema.safeParse(description);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['description'] });
        });
      }
    }
  });

export const updateOrgApplicationNameOrDescriptionByOrgAdminZodSchema = z
  .object({
    applicationId: applicationIdZodSchema,
    name: z.string().optional(),
    description: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    const { name, description } = data;

    if (!name && !description) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['name'],
      });
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please provide either name or description to update.',
        path: ['description'],
      });
    }

    if (name) {
      const result = nameZodSchema.safeParse(name);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['name'] });
        });
      }
    }

    if (description) {
      const result = descriptionZodSchema.safeParse(description);
      if (!result.success) {
        result.error.issues.forEach((issue) => {
          ctx.addIssue({ ...issue, path: ['description'] });
        });
      }
    }
  });

export const permissionKeyZodSchema = z
  .string()
  .min(2, 'Permission key must be at least 2 characters long')
  .regex(
    /^[a-z]+([A-Z][a-z]*)*$/,
    'Must be in camelCase (e.g., readUser, updateProfile)'
  );

export const permissionNameZodSchema = z
  .string()
  .regex(
    /^[a-z_]+$/,
    'Only lowercase letters and underscores allowed. (e.g., user_details)'
  )
  .regex(
    /^[a-z](?:[a-z_]*[a-z])?$/,
    "Name can't start or end with an underscore"
  )
  .min(2, 'Permission name must be at least 2 characters long');

export const permissionMethodZodSchema = z.enum(permissionMethods, {
  errorMap: () => ({ message: 'Please select correct permission method' }),
});

export const permissionDescriptionZodSchema = z
  .string()
  .min(5, 'Description must be at least 5 characters long');

export const addPermissionZodSchema = z.object({
  key: permissionKeyZodSchema,
  method: permissionMethodZodSchema,
  name: permissionNameZodSchema,
  description: permissionDescriptionZodSchema,
  applicationId: applicationIdZodSchema,
});

export const updatePermissionZodSchema = addPermissionZodSchema
  .extend({
    permissionId: permissionIdZodSchema,
  })
  .omit({
    applicationId: true,
  });

export const roleNameZodSchema = z
  .string()
  .min(2, 'Role name must be at least 2 characters long');

export const createRoleZodSchema = z.object({
  name: roleNameZodSchema,
  description: descriptionZodSchema,
  isAdminRole: z.boolean().optional(),
  applicationId: applicationIdZodSchema,
});
