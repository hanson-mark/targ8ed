import { v } from 'convex/values';
import { z } from 'zod';
import { internal } from '../../../../_generated/api';
import {
  internalMutation,
  mutation,
  query,
} from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { ICurrentApplication } from '../../../../types/convex-types';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import {
  assignUserToApplication,
  getFormattedSidebarDataWithModules,
  getOrgApplicationList,
  getUserApplicationList,
} from './applications.utils';

import {
  applicationIdZodSchema,
  applicationKeyZodSchema,
  orgIdZodSchema,
  roleIdZodSchema,
  userIdZodSchema,
} from '../../../../validations/common';
import {
  getApplicationIDsToApplicationRolesMap,
  getApplicationRolesWithPermissions,
} from './applications.utils';

// Middleware options
const applicationKey = APPLICATION_KEYS.global;

// ====================== [ Functions ] ======================
export const readUserApplicationByKey = query(
  convexOrgMiddleware({
    options: {},
    inputs: { key: v.string() },
    zodSchema: z.object({ key: applicationKeyZodSchema }),
    handler: async (ctx, { key }, currentUser) => {
      // Step-01: Checking main application && Org application
      const application = await ctx.db
        .query('applications')
        .withIndex('by_key', (q) => q.eq('key', key))
        .first();

      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'No application found. Or invalid request.'
        );
      }

      const orgApplication = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q
            .eq('organizationId', currentUser?.organization?._id)
            .eq('applicationId', application?._id)
        )
        .first();

      // Step-03: Checking user application
      const userApplication = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', currentUser?._id)
            .eq('organizationId', currentUser?.organization?._id)
            .eq('applicationId', application?._id)
        )
        .first();

      if (
        !application?.isActive ||
        !userApplication ||
        !userApplication?.isActive ||
        !orgApplication ||
        !orgApplication?.isActive
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'You do not have access'
        );
      }

      // Step-04: Checking user roles
      const roles = await getApplicationRolesWithPermissions(
        ctx,
        application?._id
      );
      const rolesMap = new Map(roles?.map((role) => [role?._id, role]));

      const finalRoles = userApplication?.roles
        ?.map((roleId) => rolesMap.get(roleId)!)
        .filter(Boolean);

      const applicationModules = await ctx.db
        .query('applicationModules')
        .withIndex('by_application_link', (q) =>
          q.eq('applicationId', application?._id)
        )
        .collect();

      const sidebar = getFormattedSidebarDataWithModules(
        application?.sidebar || [],
        applicationModules || []
      );

      const formattedApplication: ICurrentApplication = {
        ...application,
        sidebar,
        roles: finalRoles,
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved user application',
        formattedApplication
      );
    },
  })
);

// Query: Retrieve available applications to add user
export const readAvailableApplicationsToAddUser = query(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'readAvailableApplicationsToAddUser',
    },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, { userId, organizationId }) => {
      //Step-1: Check user is exist on the organization
      const orgUser = await ctx.db
        .query('organizationUsers')
        .withIndex('by_user_organization', (q) =>
          q.eq('userId', userId).eq('organizationId', organizationId)
        )
        .first();

      if (!orgUser) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'The user is not exist in the organization.'
        );
      }

      // Step-2: Retrieving all the applications of the organization
      const orgApplicationList = await getOrgApplicationList(
        ctx,
        organizationId
      );

      // Step-3: Retrieving all the applications of the user
      const userApplications = await getUserApplicationList({
        ctx,
        userId,
        organizationId,
        includeRoles: false,
        hideSidebar: true,
      });
      const userApplicationIDs = userApplications.map((item) => item?._id);

      // Step-4: Filtering available applications
      const availableApplications = orgApplicationList.filter(
        (item) => !userApplicationIDs.includes(item?.applicationId)
      );
      const availableApplicationIDs = availableApplications?.map(
        (item) => item?.applicationId
      );

      // Step-5: Retrieving roles for each application & building a Map
      const applicationsRolesMap = await getApplicationIDsToApplicationRolesMap(
        ctx,
        availableApplicationIDs
      );

      // Step-6: Formatting final available application list with adding roles
      const finalList = availableApplications?.map((item) => ({
        ...item,
        roles: applicationsRolesMap.get(item?.applicationId) || [],
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved available applications for user',
        finalList
      );
    },
  })
);

// Query: Retrieve available applications to add user, accessible only by a org admin.
export const readAvailableApplicationsToAddUserByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { userId: v.id('users') },
    zodSchema: z.object({ userId: userIdZodSchema }),
    handler: async (ctx, { userId }, currentUser) => {
      //Step-1: Check user is exist on the organization
      const orgUser = await ctx.db
        .query('organizationUsers')
        .withIndex('by_user_organization', (q) =>
          q
            .eq('userId', userId)
            .eq('organizationId', currentUser.organization._id)
        )
        .first();

      if (!orgUser) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'The user is not exist in the organization.'
        );
      }

      // Step-2: Retrieving all the applications of the organization
      const orgApplicationList = await getOrgApplicationList(
        ctx,
        currentUser.organization._id
      );

      // Step-3: Retrieving all the applications of the user
      const userApplications = await getUserApplicationList({
        ctx,
        userId,
        organizationId: currentUser.organization._id,
        includeRoles: false,
        hideSidebar: true,
      });
      const userApplicationIDs = userApplications.map((item) => item?._id);

      // Step-4: Filtering available applications
      const availableApplications = orgApplicationList.filter(
        (item) => !userApplicationIDs.includes(item?.applicationId)
      );
      const availableApplicationIDs = availableApplications?.map(
        (item) => item?.applicationId
      );

      // Step-5: Retrieving roles for each application & building a Map
      const applicationsRolesMap = await getApplicationIDsToApplicationRolesMap(
        ctx,
        availableApplicationIDs
      );

      // Step-6: Formatting final available application list with adding roles
      const finalList = availableApplications?.map((item) => ({
        ...item,
        roles: applicationsRolesMap.get(item?.applicationId) || [],
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved available applications for user',
        finalList
      );
    },
  })
);

// Mutation: Add a user to an application in an organization
export const createApplicationAccessForUser = mutation(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'createApplicationAccessForUser',
    },
    inputs: {
      userId: v.id('users'),
      applicationId: v.id('applications'),
      organizationId: v.id('organizations'),
      roleId: v.id('roles'),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      organizationId: orgIdZodSchema,
      userId: userIdZodSchema,
      roleId: roleIdZodSchema,
    }),
    handler: async (
      ctx,
      { userId, applicationId, organizationId, roleId },
      currentUser
    ) => {
      const userAppId = await assignUserToApplication(
        ctx,
        userId,
        organizationId,
        applicationId,
        roleId,
        currentUser?._id
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Successfully assigned user to application',
        userAppId
      );
    },
  })
);

// Mutation: Add a user to an application in an organization, accessible only by a org admin.
export const createApplicationAccessForUserByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      applicationId: v.id('applications'),
      roleId: v.id('roles'),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      userId: userIdZodSchema,
      roleId: roleIdZodSchema,
    }),
    handler: async (ctx, { userId, applicationId, roleId }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const userAppId = await assignUserToApplication(
        ctx,
        userId,
        organizationId,
        applicationId,
        roleId,
        currentUser?._id
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Successfully assigned user to application',
        userAppId
      );
    },
  })
);

// Query: Retrieve a list of user applications for a given organization
export const readUserApplicationList = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readUserApplicationList' },
    inputs: {
      organizationId: v.id('organizations'),
      userId: v.id('users'),
      isActive: v.optional(v.boolean()),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      userId: userIdZodSchema,
      isActive: z.boolean().optional(),
    }),
    handler: async (ctx, { organizationId, userId, isActive }) => {
      const userApplications = await getUserApplicationList({
        ctx,
        userId,
        organizationId,
        returnOnlyActiveApps: isActive,
        includeRoles: true,
        hideSidebar: true,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved user applications',
        userApplications
      );
    },
  })
);

// Query: Retrieve a list of user applications for a given organization, accessible only by a org admin.
export const readUserApplicationListByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      isActive: v.optional(v.boolean()),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      isActive: z.boolean().optional(),
    }),
    handler: async (ctx, { userId, isActive }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const userApplications = await getUserApplicationList({
        ctx,
        userId,
        organizationId,
        returnOnlyActiveApps: isActive,
        includeRoles: true,
        hideSidebar: true,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully retrieved user applications',
        userApplications
      );
    },
  })
);

// Mutation: Change the status of a user's application (active/inactive)
export const updateUserApplicationStatus = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateUserApplicationStatus' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
      applicationId: v.id('applications'),
      isActive: v.boolean(),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      organizationId: orgIdZodSchema,
      userId: userIdZodSchema,
      isActive: z.boolean().optional(),
    }),
    handler: async (ctx, inputs) => {
      const existingUserApp = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', inputs.userId)
            .eq('organizationId', inputs.organizationId)
            .eq('applicationId', inputs.applicationId)
        )
        .first();

      if (!existingUserApp) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User application not found'
        );
      }

      const orgApplication = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q
            .eq('organizationId', inputs?.organizationId)
            .eq('applicationId', inputs?.applicationId)
        )
        .first();
      if (!orgApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist in organization'
        );
      }

      const mainApplication = await ctx.db.get(existingUserApp?.applicationId);
      if (!mainApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application not found'
        );
      }

      const userAppId = existingUserApp._id;

      // Updating the user application status
      await ctx.db.patch(userAppId, {
        isActive: inputs.isActive,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed user application status',
        inputs?.applicationId
      );
    },
  })
);

// Mutation: Change the status of a user's application (active/inactive), accessible only by a org admin.
export const updateUserApplicationStatusByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      applicationId: v.id('applications'),
      isActive: v.boolean(),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      userId: userIdZodSchema,
      isActive: z.boolean().optional(),
    }),
    handler: async (ctx, inputs, currentUser) => {
      const organizationId = currentUser.organization._id;

      const existingUserApp = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', inputs.userId)
            .eq('organizationId', organizationId)
            .eq('applicationId', inputs.applicationId)
        )
        .first();

      if (!existingUserApp) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User application not found'
        );
      }

      const orgApplication = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q
            .eq('organizationId', organizationId)
            .eq('applicationId', inputs?.applicationId)
        )
        .first();
      if (!orgApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist in organization'
        );
      }

      const mainApplication = await ctx.db.get(existingUserApp?.applicationId);
      if (!mainApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application not found'
        );
      }

      const userAppId = existingUserApp._id;

      // Updating the user application status
      await ctx.db.patch(userAppId, {
        isActive: inputs.isActive,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed user application status',
        inputs?.applicationId
      );
    },
  })
);

// Mutation: Change the role of a application user
export const updateUserRoleInApplication = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateUserRoleInApplication' },
    inputs: {
      userId: v.id('users'),
      organizationId: v.id('organizations'),
      applicationId: v.id('applications'),
      roleId: v.id('roles'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      organizationId: orgIdZodSchema,
      applicationId: applicationIdZodSchema,
      roleId: roleIdZodSchema,
    }),
    handler: async (ctx, { userId, organizationId, applicationId, roleId }) => {
      // Step-01: Check user application
      const existingUserApp = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', userId)
            .eq('organizationId', organizationId)
            .eq('applicationId', applicationId)
        )
        .first();

      if (!existingUserApp) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User application not found'
        );
      }

      // Step-02: Check organization's application
      const orgApplication = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q
            .eq('organizationId', organizationId)
            .eq('applicationId', applicationId)
        )
        .first();
      if (!orgApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist in organization'
        );
      }

      // Step-03: Check main application
      const mainApplication = await ctx.db.get(existingUserApp.applicationId);
      if (!mainApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application not found'
        );
      }

      // Step-04: Check application role
      const role = await ctx.db.get(roleId);

      if (!role || role?.applicationId !== mainApplication._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Role does not exist in the application'
        );
      }

      // Step-05: Updating the user application status
      const userAppId = existingUserApp._id;
      await ctx.db.patch(userAppId, {
        roles: [roleId],
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed application user role',
        applicationId
      );
    },
  })
);

// Mutation: Change the role of a application user, accessible only by a org admin.
export const updateUserRoleInApplicationByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      applicationId: v.id('applications'),
      roleId: v.id('roles'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      applicationId: applicationIdZodSchema,
      roleId: roleIdZodSchema,
    }),
    handler: async (ctx, { userId, applicationId, roleId }, currentUser) => {
      const organizationId = currentUser.organization._id;

      // Step-01: Check user application
      const existingUserApp = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', userId)
            .eq('organizationId', organizationId)
            .eq('applicationId', applicationId)
        )
        .first();

      if (!existingUserApp) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'User application not found'
        );
      }

      // Step-02: Check organization's application
      const orgApplication = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q
            .eq('organizationId', organizationId)
            .eq('applicationId', applicationId)
        )
        .first();
      if (!orgApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist in organization'
        );
      }

      // Step-03: Check main application
      const mainApplication = await ctx.db.get(existingUserApp.applicationId);
      if (!mainApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application not found'
        );
      }

      // Step-04: Check application role
      const role = await ctx.db.get(roleId);

      if (!role || role?.applicationId !== mainApplication._id) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Role does not exist in the application'
        );
      }

      // Step-05: Updating the user application status
      const userAppId = existingUserApp._id;
      await ctx.db.patch(userAppId, {
        roles: [roleId],
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed application user role',
        applicationId
      );
    },
  })
);

// Mutation: Remove a user from an application
export const deleteUserApplication = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteUserApplication' },
    inputs: {
      userId: v.id('users'),
      applicationId: v.id('applications'),
      organizationId: v.id('organizations'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      applicationId: applicationIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, { userId, organizationId, applicationId }) => {
      const existing = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', userId)
            .eq('organizationId', organizationId)
            .eq('applicationId', applicationId)
        )
        .first();

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'User does not belongs to the application'
        );
      }

      const userApplicationId = existing._id;

      await ctx.db.patch(userApplicationId, {
        isDeleting: true,
      });

      await ctx.scheduler.runAfter(
        10,
        internal.functions.apps.global.applications.userApplications
          .internalRemoveUserApplicationAndData,
        {
          userId,
          applicationId,
          userApplicationId,
          organizationId,
        }
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Removed user application successfully',
        true
      );
    },
  })
);

// Mutation: Remove a user from an application, accessible only by a org admin.
export const deleteUserApplicationByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      userId: v.id('users'),
      applicationId: v.id('applications'),
    },
    zodSchema: z.object({
      userId: userIdZodSchema,
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, { userId, applicationId }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const existing = await ctx.db
        .query('userApplications')
        .withIndex('by_user_organization_application', (q) =>
          q
            .eq('userId', userId)
            .eq('organizationId', organizationId)
            .eq('applicationId', applicationId)
        )
        .first();

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'User does not belongs to the application'
        );
      }

      const userApplicationId = existing._id;

      await ctx.db.patch(userApplicationId, {
        isDeleting: true,
      });

      await ctx.scheduler.runAfter(
        10,
        internal.functions.apps.global.applications.userApplications
          .internalRemoveUserApplicationAndData,
        {
          userId,
          applicationId,
          userApplicationId,
          organizationId,
        }
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Removed user application successfully',
        true
      );
    },
  })
);

export const internalRemoveUserApplicationAndData = internalMutation({
  args: {
    userId: v.id('users'),
    applicationId: v.id('applications'),
    userApplicationId: v.id('userApplications'),
    organizationId: v.id('organizations'),
  },
  handler: async (ctx, args) => {
    const application = await ctx.db.get(args?.applicationId);

    if (!application || !application?.key) return;
    switch (application?.key) {
      // For quick note application deletion
      case APPLICATION_KEYS.quickNote:
        const allQuickNotesForTheUser = await ctx.db
          .query(APPLICATION_KEYS.quickNote)
          .withIndex('by_organization_userId', (q) =>
            q
              .eq('organizationId', args?.organizationId)
              .eq('userId', args.userId)
          )
          .collect();

        await Promise.all(
          allQuickNotesForTheUser.map((item) => ctx.db.delete(item?._id))
        );
        break;

      default:
        break;
    }

    await ctx.db.delete(args.userApplicationId);
  },
});
