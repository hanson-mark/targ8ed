import { v } from 'convex/values';
import { z } from 'zod';
import { Id } from '../../../../_generated/dataModel';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import {
  applicationIdZodSchema,
  convexPaginationQueryZodSchema,
  orgIdZodSchema,
} from '../../../../validations/common';
import {
  getOrgApplicationList,
  getOrgApplicationOrError,
} from './applications.utils';
import {
  updateOrgApplicationNameOrDescriptionByOrgAdminZodSchema,
  updateOrgApplicationNameOrDescriptionZodSchema,
} from './applications.validations';

const applicationKey = APPLICATION_KEYS.global;

// Query: Retrieve organization list for adding to application
export const readAvailableOrgListToAddApplication = query(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'readAvailableOrgListToAddApplication',
    },
    inputs: {
      applicationId: v.id('applications'),
      search: v.optional(v.string()),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      search: z.string().optional(),
    }),
    handler: async (ctx, { applicationId, search = '' }) => {
      // Step-01: Getting application's organization list
      const applicationOrgList = await ctx.db
        .query('organizationApplications')
        .withIndex('by_application', (q) =>
          q.eq('applicationId', applicationId)
        )
        .collect();
      const existingOrgIDs = applicationOrgList?.map(
        (item) => item?.organizationId
      );

      // Step-02: Getting first 20 organizations
      let orgQuery;
      if (search) {
        orgQuery = ctx.db
          .query('organizations')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', search || '')
          );
      } else {
        orgQuery = ctx.db.query('organizations');
      }

      const organizations = await orgQuery.take(20);

      const finalOrgs = organizations
        ?.filter((item) => !existingOrgIDs.includes(item?._id))
        ?.map((item) => ({ _id: item?._id, name: item?.name }));

      // Return the details of org application details
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Organizations retrieved successfully',
        finalOrgs
      );
    },
  })
);

// Query: Retrieve available application list for adding application to organization
export const readAvailableApplicationListToAddInOrg = query(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'readAvailableApplicationListToAddInOrg',
    },
    inputs: {
      organizationId: v.id('organizations'),
      search: v.optional(v.string()),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      search: z.string().optional(),
    }),
    handler: async (ctx, { organizationId, search = '' }) => {
      // Step-01: Getting organization's application list
      const applicationOrgList = await ctx.db
        .query('organizationApplications')
        .withIndex('by_organization_application', (q) =>
          q.eq('organizationId', organizationId)
        )
        .collect();
      const existingApplicationIDs = applicationOrgList?.map(
        (item) => item?.applicationId
      );

      // Step-02: Getting first 20 applications
      let applicationQuery;
      if (search) {
        applicationQuery = ctx.db
          .query('applications')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', search || '')
          );
      } else {
        applicationQuery = ctx.db.query('applications');
      }

      const applications = await applicationQuery.take(20);

      const finalApplications = applications
        ?.filter((item) => !existingApplicationIDs.includes(item?._id))
        ?.map((item) => ({ _id: item?._id, name: item?.name }));

      // Return the details of org application details
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Applications retrieved successfully',
        finalApplications
      );
    },
  })
);

// Mutation: Add an application to an organization
export const createApplicationAccessOrg = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createApplicationAccessOrg' },
    inputs: {
      applicationId: v.id('applications'), // ID of the application to be added
      organizationId: v.id('organizations'), // ID of the organization
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      organizationId: orgIdZodSchema,
    }),
    handler: async (ctx, inputs, currentUser) => {
      // Check if the application is already associated with the organization
      const existing = await getOrgApplicationOrError(ctx, inputs, false);

      // If the application already exists, throw an error
      if ('_id' in existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'Application already exists in this organization'
        );
      }

      const application = await ctx.db.get(inputs.applicationId);

      // If the Application is not available
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application not found'
        );
      }

      // Insert the new application into the organization's applications
      await ctx.db.insert('organizationApplications', {
        applicationId: inputs.applicationId,
        organizationId: inputs.organizationId,

        name: application?.name,
        description: application?.description,
        isActive: true,

        addedBy: currentUser?._id,
      });

      // Return the newly added application data
      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Application connected to the organization successfully',
        inputs?.applicationId
      );
    },
  })
);

// Query: Retrieve org application details
export const readOrgApplication = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readOrgApplication' },
    inputs: {
      organizationId: v.id('organizations'),
      applicationId: v.id('applications'),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, { organizationId, applicationId }) => {
      const orgApplicationResult = await getOrgApplicationOrError(
        ctx,
        { organizationId, applicationId },
        true
      );

      if (!('_id' in orgApplicationResult)) {
        return orgApplicationResult;
      }

      // Return the details of org application details
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Application retrieved successfully',
        orgApplicationResult
      );
    },
  })
);

// Query: Retrieve org application details, accessible only by a org admin.
export const readOrgApplicationByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: { applicationId: v.id('applications') },
    zodSchema: z.object({ applicationId: applicationIdZodSchema }),
    handler: async (ctx, { applicationId }, currentUser) => {
      const organizationId = currentUser.organization._id;

      const orgApplicationResult = await getOrgApplicationOrError(
        ctx,
        { organizationId, applicationId },
        true
      );

      if (!('_id' in orgApplicationResult)) {
        return orgApplicationResult;
      }

      // Return the details of org application details
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Application retrieved successfully',
        orgApplicationResult
      );
    },
  })
);

// Query: Retrieve a list of applications for a specific organization
export const readApplicationListByOrgId = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readApplicationListByOrgId' },
    inputs: { organizationId: v.id('organizations') }, // ID of the organization
    zodSchema: z.object({ organizationId: orgIdZodSchema }),
    handler: async (ctx, { organizationId }) => {
      const orgApplicationList = await getOrgApplicationList(
        ctx,
        organizationId
      );
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved application list successfully.',
        orgApplicationList
      );
    },
  })
);

// Query: Gets all organization list by application id
export const readOrgListByApplicationId = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readOrgListByApplicationId' },
    inputs: { applicationId: v.id('applications') },
    zodSchema: z.object({ applicationId: applicationIdZodSchema }),
    handler: async (ctx, { applicationId }) => {
      const applicationInOrganizations = await ctx.db
        .query('organizationApplications')
        .withIndex('by_application', (q) =>
          q.eq('applicationId', applicationId)
        )
        .collect();

      const orgIds = applicationInOrganizations.map(
        (application) => application.organizationId
      );

      const organizations = await Promise.all(
        orgIds.map((orgId) => ctx.db.get(orgId))
      );

      // Build a Map for quick lookup
      const orgMap = new Map(
        organizations.filter(Boolean).map((org) => [org!._id, org])
      );

      const orgList = applicationInOrganizations.map((orgApplication) => ({
        ...orgApplication,
        organization: orgMap.get(orgApplication.organizationId)!,
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Retrieved organizations by application',
        orgList
      );
    },
  })
);

// Query: Retrieves org Application list, accessible only by a org admin.
export const readOrgApplicationListByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      limit: v.number(),
      cursor: v.optional(v.string()),
      sortOrder: v.union(v.literal('asc'), v.literal('desc')),
      search: v.optional(v.string()),
    },
    zodSchema: convexPaginationQueryZodSchema,
    handler: async (ctx, args, currentUser) => {
      let applicationsQuery;

      // If a search term is provided, filter applications by name.
      if (args.search) {
        applicationsQuery = ctx.db
          .query('organizationApplications')
          .withSearchIndex('search_by_name', (q) =>
            q
              .search('name', args.search || '')
              .eq('organizationId', currentUser.organization._id)
          );
      } else {
        // Otherwise, sort applications by the specified order.
        applicationsQuery = ctx.db
          .query('organizationApplications')
          .withIndex('by_organization_application', (q) =>
            q.eq('organizationId', currentUser.organization?._id)
          )
          .order(args.sortOrder);
      }

      const result = await applicationsQuery.paginate({
        numItems: args.limit,
        cursor: args.cursor || null,
      });

      const applicationIDs = result?.page?.map((item) => item?.applicationId);
      const applicationsRes = await Promise.all(
        applicationIDs?.map((appId) => ctx.db.get(appId))
      );
      const applicationMap = new Map(
        applicationsRes
          .filter((item) => (item?._id ? true : false))
          ?.map((item) => [
            item?._id as Id<'applications'>,
            { ...item, sidebar: undefined },
          ])
      );

      const meta = {
        limit: args?.limit,
        cursor: result?.continueCursor,
        sortOrder: args?.sortOrder,
        isLastPage: result?.isDone,
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        "Retrieved organization's applications",
        result?.page?.map((item) => ({
          ...item,
          application: applicationMap.get(item?.applicationId),
        })),
        meta
      );
    },
  })
);

// Mutation: Changes the status of an org application
export const updateOrgApplicationStatus = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateOrgApplicationStatus' },
    inputs: {
      organizationId: v.id('organizations'),
      applicationId: v.id('applications'),
      isActive: v.boolean(),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      applicationId: applicationIdZodSchema,
      isActive: z.boolean(),
    }),
    handler: async (ctx, inputs) => {
      const orgApplication = await getOrgApplicationOrError(ctx, inputs, true);

      if (!('_id' in orgApplication)) {
        return orgApplication;
      }

      const orgApplicationId = orgApplication?._id;
      if (!orgApplication?.application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      const isRootAppDisabled = !orgApplication?.application?.isActive;
      if (isRootAppDisabled) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          "Main application is disabled, you can't change status"
        );
      }

      // Changing status
      await ctx.db.patch(orgApplicationId, {
        isActive: inputs.isActive,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed application status',
        inputs?.applicationId
      );
    },
  })
);

// Mutation: Changes the status of an org application, accessible only by a org admin.
export const updateOrgApplicationStatusByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      applicationId: v.id('applications'),
      isActive: v.boolean(),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      isActive: z.boolean(),
    }),
    handler: async (ctx, inputs, currentUser) => {
      const orgApplication = await getOrgApplicationOrError(
        ctx,
        { ...inputs, organizationId: currentUser.organization._id },
        true
      );

      if (!('_id' in orgApplication)) {
        return orgApplication;
      }

      const orgApplicationId = orgApplication?._id;
      if (!orgApplication?.application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      const isRootAppDisabled = !orgApplication?.application?.isActive;
      if (isRootAppDisabled) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          "Main application is disabled, you can't change status"
        );
      }

      // Changing status
      await ctx.db.patch(orgApplicationId, {
        isActive: inputs.isActive,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully changed application status',
        inputs?.applicationId
      );
    },
  })
);

// Mutation: Updates the name of an organization's application
export const updateOrgApplicationNameOrDescription = mutation(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'updateOrgApplicationNameOrDescription',
    },
    inputs: {
      organizationId: v.id('organizations'),
      applicationId: v.id('applications'),
      name: v.optional(v.string()),
      description: v.optional(v.string()),
    },
    zodSchema: updateOrgApplicationNameOrDescriptionZodSchema,
    handler: async (ctx, args) => {
      const orgApplicationResult = await getOrgApplicationOrError(
        ctx,
        args,
        false
      );

      if (!('_id' in orgApplicationResult)) {
        return orgApplicationResult;
      }

      const orgApplicationId = orgApplicationResult?._id;

      const data = {
        ...(args?.name ? { name: args?.name } : {}),
        ...(args?.description ? { description: args?.description } : {}),
      };

      const hasUpdatableFields = Object.keys(data)?.length > 0;

      if (!hasUpdatableFields) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'Please enter name or description'
        );
      }

      await ctx.db.patch(orgApplicationId, {
        ...data,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        `Successfully updated ${Object.keys(data)?.join(' and ')}`,
        args.applicationId
      );
    },
  })
);

// Mutation: Updates the name of an organization's application, accessible only by a org admin.
export const updateOrgApplicationNameOrDescriptionByOrgAdmin = mutation(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      applicationId: v.id('applications'),
      name: v.optional(v.string()),
      description: v.optional(v.string()),
    },
    zodSchema: updateOrgApplicationNameOrDescriptionByOrgAdminZodSchema,
    handler: async (ctx, args, currentUser) => {
      const orgApplicationResult = await getOrgApplicationOrError(
        ctx,
        { ...args, organizationId: currentUser.organization._id },
        false
      );

      if (!('_id' in orgApplicationResult)) {
        return orgApplicationResult;
      }

      const orgApplicationId = orgApplicationResult?._id;

      const data = {
        ...(args?.name ? { name: args?.name } : {}),
        ...(args?.description ? { description: args?.description } : {}),
      };

      const hasUpdatableFields = Object.keys(data)?.length > 0;

      if (!hasUpdatableFields) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'Please enter name or description'
        );
      }

      await ctx.db.patch(orgApplicationId, {
        ...data,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        `Successfully updated ${Object.keys(data)?.join(' and ')}`,
        args.applicationId
      );
    },
  })
);

// Mutation: Remove an application from an organization
export const deleteOrgApplication = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteOrgApplication' },
    inputs: {
      organizationId: v.id('organizations'),
      applicationId: v.id('applications'),
    },
    zodSchema: z.object({
      organizationId: orgIdZodSchema,
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, args) => {
      const existingResult = await getOrgApplicationOrError(ctx, args, false);

      if (!('_id' in existingResult)) {
        return existingResult;
      }

      // Remove the application access from user first
      const userApplications = await ctx.db
        .query('userApplications')
        .withIndex('by_organization_application', (q) =>
          q
            .eq('organizationId', args?.organizationId)
            .eq('applicationId', args?.applicationId)
        )
        .collect();

      await Promise.all(
        userApplications?.map((item) => ctx.db.delete(item?._id))
      );

      // Deleting the organization application
      const orgApplicationId = existingResult._id;
      await ctx.db.delete(orgApplicationId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Successfully removed the application',
        true
      );
    },
  })
);
