import { v } from 'convex/values';
import { z } from 'zod';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { permissionMethods } from '../../../../constants/common';
import { permissionMethodField } from '../../../../utils/fields';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import {
  applicationIdZodSchema,
  permissionIdZodSchema,
} from '../../../../validations/common';
import { getPermissionByPermissionKey } from './applications.utils';
import {
  addPermissionZodSchema,
  updatePermissionZodSchema,
} from './applications.validations';

const applicationKey = APPLICATION_KEYS.global;

// Mutation: Creates a new permission to an application
export const createPermission = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createPermission' },
    inputs: {
      key: v.string(),
      method: permissionMethodField,
      name: v.string(),
      description: v.string(),
      applicationId: v.id('applications'),
    },
    zodSchema: addPermissionZodSchema,
    handler: async (ctx, inputs, currentUser) => {
      // Check if application exists
      const application = await ctx.db.get(inputs.applicationId);
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      // Check if permission already exists
      const existingPermission = await getPermissionByPermissionKey(
        ctx,
        inputs.key,
        inputs.applicationId
      );

      if (existingPermission) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'Permission already exists with the same key in the application'
        );
      }

      // Creates new permission
      const permissionId = await ctx.db.insert('permissions', {
        key: inputs.key,
        method: inputs.method,
        name: inputs.name,
        description: inputs.description,
        applicationId: inputs.applicationId,
        addedBy: currentUser?._id,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Permission added successfully',
        permissionId
      );
    },
  })
);

// Query: Fetches all permissions for a specific application
export const readPermissions = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readPermissions' },
    inputs: {
      method: v.optional(permissionMethodField),
      search: v.optional(v.string()),
      applicationId: v.id('applications'),
    },
    zodSchema: z.object({
      search: z.string().optional(),
      method: z.enum(permissionMethods).optional(),
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, { applicationId, method, search }) => {
      // Check if application exists
      const application = await ctx.db.get(applicationId);
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      // Fetch all permissions for the application
      let permissionsQuery;
      if (search) {
        permissionsQuery = ctx.db
          .query('permissions')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', search || '').eq('applicationId', applicationId)
          );
      } else if (method && method !== undefined) {
        permissionsQuery = ctx.db
          .query('permissions')
          .withIndex('by_application_method', (q) =>
            q
              .eq('applicationId', applicationId)
              .eq('method', method as (typeof permissionMethods)[number])
          );
      } else {
        permissionsQuery = ctx.db
          .query('permissions')
          .withIndex('by_application_method', (q) =>
            q.eq('applicationId', applicationId)
          );
      }

      const permissions = await permissionsQuery.collect();

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Permissions fetched successfully',
        permissions
      );
    },
  })
);

// Mutation: Updates an existing permission
export const updatePermission = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updatePermission' },
    inputs: {
      permissionId: v.id('permissions'),
      key: v.string(),
      name: v.string(),
      method: permissionMethodField,
      description: v.string(),
    },
    zodSchema: updatePermissionZodSchema,
    handler: async (ctx, args) => {
      // Check if permission exists
      const permission = await ctx.db.get(args.permissionId);
      if (!permission) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Permission does not exist'
        );
      }

      // Check if the function name already exists in the application on other permissions
      const otherPermissionWithSameKey = await getPermissionByPermissionKey(
        ctx,
        args.key,
        permission?.applicationId
      );

      if (
        otherPermissionWithSameKey &&
        otherPermissionWithSameKey._id !== args.permissionId
      ) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'The key is already used in the application'
        );
      }

      // Update permission
      await ctx.db.patch(args.permissionId, {
        key: args.key,
        method: args.method,
        name: args.name,
        description: args.description,
        updatedAt: Date.now(),
      });
      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Permission updated successfully',
        args?.permissionId
      );
    },
  })
);

// Mutation: Removes a permission from an application
export const deletePermission = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deletePermission' },
    inputs: { permissionId: v.id('permissions') },
    zodSchema: z.object({ permissionId: permissionIdZodSchema }),
    handler: async (ctx, { permissionId }) => {
      // Check if permission exists
      const permission = await ctx.db.get(permissionId);
      if (!permission) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Permission does not exist'
        );
      }

      // Remove the permission from all roles
      const allRoles = await ctx.db
        .query('roles')
        .withIndex('by_application_role', (q) =>
          q.eq('applicationId', permission.applicationId)
        )
        .collect();

      const affectedRoles = allRoles.filter((role) =>
        (role.permissions || [])?.includes(permissionId)
      );

      for (const role of affectedRoles) {
        const updatedPermissions = role.permissions.filter(
          (id) => id !== permissionId
        );
        await ctx.db.patch(role._id, { permissions: updatedPermissions });
      }

      // Delete permission
      await ctx.db.delete(permissionId);
      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Permission deleted successfully',
        true
      );
    },
  })
);
