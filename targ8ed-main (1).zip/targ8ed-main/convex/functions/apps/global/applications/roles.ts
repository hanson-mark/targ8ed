import { v } from 'convex/values';
import { z } from 'zod';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { IRole } from '../../../../types/convex-types';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import { convexOrgMiddleware } from '../../../../utils/middlewares/convexOrgMiddleware';
import {
  applicationIdZodSchema,
  descriptionZodSchema,
  permissionIdZodSchema,
  roleIdZodSchema,
} from '../../../../validations/common';
import {
  createRoleZodSchema,
  roleNameZodSchema,
} from './applications.validations';

const applicationKey = APPLICATION_KEYS.global;

// Mutation: Creates a new role to an application
export const createApplicationRole = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createApplicationRole' },
    inputs: {
      name: v.string(),
      description: v.string(),
      isAdminRole: v.boolean(),
      applicationId: v.id('applications'),
    },
    zodSchema: createRoleZodSchema,
    handler: async (ctx, inputs, currentUser) => {
      // Check if application exists
      const application = await ctx.db.get(inputs.applicationId);
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      // Check if role already exists
      const existingRole = await ctx.db
        .query('roles')
        .withIndex('by_application_role', (q) =>
          q.eq('applicationId', inputs?.applicationId).eq('name', inputs.name)
        )
        .first();

      if (existingRole) {
        return generateConvexErrorResponse(
          HttpStatusCodes.CONFLICT,
          'Role already exists in the application'
        );
      }

      // Add new role
      const roleId = await ctx.db.insert('roles', {
        name: inputs.name,
        description: inputs.description,
        isAdminRole: inputs?.isAdminRole || false,
        permissions: [],
        applicationId: inputs.applicationId,
        addedBy: currentUser?._id,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Role added successfully',
        roleId
      );
    },
  })
);

export const readApplicationRoleDetails = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readApplicationRoleDetails' },
    inputs: { roleId: v.id('roles'), applicationId: v.id('applications') },
    zodSchema: z.object({
      roleId: roleIdZodSchema,
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, { roleId, applicationId }) => {
      const role = await ctx.db.get(roleId);
      if (!role) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Role not found'
        );
      }

      if (role.applicationId !== applicationId) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'The role is not associated with the application'
        );
      }

      const application = await ctx.db.get(role.applicationId);
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'No application found that is connected with the role.'
        );
      }

      const allPermissions = await ctx.db
        .query('permissions')
        .withIndex('by_application_key', (q) =>
          q.eq('applicationId', role.applicationId)
        )
        .collect();

      const permissionsMap = new Map(
        allPermissions?.map((permission) => [permission._id, permission])
      );

      const formattedRole = {
        ...role,
        application,
        permissions: role?.isAdminRole
          ? allPermissions
          : role?.permissions?.map(
              (permissionId) => permissionsMap.get(permissionId)!
            ),
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Role fetched successfully',
        formattedRole
      );
    },
  })
);

// Query: Fetches all roles of an application
export const readApplicationRoles = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readApplicationRoles' },
    inputs: {
      search: v.optional(v.string()),
      applicationId: v.id('applications'),
    },
    zodSchema: z.object({
      search: z.string().optional(),
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, { applicationId, search = '' }) => {
      // Step-01: Check if application exists
      const application = await ctx.db.get(applicationId);
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      // Step-02: Fetch all roles of the application
      let rolesQuery;
      if (search) {
        rolesQuery = ctx.db
          .query('roles')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', search || '').eq('applicationId', applicationId)
          );
      } else {
        rolesQuery = ctx.db
          .query('roles')
          .withIndex('by_application_role', (q) =>
            q.eq('applicationId', application._id)
          );
      }

      // Step-03: Retrieving all roles & permissions and creating a permissions Map
      const roles = await rolesQuery.collect();

      const allPermissions = await ctx.db
        .query('permissions')
        .withIndex('by_application_key', (q) =>
          q.eq('applicationId', applicationId)
        )
        .collect();

      const permissionsMap = new Map(
        allPermissions?.map((permission) => [permission._id, permission])
      );

      // Step-04: Formatting roles and sending as response
      const formattedRoles: IRole[] = roles?.map((role) => ({
        ...role,
        permissions: role?.isAdminRole
          ? allPermissions
          : role?.permissions?.map(
              (permissionId) => permissionsMap.get(permissionId)!
            ),
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Roles fetched successfully',
        formattedRoles
      );
    },
  })
);

// Query: Fetches all roles of an application, accessible only by a org admin.
export const readApplicationRolesByOrgAdmin = query(
  convexOrgMiddleware({
    options: { accessTypes: ['org-admin'] },
    inputs: {
      search: v.optional(v.string()),
      applicationId: v.id('applications'),
    },
    zodSchema: z.object({
      search: z.string().optional(),
      applicationId: applicationIdZodSchema,
    }),
    handler: async (ctx, { applicationId, search = '' }) => {
      // Step-01: Check if application exists
      const application = await ctx.db.get(applicationId);
      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application does not exist'
        );
      }

      // Step-02: Fetch all roles of the application
      let rolesQuery;
      if (search) {
        rolesQuery = ctx.db
          .query('roles')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', search || '').eq('applicationId', applicationId)
          );
      } else {
        rolesQuery = ctx.db
          .query('roles')
          .withIndex('by_application_role', (q) =>
            q.eq('applicationId', application._id)
          );
      }

      // Step-03: Retrieving all roles & permissions and creating a permissions Map
      const roles = await rolesQuery.collect();

      const allPermissions = await ctx.db
        .query('permissions')
        .withIndex('by_application_key', (q) =>
          q.eq('applicationId', applicationId)
        )
        .collect();

      const permissionsMap = new Map(
        allPermissions?.map((permission) => [permission._id, permission])
      );

      // Step-04: Formatting roles and sending as response
      const formattedRoles: IRole[] = roles?.map((role) => ({
        ...role,
        permissions: role?.isAdminRole
          ? allPermissions
          : role?.permissions?.map(
              (permissionId) => permissionsMap.get(permissionId)!
            ),
      }));

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Roles fetched successfully',
        formattedRoles
      );
    },
  })
);

// Mutation: Updates a role of an application with name & permissions
export const updateApplicationRole = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateApplicationRole' },
    inputs: {
      roleId: v.id('roles'),
      name: v.string(),
      description: v.string(),
      isAdminRole: v.boolean(),
    },
    zodSchema: z.object({
      roleId: roleIdZodSchema,
      name: roleNameZodSchema,
      description: descriptionZodSchema,
      isAdminRole: z.boolean().optional(),
    }),
    handler: async (ctx, { roleId, name, description, isAdminRole }) => {
      // Check if role exists
      const role = await ctx.db.get(roleId);
      if (!role) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Role does not exist'
        );
      }

      // Update role permissions
      await ctx.db.patch(roleId, {
        name,
        description,
        isAdminRole: !!isAdminRole,
        updatedAt: Date.now(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Role permissions updated successfully',
        roleId
      );
    },
  })
);

// Mutation: Updates a role of an application with name & permissions
export const updatePermissionsOfApplicationRole = mutation(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'updatePermissionsOfApplicationRole',
    },
    inputs: {
      roleId: v.id('roles'),
      permissions: v.array(v.id('permissions')),
    },
    zodSchema: z.object({
      roleId: roleIdZodSchema,
      permissions: z.array(permissionIdZodSchema),
    }),
    handler: async (ctx, { roleId, permissions }) => {
      // Check if role exists
      const role = await ctx.db.get(roleId);
      if (!role) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Role does not exist'
        );
      }

      // Update role permissions
      await ctx.db.patch(roleId, {
        permissions: permissions,
        updatedAt: Date.now(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Permissions of the role has been updated successfully',
        roleId
      );
    },
  })
);

// Mutation: Deletes a role from an application
export const deleteApplicationRole = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteApplicationRole' },
    inputs: { roleId: v.id('roles') },
    zodSchema: z.object({ roleId: roleIdZodSchema }),
    handler: async (ctx, { roleId }) => {
      // Check if role exists
      const role = await ctx.db.get(roleId);
      if (!role) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Role does not exist'
        );
      }

      // Delete role
      await ctx.db.delete(roleId);

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        'Role deleted successfully',
        true
      );
    },
  })
);
