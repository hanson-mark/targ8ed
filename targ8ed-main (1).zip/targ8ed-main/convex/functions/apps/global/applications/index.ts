import { v } from 'convex/values';
import { z } from 'zod';
import { internal } from '../../../../_generated/api';
import { mutation, query } from '../../../../_generated/server';
import { APPLICATION_KEYS } from '../../../../constants/applicationKey';
import { ROOT_CONFIG } from '../../../../constants/rootConfig';
import {
  getFormattedImageURL,
  removeFileFromStorage,
} from '../../../../utils/common';
import {
  generateConvexErrorResponse,
  generateConvexSuccessResponse,
} from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';
import { convexAppMiddleware } from '../../../../utils/middlewares/convexAppMiddleware';
import {
  applicationIdZodSchema,
  applicationKeyZodSchema,
  convexPaginationQueryZodSchema,
  descriptionZodSchema,
  nameZodSchema,
  sidebarTreeItemZodSchema,
  storageIdZodSchema,
} from '../../../../validations/common';
import { getFormattedSidebarDataWithModules } from './applications.utils';
import { updateApplicationNameOrDescriptionZodSchema } from './applications.validations';

// Middleware options
const applicationKey = APPLICATION_KEYS.global;

// Query: Checks if a key is available by querying the 'applications' table.
export const readKeyAvailability = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readKeyAvailability' },
    inputs: { key: v.string() },
    zodSchema: z.object({ key: applicationKeyZodSchema }),
    handler: async (ctx, { key }) => {
      const application = await ctx.db
        .query('applications')
        .withIndex('by_key', (q) => q.eq('key', key))
        .first();

      const isAvailable = application?._id ? false : true;

      return {
        success: isAvailable,
        data: isAvailable,
        message: isAvailable
          ? `Key "${key}" is available`
          : `Key "${key}" is not available`,
      };
    },
  })
);

// Mutation: Creates a new application
export const createApplication = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'createApplication' },
    inputs: {
      name: v.string(),
      description: v.string(),
      key: v.string(),
    },
    zodSchema: z.object({
      name: nameZodSchema,
      description: descriptionZodSchema,
      key: applicationKeyZodSchema,
    }),
    handler: async (ctx, inputs, currentUser) => {
      const applicationId = await ctx.db.insert('applications', {
        ...inputs,
        sidebar: [],
        createdBy: currentUser?._id,
        isActive: true,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.CREATED,
        'Application added successfully',
        applicationId
      );
    },
  })
);

// Query: Fetches a single application by its ID
export const readApplicationDetails = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readApplicationDetails' },
    inputs: { applicationId: v.id('applications') },
    zodSchema: z.object({ applicationId: applicationIdZodSchema }),
    handler: async (ctx, { applicationId }) => {
      const application = await ctx.db.get(applicationId);

      if (!application) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Application not found'
        );
      }

      const applicationModules = await ctx.db
        .query('applicationModules')
        .withIndex('by_application_link', (q) =>
          q.eq('applicationId', application?._id)
        )
        .collect();

      const sidebar = getFormattedSidebarDataWithModules(
        application?.sidebar || [],
        applicationModules || []
      );

      const formattedApplication = {
        ...application,
        sidebar,
        modules: applicationModules,
        image: await getFormattedImageURL(ctx, application?.imageId, ''),
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Application retrieved successfully',
        formattedApplication
      );
    },
  })
);

// Query: Fetches all applications with optional search, sorting, and pagination.
export const readApplications = query(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'readApplications' },
    inputs: {
      limit: v.number(),
      cursor: v.optional(v.string()),
      sortOrder: v.union(v.literal('asc'), v.literal('desc')),
      search: v.optional(v.string()),
    },
    zodSchema: convexPaginationQueryZodSchema,
    handler: async (
      ctx,
      { limit, cursor = undefined, sortOrder, search = undefined }
    ) => {
      let applicationsQuery;

      // If a search term is provided, filter applications by name.
      if (search) {
        applicationsQuery = ctx.db
          .query('applications')
          .withSearchIndex('search_by_name', (q) =>
            q.search('name', search || '')
          );
      } else {
        // Otherwise, sort applications by the specified order.
        applicationsQuery = ctx.db.query('applications').order(sortOrder);
      }

      const result = await applicationsQuery.paginate({
        numItems: limit,
        cursor: cursor || null,
      });

      const meta = {
        limit,
        cursor: result?.continueCursor,
        sortOrder,
        isLastPage: result?.isDone,
      };

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Applications retrieved successfully',
        result?.page,
        meta
      );
    },
  })
);

// Mutation: Update application image id
export const updateApplicationImageId = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateApplicationImageId' },
    inputs: {
      applicationId: v.id('applications'),
      imageId: v.id('_storage'),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      imageId: storageIdZodSchema,
    }),
    handler: async (ctx, { applicationId, imageId }) => {
      const existingApplication = await ctx.db.get(applicationId);

      if (existingApplication?.imageId) {
        await removeFileFromStorage(ctx, existingApplication?.imageId);
      }

      await ctx.db.patch(applicationId, {
        imageId,
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Uploaded application logo successfully',
        applicationId
      );
    },
  })
);

// Mutation: Changes the status of an application
export const updateApplicationStatus = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateApplicationStatus' },
    inputs: {
      applicationId: v.id('applications'),
      isActive: v.boolean(),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      isActive: z.boolean(),
    }),
    handler: async (ctx, { applicationId, isActive }, currentUser) => {
      const isSameApplication =
        currentUser?.appUser?.applicationId == applicationId;

      if (isSameApplication) {
        return generateConvexErrorResponse(
          HttpStatusCodes.FORBIDDEN,
          'You can not change your current application status'
        );
      }

      const application = await ctx.db.get(applicationId);
      if (application?.key === ROOT_CONFIG.application.key) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          "You can't change root application status"
        );
      }

      await ctx.db.patch(applicationId, {
        isActive: isActive,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Successfully updated application status',
        applicationId
      );
    },
  })
);

// Mutation: Updates the name of an application
export const updateApplicationNameOrDescription = mutation(
  convexAppMiddleware({
    options: {
      applicationKey,
      permissionKey: 'updateApplicationNameOrDescription',
    },
    inputs: {
      applicationId: v.id('applications'),
      name: v.optional(v.string()),
      description: v.optional(v.string()),
    },
    zodSchema: updateApplicationNameOrDescriptionZodSchema,
    handler: async (ctx, args) => {
      const data = {
        ...(args?.name ? { name: args?.name } : {}),
        ...(args?.description ? { description: args?.description } : {}),
      };

      const hasUpdatableFields = Object.keys(data)?.length > 0;

      if (!hasUpdatableFields) {
        return generateConvexErrorResponse(
          HttpStatusCodes.BAD_REQUEST,
          'Please enter name or description'
        );
      }

      const applicationId = args?.applicationId;

      await ctx.db.patch(applicationId, {
        ...data,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        `Successfully updated ${Object.keys(data)?.join(' and ')}`,
        applicationId
      );
    },
  })
);

// Mutation: Updates the sidebar of an application
export const updateSidebar = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'updateSidebar' },
    inputs: {
      applicationId: v.id('applications'),
      sidebar: v.array(v.any()),
    },
    zodSchema: z.object({
      applicationId: applicationIdZodSchema,
      sidebar: z.array(sidebarTreeItemZodSchema),
    }),
    handler: async (ctx, args) => {
      const applicationId = args?.applicationId;

      await ctx.db.patch(applicationId, {
        sidebar: args.sidebar,
        updatedAt: new Date().getTime(),
      });

      return generateConvexSuccessResponse(
        HttpStatusCodes.OK,
        'Updated application sidebar successfully',
        applicationId
      );
    },
  })
);

// Mutation: Removes an application
export const deleteApplication = mutation(
  convexAppMiddleware({
    options: { applicationKey, permissionKey: 'deleteApplication' },
    inputs: { applicationId: v.id('applications') },
    zodSchema: z.object({ applicationId: applicationIdZodSchema }),
    handler: async (ctx, args) => {
      const existing = await ctx.db.get(args?.applicationId);

      if (!existing) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'No application found to delete'
        );
      }

      if (existing?.key === ROOT_CONFIG.application.key) {
        return generateConvexErrorResponse(
          HttpStatusCodes.NOT_FOUND,
          'Root application is not deletable.'
        );
      }

      // Updating application's "isDeleting" flag
      await ctx.db.patch(args?.applicationId, { isDeleting: true });

      // Running internal mutation to delete org & it's relationships
      await ctx.runMutation(
        internal.functions.apps.global.applications.internal.removeAppRelations,
        { applicationId: args?.applicationId }
      );

      return generateConvexSuccessResponse(
        HttpStatusCodes.NO_CONTENT,
        "Removed the application and it's relations",
        true
      );
    },
  })
);
