import { Doc, Id } from '../../../../_generated/dataModel';
import { MutationCtx, QueryCtx } from '../../../../_generated/server';
import {
  IConvexErrorResponse,
  IConvexSidebarTreeItem,
  IOrgApplication,
  IRole,
} from '../../../../types/convex-types';
import { getFormattedImageURL } from '../../../../utils/common';
import { generateConvexErrorResponse } from '../../../../utils/generateResponse';
import HttpStatusCodes from '../../../../utils/httpStatusCode';

// ===================== [ Application related] ===============

interface IOrgAndApplicationId {
  organizationId: Id<'organizations'>;
  applicationId: Id<'applications'>;
}

export const getOrgApplicationOrError = async (
  ctx: QueryCtx | MutationCtx,
  { organizationId, applicationId }: IOrgAndApplicationId,
  withDetails: boolean = true
): Promise<IOrgApplication | IConvexErrorResponse> => {
  // Get the org application
  const orgApplication = await ctx.db
    .query('organizationApplications')
    .withIndex('by_organization_application', (q) =>
      q.eq('organizationId', organizationId).eq('applicationId', applicationId)
    )
    .first();

  if (!orgApplication) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'Application does not exist in this organization'
    );
  }

  if (!withDetails) {
    return {
      ...orgApplication,
      application: undefined,
      organization: undefined,
    };
  }

  const organization = await ctx.db.get(organizationId);
  if (!organization) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'Organization not found'
    );
  }

  const application = await ctx.db.get(applicationId);
  if (!application) {
    return generateConvexErrorResponse(
      HttpStatusCodes.NOT_FOUND,
      'Application not found'
    );
  }

  // Return the details of org application details
  return {
    ...orgApplication,
    isActive: application?.isActive ? orgApplication?.isActive : false,
    application: {
      ...application,
      image: await getFormattedImageURL(ctx, application?.imageId, ''),
      sidebar: undefined,
    },
    organization,
  };
};

export const getOrgApplicationList = async (
  ctx: QueryCtx | MutationCtx,
  organizationId: Id<'organizations'>
) => {
  // Get the list of applications associated with the organization
  const applicationInOrganization = await ctx.db
    .query('organizationApplications')
    .withIndex('by_organization_application', (q) =>
      q.eq('organizationId', organizationId)
    )
    .collect();

  // Extract the application IDs from the retrieved data
  const applicationIds = applicationInOrganization.map(
    (user) => user.applicationId
  );

  // Fetch the application details for each application ID
  const applicationsWithoutImage = await Promise.all(
    applicationIds.map((appId) => ctx.db.get(appId))
  );
  const applications = await Promise.all(
    applicationsWithoutImage?.map(async (item) =>
      item && item?.imageId
        ? {
            ...item,
            image: (await ctx.storage.getUrl(item?.imageId)) || undefined,
          }
        : null
    )
  );

  // Build a Map for quick lookup of applications by their ID
  const applicationMap = new Map(
    applications.filter(Boolean).map((org) => [org!._id, org])
  );

  // The list of applications with the associated data
  const orgApplicationList = applicationInOrganization.map((orgApplication) => {
    const application = applicationMap.get(orgApplication.applicationId);
    const formattedApplication = application
      ? { ...application, sidebar: undefined }
      : application;
    return {
      ...orgApplication,
      application: formattedApplication!,
    };
  });

  return orgApplicationList;
};

export const formatUserApplication = (
  userApplication?: Doc<'userApplications'> | null,
  orgApplication?: Doc<'organizationApplications'> | null,
  mainApplication?: (Doc<'applications'> & { roles?: Doc<'roles'>[] }) | null,
  returnOnlyActive: boolean = false,
  hideSidebar: boolean = false
) => {
  if (!mainApplication || !orgApplication || !userApplication) return null;

  const isActive = mainApplication.isActive ? userApplication.isActive : false;

  if (returnOnlyActive && !isActive) return null;

  const allRoles = mainApplication?.roles || [];
  const roles =
    allRoles?.length > 0
      ? userApplication.roles
          ?.map(
            (roleId) =>
              allRoles?.find((role) => role?._id === roleId) as Doc<'roles'>
          )
          .filter(Boolean)
      : userApplication.roles;

  return {
    ...mainApplication,
    sidebar: hideSidebar ? undefined : mainApplication?.sidebar,
    name: orgApplication?.name,
    isActive,
    roles: roles || [],
    userId: userApplication?.userId,
    organizationId: userApplication?.organizationId,
  };
};

export const getUserApplicationList = async (params: {
  ctx: QueryCtx | MutationCtx;

  userId: Id<'users'>;
  organizationId: Id<'organizations'>;

  returnOnlyActiveApps?: boolean;
  includeRoles?: boolean;
  hideSidebar?: boolean;
}) => {
  const {
    ctx,
    userId,
    organizationId,
    returnOnlyActiveApps = false,
    includeRoles = true,
    hideSidebar = false,
  } = params;

  // Step-1: User Applications
  const userApplications = await ctx.db
    .query('userApplications')
    .withIndex('by_user_organization_application', (q) =>
      q.eq('userId', userId).eq('organizationId', organizationId)
    )
    .filter((q) => q.neq(q.field('isDeleting'), true))
    .collect();

  const userApplicationIDs = userApplications
    .filter((app) =>
      !returnOnlyActiveApps ? true : app?.isActive ? true : false
    )
    .map((user) => user.applicationId);

  // Step-2: Org Applications
  const orgApplications = await ctx.db
    .query('organizationApplications')
    .withIndex('by_organization_application', (q) =>
      q.eq('organizationId', organizationId)
    )
    .collect();
  // Build a Map for quick lookup
  const orgApplicationMap = new Map(
    orgApplications
      .filter((app) => (app?.isActive ? true : false))
      .map((app) => [app!.applicationId, app])
  );
  const userApplicationIDSet = new Set(userApplicationIDs);

  const orgApplicationIDsForUser = orgApplications
    .map((item) => (item?.isActive ? item?.applicationId : null))
    .filter((orgAppId): orgAppId is Id<'applications'> => {
      if (!orgAppId) return false;
      return Boolean(orgAppId && userApplicationIDSet.has(orgAppId));
    });

  // Step-3: Applications & application roles
  const rawApplications = await Promise.all(
    orgApplicationIDsForUser.map((appId) => ctx.db.get(appId))
  );
  const applications = await Promise.all(
    rawApplications.map(async (app) =>
      app && app?.isActive
        ? {
            ...app,
            image: await getFormattedImageURL(ctx, app?.imageId, ''),
          }
        : app
    )
  );

  let applicationRolesMap: Map<Id<'applications'>, Doc<'roles'>[]> | undefined;
  if (includeRoles) {
    applicationRolesMap = await getApplicationIDsToApplicationRolesMap(
      ctx,
      orgApplicationIDsForUser
    );
  }

  // Build a Map for quick lookup
  const applicationMap = new Map(
    applications
      .filter((app) => (app && app?._id ? true : false))
      .map((app) => [
        app?._id,
        {
          ...((app || {}) as Doc<'applications'>),
          ...(includeRoles && applicationRolesMap
            ? { roles: applicationRolesMap.get(app?._id as Id<'applications'>) }
            : { roles: [] }),
        },
      ])
  );

  const finalList = userApplications
    .map((userApp) => {
      const mainApplication = applicationMap.get(userApp.applicationId);
      const orgApplication = orgApplicationMap.get(userApp?.applicationId);

      return formatUserApplication(
        userApp,
        orgApplication,
        mainApplication,
        returnOnlyActiveApps,
        hideSidebar
      );
    })
    .filter((app): app is NonNullable<typeof app> => !!app);

  return finalList || [];
};

export const getAvailableAssignedApplications = async (
  ctx: QueryCtx | MutationCtx,
  organizationId: Id<'organizations'>,
  assignedApplications: {
    applicationId: Id<'applications'>;
    roleId: Id<'roles'>;
  }[]
) => {
  // Step-03: Collecting available application IDs
  const orgApplications = await getOrgApplicationList(ctx, organizationId);
  const orgApplicationIDs = orgApplications?.map((item) => item?.applicationId);
  const assignedApplicationIDs = assignedApplications?.map(
    (item) => item?.applicationId
  );
  const availableApplicationIDs = (orgApplicationIDs || [])?.filter((appID) =>
    assignedApplicationIDs.includes(appID)
  );

  // Step-04: Collecting available roles
  const roleIds = [
    ...new Set(assignedApplications?.map((item) => item?.roleId)),
  ];
  const rolesRes = await Promise.all(
    roleIds?.map((roleId) => ctx.db.get(roleId))
  );
  const roles = rolesRes.filter(Boolean);

  // Step-05: Collecting final assigned applications
  const finalAssignedApplications = availableApplicationIDs
    ?.map((appId) => {
      const assignedApp = assignedApplications?.find(
        (app) => app.applicationId === appId
      );
      const role = roles?.find((r) => r?._id === assignedApp?.roleId);

      if (assignedApp?.applicationId && role?._id) {
        return assignedApp;
      }

      return null;
    })
    .filter(Boolean) as {
    applicationId: Id<'applications'>;
    roleId: Id<'roles'>;
  }[];

  return finalAssignedApplications;
};

export const assignUserToApplication = async (
  ctx: MutationCtx,
  userId: Id<'users'>,
  organizationId: Id<'organizations'>,
  applicationId: Id<'applications'>,
  roleId: Id<'roles'>,
  addedBy?: Id<'users'>
) => {
  const existing = await ctx.db
    .query('userApplications')
    .withIndex('by_user_organization_application', (q) =>
      q
        .eq('userId', userId)
        .eq('organizationId', organizationId)
        .eq('applicationId', applicationId)
    )
    .first();

  if (existing) {
    return generateConvexErrorResponse(
      HttpStatusCodes.CONFLICT,
      'User is already added in this application'
    );
  }

  const userAppId = await ctx.db.insert('userApplications', {
    userId: userId,
    applicationId: applicationId,
    organizationId: organizationId,
    roles: [roleId],
    isActive: true,
    addedBy: addedBy,
  });

  return userAppId;
};

// Formats sidebar data with module data
export const getFormattedSidebarDataWithModules = (
  sidebarData: IConvexSidebarTreeItem[],
  applicationModules: Doc<'applicationModules'>[]
) => {
  const moduleMap = new Map(
    applicationModules?.map((item) => [item?._id, item])
  );
  const getFormattedItem = (
    item: IConvexSidebarTreeItem
  ): IConvexSidebarTreeItem | null => {
    const children = item.children
      ? ((item.children as IConvexSidebarTreeItem[])
          .map(getFormattedItem)
          .filter(Boolean) as IConvexSidebarTreeItem[])
      : [];

    if (item?.type === 'link' || item?.type === 'split-button') {
      const appModule = moduleMap.get(item?.moduleId);
      if (!appModule) return null;

      return {
        ...item,
        children,
        module: appModule,
      } as IConvexSidebarTreeItem;
    } else {
      return { ...item, children } as IConvexSidebarTreeItem;
    }
  };

  const formattedData = (sidebarData?.map(getFormattedItem) || []).filter(
    Boolean
  ) as IConvexSidebarTreeItem[];

  return formattedData;
};

// ==================== [ Roles & Permissions ] ==============
export const getPermissionByPermissionKey = async (
  ctx: QueryCtx | MutationCtx,
  key: string,
  applicationId: Id<'applications'>
) => {
  const permission = await ctx.db
    .query('permissions')
    .withIndex('by_application_key', (q) =>
      q.eq('applicationId', applicationId).eq('key', key)
    )
    .first();

  return permission;
};

export const getApplicationPermissions = async (
  ctx: QueryCtx | MutationCtx,
  applicationId: Id<'applications'>
) => {
  const permissions = await ctx.db
    .query('permissions')
    .withIndex('by_application_key', (q) =>
      q.eq('applicationId', applicationId)
    )
    .collect();

  return permissions;
};

export const getApplicationRoles = async (
  ctx: QueryCtx | MutationCtx,
  applicationId: Id<'applications'>
) => {
  const roles = await ctx.db
    .query('roles')
    .withIndex('by_application_role', (q) =>
      q.eq('applicationId', applicationId)
    )
    .collect();

  return roles;
};

export const getApplicationRolesWithPermissions = async (
  ctx: QueryCtx | MutationCtx,
  applicationId: Id<'applications'>
) => {
  const permissions = await getApplicationPermissions(ctx, applicationId);
  const permissionsMap = new Map(
    permissions?.map((permission) => [permission!._id, permission])
  );

  const roles = await getApplicationRoles(ctx, applicationId);

  const formattedRoles: IRole[] = roles?.map((role) => ({
    ...role,
    permissions: role?.isAdminRole
      ? permissions
      : role?.permissions?.map(
          (permissionId) => permissionsMap.get(permissionId)!
        ),
  }));

  return formattedRoles;
};

export const getApplicationIDsToApplicationRolesMap = async (
  ctx: QueryCtx | MutationCtx,
  applicationIDs: Id<'applications'>[]
) => {
  // Step-5: Retrieving roles for each application & building a Map
  const applicationsRolesResponse = await Promise.all(
    applicationIDs?.map((applicationId) =>
      getApplicationRoles(ctx, applicationId)
    )
  );
  const applicationsRolesMap = new Map<Id<'applications'>, Doc<'roles'>[]>();

  applicationsRolesResponse.forEach((roles) => {
    roles?.forEach((role) => {
      const appId = role.applicationId;
      if (!applicationsRolesMap.has(appId)) {
        applicationsRolesMap.set(appId, []);
      }

      applicationsRolesMap.get(appId)!.push(role);
    });
  });
  return applicationsRolesMap;
};
