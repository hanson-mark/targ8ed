import { v } from 'convex/values';
import { mutation } from '../_generated/server';
import { removeFileFromStorage } from '../utils/common';

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const removeFile = mutation({
  args: { storageId: v.id('_storage') },
  handler: async (ctx, { storageId }) => {
    if (storageId && storageId?.length > 1) {
      await removeFileFromStorage(ctx, storageId);
    }
  },
});
