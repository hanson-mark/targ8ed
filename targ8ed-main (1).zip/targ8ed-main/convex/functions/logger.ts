import { v } from 'convex/values';
import { mutation } from '../_generated/server';

export const log = mutation({
  args: {
    text: v.string(),
  },
  handler: async (ctx, args) => {
    const logId = await ctx.db.insert('dbLogger', {
      ...args,
    });
    return logId;
  },
});
