import { v } from 'convex/values';
import { internalMutation, internalQuery } from '../_generated/server';

export const createTracker = internalMutation({
  args: { groupKey: v.string(), name: v.string() },
  handler: async (ctx, args) => {
    const trackerId = await ctx.db.insert('deletionTracker', {
      groupKey: args?.groupKey,
      name: args?.name,
      status: 'pending',
    });

    return trackerId;
  },
});

export const changeStatus = internalMutation({
  args: {
    trackerId: v.id('deletionTracker'),
    status: v.union(v.literal('done'), v.literal('error')),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args?.trackerId, {
      status: args?.status,
    });

    return args?.trackerId;
  },
});

export const removeTrackers = internalMutation({
  args: { groupKey: v.string() },
  handler: async (ctx, args) => {
    const trackersData = await ctx.db
      .query('deletionTracker')
      .withIndex('by_groupKey', (q) => q.eq('groupKey', args?.groupKey))
      .collect();

    await Promise.all(trackersData?.map((item) => ctx.db.delete(item?._id)));

    return true;
  },
});

export const getTracker = internalQuery({
  args: { trackerId: v.id('deletionTracker') },
  handler: async (ctx, args) => {
    const trackerData = await ctx.db.get(args?.trackerId);

    return trackerData;
  },
});

export const getTrackersByKey = internalQuery({
  args: { groupKey: v.string() },
  handler: async (ctx, args) => {
    const trackersData = await ctx.db
      .query('deletionTracker')
      .withIndex('by_groupKey', (q) => q.eq('groupKey', args?.groupKey))
      .collect();

    return trackersData || [];
  },
});
