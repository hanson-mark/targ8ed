import { defineSchema, defineTable } from 'convex/server';
import { v } from 'convex/values';
import {
  assignedApplicationsField,
  permissionMethodField,
  statusField,
  themeBorderRadiusField,
  themeColorField,
  themeModeField,
} from './utils/fields';

// *********************** [ Tables ] **********************
// Users Table
const users = defineTable({
  name: v.string(),
  email: v.string(),
  image: v.string(),
  imageId: v.optional(v.id('_storage')),
  createdBy: v.optional(v.id('users')),
  status: statusField,

  isDeleting: v.optional(v.boolean()),
  updatedAt: v.optional(v.number()),
})
  .index('by_email', ['email'])
  .searchIndex('search_by_name', {
    searchField: 'name',
  });

// Organization Table
const organizations = defineTable({
  name: v.string(),
  description: v.string(),
  image: v.optional(v.string()),
  imageId: v.optional(v.id('_storage')),
  status: statusField,
  subdomain: v.string(),
  // Theme
  themeColor: themeColorField,
  themeMode: themeModeField,
  themeBorderRadius: themeBorderRadiusField,

  // Deleting flag
  isDeleting: v.optional(v.boolean()),

  // Timestamp
  createdBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_name', ['name'])
  .index('by_subdomain', ['subdomain'])
  .searchIndex('search_by_name', {
    searchField: 'name',
  });

// Applications Table
const applications = defineTable({
  key: v.string(),
  name: v.string(),
  image: v.optional(v.string()),
  imageId: v.optional(v.id('_storage')),
  description: v.string(),
  isActive: v.boolean(),

  // Sidebar
  sidebar: v.array(v.any()),

  isDeleting: v.optional(v.boolean()),

  // Timestamp
  createdBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_name', ['name'])
  .index('by_key', ['key'])
  .searchIndex('search_by_name', {
    searchField: 'name',
  });

// Organization Applications Table
const organizationApplications = defineTable({
  organizationId: v.id('organizations'),
  applicationId: v.id('applications'),

  name: v.string(),
  description: v.string(),
  isActive: v.boolean(),

  addedBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_application', ['applicationId'])
  .index('by_organization_application', ['organizationId', 'applicationId'])
  .searchIndex('search_by_name', {
    searchField: 'name',
    filterFields: ['organizationId'],
  });

// Organization Users Table
const organizationUsers = defineTable({
  userId: v.id('users'),
  organizationId: v.id('organizations'),
  isOrgAdmin: v.optional(v.boolean()),
  status: statusField,
  addedBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_organization_isOrgAdmin', ['organizationId', 'isOrgAdmin'])
  .index('by_user_organization', ['userId', 'organizationId']);

// Invite user to organization
const orgUserInvitations = defineTable({
  email: v.string(),
  name: v.string(),
  token: v.string(),
  assignedApplications: assignedApplicationsField,
  invitedBy: v.id('users'),
  organizationId: v.id('organizations'),
  expiresAt: v.number(),
})
  .searchIndex('search_by_email', { searchField: 'email' })
  .index('by_organizationId_email', ['organizationId', 'email'])
  .index('by_organizationId_expiresAt', ['organizationId', 'expiresAt']);

// User Applications Table
const userApplications = defineTable({
  userId: v.id('users'),
  organizationId: v.id('organizations'),
  applicationId: v.id('applications'),
  roles: v.array(v.id('roles')),
  isActive: v.boolean(),

  isDeleting: v.optional(v.boolean()),

  addedBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_application', ['applicationId'])
  .index('by_organization_application', ['organizationId', 'applicationId'])
  .index('by_user_organization_application', [
    'userId',
    'organizationId',
    'applicationId',
    'isDeleting',
  ]);

// Permissions Table
const permissions = defineTable({
  key: v.string(),
  method: permissionMethodField,
  name: v.string(),
  description: v.string(),
  applicationId: v.id('applications'),
  addedBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_application_key', ['applicationId', 'key'])
  .index('by_application_method', ['applicationId', 'method'])
  .searchIndex('search_by_name', {
    searchField: 'name',
    filterFields: ['applicationId'],
  });

// Roles Table
const roles = defineTable({
  name: v.string(),
  description: v.string(),
  isAdminRole: v.boolean(),
  permissions: v.array(v.id('permissions')),
  applicationId: v.id('applications'),
  addedBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
})
  .index('by_application_role', ['applicationId', 'name'])
  .searchIndex('search_by_name', {
    searchField: 'name',
    filterFields: ['applicationId'],
  });

// Application Modules Table
const applicationModules = defineTable({
  name: v.string(),
  description: v.string(),
  link: v.string(),
  applicationId: v.id('applications'),
  addedBy: v.optional(v.id('users')),
  updatedAt: v.optional(v.number()),
}).index('by_application_link', ['applicationId', 'link']);

// OTPs Table
const otps = defineTable({
  userId: v.optional(v.id('users')), // might be null if it's for guest flow
  email: v.string(), // OTP will be send to this email address
  otp: v.string(), // the actual OTP code
  purpose: v.union(
    v.literal('initial_setup'),
    v.literal('email_change'),
    v.literal('password_reset'),
    v.literal('guest_verification'),
    v.literal('two_factor'),
    v.literal('other')
  ), // type of OTP use-case
  expiresAt: v.number(), // timestamp in ms
})
  .index('by_userId_purpose', ['userId', 'purpose'])
  .index('by_email_purpose', ['email', 'purpose']);

// Deletion tracker
const deletionTracker = defineTable({
  groupKey: v.string(),
  name: v.string(),
  status: v.union(v.literal('pending'), v.literal('done'), v.literal('error')),
}).index('by_groupKey', ['groupKey']);

// DB Logger Table
const dbLogger = defineTable({
  text: v.string(),
});

// =================================== [ All Application Schema ] =============================
const quickNoteApplication = defineTable({
  title: v.string(),
  content: v.string(),
  userId: v.id('users'),
  organizationId: v.id('organizations'),
  updatedAt: v.optional(v.number()),
})
  .index('by_userId', ['userId'])
  .index('by_organization_userId', ['organizationId', 'userId']);

export default defineSchema({
  users,
  organizations,
  applications,
  organizationApplications,
  organizationUsers,
  orgUserInvitations,
  userApplications,
  permissions,
  roles,
  applicationModules,
  otps,

  deletionTracker,
  dbLogger,

  // All main application schemas
  quickNote: quickNoteApplication,
});
