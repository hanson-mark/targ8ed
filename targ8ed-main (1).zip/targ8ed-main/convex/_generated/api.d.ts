/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import type * as constants_applicationKey from "../constants/applicationKey.js";
import type * as constants_common from "../constants/common.js";
import type * as constants_defaultPagination from "../constants/defaultPagination.js";
import type * as constants_rootConfig from "../constants/rootConfig.js";
import type * as constants_subdomain from "../constants/subdomain.js";
import type * as constants_theme from "../constants/theme.js";
import type * as functions_apps_global_applications_index from "../functions/apps/global/applications/index.js";
import type * as functions_apps_global_applications_internal from "../functions/apps/global/applications/internal.js";
import type * as functions_apps_global_applications_modules from "../functions/apps/global/applications/modules.js";
import type * as functions_apps_global_applications_orgApplications from "../functions/apps/global/applications/orgApplications.js";
import type * as functions_apps_global_applications_permissions from "../functions/apps/global/applications/permissions.js";
import type * as functions_apps_global_applications_roles from "../functions/apps/global/applications/roles.js";
import type * as functions_apps_global_applications_userApplications from "../functions/apps/global/applications/userApplications.js";
import type * as functions_apps_global_initialSetup_index from "../functions/apps/global/initialSetup/index.js";
import type * as functions_apps_global_organizations_index from "../functions/apps/global/organizations/index.js";
import type * as functions_apps_global_organizations_internal from "../functions/apps/global/organizations/internal.js";
import type * as functions_apps_global_users_index from "../functions/apps/global/users/index.js";
import type * as functions_apps_global_users_internal from "../functions/apps/global/users/internal.js";
import type * as functions_apps_global_users_orgUserInvitations from "../functions/apps/global/users/orgUserInvitations.js";
import type * as functions_apps_global_users_orgUsers from "../functions/apps/global/users/orgUsers.js";
import type * as functions_apps_quickNote_index from "../functions/apps/quickNote/index.js";
import type * as functions_deletionTracker from "../functions/deletionTracker.js";
import type * as functions_file from "../functions/file.js";
import type * as functions_logger from "../functions/logger.js";
import type * as http from "../http.js";
import type * as utils_common from "../utils/common.js";
import type * as utils_encryption from "../utils/encryption.js";
import type * as utils_errorHandlers from "../utils/errorHandlers.js";
import type * as utils_fields from "../utils/fields.js";
import type * as utils_generateResponse from "../utils/generateResponse.js";
import type * as utils_httpStatusCode from "../utils/httpStatusCode.js";
import type * as utils_middlewares_convexAppMiddleware from "../utils/middlewares/convexAppMiddleware.js";
import type * as utils_middlewares_convexOrgMiddleware from "../utils/middlewares/convexOrgMiddleware.js";
import type * as utils_middlewares_convexPublicMiddleware from "../utils/middlewares/convexPublicMiddleware.js";
import type * as validations_common from "../validations/common.js";

/**
 * A utility for referencing Convex functions in your app's API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
declare const fullApi: ApiFromModules<{
  "constants/applicationKey": typeof constants_applicationKey;
  "constants/common": typeof constants_common;
  "constants/defaultPagination": typeof constants_defaultPagination;
  "constants/rootConfig": typeof constants_rootConfig;
  "constants/subdomain": typeof constants_subdomain;
  "constants/theme": typeof constants_theme;
  "functions/apps/global/applications/index": typeof functions_apps_global_applications_index;
  "functions/apps/global/applications/internal": typeof functions_apps_global_applications_internal;
  "functions/apps/global/applications/modules": typeof functions_apps_global_applications_modules;
  "functions/apps/global/applications/orgApplications": typeof functions_apps_global_applications_orgApplications;
  "functions/apps/global/applications/permissions": typeof functions_apps_global_applications_permissions;
  "functions/apps/global/applications/roles": typeof functions_apps_global_applications_roles;
  "functions/apps/global/applications/userApplications": typeof functions_apps_global_applications_userApplications;
  "functions/apps/global/initialSetup/index": typeof functions_apps_global_initialSetup_index;
  "functions/apps/global/organizations/index": typeof functions_apps_global_organizations_index;
  "functions/apps/global/organizations/internal": typeof functions_apps_global_organizations_internal;
  "functions/apps/global/users/index": typeof functions_apps_global_users_index;
  "functions/apps/global/users/internal": typeof functions_apps_global_users_internal;
  "functions/apps/global/users/orgUserInvitations": typeof functions_apps_global_users_orgUserInvitations;
  "functions/apps/global/users/orgUsers": typeof functions_apps_global_users_orgUsers;
  "functions/apps/quickNote/index": typeof functions_apps_quickNote_index;
  "functions/deletionTracker": typeof functions_deletionTracker;
  "functions/file": typeof functions_file;
  "functions/logger": typeof functions_logger;
  http: typeof http;
  "utils/common": typeof utils_common;
  "utils/encryption": typeof utils_encryption;
  "utils/errorHandlers": typeof utils_errorHandlers;
  "utils/fields": typeof utils_fields;
  "utils/generateResponse": typeof utils_generateResponse;
  "utils/httpStatusCode": typeof utils_httpStatusCode;
  "utils/middlewares/convexAppMiddleware": typeof utils_middlewares_convexAppMiddleware;
  "utils/middlewares/convexOrgMiddleware": typeof utils_middlewares_convexOrgMiddleware;
  "utils/middlewares/convexPublicMiddleware": typeof utils_middlewares_convexPublicMiddleware;
  "validations/common": typeof validations_common;
}>;
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;
