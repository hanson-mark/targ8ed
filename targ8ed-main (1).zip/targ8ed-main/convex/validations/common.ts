import { z } from 'zod';
import { Id } from '../_generated/dataModel';
import {
  APPLICATION_KEY_MAX_LENGTH,
  APPLICATION_KEY_MIN_LENGTH,
  RESERVED_APPLICATION_KEY,
} from '../constants/applicationKey';
import { treeItemTypes } from '../constants/common';
import { DEFAULT_PAGE_LIMIT } from '../constants/defaultPagination';
import {
  RESERVED_SUBDOMAINS,
  SUBDOMAIN_MAX_LENGTH,
  SUBDOMAIN_MIN_LENGTH,
} from '../constants/subdomain';
import { IConvexSidebarTreeItem } from '../types/convex-types';

// * ID type zod validation schema
export const applicationIdZodSchema = z
  .string({ required_error: 'Application ID is required.' })
  .min(1, 'Application ID is required.') as unknown as z.ZodType<
  Id<'applications'>
>;

export const orgIdZodSchema = z
  .string({ required_error: 'Organization ID is required.' })
  .min(1, 'Organization ID is required.') as unknown as z.ZodType<
  Id<'organizations'>
>;

export const userIdZodSchema = z
  .string({ required_error: 'User ID is required.' })
  .min(1, 'User ID is required.') as unknown as z.ZodType<Id<'users'>>;

export const permissionIdZodSchema = z
  .string({ required_error: 'Permission ID is required.' })
  .min(1, 'Permission ID is required.') as unknown as z.ZodType<
  Id<'permissions'>
>;

export const roleIdZodSchema = z
  .string({ required_error: 'Role ID is required.' })
  .min(1, 'Role ID is required.') as unknown as z.ZodType<Id<'roles'>>;

export const invitationIdZodSchema = z
  .string({ required_error: 'Invitation ID is required.' })
  .min(1, 'Invitation ID is required.') as unknown as z.ZodType<
  Id<'orgUserInvitations'>
>;

export const appModuleIdZodSchema = z
  .string({ required_error: 'Module ID is required.' })
  .min(1, 'Module ID is required.') as unknown as z.ZodType<
  Id<'applicationModules'>
>;

export const storageIdZodSchema = z
  .string({ required_error: 'Storage ID is required.' })
  .min(1, 'Storage ID is required.') as unknown as z.ZodType<Id<'_storage'>>;

// * Common zod schema
export const nameZodSchema = z
  .string({ required_error: 'Name is required' })
  .min(3, 'Minimum 3 characters are required.')
  .max(100, 'Maximum 100 characters are allowed.');
export const descriptionZodSchema = z
  .string({ required_error: 'Description is required' })
  .min(3, 'Minimum 3 characters are required.')
  .max(100, 'Maximum 100 characters are allowed.');

export const emailZodSchema = z
  .string({ required_error: 'Email address is required.' })
  .min(1, 'Email address is required')
  .email('Invalid email address.');

export const otpZodSchema = z
  .string()
  .min(6, 'OTP must be in 6 digits')
  .max(6, "OTP length can't be more than 6");

export const applicationKeyZodSchema = z
  .string({ required_error: 'Application key is required' })
  .min(
    APPLICATION_KEY_MIN_LENGTH,
    `Must be at least ${APPLICATION_KEY_MIN_LENGTH} characters`
  )
  .max(
    APPLICATION_KEY_MAX_LENGTH,
    `Must not exceed ${APPLICATION_KEY_MAX_LENGTH} characters`
  )
  .regex(/^[a-z][a-zA-Z0-9]*$/, {
    message:
      'Must start with a lowercase letter and contain only alphanumeric characters',
  })
  .refine((val) => !val.includes(' '), {
    message: 'Spaces are not allowed',
  })
  .refine((val) => !RESERVED_APPLICATION_KEY.includes(val), {
    message: 'This key is reserved. Please choose another one.',
  });

export const subdomainZodSchemaWithoutReservationCheck = z
  .string({ required_error: 'Subdomain is required' })
  .min(
    SUBDOMAIN_MIN_LENGTH,
    `Minimum ${SUBDOMAIN_MIN_LENGTH} characters required`
  )
  .max(
    SUBDOMAIN_MAX_LENGTH,
    `Maximum ${SUBDOMAIN_MAX_LENGTH} characters allowed`
  )
  .regex(/^[a-z0-9-]+$/, {
    message: 'Only lowercase letters, numbers, and hyphens are allowed',
  })
  .refine((val) => !val.startsWith('-') && !val.endsWith('-'), {
    message: 'Subdomain cannot start or end with a hyphen',
  })
  .refine((val) => val === val.toLowerCase(), {
    message: 'Subdomain must be lowercase',
  })
  .refine((val) => isNaN(Number(val)), {
    message: 'Subdomain cannot be entirely numeric',
  })
  .refine((val) => !val.includes(' '), {
    message: 'Subdomain cannot contain spaces',
  })
  .refine((val) => /[a-z0-9]$/.test(val), {
    message: 'Subdomain must end with a letter or number',
  })
  .refine((val) => !/--+/.test(val), {
    message: 'Subdomain cannot contain consecutive hyphens',
  });
export const subdomainZodSchema =
  subdomainZodSchemaWithoutReservationCheck.refine(
    (val) => !RESERVED_SUBDOMAINS.includes(val),
    {
      message: 'This subdomain is reserved. Please choose another one.',
    }
  );

export const bySubdomainArgsZodSchema = z.object({
  subdomain: subdomainZodSchema,
});

// ========================== [ Tree Item Schema - START ] =====================
export const treeItemLinkZodSchema = z.string().superRefine((val, ctx) => {
  // Check if it starts with / or #
  if (!val.startsWith('/') && !val.startsWith('#')) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message:
        'Link must start with "/" (e.g., /example) or "#" (e.g., #section)',
    });
  }

  // If it starts with #, validate hash
  if (val.startsWith('#')) {
    if (!/^#[\w-]+$/.test(val)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Hash links can only contain letters, numbers, and "-".',
      });
    }
    return; // skip further path checks for hash
  }

  // Validate relative paths
  if (val.startsWith('/')) {
    // Check for invalid characters
    if (
      !/^\/([a-z0-9\-]+\/?)*([a-z0-9\-]+)?([?][a-z0-9=&-]*)?(#[a-z0-9-]*)?$/.test(
        val
      )
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          'Links can only use lowercase letters, numbers, "-", "/", "?" and "#"',
      });
    }

    // Optional: prevent starting segment with "-"
    const segments = val.split('/').filter(Boolean);
    if (segments.some((seg) => seg.startsWith('-'))) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Path segments cannot start with a hyphen "-"',
      });
    }
  }
});

// external links check
// .refine(
//   (val) => {
//     if (!(val.startsWith('http://') || val.startsWith('https://')))
//       return true; // skip if not external

//     try {
//       const url = new URL(val);
//       const isHttp = url.protocol === 'http:' || url.protocol === 'https:';
//       const hostname = url.hostname;

//       if (!hostname.includes('.')) return false;

//       const parts = hostname.split('.');
//       const tld = parts.at(-1);

//       // TLD must be alphabetic and at least 2 chars
//       const hasValidTld = /^[a-zA-Z]{2,}$/.test(tld || '');
//       const isWwwSubdomain = parts.length > 2 && parts[0] === 'www';

//       return isHttp && hasValidTld && (isWwwSubdomain || parts.length > 1);
//     } catch {
//       return false;
//     }
//   },
//   {
//     message: 'External links must be a valid URL (e.g., https://example.com)',
//   }
// );

const baseTreeItemSchema = z.object({
  type: z.enum(treeItemTypes),
  label: z.string().min(1, 'Label is required'),
});

// Case 1: type = 'group' → no icon, no moduleId
const groupTreeItemSchema = baseTreeItemSchema.extend({
  type: z.literal('group'),
  icon: z.string().optional().or(z.literal('')),
  moduleId: z.string().optional().or(z.literal('')),
});

// Case 2: type = 'submenu' → has icon, but no moduleId
const submenuTreeItemSchema = baseTreeItemSchema.extend({
  type: z.literal('submenu'),
  icon: z.string().min(1, 'Icon is required'),
  moduleId: z.string().optional().or(z.literal('')),
});

// Case 3: type = 'link' → requires icon & moduleId
const linkTreeItemSchema = baseTreeItemSchema.extend({
  type: z.literal('link'),
  icon: z.string().min(1, 'Icon is required'),
  moduleId: z.string().min(1, 'Module is required'),
});

// Case 4: type = 'split-button' → requires icon & moduleId
const splitButtonTreeItemSchema = baseTreeItemSchema.extend({
  type: z.literal('split-button'),
  icon: z.string().min(1, 'Icon is required'),
  moduleId: z.string().min(1, 'Module is required'),
  collapsed: z.boolean().optional(),
});

// Case 5: type = 'separator'
const separatorTreeItemSchema = baseTreeItemSchema.extend({
  type: z.literal('separator'),
  icon: z.string().optional(),
  label: z.string().optional(),
});

// Final discriminated union with extra fields added to each schema
const groupTreeItemWithExtras = groupTreeItemSchema.extend({
  id: z.string().min(8, 'Id is invalid'),
  collapsed: z.boolean().optional(),
  children: z.lazy(() => z.array(sidebarTreeItemZodSchema).optional()),
});
const submenuTreeItemWithExtras = submenuTreeItemSchema.extend({
  id: z.string().min(8, 'Id is invalid'),
  collapsed: z.boolean().optional(),
  children: z.lazy(() => z.array(sidebarTreeItemZodSchema).optional()),
});
const linkTreeItemWithExtras = linkTreeItemSchema.extend({
  id: z.string().min(8, 'Id is invalid'),
  collapsed: z.boolean().optional(),
  children: z.lazy(() => z.array(sidebarTreeItemZodSchema).optional()),
});
const splitButtonItemWithExtras = splitButtonTreeItemSchema.extend({
  id: z.string().min(8, 'Id is invalid'),
  collapsed: z.boolean().optional(),
  children: z.lazy(() => z.array(sidebarTreeItemZodSchema).optional()),
});

const separatorItemWithExtras = separatorTreeItemSchema.extend({
  id: z.string().min(8, 'Id is invalid'),
  collapsed: z.boolean().optional(),
  children: z.lazy(() => z.array(sidebarTreeItemZodSchema).optional()),
});

export const addTreeItemZodSchema = z.discriminatedUnion('type', [
  groupTreeItemSchema,
  submenuTreeItemSchema,
  linkTreeItemSchema,
  splitButtonTreeItemSchema.extend({
    expanded: z.boolean().optional(),
  }),
  separatorTreeItemSchema,
]);

export const sidebarTreeItemZodSchema = z.lazy(() =>
  z.discriminatedUnion('type', [
    groupTreeItemWithExtras,
    submenuTreeItemWithExtras,
    linkTreeItemWithExtras,
    splitButtonItemWithExtras,
    separatorItemWithExtras,
  ])
) as z.ZodType<IConvexSidebarTreeItem>;

// ========================== [ Tree Item Schema - END ] =====================

// * request zod schema
export const paginationOptsZodSchema = z.object({
  numItems: z.number(),
  cursor: z.union([z.string(), z.null()]),
  endCursor: z.union([z.string(), z.null()]).optional(),
  id: z.number().optional(),
  maximumRowsRead: z.number().optional(),
  maximumBytesRead: z.number().optional(),
});

export const sortOrderZodSchema = z
  .union([z.literal('asc'), z.literal('desc')])
  .default('desc');

export const convexPaginationQueryZodSchema = z.object({
  search: z.string().optional(),
  sortOrder: sortOrderZodSchema,
  cursor: z.string().optional(),
  limit: z.coerce
    .number()
    .optional()
    .default(DEFAULT_PAGE_LIMIT)
    .refine((val) => val > 0, {
      message: 'Limit must be a positive number',
    }),
});

// * response
export const convexResponseMetaZodSchema =
  convexPaginationQueryZodSchema.extend({
    limit: z.coerce.number().optional().default(Number(DEFAULT_PAGE_LIMIT)),
    isLastPage: z.boolean(),
  });
