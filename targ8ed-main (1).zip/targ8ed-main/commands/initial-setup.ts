import { ConvexHttpClient } from 'convex/browser';
import * as dotenv from 'dotenv';
import 'dotenv/config';
import open from 'open'; // <-- install with `yarn add open`
import { api } from '../convex/_generated/api';

// Loading env variables
const envFilePath = '.env.local';
dotenv.config({ path: envFilePath });

const convexUrl = process.env.NEXT_PUBLIC_CONVEX_URL;
if (!convexUrl) {
  console.error(
    `❌ Missing NEXT_PUBLIC_CONVEX_URL in your environment. Please add it to your '${envFilePath}' file.`
  );
  process.exit(1);
}

const client = new ConvexHttpClient(convexUrl);

async function main() {
  if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
    const result = await client.query(
      api.functions.apps.global.initialSetup.index.checkHasInitialSetup
    );

    if (!result?.hasInitialSetup) {
      const setupUrl = 'http://localhost:3000/initial-setup';
      console.log('Opening initial setup page in your browser...');
      await open(setupUrl); // <-- this opens the link
    } else {
      console.log('You already have the initial setup.');
    }
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
