import { responseMetaZodSchema } from '@/hono-app/validations/common-validations';
import { OpenAPIHono, RouteConfig, RouteHandler, z } from '@hono/zod-openapi';
import { ILogger } from './logger';

export interface IHonoAppBindings {
  Variables: {
    logger: ILogger;
  };
}

export type IHonoAppOpenAPI = OpenAPIHono<IHonoAppBindings>;

export type IHonoRouteHandler<R extends RouteConfig> = RouteHandler<
  R,
  IHonoAppBindings
>;

export type IHonoResponseMeta = z.infer<typeof responseMetaZodSchema>;
export interface IHonoResponse<T = undefined> {
  success: boolean;
  statusCode: number;
  message: string;
  data?: T;
  meta?: IHonoResponseMeta;
  stack?: string;
  errorSources?: { path: string; message: string }[];
}

export type IErrorResponse<T = undefined> = Omit<
  IHonoResponse<T>,
  'data' | 'meta'
>;
