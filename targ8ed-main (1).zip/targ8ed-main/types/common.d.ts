import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import { defaultSortOrders } from '@/hono-app/constants/pagination';
import appConfig from '@/lib/app-config';

export type ILocale = (typeof appConfig.i18n.locales)[number];

export type IHttpErrorStatusCode = Pick<
  typeof HttpStatusCodes,
  'INTERNAL_SERVER_ERROR' | 'UNAUTHORIZED' | 'NOT_FOUND' | 'BAD_REQUEST'
>;

export type ISortOrder = (typeof defaultSortOrders)[number];
