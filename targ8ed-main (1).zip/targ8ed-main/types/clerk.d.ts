export interface IClerkError {
  status: number;
  clerkTraceId: string;
  clerkError: boolean;
  errors: {
    code: string;
    message: string;
    longMessage: string;
    meta: {
      paramName: string;
    };
  }[];
}

export interface IClerkApiUser {
  id: string;

  email_addresses: { id: string; email_address: string }[];
  external_accounts: {
    id: string;
    external_account_id: string;
    email_address: string;
  }[];
}

export type IClerkIdentityUser = {
  id: string;
  firstName: string | null;
  lastName: string | null;
  imageUrl: string;
  locked: boolean;
  lastSignInAt: number | null;
  emailAddresses: {
    emailAddress: string;
    verification: {
      status: string;
    } | null;
  }[];
  externalAccounts: {
    provider: string;
  }[];
};

export type IClerkUser = {
  id: string;
  banned: boolean;
  locked: boolean;
  createdAt: number;
  updatedAt: number;
  imageUrl: string;
  primaryEmailAddressId: string;
  lastSignInAt: number;
  firstName: string;
  lastName: string;
  emailAddresses: IClerkEmailAddress[];
  externalAccounts: IClerkExternalAccount[];
  lastActiveAt: number;
};

export interface IClerkEmailAddress {
  id: string;
  emailAddress: string;
  verification: IClerkEmailAddressVerification | null;
  linkedTo: IClerkLinkedTo[];
}

export interface IClerkLinkedTo {
  id: string;
  type: string;
}

export interface IClerkEmailAddressVerification {
  status: string;
  strategy: string;
}

export interface IClerkExternalAccount {
  id: string;
  provider: string;
  identificationId: string;
  externalId: string;
  approvedScopes: string;
  emailAddress: string;
  firstName: string;
  lastName: string;
  imageUrl: string;
  username: string | null;
  label: string | null;
  verification: IClerkExternalAccountVerification | null;
}

export interface IClerkExternalAccountVerification {
  status: string;
  strategy: string;
  externalVerificationRedirectURL: URL | null;
  attempts: number | null;
  expireAt: number | null;
  nonce: string | null;
  message: string | null;
}
