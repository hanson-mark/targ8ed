import { Doc } from '@/convex/_generated/dataModel';
import {
  IConvexTreeGroupItem,
  IConvexTreeLinkItem,
  IConvexTreeSeparatorItem,
  IConvexTreeSplitButtonItem,
  IConvexTreeSubmenuItem,
} from '@/convex/types/convex-types';
import type { UniqueIdentifier } from '@dnd-kit/core';
import type { MutableRefObject } from 'react';
import { ILucideIconName } from './dashboard-layout';

interface ITreeGroupItem extends IConvexTreeGroupItem {
  id: UniqueIdentifier;
  icon: ILucideIconName;
}
interface ITreeSubmenuItem extends IConvexTreeSubmenuItem {
  id: UniqueIdentifier;
  icon: ILucideIconName;
}
interface ITreeLinkItem extends IConvexTreeLinkItem {
  id: UniqueIdentifier;
  icon: ILucideIconName;
  module?: Doc<'applicationModules'>;
}
interface ITreeSplitButtonItem extends IConvexTreeSplitButtonItem {
  id: UniqueIdentifier;
  icon: ILucideIconName;
  module?: Doc<'applicationModules'>;
}
interface ITreeSeparatorItem extends IConvexTreeSeparatorItem {
  id: UniqueIdentifier;
  icon: undefined;
}
export type ITreeItem =
  | ITreeGroupItem
  | ITreeSubmenuItem
  | ITreeLinkItem
  | ITreeSplitButtonItem
  | ITreeSeparatorItem;

// Flattened items
type ICommonFlattenedItem = {
  parentId: UniqueIdentifier | null;
  depth: number;
  index: number;
};
export type IFlattenedItem =
  | (ITreeGroupItem & ICommonFlattenedItem)
  | (ITreeSubmenuItem & ICommonFlattenedItem)
  | (ITreeLinkItem & ICommonFlattenedItem)
  | (ITreeSplitButtonItem & ICommonFlattenedItem)
  | (ITreeSeparatorItem & ICommonFlattenedItem);

// Sensor context
export type ISensorContext = MutableRefObject<{
  items: IFlattenedItem[];
  offset: number;
}>;

// onAddItem
type IOnAddTreeItem = (parent: ITreeItem) => void;
