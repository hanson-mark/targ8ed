import { ICurrentApplication } from '@/convex/types/convex-types';
import { ICurrentGlobalUser } from '@/stores/globalStore';
import { ICurrentOrgUser } from '@/stores/subdomainStore';
import * as LucideIcons from 'lucide-react';
import { ReactNode } from 'react';
import { ITreeItem } from './sortable-tree-menu';

export type ILucideIconName = Exclude<
  keyof typeof LucideIcons,
  'icons' | 'createLucideIcon'
>;

export type IDashboardLayoutType =
  | 'subdomain-dashboard'
  | 'subdomain-application';

export interface IGlobalLayoutProps {
  children: ReactNode;
  userConfig: ICurrentGlobalUser | null;
  type: Exclude<
    IDashboardLayoutType,
    'subdomain-dashboard' | 'subdomain-application'
  >;
}

export interface IOrgLayoutProps {
  children: ReactNode;
  userConfig: ICurrentOrgUser | null;
  type: Exclude<IDashboardLayoutType, 'subdomain-application'>;
}

export interface IOrgApplicationLayoutProps {
  children: ReactNode;
  userConfig: ICurrentOrgUser | null;
  application: ICurrentApplication;
  type: Exclude<IDashboardLayoutType, 'subdomain-dashboard'>;
}

export interface IDashboardLayoutContext extends ISidebarData {
  selectedHeaderItem?: ISidebarHeaderSwitcherItem;
  selectedMenuItem?: ISdebarGroupItem;
}

export interface ISidebarData {
  isGlobal?: boolean;
  homePage: ISidebarHomePage;
  headerSwitcherItems: ISidebarHeaderSwitcherItem[];
  groupedMenu: ISdebarGroupItem[];
}

export interface ISidebarHomePage {
  id: string;
  icon: ILucideIconName;
  image?: string;
  title: string;
  subtitle: string;
  link: string;
}

export interface ISidebarHeaderSwitcherItem {
  id: string;
  icon: ILucideIconName;
  image?: string;
  title: string;
  subtitle: string;
  type: 'link' | 'switcher';
  link?: string;
}

export interface ISdebarGroupItem {
  id: string;
  title: string;
  link?: string;
  icon?: ILucideIconName;
  isOpen?: boolean;
  type: ITreeItem['type'];
  items: ISdebarGroupItem[];
}

export interface ISidebarUserData {
  name: string;
  email: string;
  avatar: string;
}
