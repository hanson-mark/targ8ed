import { CheckedState } from '@radix-ui/react-checkbox';
import { ColumnDef, Row, Table } from '@tanstack/react-table';
import { ReactNode } from 'react';
import { ILucideIconName } from './dashboard-layout';

export interface IDataTableProps<T> {
  columns: ColumnDef<T>[];
  table: Table<T>;
}

export interface IDataTablePaginationProps<T> {
  table: Table<T>;
}

type IDataTableConvexPaginationOldProps = {
  table: Table;
  handleNextPage: () => void;
  handlePrevPage: () => void;
  handleFirstPage: () => void;
  limit: number;
  handleLimitChange: (limit: number) => void;
  isLastPage: boolean;
  hasPrevPage: boolean;
};

type IDataTableConvexPaginationProps = {
  table: Table;
  limit: number;
  handleLimitChange: (limit: number) => void;
  loadMore: (numItems: number) => void;
  status: 'LoadingFirstPage' | 'CanLoadMore' | 'LoadingMore' | 'Exhausted';
};

export interface IDataTableSearchableInputProps<T> {
  table: Table<T>;
  filterableColumn: keyof T;
}

export interface IDataTableColumnsProps<T> {
  table: Table<T>;
}

export interface IDataTableActionDropdownProps {
  items: ITableActionDropdownMenuItems[];
}

export interface ITableCheckboxSelectColumnConfig {
  columnId: string;
  onAllCheckedChange?: (value: CheckedState) => void;
  onRowCheckedChange?: (value: CheckedState) => void;
}

export interface ITableSortableTextColumnConfig<T> {
  accessorKey: keyof T;
  headerTitle: string;
  casing?: 'capitalize' | 'lowercase' | 'none';
  enableSorting?: boolean;
  enableHiding?: boolean;
  formatter?: (value: unknown, row: Row<T>) => ReactNode;
}

export type ITableActionDropdownMenuItems =
  | {
      id: string;
      icon?: ILucideIconName;
      label: string;
      type: 'button';
      onClick: () => void;
    }
  | { id: string; type: 'separator' }
  | { id: string; type: 'component'; renderer: () => ReactNode }
  | {
      id: string;
      icon?: ILucideIconName;
      label: string;
      type: 'link';
      target?: '_blank' | '_parent' | '_self' | '_top';
      href: string;
    };

export interface ITableActionDropdownColumnConfig<T> {
  headerTitle?: string;
  menuItems: (rowData: T) => ITableActionDropdownMenuItems[];
}

export interface ISimpleDataTableColumn<T> {
  header: string;
  cell: (row: T) => ReactNode;
  className?: string;
}

export interface ISimpleDataTableProps<T> {
  data: T[];
  columns: ISimpleDataTableColumn<T>[];
  keyField: keyof T;
  emptyMessage?: string;
  className?: string;
}
