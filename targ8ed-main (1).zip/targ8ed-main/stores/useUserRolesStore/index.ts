import { IRole } from '@/convex/types/convex-types';
import { create } from 'zustand';

interface ISubdomainStore {
  roles: IRole[];
  permissions: string[];
  setRoles: (roles: IRole[]) => void;
}

const useUserRolesStore = create<ISubdomainStore>()((set) => ({
  roles: [],
  permissions: [],
  setRoles: (roles) => {
    const permissions = (roles || [])
      ?.flatMap((item) => item?.permissions)
      ?.map((item) => item?.key);

    set({ roles: roles || [], permissions: permissions || [] });
  },
}));

export default useUserRolesStore;
