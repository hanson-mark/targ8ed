import { Id } from '@/convex/_generated/dataModel';
import { IOrgUser, IUserApplication } from '@/convex/types/convex-types';
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

export interface ICurrentOrgUser extends IOrgUser {
  applications: IUserApplication[];
  storedAt: number;
}

interface ISubdomainStore {
  tempEmail: string | null;
  setTempEmail: (tempEmail: string | null) => void;
  userConfig: ICurrentOrgUser | null;
  currentOrgId: Id<'organizations'>;
  setUserConfig: (userConfig: ICurrentOrgUser | null) => void;
}

const useSubdomainStore = create<ISubdomainStore>()(
  devtools(
    persist(
      (set) => ({
        tempEmail: null,
        setTempEmail: (tempEmail) => {
          set({ tempEmail });
        },
        userConfig: null,
        currentOrgId: '' as Id<'organizations'>,
        setUserConfig: (userConfig) =>
          set({
            userConfig,
            currentOrgId: userConfig?.organizationId,
            tempEmail: null,
          }),
      }),
      { name: 'mtf_org' }
    )
  )
);

export default useSubdomainStore;
