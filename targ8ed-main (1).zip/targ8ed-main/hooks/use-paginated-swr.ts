import { defaultSortOrders } from '@/hono-app/constants/pagination';
import { buildUrlWithQueryParams } from '@/lib/data-formatters/url-formatter';
import {
  DEFAULT_PAGE_LIMIT,
  DEFAULT_SORT_ORDER,
} from '@/lib/default-data/default-pagination';
import { fetcher } from '@/lib/fetchers';
import { ISortOrder } from '@/types/common';
import { IHonoResponse } from '@/types/hono';
import { useState } from 'react';
import useSWR, { mutate } from 'swr';

export interface IPaginatedSwrMutationKeys {
  initial: string;
  current: string;
}

interface IProps {
  url: string;
  initialLimit?: number;
  initialSortOrder?: 'asc' | 'desc';
  search?: string;
}

export const mutatePaginatedSWR = (mutationKeys: IPaginatedSwrMutationKeys) => {
  if (mutationKeys?.initial) {
    mutate(mutationKeys.initial);
  }

  if (mutationKeys?.current && mutationKeys?.initial != mutationKeys?.current) {
    mutate(mutationKeys.current);
  }
};

export default function usePaginatedSWR<T>({
  url,
  initialLimit = Number(DEFAULT_PAGE_LIMIT),
  initialSortOrder = DEFAULT_SORT_ORDER,
  search,
}: IProps) {
  const [limit, setLimit] = useState(initialLimit);
  const [sortOrder, setSortOrder] = useState(initialSortOrder);
  const [cursorStack, setCursorStack] = useState<string[]>([]);
  const [currentCursor, setCurrentCursor] = useState<string>();

  const initialMutationKey = buildUrlWithQueryParams(url, {
    limit: initialLimit,
    cursor: '',
    sortOrder: initialSortOrder,
    ...(search ? { search } : {}),
  });

  const finalURL = buildUrlWithQueryParams(url, {
    limit,
    cursor: currentCursor || '',
    sortOrder,
    ...(search ? { search } : {}),
  });

  const { data, isLoading, error } = useSWR<IHonoResponse<T[]>>(
    url ? finalURL : null,
    fetcher,
    { revalidateOnFocus: false }
  );

  const handleNextPage = () => {
    if (data?.meta?.cursor) {
      setCursorStack((prev) => [...prev, currentCursor!]);
      setCurrentCursor(data.meta.cursor);
    }
  };

  const handlePrevPage = () => {
    const newStack = [...cursorStack];
    const prevCursor = newStack.pop();
    setCursorStack(newStack);
    setCurrentCursor(prevCursor ?? '');
  };

  const handleFirstPage = () => {
    setCursorStack([]);
    setCurrentCursor('');
  };

  const handleLimitChange = (value: number) => {
    if (limit == value) return;

    setLimit(value);
    setCursorStack([]);
    setCurrentCursor('');
  };

  const handleSortOrderChange = (value: string) => {
    if (value == sortOrder || !defaultSortOrders.includes(value as ISortOrder))
      return;

    setSortOrder(value as ISortOrder);
    setCursorStack([]);
    setCurrentCursor('');
  };

  const mutationKeys = {
    initial: initialMutationKey,
    current: finalURL,
  };

  return {
    data: data?.data ?? [],
    meta: data?.meta,
    isLoading,
    error,
    invalidate: () => mutatePaginatedSWR(mutationKeys),
    mutationKeys,
    pagination: {
      // Handles limit
      limit,
      handleLimitChange,

      // Handles sort order
      sortOrder: data?.meta?.sortOrder,
      handleSortOrderChange,

      // Handles prev and first page
      handleFirstPage,
      handlePrevPage,
      hasPrevPage: cursorStack.length > 0,

      // Handles next page & checking is last page
      handleNextPage,
      isLastPage: data?.meta?.isLastPage || false,
    },
  };
}
