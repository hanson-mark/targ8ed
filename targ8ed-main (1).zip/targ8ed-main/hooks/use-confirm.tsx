'use client';

import CustomDialog from '@/components/common/custom-dialog';
import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { ILucideIconName } from '@/types/dashboard-layout';
import { ReactElement, ReactNode, useState } from 'react';

interface IActionButton {
  variant?: 'default' | 'outline' | 'secondary' | 'destructive';
  label?: string;
}

interface IIcon {
  name: ILucideIconName;
  variant?: 'default' | 'success' | 'error' | 'info';
}

export interface IUseConfirmProps {
  icon?: IIcon;
  title?: string | ReactNode;
  description?: string | ReactNode;
  confirmButton?: IActionButton;
  cancelButton?: IActionButton;
}

type IConfirmFnOptions = Partial<IUseConfirmProps>;

type IReturnType = [
  () => ReactElement | null,
  (options?: IConfirmFnOptions) => Promise<boolean>,
];

interface IConfirmPromise {
  resolve: (value: boolean) => void;
  options?: IConfirmFnOptions;
}

const useConfirm = ({
  title,
  description,
  icon,
  confirmButton,
  cancelButton,
}: IUseConfirmProps = {}): IReturnType => {
  const [promise, setPromise] = useState<IConfirmPromise | null>(null);

  const confirm = (options?: IConfirmFnOptions) =>
    new Promise<boolean>((resolve) => {
      setPromise({ resolve, options });
    });

  const handleClose = () => setPromise(null);

  const handleCancel = () => {
    promise?.resolve(false);
    handleClose();
  };

  const handleConfirm = () => {
    promise?.resolve(true);
    handleClose();
  };

  const ConfirmDialog = () => {
    if (!promise) return null;

    // Icon
    const dialogIcon = promise?.options?.icon ?? icon;

    // Title & Description
    const dialogTitle = promise?.options?.title ?? title;
    const dialogDescription = promise?.options?.description ?? description;

    // Action Buttons
    const dialogConfirmButton =
      promise?.options?.confirmButton ?? confirmButton;
    const dialogCancelButton = promise?.options?.cancelButton ?? cancelButton;

    return (
      <CustomDialog isOpen onOpenChange={handleClose} title="" description="">
        <div className="flex flex-col items-center text-center gap-4 py-4">
          <div
            className={cn(
              'w-20 h-20 rounded-full flex justify-center items-center',
              {
                'bg-destructive/10': dialogIcon?.variant === 'error',
                'bg-green-500/30': dialogIcon?.variant === 'success',
                'bg-blue-500/30': dialogIcon?.variant === 'info',
                'bg-muted':
                  dialogIcon?.variant === 'default' || !dialogIcon?.variant,
              }
            )}
          >
            <LucideIcon
              name={dialogIcon?.name || 'InfoIcon'}
              className={cn('w-10 h-10 ', {
                'text-destructive': dialogIcon?.variant === 'error',
                'text-success': dialogIcon?.variant === 'success',
                'text-info': dialogIcon?.variant === 'info',
                'text-primary':
                  dialogIcon?.variant === 'default' || !dialogIcon?.variant,
              })}
            />
          </div>

          <h2 className="text-xl font-medium">{dialogTitle}</h2>
          <div className="text-sm text-muted-foreground max-w-sm">
            {dialogDescription}
          </div>
        </div>

        <DialogFooter className="flex !justify-center">
          <Button
            onClick={handleCancel}
            variant={dialogCancelButton?.variant ?? 'outline'}
          >
            {dialogCancelButton?.label ?? 'Cancel'}
          </Button>
          <Button
            onClick={handleConfirm}
            variant={dialogConfirmButton?.variant ?? 'default'}
          >
            {dialogConfirmButton?.label ?? 'Confirm'}
          </Button>
        </DialogFooter>
      </CustomDialog>
    );
  };

  return [ConfirmDialog, confirm];
};

export default useConfirm;
