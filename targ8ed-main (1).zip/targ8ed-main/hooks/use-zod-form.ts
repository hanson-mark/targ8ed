// hooks/useZodForm.ts
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, UseFormProps, UseFormReturn } from 'react-hook-form';
import { z, ZodType, ZodTypeDef } from 'zod';

function useZodForm<
  TSchema extends ZodType<Record<string, unknown>, ZodTypeDef>
>(
  schema: TSchema,
  options?: Omit<UseFormProps<z.infer<TSchema>>, 'resolver'>
): UseFormReturn<z.infer<TSchema>> {
  return useForm<z.infer<TSchema>>({
    ...options,
    resolver: zodResolver(schema),
  });
}

export default useZodForm;
