import {
  IConvexErrorResponse,
  IConvexResponse,
} from '@/convex/types/convex-types';
import { OptionalRestArgsOrSkip, useQuery } from 'convex/react';
import { DefaultFunctionArgs, FunctionReference } from 'convex/server';
import { useMemo } from 'react';

type IQuery<TData, TArgs extends DefaultFunctionArgs> = FunctionReference<
  'query',
  'public',
  TArgs,
  IConvexErrorResponse | IConvexResponse<TData>,
  string | undefined
>;

const useConvexQuery = <
  TData,
  TArgs extends DefaultFunctionArgs,
  TArgument extends OptionalRestArgsOrSkip<IQuery<TData, TArgs>>,
>(
  query: IQuery<TData, TArgs>,
  ...args: TArgument
) => {
  const result = useQuery(query, ...(args || []));

  const successResult = useMemo(() => {
    return result && result?.success === true ? result : undefined;
  }, [result]);

  const data = useMemo(() => successResult?.data, [successResult]);
  const error = useMemo(() => {
    return result && result?.success === false ? result : undefined;
  }, [result]);

  return {
    data: data,
    error,
    isLoading: result === undefined || (!data && !error),
  };
};

export default useConvexQuery;
