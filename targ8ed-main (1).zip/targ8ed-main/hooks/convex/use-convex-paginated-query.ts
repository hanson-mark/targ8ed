'use client';

import {
  DEFAULT_PAGE_LIMIT,
  DEFAULT_SORT_ORDER,
} from '@/convex/constants/defaultPagination';
import {
  IConvexErrorResponse,
  IConvexResponse,
} from '@/convex/types/convex-types';
import { defaultSortOrders } from '@/hono-app/constants/pagination';
import { ISortOrder } from '@/types/common';
import { OptionalRestArgsOrSkip, useQuery } from 'convex/react';
import { DefaultFunctionArgs, FunctionReference } from 'convex/server';
import { useMemo, useState } from 'react';

// type IQuery<T> = FunctionReference<
//   'query',
//   'public',
//   {
//     inputs:
//       | {
//           cursor?: string | undefined;
//           limit: number;
//           sortOrder: 'asc' | 'desc';
//         }
//       | object
//       | undefined;
//   },
//   IConvexErrorResponse | IConvexResponse<T[]>,
//   string | undefined
// >;

// interface IProps<T> {
//   query: IQuery<T>;
//   currentOrgId?: Id<'organizations'>;
//   search?: string;
//   initialLimit?: number;
//   initialSortOrder?: 'asc' | 'desc';
// }

type IQuery2<TData, TArgs extends DefaultFunctionArgs> = FunctionReference<
  'query',
  'public',
  TArgs,
  IConvexErrorResponse | IConvexResponse<TData>,
  string | undefined
>;

type PaginationArgs = {
  cursor?: string;
  limit?: number;
  sortOrder?: ISortOrder;
  search?: string;
};

export const useConvexPaginatedQuery = <
  TData,
  TArgs extends DefaultFunctionArgs,
  TArgument extends OptionalRestArgsOrSkip<IQuery2<TData, TArgs>>,
>(
  query2: IQuery2<TData, TArgs>,
  args: Omit<TArgs, 'inputs'> & {
    inputs: Omit<TArgs['inputs'], keyof PaginationArgs> & PaginationArgs;
  }
) => {
  const {
    limit: initialLimit = DEFAULT_PAGE_LIMIT,
    search = '',
    sortOrder: initialSortOrder = DEFAULT_SORT_ORDER,
  } = (args.inputs ?? {}) as PaginationArgs;

  const [limit, setLimit] = useState(initialLimit);
  const [sortOrder, setSortOrder] = useState(initialSortOrder);
  const [cursorStack, setCursorStack] = useState<string[]>([]);
  const [currentCursor, setCurrentCursor] = useState<string>();

  const result = useQuery(
    query2,
    ...([
      {
        ...args,
        inputs: {
          ...(args.inputs ?? {}),
          limit,
          cursor: currentCursor,
          sortOrder,
          ...(search ? { search } : {}),
        },
      },
    ] as unknown as TArgument)
  );

  const successResult = useMemo(
    () => (result && result.success === true ? result : undefined),
    [result]
  );

  const data = useMemo(
    () => successResult?.data ?? [],
    [successResult]
  ) as TData;
  const meta = useMemo(() => successResult?.meta, [successResult]);
  const error = useMemo(
    () => (result && result.success === false ? result : undefined),
    [result]
  );

  const handleNextPage = () => {
    if (meta?.cursor) {
      setCursorStack((prev) => [...prev, currentCursor!]);
      setCurrentCursor(meta?.cursor);
    }
  };

  const handlePrevPage = () => {
    const newStack = [...cursorStack];
    const prevCursor = newStack.pop();
    setCursorStack(newStack);
    setCurrentCursor(prevCursor ?? '');
  };

  const handleFirstPage = () => {
    setCursorStack([]);
    setCurrentCursor('');
  };

  const handleLimitChange = (value: number) => {
    if (limit === value) return;
    setLimit(value);
    setCursorStack([]);
    setCurrentCursor('');
  };

  const handleSortOrderChange = (value: string) => {
    if (value === sortOrder || !defaultSortOrders.includes(value as ISortOrder))
      return;
    setSortOrder(value as ISortOrder);
    setCursorStack([]);
    setCurrentCursor('');
  };

  return {
    data,
    meta,
    error,
    isLoading: result === undefined || (!data && !error),
    pagination: {
      limit,
      sortOrder,
      hasPrevPage: cursorStack.length > 0,
      isLastPage: meta?.isLastPage ?? false,
      handleNextPage,
      handlePrevPage,
      handleFirstPage,
      handleLimitChange,
      handleSortOrderChange,
    },
  };
};
