'use client';

import { useAction } from 'convex/react';
import { FunctionReference } from 'convex/server';
import { useCallback, useRef, useState } from 'react';

interface IHookOptions<TData> {
  onSuccess?: (data: TData) => void;
  onError?: (error: Error) => void;
  onSettled?: () => void;
}

interface IRequestState<TData> {
  isLoading: boolean;
  isError: boolean;
  isSuccess: boolean;
  isSettled: boolean;
  error: Error | null;
  data: TData | null;
}

export function useConvexAction<
  TFn extends FunctionReference<'action'>,
  TArgs extends Parameters<ReturnType<typeof useAction<TFn>>>,
  TReturn extends Awaited<ReturnType<ReturnType<typeof useAction<TFn>>>>,
>(fn: TFn, options?: IHookOptions<TReturn>) {
  const action = useAction(fn);

  const [state, setState] = useState<IRequestState<TReturn>>({
    isLoading: false,
    isError: false,
    isSuccess: false,
    isSettled: false,
    error: null,
    data: null,
  });

  const onSuccessRef = useRef(options?.onSuccess);
  const onErrorRef = useRef(options?.onError);
  const onSettledRef = useRef(options?.onSettled);

  const call = useCallback(
    async (...args: TArgs): Promise<TReturn> => {
      setState({
        isLoading: true,
        isError: false,
        isSuccess: false,
        isSettled: false,
        error: null,
        data: null,
      });

      try {
        const result = await action(...args);
        setState((prev) => ({
          ...prev,
          isSuccess: true,
          data: result,
        }));
        onSuccessRef.current?.(result);
        return result;
      } catch (err) {
        const error = err as Error;
        setState((prev) => ({
          ...prev,
          isError: true,
          error,
        }));
        onErrorRef.current?.(error);
        throw error;
      } finally {
        setState((prev) => ({
          ...prev,
          isLoading: false,
          isSettled: true,
        }));
        onSettledRef.current?.();
      }
    },
    [action]
  );

  return { ...state, call };
}
