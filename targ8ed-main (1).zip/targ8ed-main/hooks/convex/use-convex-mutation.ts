'use client';

import { useMutation } from 'convex/react';
import { FunctionReference } from 'convex/server';
import { useCallback, useRef, useState } from 'react';

interface IHookOptions<TData> {
  onSuccess?: (data: TData) => void;
  onError?: (error: Error) => void;
  onSettled?: () => void;
}

interface IRequestState<TData> {
  isLoading: boolean;
  isError: boolean;
  isSuccess: boolean;
  isSettled: boolean;
  error: Error | null;
  data: TData | null;
}

export function useConvexMutation<
  TFn extends FunctionReference<'mutation'>,
  TArgs extends Parameters<ReturnType<typeof useMutation<TFn>>>,
  TReturn extends Awaited<ReturnType<ReturnType<typeof useMutation<TFn>>>>,
>(fn: TFn, options?: IHookOptions<TReturn>) {
  const mutation = useMutation(fn);

  const [state, setState] = useState<IRequestState<TReturn>>({
    isLoading: false,
    isError: false,
    isSuccess: false,
    isSettled: false,
    error: null,
    data: null,
  });

  const onSuccessRef = useRef(options?.onSuccess);
  const onErrorRef = useRef(options?.onError);
  const onSettledRef = useRef(options?.onSettled);

  const mutate = useCallback(
    async (...args: TArgs): Promise<TReturn> => {
      setState({
        isLoading: true,
        isError: false,
        isSuccess: false,
        isSettled: false,
        error: null,
        data: null,
      });

      try {
        const result = await mutation(...args);
        setState((prev) => ({
          ...prev,
          isSuccess: true,
          data: result,
        }));
        onSuccessRef.current?.(result);
        return result;
      } catch (err) {
        const error = err as Error;
        setState((prev) => ({
          ...prev,
          isError: true,
          error,
        }));
        onErrorRef.current?.(error);
        throw error;
      } finally {
        setState((prev) => ({
          ...prev,
          isLoading: false,
          isSettled: true,
        }));
        onSettledRef.current?.();
      }
    },
    [mutation]
  );

  return { ...state, mutate };
}
