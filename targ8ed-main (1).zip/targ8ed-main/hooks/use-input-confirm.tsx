'use client';

import CustomDialog from '@/components/common/custom-dialog';
import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { ILucideIconName } from '@/types/dashboard-layout';
import { ReactElement, ReactNode, useState } from 'react';

interface IActionButton {
  variant?: 'default' | 'outline' | 'secondary' | 'destructive';
  label?: string;
}

interface IIcon {
  name: ILucideIconName;
  variant?: 'default' | 'success' | 'error' | 'info';
}

export interface IUseInputConfirmProps {
  icon?: IIcon;
  title?: string | ReactNode;
  description?: string | ReactNode;
  confirmButton?: IActionButton;
  cancelButton?: IActionButton;
  label?: string | ReactNode;
  requiredValue?: string;
  inputPlaceholder?: string;
}

type IConfirmFnOptions = Partial<IUseInputConfirmProps>;

type IReturnType = [
  () => ReactElement | null,
  (options?: IConfirmFnOptions) => Promise<string | boolean>,
];

interface IConfirmPromise {
  resolve: (value: boolean | string) => void;
  options?: IConfirmFnOptions;
}

const useInputConfirm = ({
  title,
  description,
  icon,
  confirmButton,
  cancelButton,
  requiredValue,
  inputPlaceholder,
}: IUseInputConfirmProps): IReturnType => {
  const [promise, setPromise] = useState<IConfirmPromise | null>(null);

  const confirm = (options?: IConfirmFnOptions) =>
    new Promise<boolean | string>((resolve) => {
      setPromise({ resolve, options });
    });

  const handleClose = () => setPromise(null);

  const ConfirmDialog = () => {
    // keep inputValue LOCAL to the dialog so it doesn’t reset globally
    const [inputValue, setInputValue] = useState('');

    if (!promise) return null;

    const handleCancel = () => {
      promise?.resolve(false);
      handleClose();
    };

    const handleConfirm = () => {
      promise?.resolve(inputValue || false);
      handleClose();
    };

    const dialogIcon = promise?.options?.icon ?? icon;
    const dialogTitle = promise?.options?.title ?? title;
    const dialogDescription = promise?.options?.description ?? description;
    const dialogConfirmButton =
      promise?.options?.confirmButton ?? confirmButton;
    const dialogCancelButton = promise?.options?.cancelButton ?? cancelButton;
    const dialogRequiredValue =
      promise?.options?.requiredValue ?? requiredValue;

    return (
      <CustomDialog isOpen onOpenChange={handleClose} title="" description="">
        <div className="flex flex-col items-center text-center gap-3 py-4">
          <div
            className={cn(
              'w-20 h-20 rounded-full flex justify-center items-center',
              {
                'bg-destructive/10': dialogIcon?.variant === 'error',
                'bg-green-500/30': dialogIcon?.variant === 'success',
                'bg-blue-500/30': dialogIcon?.variant === 'info',
                'bg-muted':
                  dialogIcon?.variant === 'default' || !dialogIcon?.variant,
              }
            )}
          >
            <LucideIcon
              name={dialogIcon?.name || 'InfoIcon'}
              className={cn('w-10 h-10 ', {
                'text-destructive': dialogIcon?.variant === 'error',
                'text-success': dialogIcon?.variant === 'success',
                'text-info': dialogIcon?.variant === 'info',
                'text-primary':
                  dialogIcon?.variant === 'default' || !dialogIcon?.variant,
              })}
            />
          </div>

          <h2 className="text-xl font-medium">{dialogTitle}</h2>
          <div className="text-sm text-muted-foreground max-w-sm">
            {dialogDescription}
          </div>
          <div className="w-full space-y-2 flex flex-col items-center">
            <Label
              htmlFor="confirm-input"
              className="text-sm font-medium text-muted-foreground"
            >
              {promise?.options?.label ??
                (dialogRequiredValue ? (
                  <>
                    Type <b className="text-primary">{dialogRequiredValue}</b>{' '}
                    to confirm
                  </>
                ) : (
                  'Enter confirmation text'
                ))}
            </Label>

            <Input
              id="confirm-input"
              value={inputValue}
              placeholder={
                promise?.options?.inputPlaceholder ??
                inputPlaceholder ??
                'Enter value here...'
              }
              onChange={(e) => setInputValue(e.target.value)}
              autoComplete="off"
              spellCheck={false}
              onPaste={(e) => e.preventDefault()}
              onCopy={(e) => e.preventDefault()}
              onCut={(e) => e.preventDefault()}
            />
          </div>
        </div>

        <DialogFooter className="flex !justify-center">
          <Button
            onClick={handleCancel}
            variant={dialogCancelButton?.variant ?? 'outline'}
          >
            {dialogCancelButton?.label ?? 'Cancel'}
          </Button>
          <Button
            onClick={handleConfirm}
            variant={dialogConfirmButton?.variant ?? 'destructive'}
            disabled={inputValue !== dialogRequiredValue}
          >
            {dialogConfirmButton?.label ?? 'Confirm'}
          </Button>
        </DialogFooter>
      </CustomDialog>
    );
  };

  return [ConfirmDialog, confirm];
};

export default useInputConfirm;
