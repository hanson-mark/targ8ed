'use client';
import { useCallback, useRef, useState } from 'react';

type HTTPMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

interface IRequestOptions {
  url: string;
  method?: HTTPMethod;
  body?: unknown;
  headers?: HeadersInit;
}

interface IHookOptions<TData> {
  onSuccess?: (data: TData) => void;
  onError?: (error: Error) => void;
  onSettled?: () => void;
}

export type ISendRequest<TData = unknown> = (
  options: IRequestOptions
) => Promise<TData>;

interface IRequestState<TData> {
  isLoading: boolean;
  isError: boolean;
  isSuccess: boolean;
  isSettled: boolean;
  error: Error | null;
  data: TData | null;
}

export function useRequest<TData = unknown>(options?: IHookOptions<TData>) {
  const [state, setState] = useState<IRequestState<TData>>({
    isLoading: false,
    isError: false,
    isSuccess: false,
    isSettled: false,
    error: null,
    data: null,
  });

  // useRef to persist the handlers without causing re-renders
  const onSuccessRef = useRef(options?.onSuccess);
  const onErrorRef = useRef(options?.onError);
  const onSettledRef = useRef(options?.onSettled);

  const sendRequest: ISendRequest<TData> = useCallback(
    ({
      url,
      method = 'POST',
      body,
      headers,
    }: IRequestOptions): Promise<TData> => {
      setState({
        isLoading: true,
        isError: false,
        isSuccess: false,
        isSettled: false,
        error: null,
        data: null,
      });

      return new Promise<TData>((resolve, reject) => {
        fetch(url, {
          method,
          headers: {
            'Content-Type': 'application/json',
            ...headers,
          },
          body: body ? JSON.stringify(body) : undefined,
        })
          .then(async (res) => {
            const json = await res.json().catch(() => null);
            if (!res.ok)
              throw new Error(json?.message || 'Something went wrong');
            return json;
          })
          .then((data) => {
            onSuccessRef.current?.(data);
            setState((prev) => ({
              ...prev,
              isSuccess: true,
              data,
            }));
            resolve(data);
          })
          .catch((err: Error) => {
            onErrorRef.current?.(err);
            setState((prev) => ({
              ...prev,
              isError: true,
              error: err,
            }));
            reject(err);
          })
          .finally(() => {
            onSettledRef.current?.();
            setState((prev) => ({
              ...prev,
              isLoading: false,
              isSettled: true,
            }));
          });
      });
    },
    []
  );

  return { ...state, sendRequest };
}
