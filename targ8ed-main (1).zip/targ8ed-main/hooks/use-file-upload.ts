'use client';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { getImageDimensions } from '@/lib/file-utils';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { useConvexMutation } from './convex/use-convex-mutation';

export interface IUseFileUploadProps {
  autoClearPreview?: boolean;
  maxFileSizeInKB?: number;
  allowedFileTypes?: string[];
  allowedImageDimension?: {
    type: 'exact' | 'minimum' | 'maximum' | 'ratio';
    width?: number;
    height?: number;
  };
}

const useFileUpload = (props?: IUseFileUploadProps) => {
  // Destructure and set default value for autoClearPreview
  const autoClearPreview = props?.autoClearPreview || false;

  // State for tracking upload progress and preview URL
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState('');

  // Convex mutation for generating upload URL
  const { isLoading: isGeneratingUrl, mutate: generateUploadUrl } =
    useConvexMutation(api.functions.file.generateUploadUrl);

  // Toast ID for consistent notifications
  const toastId = 'file-upload-toast';

  // Validate the file type based on allowedFileTypes
  const validateFileType = (file: File): boolean => {
    if (
      props?.allowedFileTypes &&
      !props.allowedFileTypes.includes(file.type)
    ) {
      toast.error('Invalid file type', { id: toastId });
      return false;
    }
    return true;
  };

  // Validate the file size against maxFileSizeInKB
  const validateFileSize = (file: File): boolean => {
    const maxBytes = (props?.maxFileSizeInKB || 0) * 1024;
    if (maxBytes > 0 && file.size > maxBytes) {
      toast.error(`File size must be under ${props?.maxFileSizeInKB}KB`, {
        id: toastId,
      });
      return false;
    }
    return true;
  };

  // Validate the image's dimensions according to the defined rules
  const validateImageDimensions = async (file: File): Promise<boolean> => {
    if (!props?.allowedImageDimension) return true;

    const imageDimensions = await getImageDimensions(file);
    if (!imageDimensions) {
      toast.error('Unable to read image dimensions', { id: toastId });
      return false;
    }

    const { width, height } = imageDimensions;
    const {
      type,
      width: targetWidth,
      height: targetHeight,
    } = props.allowedImageDimension;

    switch (type) {
      case 'exact':
        if (
          (targetWidth && width !== targetWidth) ||
          (targetHeight && height !== targetHeight)
        ) {
          toast.error(
            `Image must be exactly ${targetWidth ?? '?'}x${targetHeight ?? '?'}px`,
            { id: toastId }
          );
          return false;
        }
        break;

      case 'minimum':
        if (
          (targetWidth && width < targetWidth) ||
          (targetHeight && height < targetHeight)
        ) {
          toast.error(
            `Image must be at least ${targetWidth ?? '?'}x${targetHeight ?? '?'}px`,
            { id: toastId }
          );
          return false;
        }
        break;

      case 'maximum':
        if (
          (targetWidth && width > targetWidth) ||
          (targetHeight && height > targetHeight)
        ) {
          toast.error(
            `Image must be at most ${targetWidth ?? '?'}x${targetHeight ?? '?'}px`,
            { id: toastId }
          );
          return false;
        }
        break;

      case 'ratio':
        if (!targetWidth || !targetHeight) {
          toast.error(
            'Both width and height must be provided for ratio check.',
            {
              id: toastId,
            }
          );
          return false;
        }
        const expectedRatio = targetWidth / targetHeight;
        const actualRatio = width / height;
        const tolerance = 0.01; // allow minor precision issues

        if (Math.abs(expectedRatio - actualRatio) > tolerance) {
          toast.error(
            `Image must have a ${targetWidth}:${targetHeight} ratio.`,
            { id: toastId }
          );
          return false;
        }
        break;

      default:
        toast.error('Unknown dimension validation type', { id: toastId });
        return false;
    }

    return true;
  };

  // Perform all file validations (type, size, and dimensions)
  const validateFile = async (file: File): Promise<boolean> => {
    // ✅ Validate file type
    const isValidType = validateFileType(file);
    if (!isValidType) {
      return false;
    }

    // ✅ Validate file size
    const isValidSize = validateFileSize(file);
    if (!isValidSize) {
      return false;
    }

    // ✅ Validate image dimensions
    const isValidDimensions = await validateImageDimensions(file);
    if (!isValidDimensions) {
      return false;
    }

    return true;
  };

  // Cleanup utility after upload completes or fails
  const cleanupAfterUpload = (forceRemovePreview?: boolean) => {
    setIsUploading(false);

    const shouldAutoClear = forceRemovePreview || autoClearPreview !== false;

    if (shouldAutoClear) {
      setPreviewUrl('');
    }
  };

  // Upload file and return storageId if successful
  const uploadFile = async (file: File) => {
    if (!file) return;

    setIsUploading(true);
    toast.loading('Uploading file...', { id: toastId });

    try {
      // Generate preview url
      const localPreviewUrl = URL.createObjectURL(file);
      if (localPreviewUrl?.length > 0) {
        setPreviewUrl(localPreviewUrl);
      }

      const isValid = await validateFile(file);

      if (!isValid) {
        cleanupAfterUpload();
        return null;
      }

      // Generate upload URL
      const uploadUrl = await generateUploadUrl();
      if (!uploadUrl) {
        toast.error('Failed to generate upload URL', { id: toastId });
        cleanupAfterUpload();
        return null;
      }

      // Upload file to the generated URL
      const result = await fetch(uploadUrl, {
        method: 'POST',
        headers: { 'Content-Type': file.type },
        body: file,
      });
      const { storageId } = await result.json();

      if (storageId) {
        toast.success('File uploaded successfully', { id: toastId });
        return storageId as Id<'_storage'>;
      } else {
        toast.error('File upload failed', { id: toastId });
        return null;
      }
    } catch (error) {
      toast.error((error as Error)?.message || 'Failed to upload file', {
        id: toastId,
      });
      return null;
    } finally {
      cleanupAfterUpload();
    }
  };

  return {
    toastId,
    previewUrl,
    clearPreview: () => setPreviewUrl(''),
    uploadFile,
    isUploading: isUploading || isGeneratingUrl,
  };
};

export default useFileUpload;
