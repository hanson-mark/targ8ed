import { getUserLocale } from '@/actions/i18n/locale-manager';
import RootClientProvider from '@/components/providers/root-client-provider';
import { api } from '@/convex/_generated/api';
import { themeBorderRadiusName } from '@/convex/constants/theme';
import { getSubDomainInServer } from '@/lib/app-config';
import { defaultMetaData } from '@/lib/default-data/meta-data';
import { fetchQuery } from 'convex/nextjs';
import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { ReactNode } from 'react';
import { Toaster } from 'react-hot-toast';
import './globals.css';

interface IProps {
  children: ReactNode;
}

export async function generateMetadata(): Promise<Metadata> {
  const subdomain = await getSubDomainInServer();

  // Get organization data
  const orgResult = subdomain
    ? await fetchQuery(
        api.functions.apps.global.organizations.index
          .readOrganizationDetailsBySubdomain,
        { subdomain }
      )
    : null;

  const organization =
    orgResult && 'data' in orgResult ? orgResult?.data : null;

  return {
    ...defaultMetaData,
    title: organization?.name || defaultMetaData?.title,
    description: organization?.description || defaultMetaData?.description,
  };
}

export default async function RootLayout({ children }: IProps) {
  // Getting locale
  const locale = await getUserLocale();

  // Getting border radius class name
  const themeBorderRadiusClassName = (await cookies()).get(
    themeBorderRadiusName
  )?.value;

  return (
    <html
      lang={locale}
      className={themeBorderRadiusClassName || ''}
      suppressHydrationWarning
    >
      <body>
        <RootClientProvider>{children}</RootClientProvider>
        <Toaster />
      </body>
    </html>
  );
}
