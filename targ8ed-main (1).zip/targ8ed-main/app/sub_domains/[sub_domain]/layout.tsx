import SubdomainLayout from '@/components/layouts/subdomain-layout';
import { api } from '@/convex/_generated/api';
import { getSubDomainInServer } from '@/lib/app-config';
import requiredEnvVariables from '@/lib/env-variables';
import { fetchQuery } from 'convex/nextjs';
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const RootOrgLayout = async ({ children }: IProps) => {
  const subdomain = await getSubDomainInServer();

  // Get organization data
  const orgResult = await fetchQuery(
    api.functions.apps.global.organizations.index
      .readOrganizationDetailsBySubdomain,
    { subdomain }
  );

  const organization =
    orgResult && 'data' in orgResult ? orgResult?.data : null;

  if (!organization || !organization?._id) {
    const headersList = await headers();
    const forwardedProto = headersList.get('x-forwarded-proto') ?? 'http'; // Default fallback
    const url = `${forwardedProto}://${requiredEnvVariables.NEXT_PUBLIC_MAIN_DOMAIN}/404`;

    redirect(url);
    return;
  }

  return (
    <SubdomainLayout organization={organization}>{children}</SubdomainLayout>
  );
};

export default RootOrgLayout;
