'use client';

import { updateClerkUserEmail } from '@/actions/auth/user';
import { sendEmailChangeOTP } from '@/actions/resend/otp-manages';
import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from '@/components/ui/input-otp';
import { api } from '@/convex/_generated/api';
import { IUser } from '@/convex/types/convex-types';
import { emailZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { cn } from '@/lib/utils';
import useSubdomainStore from '@/stores/subdomainStore';
import { REGEXP_ONLY_DIGITS } from 'input-otp';
import { ArrowLeftIcon, EditIcon } from 'lucide-react';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  userData?: IUser;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const RESEND_TIMEOUT = 120; // 2 minutes in seconds

const UpdateUserEmailDialog = ({
  userData,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId, setTempEmail } = useSubdomainStore();

  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [otpSentData, setOtpSentData] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  const { mutate: updateEmail } = useConvexMutation(
    api.functions.apps.global.users.index.updateUserEmailRequestByUser
  );
  const { mutate: confirmUpdateEmail } = useConvexMutation(
    api.functions.apps.global.users.index.updateUserEmailConfirmByUser
  );

  const validationSchema = z.object({
    email: emailZodSchema,
    ...(step === 'otp'
      ? { otp: z.string().length(6) }
      : { otp: z.string().optional() }),
  });

  const formMethods = useZodForm(validationSchema, {
    defaultValues: { email: '', otp: '' },
  });
  const formValues = formMethods.watch();

  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setStep('email');
    setOtpSentData(null);
    setResendTimer(0);
    setShowDialog(state);
  };

  // Timer effect for resend
  useEffect(() => {
    if (resendTimer <= 0) return;
    const interval = setInterval(() => {
      setResendTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [resendTimer]);

  // Step 1: Send OTP
  const handleEmailSubmit = async (
    values: z.infer<typeof validationSchema>
  ) => {
    // const users = await getClerkUsersByEmail(userData?.email || '');
    // console.log({ users });

    // return;

    if (!userData?._id) return;

    const oldEmail = userData.email?.trim().toLowerCase();
    const newEmail = values.email?.trim().toLowerCase();

    if (oldEmail === newEmail) {
      toast.error('You did not change your email address');
      return;
    }

    setIsProcessing(true);
    const toastId = 'update-email';
    toast.loading('Creating email change request...', { id: toastId });

    try {
      const res = await updateEmail({
        currentOrgId,
        inputs: { newEmail },
      });

      if (res?.success) {
        toast.loading('Sending OTP to your new email...', { id: toastId });
        const sent = await sendEmailChangeOTP({
          name: userData?.name,
          encryptedData: res?.data || '',
        });

        console.log({ sent });

        if (sent) {
          setOtpSentData(res?.data || '');
          setStep('otp');
          setResendTimer(RESEND_TIMEOUT);
          toast.success('OTP sent successfully to your new email', {
            id: toastId,
          });
        } else {
          toast.error('Failed to send OTP', { id: toastId });
        }
      } else {
        toast.error(res?.message || 'Failed to update email', { id: toastId });
      }
    } catch (err) {
      toast.error(
        (err as { message: string })?.message || 'Failed to update email',
        { id: toastId }
      );
    } finally {
      setIsProcessing(false);
    }
  };

  // Step 2: Verify OTP
  const handleOtpSubmit = async (values: z.infer<typeof validationSchema>) => {
    if (!otpSentData) return;

    setIsProcessing(true);
    const toastId = 'verify-otp';
    toast.loading('Verifying OTP...', { id: toastId });

    const oldEmail = (userData?.email || '')?.trim()?.toLowerCase();
    const newEmail = values?.email?.trim()?.toLowerCase();

    try {
      const res = await confirmUpdateEmail({
        currentOrgId,
        inputs: {
          newEmail: values?.email,
          otp: values.otp || '',
        },
      });
      setTempEmail(values?.email);

      if (res?.success) {
        toast.loading('Updating email address...', { id: toastId });

        const clerkEmailUpdateRes = await updateClerkUserEmail({
          name: userData?.name || '',
          oldEmail,
          newEmail,
        });

        if (clerkEmailUpdateRes?.success) {
          location.reload();
          toast.success('New email address updated successfully.', {
            id: toastId,
          });
          onOpenChange(false);
        } else {
          toast.error(
            'Email updated but there is an authentication issue. Contact with technical team.',
            { id: toastId }
          );
        }
      } else {
        setTempEmail(null);
        toast.error(res?.message || 'Invalid OTP', { id: toastId });
      }
    } catch (err) {
      setTempEmail(null);
      toast.error(
        (err as { message: string })?.message || 'Failed to verify OTP',
        { id: toastId }
      );
    } finally {
      setIsProcessing(false);
    }
  };

  // Resend OTP
  const handleResendOtp = async () => {
    if (!userData?._id || !formValues.email) return;

    setIsProcessing(true);
    const toastId = 'resend-otp';
    toast.loading('Resending OTP...', { id: toastId });

    try {
      const res = await updateEmail({
        currentOrgId,
        inputs: { newEmail: formValues.email },
      });

      if (res?.success) {
        const sent = await sendEmailChangeOTP({
          name: userData?.name,
          encryptedData: res?.data || '',
        });

        if (sent) {
          formMethods.setValue('otp', '');
          setOtpSentData(res?.data || '');
          setResendTimer(RESEND_TIMEOUT);
          toast.success('OTP resent successfully!', { id: toastId });
        } else {
          toast.error('Failed to resend OTP', { id: toastId });
        }
      } else {
        toast.error(res?.message || 'Failed to resend OTP', { id: toastId });
      }
    } catch (err) {
      toast.error(
        (err as { message: string })?.message || 'Failed to resend OTP',
        { id: toastId }
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const onSubmit = async (values: z.infer<typeof validationSchema>) => {
    if (step === 'email') {
      handleEmailSubmit(values);
    } else {
      handleOtpSubmit(values);
    }
  };

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Update Your Email"
      description={
        step === 'email'
          ? "Enter your new email address below. We'll send an OTP for verification."
          : ''
      }
      classNames={{
        content: step == 'otp' ? '[&_h2]:text-center [&_p]:text-center' : '',
      }}
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-2 pb-6">
            {step == 'email' && (
              <FormInput
                disabled={isProcessing}
                name="email"
                label="New Email"
                placeholder="Enter your new email address"
              />
            )}

            {step == 'otp' && (
              <div className="flex flex-col items-center gap-1">
                <div className="text-sm mb-1 text-center">
                  We’ve sent a 6-digit OTP to{' '}
                  <p className="inline">
                    <span className="inline-block font-bold text-primary">
                      {formValues?.email}
                    </span>{' '}
                    <Button
                      variant={'ghost'}
                      size={'icon'}
                      className="p-1 !size-7"
                      onClick={() => {
                        formMethods.setValue('otp', '');
                        setStep('email');
                      }}
                    >
                      <EditIcon />
                    </Button>
                  </p>
                </div>
                <p className="text-sm mb-1 text-center">
                  Please check your inbox (or spam folder) and enter it to
                  verify
                </p>
                <InputOTP
                  maxLength={6}
                  value={formValues?.otp}
                  pattern={REGEXP_ONLY_DIGITS}
                  onChange={(val) => {
                    formMethods.setValue('otp', val, {
                      shouldValidate:
                        !!formMethods.formState.errors.otp?.message,
                    });
                  }}
                >
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <InputOTPGroup key={i}>
                      <InputOTPSlot index={i} />
                      {i === 2 && <InputOTPSeparator />}
                    </InputOTPGroup>
                  ))}
                </InputOTP>
                {formMethods.formState.errors.otp?.message && (
                  <div
                    className={cn(
                      '-mt-0.5 text-xs font-normal text-destructive'
                    )}
                  >
                    {formMethods.formState.errors.otp?.message?.toString()}
                  </div>
                )}

                {/* Resend + Edit Email */}
                <div className="flex items-center gap-1 text-sm">
                  {`Didn't get the OTP?`}{' '}
                  <Button
                    type="button"
                    variant="link"
                    className="px-1 py-1"
                    onClick={handleResendOtp}
                    disabled={isProcessing || resendTimer > 0}
                  >
                    {resendTimer > 0
                      ? `Resend in ${Math.floor(resendTimer / 60)}:${String(
                          resendTimer % 60
                        ).padStart(2, '0')}`
                      : 'Resend OTP'}
                  </Button>
                </div>
              </div>
            )}
          </div>
          <DialogFooter
            className={cn(
              'flex-row',
              step === 'email' ? 'justify-end' : '!justify-center !items-center'
            )}
          >
            {step == 'otp' && (
              <Button
                disabled={isProcessing}
                type="button"
                variant="outline"
                className="min-w-34"
                onClick={() => {
                  formMethods.setValue('otp', '');
                  setStep('email');
                }}
              >
                <ArrowLeftIcon /> Back
              </Button>
            )}
            <Button disabled={isProcessing} type="submit" className="min-w-34">
              {isProcessing
                ? `${step == 'email' ? 'Processing' : 'Verifying'}...`
                : `${step == 'email' ? 'Send OTP' : 'Verify'}`}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default UpdateUserEmailDialog;
