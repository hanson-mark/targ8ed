'use client';
import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import ProfileImageWithUploader from '@/components/common/profile-image-with-uploader';
import FormInput from '@/components/form/form-input';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore, { ICurrentOrgUser } from '@/stores/subdomainStore';
import { useClerk } from '@clerk/nextjs';
import { LogOutIcon, SquarePenIcon } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import { z } from 'zod';
import UpdateUserEmailDialog from './_components/update-user-email-dialog';
import UpdateUserNameDialog from './_components/update-user-name-dialog';

const ProfilePage = () => {
  const router = useRouter();
  const { signOut } = useClerk();

  const { currentOrgId } = useSubdomainStore();

  // Mutations
  const { isLoading: isImageUpdating, mutate: updateUserImage } =
    useConvexMutation(
      api.functions.apps.global.users.index.updateUserImageIdByUser
    );

  // Stores
  const { userConfig } = useSubdomainStore();

  const user =
    userConfig && 'globalUser' in userConfig
      ? userConfig?.globalUser
      : userConfig && 'name' in userConfig
        ? (userConfig as unknown as IUser)
        : undefined;

  // States
  const [showUpdateNameDialog, setShowUpdateNameDialog] = useState(false);
  const [showUpdateEmailDialog, setShowUpdateEmailDialog] = useState(false);

  const userDetailsFormZodSchema = z.object({
    _id: z.string().optional(),
    name: z.string().optional(),
    email: z.string().optional(),
    status: z.boolean().optional(),
  });

  // React hook form
  const formMethods = useZodForm(userDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      email: '',
      status: false,
    },
  });

  // Updating form based on user data change
  useEffect(() => {
    formMethods.reset({
      _id: user?._id,
      name: (user?.name || '') as string,
      email: ((user as ICurrentOrgUser['globalUser'])?.email || '') as string,
      status: user?.status === 'active' ? true : false,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  if (!user) {
    return (
      <p className="text-center text-destructive py-10">
        Failed to load user profile.
      </p>
    );
  }

  return (
    <div className="mx-auto max-w-3xl w-full">
      <h1 className="text-2xl font-semibold text-center mb-5">
        Profile Details
      </h1>
      <div className="space-y-4 mb-10">
        {/* Profile Image  */}
        <ProfileImageWithUploader
          imageURL={getConvexImageURL(user?.imageId as Id<'_storage'>)}
          imageAlt={user?.name || ''}
          isImageIdUpdating={isImageUpdating}
          onUpdateImageId={(storageId) =>
            updateUserImage({
              currentOrgId,
              inputs: { imageId: storageId },
            })
          }
          fileUploaderProps={{
            maxFileSizeInKB: 300,
          }}
        />

        <FormProvider {...formMethods}>
          <form
            className="space-y-4"
            onSubmit={formMethods.handleSubmit(() => {})}
          >
            <div className="flex gap-2 items-end">
              <FormInput disabled name="name" label="Name" />{' '}
              <ButtonWithTooltip
                variant={'ghost'}
                tooltipContent="Update Name"
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
                onClick={() => setShowUpdateNameDialog(true)}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            </div>

            <div className="flex gap-2 items-end">
              <FormInput disabled name="email" label="Email" />
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
                tooltipContent="Update Email"
                onClick={() => setShowUpdateEmailDialog(true)}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            </div>

            <div className="flex justify-center">
              <ButtonWithTooltip
                variant="destructive"
                tooltipContent="Logout"
                className="flex items-center gap-2"
                onClick={async () => {
                  await signOut();
                  router.push('/sign-in');
                }}
              >
                <LogOutIcon className="h-4 w-4" />
                Logout
              </ButtonWithTooltip>
            </div>
          </form>
        </FormProvider>
        <UpdateUserNameDialog
          userData={user as ICurrentOrgUser['globalUser']}
          showDialog={showUpdateNameDialog}
          setShowDialog={setShowUpdateNameDialog}
        />
        <UpdateUserEmailDialog
          userData={user as ICurrentOrgUser['globalUser']}
          showDialog={showUpdateEmailDialog}
          setShowDialog={setShowUpdateEmailDialog}
        />
      </div>
    </div>
  );
};

export default ProfilePage;
