import { fetcher } from '@/lib/fetchers';
import { IHonoResponse } from '@/types/hono';

import { useRequest } from '@/hooks/use-request';
import { IClerkIdentityUser } from '@/types/clerk';
import { Users } from 'lucide-react'; // Lucide icon for empty state
import toast from 'react-hot-toast';
import useSWR from 'swr';
import ClerkUserCard from './clerk-user-card';
import IdentitiesLoader from './identities-loader';

interface IProps {
  email?: string;
  hideUnblockButton?: boolean; // Optional prop to hide the unblock button
}

const Identities = ({ email, hideUnblockButton }: IProps) => {
  const {
    data: clerkUsers,
    isLoading: isClerkUsersLoading,
    error,
    mutate,
  } = useSWR<IHonoResponse<IClerkIdentityUser[]>>(
    email ? `/api/users/clerk-users-by-email?email=${email}` : null,
    fetcher,
    { revalidateOnFocus: false }
  );

  const { sendRequest } = useRequest();

  if (isClerkUsersLoading) {
    return <IdentitiesLoader />;
  }

  if (error || !clerkUsers?.data) {
    return (
      <p className="text-center text-destructive py-10">
        Failed to load clerk user identities
      </p>
    );
  }

  // Empty state UI when no identities found
  if (clerkUsers.data.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center text-muted-foreground py-10">
        <Users className="w-10 h-10 mb-2" />
        <p>No Clerk identities found for this user.</p>
      </div>
    );
  }

  const onUnblockBruteForce = async (clerk_user_id: string) => {
    const toastId = 'unblock-brute-force-blocked-user';
    toast.loading('Unblocking the brute force blocked user...', {
      id: toastId,
    });
    sendRequest({
      url: `/api/users/unblock-brute-force-blocked-user?clerk_user_id=${clerk_user_id}`,
      method: 'PATCH',
    })
      .then(() => {
        toast.success('Unblocked successfully', { id: toastId });
        mutate();
      })
      .catch(() => {
        toast.error('Failed to unblock the user', { id: toastId });
      });
  };

  return (
    <div className="space-y-4 mb-10">
      <div className="grid gap-4">
        {clerkUsers.data.map((item) => (
          <ClerkUserCard
            key={item?.id}
            user={item}
            hideUnblockButton={hideUnblockButton}
            onUnblockBruteForce={() => onUnblockBruteForce(item?.id)}
          />
        ))}
      </div>
    </div>
  );
};

export default Identities;
