'use client';

import useSubdomainStore from '@/stores/subdomainStore';
import Identities from './_components/identities';

const IdentitiesPage = () => {
  const { userConfig } = useSubdomainStore();
  return <Identities hideUnblockButton email={userConfig?.globalUser?.email} />;
};

export default IdentitiesPage;
