import OrgDashboardLayout from '@/components/layouts/org-dashboard-layout';
import { getSubDomainInServer } from '@/lib/app-config';
import requiredEnvVariables from '@/lib/env-variables';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const SubDomainsUserAccountLayout = async ({ children }: IProps) => {
  const subdomain = await getSubDomainInServer();
  const mainDomain = requiredEnvVariables.NEXT_PUBLIC_MAIN_DOMAIN;

  const subdomainURL = `${subdomain}.${mainDomain}`;

  return (
    <OrgDashboardLayout
      menuTitle="User Account"
      subdomainURL={subdomainURL}
      menuItems={[
        { id: 'profile', label: 'Profile', href: '/profile' },
        { id: 'identities', label: 'Identities', href: '/identities' },
      ]}
    >
      {children}
    </OrgDashboardLayout>
  );
};

export default SubDomainsUserAccountLayout;
