import { DataTableActionDropdown } from '@/components/common/data-table';
import StatusBadge from '@/components/common/status-badge';
import { IInvitation } from '@/convex/types/convex-types';
import { ILucideIconName } from '@/types/dashboard-layout';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import { format } from 'date-fns';

interface IParam {
  onRemoveInvitation: (rowData: IInvitation) => void;
  onInviteAgain: (rowData: IInvitation) => void;
  onResendInvitation: (rowData: IInvitation) => void;
}

export const getInvitationsTableColumns = ({
  onRemoveInvitation,
  onInviteAgain,
  onResendInvitation,
}: IParam) => {
  const getMenuItems = (
    rowData: IInvitation
  ): ITableActionDropdownMenuItems[] => {
    const isExpired =
      !rowData.expiresAt || new Date(rowData.expiresAt).getTime() < Date.now();

    const menu: ITableActionDropdownMenuItems[] = [];

    if (isExpired) {
      menu.push({
        id: 'invite-again',
        icon: 'RotateCcw' as ILucideIconName,
        label: 'Invite Again',
        type: 'button',
        onClick: () => {
          onInviteAgain(rowData);
        },
      });
    } else {
      menu.push({
        id: 'resend',
        icon: 'Send' as ILucideIconName,
        label: 'Resend',
        type: 'button',
        onClick: () => {
          onResendInvitation(rowData);
        },
      });
    }

    menu.push({
      id: 'delete',
      icon: 'UserMinus' as ILucideIconName,
      label: 'Delete',
      type: 'button',
      onClick: () => {
        onRemoveInvitation(rowData);
      },
    });

    return menu;
  };

  const columns: ISimpleDataTableColumn<IInvitation>[] = [
    {
      header: 'Name',
      cell: (row) => row?.name,
    },
    {
      header: 'Email',
      cell: (row) => <div className="max-w-40 truncate">{row?.email}</div>,
    },
    {
      header: 'Status',
      cell: (row) => {
        let status = 'Pending';

        if (!row.expiresAt || new Date(row.expiresAt).getTime() < Date.now()) {
          status = 'Expired';
        }

        return (
          <div>
            <StatusBadge status={status} />
          </div>
        );
      },
    },
    {
      header: 'Invited At',
      cell: (row) =>
        row?._creationTime
          ? format(new Date(row?._creationTime), 'dd-MMM-yyyy hh:mm a')
          : '-',
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};
