'use client';
import { CopyField } from '@/components/common/copy-elements';
import CustomTabs from '@/components/common/custom-tabs';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import GeneralTab from './_components/general-tab';

const ApplicationDetailsPageForOrgAdmin = () => {
  // Getting params, applicationId will be there
  const params = useParams();
  const { currentOrgId } = useSubdomainStore();

  // Application data fetching
  const {
    data: applicationResponse,
    isLoading: isApplicationLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.orgApplications
      .readOrgApplicationByOrgAdmin,
    {
      currentOrgId,
      inputs: { applicationId: params?.applicationId as Id<'applications'> },
    }
  );

  // Showing loader
  if (isApplicationLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  // Showing errors if happens
  if (error || !applicationResponse?._id) {
    return (
      <p className="text-center text-destructive py-10">
        Failed to load application data.
      </p>
    );
  }

  return (
    <div className="px-5">
      <Button variant={'ghost'} asChild>
        <Link href="/settings/applications" className="!pl-0">
          <ArrowLeftIcon /> Back to applications
        </Link>
      </Button>
      <div className="space-y-2.5 mb-5">
        <h1 className="text-3xl font-medium">{applicationResponse?.name}</h1>
        <CopyField label="Application ID" value={applicationResponse?._id} />
      </div>
      <CustomTabs
        defaultValue="general"
        tabItems={[
          {
            label: 'General',
            value: 'general',
            content: <GeneralTab applicationData={applicationResponse} />,
          },
        ]}
      />
    </div>
  );
};

export default ApplicationDetailsPageForOrgAdmin;
