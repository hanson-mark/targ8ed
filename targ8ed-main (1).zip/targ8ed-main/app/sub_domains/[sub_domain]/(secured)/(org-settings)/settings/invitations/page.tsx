'use client';

import { sendInvitationEmail } from '@/actions/resend/org-invitations';
import { SimpleDataTable } from '@/components/common/data-table';
import DebouncedSearchInput from '@/components/common/debounced-search-input';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { api } from '@/convex/_generated/api';
import { Doc } from '@/convex/_generated/dataModel';
import { invitationStatues } from '@/convex/constants/common';
import { IInvitation } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import { PlusIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import InviteUserToOrganizationDialog from './_components/invite-user-to-organization-dialog';
import { getInvitationsTableColumns } from './_utils/invitations-table-columns';

type IInvitationStatus = (typeof invitationStatues)[number];

const InvitationsPage = () => {
  const { userConfig, currentOrgId } = useSubdomainStore();

  const organizationData = userConfig?.organization as Doc<'organizations'>;

  const [selectedStatus, setSelectedStatus] = useState<
    IInvitationStatus | 'all'
  >('all');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [showInviteUserToOrgDialog, setShowInviteUserToOrgDialog] =
    useState(false);

  // Data fetching
  const {
    data: invitationList,
    isLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.users.orgUserInvitations
      .readInvitationsByOrgAdmin,
    {
      currentOrgId,
      inputs: {
        ...(debouncedSearch ? { search: debouncedSearch } : {}),
        ...(selectedStatus !== 'all'
          ? {
              status: selectedStatus as
                | (typeof invitationStatues)[number]
                | undefined,
            }
          : {}),
      },
    }
  );

  // Mutations
  const {
    mutate: requestInvitationRemoval,
    isLoading: loadingInvitationRemoval,
  } = useConvexMutation(
    api.functions.apps.global.users.orgUserInvitations
      .deleteInvitationByOrgAdmin
  );
  const { mutate: reInviteOrgUser } = useConvexMutation(
    api.functions.apps.global.users.orgUserInvitations
      .createReInvitationByOrgAdmin
  );

  const [InvitationRemoveConfirmDialog, confirmInvitationRemove] = useConfirm();

  // Handles resend invitation
  const onResendInvitation = async (rowData: IInvitation) => {
    const toastId = 'resend-invitation';
    toast.loading('Resending invitation...', { id: toastId });

    try {
      const emailStatus = await sendInvitationEmail(
        rowData.email,
        rowData.token,
        organizationData
      );

      if (emailStatus) {
        toast.success('Invitation resent successfully.', { id: toastId });
      } else {
        toast.error('Failed to resend invitation.', { id: toastId });
      }
    } catch (error) {
      toast.error(
        (error as { message?: string })?.message ||
          'Something went wrong while resending invitation.',
        { id: toastId }
      );
    }
  };

  // Handles invite again
  const onInviteAgain = async (rowData: IInvitation) => {
    const toastId = 'invite-again';
    toast.loading('Regenerating invitation...', { id: toastId });

    try {
      const res = await reInviteOrgUser({
        currentOrgId,
        inputs: { invitationId: rowData?._id },
      });

      if (!res?.success || !res?.data?.token) {
        toast.error(res?.message || 'Failed to regenerate invitation.', {
          id: toastId,
        });
        return;
      }

      const emailSent = await sendInvitationEmail(
        rowData.email,
        res.data.token,
        organizationData
      );

      if (emailSent) {
        toast.success('Invitation sent again successfully.', { id: toastId });
      } else {
        toast.error('Failed to send email invitation.', { id: toastId });
      }
    } catch (error) {
      toast.error(
        (error as { message?: string })?.message ||
          'Something went wrong while inviting again.',
        { id: toastId }
      );
    }
  };

  // Handles remove invitation
  const onRemoveInvitation = async (rowData: IInvitation) => {
    if (loadingInvitationRemoval) return;

    const isConfirmed = await confirmInvitationRemove(
      DIALOG_CONTENT.RemoveInvitationConfirm
    );
    if (!isConfirmed) return;

    const toastId = 'remove-invitation';
    toast.loading('Deleting invitation...', { id: toastId });

    requestInvitationRemoval({
      currentOrgId,
      inputs: { invitationId: rowData?._id },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'Invitation deleted successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to delete invitation.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while deleting invitation.',
          { id: toastId }
        );
      });
  };

  if (!userConfig?.organization) {
    return <ListWithActionLoader />;
  }

  if (!isLoading && (error || !invitationList)) {
    return (
      <p className="text-center text-destructive py-10">
        Failed to load invitation for this organization.
      </p>
    );
  }

  return (
    <div className="w-full space-y-4">
      <div className="space-y-2">
        <div>
          <div className="flex justify-between items-center">
            <h2 className="text-base font-medium">Invitation list</h2>
            <Button onClick={() => setShowInviteUserToOrgDialog(true)}>
              <PlusIcon /> Invite User
            </Button>
          </div>
          <p className="font-light text-sm">
            List of invitations for the organization
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          {/* Search Input */}
          <DebouncedSearchInput
            className="w-full max-w-72"
            placeholder="Search by email..."
            setDebouncedSearch={setDebouncedSearch}
          />

          {/* Status Filter Dropdown */}
          <Select
            value={selectedStatus}
            onValueChange={(value) =>
              setSelectedStatus(value as IInvitationStatus)
            }
          >
            <SelectTrigger className="w-full sm:w-40 capitalize">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              {invitationStatues?.map((item) => (
                <SelectItem key={item} value={item} className="capitalize">
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="border rounded-md p-3 space-y-4">
          {[...Array(6)].map((_, idx) => (
            <div key={idx} className="grid grid-cols-5 gap-4">
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
            </div>
          ))}
        </div>
      ) : (
        <SimpleDataTable
          data={invitationList || []}
          columns={getInvitationsTableColumns({
            onResendInvitation,
            onInviteAgain,
            onRemoveInvitation,
          })}
          keyField="_id"
        />
      )}
      <InviteUserToOrganizationDialog
        showDialog={showInviteUserToOrgDialog}
        setShowDialog={setShowInviteUserToOrgDialog}
        organizationData={organizationData}
      />

      <InvitationRemoveConfirmDialog />
    </div>
  );
};

export default InvitationsPage;
