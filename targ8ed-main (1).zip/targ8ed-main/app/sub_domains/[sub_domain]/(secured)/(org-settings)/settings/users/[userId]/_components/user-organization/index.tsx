import FormSwitch from '@/components/form/form-switch';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { getOrganizationURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import {
  LinkIcon,
  SquareArrowOutUpRightIcon,
  SquareMenuIcon,
} from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import AddUserToApplicationDialog from './add-user-to-application-dialog';
import UserApplications from './user-applications';

interface IProps {
  hideViewButtons?: boolean;
  isOrgSettings?: boolean;
  isOpen: boolean;
  userOrganization?: IOrgUser;
}

const UserOrganizationInOrgSettings = ({
  hideViewButtons,
  isOrgSettings,
  isOpen,
  userOrganization,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const [showAddUserToApplicationDialog, setShowAddUserToApplicationDialog] =
    useState(false);

  // [ Mutation ] - User Status Change
  const {
    mutate: requestUserStatusChange,
    isLoading: loadingUserStatusChange,
  } = useConvexMutation(
    api.functions.apps.global.users.orgUsers.updateOrgUserStatusByOrgAdmin
  );

  const { mutate: changeUserRole, isLoading: isChangingRole } =
    useConvexMutation(
      api.functions.apps.global.users.orgUsers.updateOrgAdminAccessByOrgAdmin
    );

  // Validation schema for form
  const validationSchema = z.object({
    status: z.boolean(),
    isOrgAdmin: z.boolean(),
  });

  // Form methods
  const formMethods = useZodForm(validationSchema, {
    defaultValues: {
      status: false,
      isOrgAdmin: false,
    },
  });

  // Handles organization user status change
  const onUserStatusChange = async (checked: boolean) => {
    formMethods.setValue('status', !checked);
    if (loadingUserStatusChange) return;

    const toastId = 'change-org-user-status';
    toast.loading('Changing organization user status...', { id: toastId });
    requestUserStatusChange({
      currentOrgId,
      inputs: {
        userId: userOrganization?.userId as Id<'users'>,
        status: checked ? 'active' : 'inactive',
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed organization user status.',
            { id: toastId }
          );
        } else {
          toast.error(
            res?.message || 'Failed to change organization user status',
            { id: toastId }
          );
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Failed to change organization user status',
          { id: toastId }
        );
      });
  };

  // Handles changing organization admin user role
  const onOrgAdminRoleChange = async (checked: boolean) => {
    if (isChangingRole) return;

    formMethods.setValue('isOrgAdmin', !checked);
    if (loadingUserStatusChange) return;

    const toastId = 'change-org-admin-role';
    toast.loading('Changing organization admin role...', { id: toastId });
    changeUserRole({
      currentOrgId,
      inputs: {
        userId: userOrganization?.userId as Id<'users'>,
        isOrgAdmin: checked,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed organization admin role.',
            { id: toastId }
          );
        } else {
          toast.error(
            res?.message || 'Failed to change organization admin role',
            { id: toastId }
          );
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Failed to change organization admin role',
          { id: toastId }
        );
      });
  };

  // Reset form when the dialog is opened
  useEffect(() => {
    if (isOpen) {
      formMethods.reset({
        status: userOrganization?.status === 'active',
        isOrgAdmin: userOrganization?.isOrgAdmin,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, userOrganization?.status, userOrganization?.isOrgAdmin]);

  const organizationURL = getOrganizationURL(
    userOrganization?.organization?.subdomain || ''
  );

  return (
    <div className="mb-7">
      <div className="mb-7">
        <FormProvider {...formMethods}>
          <form
            className="flex flex-col gap-6"
            onSubmit={formMethods.handleSubmit(() => {})}
          >
            {!hideViewButtons && (
              <div className="flex gap-2 items-center">
                <Button
                  asChild
                  type="button"
                  variant={'secondary'}
                  className="hover:bg-muted"
                >
                  <Link
                    href={`/organizations/${userOrganization?.organizationId}`}
                  >
                    <SquareMenuIcon /> Go to organization
                  </Link>
                </Button>
                <Button
                  asChild
                  type="button"
                  variant={'secondary'}
                  className="hover:bg-muted"
                >
                  <Link
                    href={organizationURL}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <SquareArrowOutUpRightIcon /> Open
                  </Link>
                </Button>
              </div>
            )}
            <FormSwitch
              name="isOrgAdmin"
              size="md"
              label={'Is organization admin?'}
              labels={{
                checked: 'Is Organization Admin? (Yes)',
                unchecked: 'Is Organization Admin? (No)',
              }}
              description="Organization Admins can manage their own organization, including its users, roles, and applications."
              onCheckedChange={onOrgAdminRoleChange}
            />
            <FormSwitch
              name="status"
              size="md"
              label={'Active'}
              labels={{
                checked: 'Active',
                unchecked: 'Inactive',
              }}
              description="User status in this organization."
              onCheckedChange={onUserStatusChange}
            />
          </form>
        </FormProvider>

        <Separator className="mt-7 mb-3" />

        <div className="">
          <div className="flex justify-between items-center">
            <h2 className="text-base font-medium">Applications</h2>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowAddUserToApplicationDialog(true)}
            >
              <LinkIcon /> Application
            </Button>
          </div>
          <p className="font-light text-sm">
            List of applications, where the user have access
          </p>
        </div>
      </div>

      {/* Table - User Applications */}
      <UserApplications
        isOrgSettings={isOrgSettings}
        userId={userOrganization?.userId || ''}
      />

      {/* Dialogs  */}
      {userOrganization?.userId && userOrganization?.organizationId ? (
        <AddUserToApplicationDialog
          userId={userOrganization?.userId}
          showDialog={showAddUserToApplicationDialog}
          setShowDialog={setShowAddUserToApplicationDialog}
        />
      ) : null}
    </div>
  );
};

export default UserOrganizationInOrgSettings;
