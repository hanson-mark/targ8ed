'use client';
import CustomTabs from '@/components/common/custom-tabs';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import UserOrganizationInOrgSettings from './_components/user-organization';

const OrgUserPage = () => {
  const { currentOrgId } = useSubdomainStore();

  // Getting params, userId will be there
  const params = useParams();

  // User data fetching
  const {
    data: userResponse,
    isLoading: isUserLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.users.orgUsers.readOrgUserDetailsByOrgAdmin,
    {
      currentOrgId,
      inputs: { userId: params?.userId as Id<'users'> },
    }
  );

  // Showing loader
  if (isUserLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  // Showing errors if happens
  if (error || !userResponse?._id) {
    return (
      <p className="text-center text-destructive py-10">
        Failed to load user data.
      </p>
    );
  }

  return (
    <div>
      <div className="space-y-2.5 mb-5">
        <Button variant={'ghost'} asChild>
          <Link href={`/settings/users`} className="!pl-0">
            <ArrowLeftIcon /> Back to users
          </Link>
        </Button>
        <div className="flex items-center gap-1 text-3xl font-medium">
          <h1 className="truncate">{userResponse?.globalUser?.name}</h1>
        </div>
      </div>
      <CustomTabs
        defaultValue="org-access"
        tabItems={[
          {
            label: 'Organization Access',
            value: 'org-access',
            content: (
              <UserOrganizationInOrgSettings
                isOpen
                hideViewButtons
                isOrgSettings
                userOrganization={userResponse}
              />
            ),
          },
        ]}
      />
    </div>
  );
};

export default OrgUserPage;
