import CustomDialog from '@/components/common/custom-dialog';
import Loader from '@/components/common/loaders/loader';
import FormDropdown from '@/components/form/form-dropdown';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  userId: Id<'users'>;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const AddUserToApplicationDialog = ({
  userId,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // Queries
  const { data: applicationsRes, isLoading: isApplicationsLoading } =
    useConvexQuery(
      api.functions.apps.global.applications.userApplications
        .readAvailableApplicationsToAddUserByOrgAdmin,
      { currentOrgId, inputs: { userId } }
    );

  // Mutations
  const { mutate: addUserToApplication, isLoading: isAdding } =
    useConvexMutation(
      api.functions.apps.global.applications.userApplications
        .createApplicationAccessForUserByOrgAdmin
    );

  // Validation schema
  const validationSchema = z.object({
    applicationId: z
      .string({ required_error: 'Application is required.' })
      .min(1, 'Application is required.') as unknown as z.ZodType<
      Id<'applications'>
    >,
    roleId: z
      .string({ required_error: 'Role is required.' })
      .min(1, 'Role is required.') as unknown as z.ZodType<Id<'roles'>>,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { applicationId: '', roleId: '' },
  });

  // Form Values
  const applicationId = formMethods.watch('applicationId');
  const selectedApplication = (applicationsRes || [])?.find(
    (item) => item?.applicationId === applicationId
  );

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isAdding) return;

    const toastId = 'adding-user-to-application';
    toast.loading('Connecting user to a application...', { id: toastId });
    addUserToApplication({
      currentOrgId,
      inputs: {
        roleId: values?.roleId,
        userId: userId as Id<'users'>,
        applicationId: values?.applicationId as Id<'applications'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message ||
              'Successfully connected the user to the application',
            { id: toastId }
          );

          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to connect user', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to connect user', {
          id: toastId,
        });
      });
  };

  // Reset form when dialog opens
  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Connect User to Application"
      description="Select an application to connect this user. They will gain access to the application."
    >
      {isApplicationsLoading ? (
        <Loader
          variant="minimal"
          message="Loading available applications for the user..."
        />
      ) : (applicationsRes || [])?.length === 0 ? (
        <div className="py-6 text-center text-muted-foreground">
          🎉 No applications in the organization. Or, the user is already added
          to all available applications in the organization.
        </div>
      ) : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormDropdown
                disabled={isAdding || isApplicationsLoading}
                name="applicationId"
                label="Select Application"
                placeholder="Select an application..."
                options={(applicationsRes || [])?.map((application) => ({
                  value: application?.applicationId || '',
                  label: application?.name || '',
                }))}
              />

              {applicationId && selectedApplication ? (
                <FormDropdown
                  disabled={isAdding || isApplicationsLoading}
                  name="roleId"
                  label="Select Role"
                  placeholder="Select a role..."
                  noOptionsMessage="No roles found"
                  options={(selectedApplication?.roles || [])?.map((role) => ({
                    value: role?._id || '',
                    label: role?.name || '',
                  }))}
                />
              ) : null}
            </div>
            <DialogFooter>
              <Button
                disabled={isAdding || !applicationId || !selectedApplication}
                type="submit"
              >
                {isAdding ? 'Connecting...' : 'Connect'}
              </Button>
            </DialogFooter>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default AddUserToApplicationDialog;
