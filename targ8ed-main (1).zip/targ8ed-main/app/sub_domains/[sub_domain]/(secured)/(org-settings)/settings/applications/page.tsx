import OrgApplicationTable from './_components/org-application-table';

const ApplicationsPage = async () => {
  return <OrgApplicationTable />;
};

export default ApplicationsPage;
