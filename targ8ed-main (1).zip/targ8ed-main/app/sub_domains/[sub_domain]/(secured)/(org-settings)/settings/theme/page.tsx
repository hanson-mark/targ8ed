'use client';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import ThemeColorInput from '@/components/common/theme/theme-color-input';
import ThemeModeInput from '@/components/common/theme/theme-mode-input';
import ThemeRadiusInput from '@/components/common/theme/theme-radius-input';
import { api } from '@/convex/_generated/api';
import {
  IThemeBorderRadius,
  IThemeColor,
  IThemeMode,
} from '@/convex/types/theme';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useSubdomainStore from '@/stores/subdomainStore';
import toast from 'react-hot-toast';

interface IChangeThemeInputParam {
  themeColor?: IThemeColor;
  themeMode?: IThemeMode;
  themeBorderRadius?: IThemeBorderRadius;
}

const ThemePage = () => {
  const { userConfig, currentOrgId } = useSubdomainStore();

  const organizationData = userConfig?.organization;

  const { mutate: changeTheme, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.organizations.index.updateOrgThemeConfigByOrgAdmin
  );

  // Handler
  const changeThemeInputs = async (params: IChangeThemeInputParam) => {
    if (organizationData && params) {
      // Final config
      const finalThemeConfig: Required<IChangeThemeInputParam> = {
        themeColor: organizationData?.themeColor,
        themeMode: organizationData?.themeMode,
        themeBorderRadius: organizationData?.themeBorderRadius,
        ...(params || {}),
      };

      const toastId = 'changing-application-theme';
      toast.loading('Changing theme config...', { id: toastId });

      changeTheme({
        currentOrgId,
        inputs: { ...finalThemeConfig },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(
              res?.message || 'Successfully changed the theme config',
              { id: toastId }
            );
          } else {
            toast.error(res?.message || 'Failed to change the theme config', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to change the theme config', {
            id: toastId,
          });
        });
    }
  };

  if (!organizationData) {
    return <ListWithActionLoader />;
  }

  return (
    <div className="space-y-7 mb-10">
      <ThemeColorInput
        disabled={isUpdating}
        label="Theme Color"
        selected={organizationData?.themeColor || 'default'}
        onSelect={(themeColor) => changeThemeInputs({ themeColor })}
      />

      <ThemeModeInput
        disabled={isUpdating}
        selected={organizationData?.themeMode || 'light'}
        onSelect={(themeMode) => changeThemeInputs({ themeMode })}
      />

      <ThemeRadiusInput
        disabled={isUpdating}
        label="Border Radius"
        selected={organizationData?.themeBorderRadius || 'default'}
        onSelect={(themeBorderRadius) =>
          changeThemeInputs({ themeBorderRadius })
        }
      />
    </div>
  );
};

export default ThemePage;
