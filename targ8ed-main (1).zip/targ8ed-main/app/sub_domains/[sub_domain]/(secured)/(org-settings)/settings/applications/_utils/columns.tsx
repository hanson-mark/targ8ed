'use client';

import {
  getActionDropdownColumnConfig,
  getSortableTextColumnConfig,
} from '@/components/common/data-table/utils/table-column-generators';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { ColumnDef } from '@tanstack/react-table';
import { format } from 'date-fns';
import Link from 'next/link';

export const applicationTableColumns: ColumnDef<
  Doc<'organizationApplications'> & {
    application?: Omit<Doc<'applications'>, 'sidebar'>;
  }
>[] = [
  getSortableTextColumnConfig({
    accessorKey: 'name',
    headerTitle: 'Name',
    formatter: (value, row) => (
      <Link
        href={`/settings/applications/${row?.original?.applicationId}`}
        className="flex items-center gap-2 max-w-44"
      >
        <ProfileImage
          imageURL={getConvexImageURL(
            row?.original?.application?.imageId as Id<'_storage'>
          )}
          iconSize={7}
          iconType="user"
        />
        <div className="max-w-full truncate"> {value as string}</div>
      </Link>
    ),
  }),
  getSortableTextColumnConfig({
    accessorKey: 'isActive',
    headerTitle: 'Status',
    formatter: (value) => (
      <div className={''}>
        <StatusBadge status={value === true ? 'active' : 'inactive'} />
      </div>
    ),
  }),
  getSortableTextColumnConfig({
    accessorKey: '_creationTime',
    headerTitle: 'Added At',
    formatter: (value) => (
      <div className="text-sm">
        {value ? format(new Date(value as string), 'dd-MMM-yyyy hh:mm a') : '-'}
      </div>
    ),
  }),
  getActionDropdownColumnConfig({
    menuItems: (rowData) => {
      return [
        {
          id: 'view',
          icon: 'SquareMenuIcon',
          label: 'View Details',
          type: 'link',
          href: `/settings/applications/${rowData?.applicationId}`,
        },
      ];
    },
  }),
];
