'use client';
import { sendInvitationEmail } from '@/actions/resend/org-invitations';
import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { api } from '@/convex/_generated/api';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { IOrganization, IUser } from '@/convex/types/convex-types';
import {
  applicationIdZodSchema,
  emailZodSchema,
  nameZodSchema,
  roleIdZodSchema,
} from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { cn } from '@/lib/utils';
import useSubdomainStore from '@/stores/subdomainStore';
import { useConvex } from 'convex/react';
import { get } from 'lodash';
import { AppWindowIcon, MoveRightIcon, PlusIcon, XIcon } from 'lucide-react';
import Image from 'next/image';
import { Dispatch, SetStateAction, useEffect, useRef, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import AssignApplicationToInvitationDialog from './assign-application-to-invitation-dialog';

interface IProps {
  organizationData?: IOrganization;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

export interface IInvitedOrgApplication {
  application: { _id: Id<'applications'>; name: string; image: string };
  role: Doc<'roles'>;
}

const InviteUserToOrganizationDialog = ({
  organizationData,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const dialogRef = useRef<HTMLDivElement>(null);

  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [invitedApplications, setInvitedApplications] = useState<
    IInvitedOrgApplication[]
  >([]);

  const [step, setStep] = useState(0);
  const [contentWidth, setContentWidth] = useState<number>(0);
  const [isCheckingUserByEmail, setIsCheckingUserByEmail] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [existingUser, setExistingUser] = useState<IUser | undefined>(); // If user already exists

  // Request
  const convexRequest = useConvex();

  // Mutations
  const { mutate: createInvitation, isLoading: isCreatingInvitation } =
    useConvexMutation(
      api.functions.apps.global.users.orgUserInvitations
        .createInvitationByOrgAdmin
    );

  // Loaders
  const isCreating = isCreatingInvitation;

  // Define validation schema based on step
  const validationSchema = z.object({
    email: emailZodSchema,
    userId: z.string(),
    ...(step === 1
      ? {
          name: nameZodSchema,
          invitedApplications: z
            .array(
              z.object({
                applicationId: applicationIdZodSchema,
                roleId: roleIdZodSchema,
              })
            )
            .min(1, 'Please assign at least one application.'),
        }
      : { name: z.string(), invitedApplications: z.array(z.any()) }),
  });

  type IFormData = z.infer<typeof validationSchema>;

  // Initialize react-hook-form with validation
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { email: '', userId: '', name: '', invitedApplications: [] },
  });

  const invitedApplicationsErrorMessage = get(
    formMethods?.formState?.errors,
    'invitedApplications'
  )?.message;

  // Reset state and form when modal opens/closes
  const onOpenChange = (open: boolean) => {
    formMethods.reset();
    setShowDialog(open);
    setStep(0);
    setExistingUser(undefined);
    setInvitedApplications([]);
  };

  // API: Fetch user by email
  const getUserByEmail = async (email: string) => {
    try {
      const userRes = await convexRequest.query(
        api.functions.apps.global.users.index.readUserDetailsByEmailByOrgAdmin,
        { currentOrgId, inputs: { email } }
      );

      return userRes?.success && userRes?.data?._id ? userRes : null;
    } catch {
      return null;
    }
  };

  // API: Check if user already exists in organization
  const getUserInOrg = async (userId: string) => {
    try {
      return await convexRequest.query(
        api.functions.apps.global.users.orgUsers.readOrgUserDetailsByOrgAdmin,
        {
          currentOrgId,
          inputs: { userId: userId as Id<'users'> },
        }
      );
    } catch {
      return null;
    }
  };

  // API: Invite user to organization
  const inviteUserToOrg = async (values: IFormData) => {
    try {
      const response = await createInvitation({
        currentOrgId,
        inputs: {
          name: values.name,
          email: values?.email,
          assignedApplications: invitedApplications?.map((item) => ({
            applicationId: item?.application?._id,
            roleId: item?.role?._id,
          })),
        },
      });

      return response;
    } catch {
      return;
    }
  };

  // Step 1 handler: Find user by email or allow creation
  const handleFirstStep = async (email: string) => {
    const toastId = 'checking-user-by-email';
    toast.loading('Checking user availability...', { id: toastId });
    setIsCheckingUserByEmail(true);

    try {
      const userRes = await getUserByEmail(email);

      if (!userRes || !userRes?.data?._id) {
        toast.success(
          'Fill user information and create user access to organization',
          {
            id: toastId,
          }
        );
        setStep(1);
        return;
      }

      const userInOrg = await getUserInOrg(userRes.data._id);

      if (userInOrg && 'data' in userInOrg && userInOrg?.data?._id) {
        toast.error('User already exists in this organization', {
          id: toastId,
        });
        return;
      }

      formMethods.setValue('userId', userRes.data._id);
      formMethods.setValue('name', userRes.data.name || '');
      setExistingUser(userRes.data);
      setStep(1);

      toast.success('User found. Proceed to assign a role.', { id: toastId });
    } catch (error) {
      console.error('Error checking user by email:', error);
      toast.error(
        (error as { message: string })?.message || 'Something went wrong',
        { id: toastId }
      );
    } finally {
      setIsCheckingUserByEmail(false);
    }
  };

  // Step 2 handler: Create new user (if needed) and add to org
  const handleSecondStep = async (values: IFormData) => {
    const toastId = 'inviting-user-to-organization';
    toast.loading('Inviting user to organization...', { id: toastId });

    const res = await inviteUserToOrg(values);
    if (res?.success && res?.data) {
      toast.loading('Sending invitation...', { id: toastId });

      setIsSendingEmail(true);

      const emailStatus = await sendInvitationEmail(
        values?.email,
        res?.data?.token || '',
        organizationData!
      );

      if (emailStatus) {
        toast.success('Invitation send successfully.', { id: toastId });
        formMethods.reset();

        // Close dialog
        onOpenChange(false);
      } else {
        toast.error('Failed to send invitation.', { id: toastId });
      }
      setIsSendingEmail(false);
    } else {
      toast.error(res?.message || 'Failed to invite user', { id: toastId });
    }
  };

  // Final submit handler
  const onSubmit = async (values: IFormData) => {
    if (step === 0) return handleFirstStep(values.email);
    if (step === 1) return handleSecondStep(values);
  };

  // Handles on add new application to invitedList
  const onAddNewApplication = (invitedApp: IInvitedOrgApplication) => {
    if (invitedApp?.application && invitedApp?.role) {
      const finalInvitedApplications = [
        ...(invitedApplications || []),
        invitedApp,
      ];
      setInvitedApplications(finalInvitedApplications);
      formMethods.setValue(
        'invitedApplications',
        finalInvitedApplications?.map((item) => ({
          applicationId: item?.application?._id,
          roleId: item?.role?._id,
        })),
        { shouldValidate: true }
      );
    }
  };

  // Reset form state when dialog opens
  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  // Setting application content's width
  useEffect(() => {
    if (step > 0) {
      const updateContentWidth = () => {
        const width = dialogRef.current?.offsetWidth ?? 0;
        setContentWidth(Math.max(100, width - 160)); // Prevents very small width
      };

      // Initial call
      updateContentWidth();

      // Attach resize listener
      window.addEventListener('resize', updateContentWidth);

      // Cleanup
      return () => window.removeEventListener('resize', updateContentWidth);
    }
  }, [step]);

  const isLoading =
    isCreating ||
    isCreatingInvitation ||
    isCheckingUserByEmail ||
    isSendingEmail;

  return (
    <>
      <CustomDialog
        dialogRef={dialogRef}
        classNames={{ content: '!p-6 !pr-3' }}
        isOpen={showDialog}
        onOpenChange={onOpenChange}
        title="Invite User to Organization"
        description={
          step === 0
            ? 'Enter the user email to check if they exist.'
            : 'Confirm user info and assign a role to invite user'
        }
      >
        <form
          onSubmit={formMethods.handleSubmit(onSubmit)}
          className="space-y-3"
        >
          <ScrollArea type="always" className="max-h-[calc(100vh-250px)] pr-3">
            <FormProvider {...formMethods}>
              <div className="grid gap-4 p-1">
                {/* Name input for new user */}
                {step === 1 && (
                  <FormInput
                    disabled={isLoading || !!existingUser?._id}
                    name="name"
                    label="Name"
                    placeholder="Enter user's name"
                  />
                )}

                {/* Email input (always shown) */}
                <FormInput
                  disabled={isLoading || step > 0}
                  type="email"
                  name="email"
                  label="Email Address"
                  placeholder="Enter user's email address"
                />

                {/* Display assigned applications list and assign button in step 1 */}
                {step === 1 && (
                  <div className="space-y-2">
                    <div className="flex gap-2 justify-between items-center">
                      <div className="">
                        <h4 className="text-sm font-semibold">
                          Assigned applications
                        </h4>
                        <p className="text-xs">
                          Select applications and roles, those user will get
                          access
                        </p>
                      </div>
                      <div className="shrink-0">
                        <Button
                          variant={'default'}
                          type="button"
                          onClick={() => setShowAssignDialog(true)}
                        >
                          <PlusIcon className="h-4 w-4" />
                          Assign
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {invitedApplications?.length === 0 ? (
                        <div className="h-20 flex justify-center items-center p-4 text-sm text-foreground bg-accent border rounded">
                          You did not assigned any application
                        </div>
                      ) : (
                        invitedApplications.map((selected) => {
                          const imageURL = selected?.application?.image;
                          return (
                            <div
                              key={selected?.application?._id}
                              className="flex items-center justify-between rounded-xl border px-2 py-1 shadow-sm bg-muted hover:bg-muted/70 transition"
                            >
                              <div className="flex items-center gap-1.5">
                                <div className="relative w-9 h-9 flex justify-center items-center rounded-md overflow-hidden">
                                  {imageURL ? (
                                    <Image
                                      fill
                                      src={imageURL || ''}
                                      alt={selected?.application?.name || ''}
                                      className="object-cover"
                                    />
                                  ) : (
                                    <AppWindowIcon />
                                  )}
                                </div>
                                <div
                                  className="space-y-0.5"
                                  style={{ width: contentWidth }}
                                >
                                  <p className="font-semibold text-sm truncate">
                                    {selected?.application?.name}
                                  </p>
                                  <p className="text-xs text-muted-foreground bg-muted rounded truncate">
                                    {selected?.role?.name}
                                  </p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  const toastId =
                                    'remove-application-from-user';
                                  toast.loading('Deleting application...', {
                                    id: toastId,
                                  });

                                  setTimeout(() => {
                                    setInvitedApplications((prev) =>
                                      prev?.filter(
                                        (item) =>
                                          item?.application?._id !==
                                          selected?.application?._id
                                      )
                                    );

                                    toast.success(
                                      'Deleted the application access',
                                      { id: toastId }
                                    );
                                  }, 300);
                                }}
                                className="text-destructive hover:text-red-600 text-sm font-medium cursor-pointer"
                              >
                                <XIcon className="w-4 h-4" />
                              </button>
                            </div>
                          );
                        })
                      )}
                      {invitedApplicationsErrorMessage ? (
                        <p
                          className={cn('text-sm font-medium text-destructive')}
                        >
                          {`${invitedApplicationsErrorMessage}`}
                        </p>
                      ) : null}
                    </div>
                  </div>
                )}
              </div>
            </FormProvider>
          </ScrollArea>
          {/* Footer actions */}
          <DialogFooter>
            <Button
              type="button"
              disabled={isLoading}
              onClick={() => onOpenChange(false)}
              variant={'outline'}
            >
              Cancel
            </Button>

            {step === 0 ? (
              <Button
                type="submit"
                disabled={isLoading || formMethods.formState.isSubmitting}
              >
                {isCheckingUserByEmail ? (
                  'Checking...'
                ) : (
                  <>
                    Next <MoveRightIcon className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            ) : (
              <Button
                type="submit"
                disabled={isLoading || formMethods.formState.isSubmitting}
              >
                {isCreatingInvitation ? 'Inviting...' : 'Invite User'}
              </Button>
            )}
          </DialogFooter>
        </form>
      </CustomDialog>
      <AssignApplicationToInvitationDialog
        showDialog={showAssignDialog}
        setShowDialog={setShowAssignDialog}
        invitedApplications={invitedApplications}
        onAddNewApplication={onAddNewApplication}
        organizationId={organizationData?._id as Id<'organizations'>}
      />
    </>
  );
};

export default InviteUserToOrganizationDialog;
