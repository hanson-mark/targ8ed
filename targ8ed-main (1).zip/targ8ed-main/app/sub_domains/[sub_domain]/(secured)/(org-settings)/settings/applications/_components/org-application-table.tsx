'use client';
import {
  DataTable,
  DataTableColumnsSelector,
  DataTableConvexPagination,
  DataTableSearchableInput,
} from '@/components/common/data-table';
import useDataTable from '@/components/common/data-table/hooks/use-data-table';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { useConvexPaginatedQuery } from '@/hooks/convex/use-convex-paginated-query';
import { downloadCSVFromObjects } from '@/lib/data-formatters/csv-file';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import { FileIcon } from 'lucide-react';
import { applicationTableColumns } from '../_utils/columns';

type IOrgApplicationData = Doc<'organizationApplications'> & {
  application?: Omit<Doc<'applications'>, 'sidebar'>;
};

const OrgApplicationTable = () => {
  const { currentOrgId } = useSubdomainStore();
  const {
    data: applications = [],
    isLoading: isApplicationsLoading,
    error,
    pagination,
  } = useConvexPaginatedQuery(
    api.functions.apps.global.applications.orgApplications
      .readOrgApplicationListByOrgAdmin,
    { currentOrgId, inputs: {} }
  );

  const { table } = useDataTable({
    columns: applicationTableColumns,
    data: applications as IOrgApplicationData[],
  });

  const handleDownload = () => {
    const exportableData = ((applications || []) as IOrgApplicationData[])?.map(
      (item: IOrgApplicationData) => ({
        _id: item?.application?._id,
        name: item?.name,
        description: item?.description,
        image: getConvexImageURL(item?.application?.imageId as Id<'_storage'>),
        key: item?.application?.key,
        status: !item?.application?.isActive
          ? 'inactive'
          : item?.isActive
            ? 'active'
            : 'inactive',
        organizationId: item?.organizationId,
        _creationTime: item?._creationTime
          ? new Date(item?._creationTime).toISOString()
          : '',
      })
    );
    downloadCSVFromObjects({
      data: exportableData,
      selectedKeys: [
        { key: '_id', title: 'ID' },
        { key: 'key', title: 'Key' },
        { key: 'name', title: 'Name' },
        { key: 'description', title: 'Description' },
        { key: 'image', title: 'Image' },
        { key: 'status', title: 'Status' },
        { key: 'organizationId', title: 'Organization ID' },
        { key: '_creationTime', title: 'Added At' },
      ],
      filenamePrefix: `organization_applications`,
      extension: 'csv',
    });
  };

  if (isApplicationsLoading) {
    return <ListWithActionLoader />;
  }

  if (error) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load applications.'}
      </p>
    );
  }

  return (
    <div>
      <div className="flex items-center pb-4 gap-4 justify-between">
        <DataTableSearchableInput filterableColumn="name" table={table} />
        <div className="flex gap-2 items-center text-sm">
          <DataTableColumnsSelector table={table} />
          <Button variant="outline" onClick={handleDownload}>
            <FileIcon className="h-4 w-4" />
            Export
          </Button>
          {/* <Button onClick={() => setAddApplicationDialog(true)}>
            <PlusIcon className="h-4 w-4" />
            Application
          </Button> */}
        </div>
      </div>

      <DataTable columns={applicationTableColumns} table={table} />

      <DataTableConvexPagination table={table} {...pagination} />
    </div>
  );
};

export default OrgApplicationTable;
