import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import { DataTableActionDropdown } from '@/components/common/data-table';
import { Badge } from '@/components/ui/badge';
import {
  IOrgApplication,
  IPermission,
  IRole,
} from '@/convex/types/convex-types';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import { PenIcon, ShieldCheckIcon, Trash2Icon } from 'lucide-react';
import Link from 'next/link';

export const getApplicationOrganizationTableColumns = () => {
  const getMenuItems = (
    rowData: IOrgApplication
  ): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'details',
        icon: 'SquareMenuIcon',
        label: 'View Details',
        type: 'link',
        href: `/organizations/${rowData?.organizationId}`,
      },
    ];
  };

  const columns: ISimpleDataTableColumn<IOrgApplication>[] = [
    {
      header: 'Organization',
      cell: (row) => (
        <Link href={`/organizations/${row?.organizationId}`}>
          {row?.organization?.name}
        </Link>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};

export const getPermissionsTableColumns = (
  args: {
    onRemovePermission: (permission: IPermission) => void;
    onOpenUpdateDialog: (permission: IPermission) => void;
  },
  activeColumns: string[]
) => {
  const columns: ISimpleDataTableColumn<IPermission>[] = [
    {
      header: 'Key',
      cell: (row) => <Badge className="rounded-full">{row?.key}</Badge>,
    },
    {
      header: 'Method',
      cell: (row) => row?.method,
    },
    {
      header: 'Name',
      cell: (row) => row?.name,
    },
    {
      header: 'Description',
      cell: (row) => row?.description,
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <div className="flex gap-2 items-center">
          <ButtonWithTooltip
            variant="ghost"
            size="icon"
            tooltipContent="Update the permission"
            className="w-8 h-8"
            onClick={() => {
              if (args.onOpenUpdateDialog) {
                args?.onOpenUpdateDialog(rowData);
              }
            }}
          >
            <PenIcon />
          </ButtonWithTooltip>
          <ButtonWithTooltip
            variant="ghost"
            size="icon"
            tooltipContent="Remove the permission"
            className="w-8 h-8 text-destructive"
            onClick={() => {
              if (args.onRemovePermission) {
                args?.onRemovePermission(rowData);
              }
            }}
          >
            <Trash2Icon />
          </ButtonWithTooltip>
        </div>
      ),
    },
  ];

  return columns?.filter((item) =>
    [...activeColumns, 'Actions']?.includes(item?.header)
  );
};

export const getRolesTableColumns = (args: {
  onRemoveRole: (permission: IRole) => void;
  onOpenUpdateDialog: (permission: IRole) => void;
  onOpenUpdatePermissionsDialog: (permission: IRole) => void;
}) => {
  const columns: ISimpleDataTableColumn<IRole>[] = [
    {
      header: 'Role Name',
      cell: (row) => row?.name,
    },
    {
      header: 'Description',
      cell: (row) => row?.description,
    },
    {
      header: 'Permissions',
      cell: (row) => (
        <div className="flex gap-2 flex-wrap">
          {row?.permissions?.length < 1 ? (
            <span className="text-gray-400 text-sm italic font-medium">
              No permissions
            </span>
          ) : (
            row?.permissions?.map((permission) => (
              <Badge key={permission?._id} className="rounded-full">
                {permission?.method}:{permission?.name}
              </Badge>
            ))
          )}
        </div>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <div className="flex gap-1 items-center">
          <ButtonWithTooltip
            variant="ghost"
            size="icon"
            tooltipContent="Update Role"
            className="w-8 h-8"
            onClick={() => {
              if (args.onOpenUpdateDialog) {
                args.onOpenUpdateDialog(rowData);
              }
            }}
          >
            <PenIcon />
          </ButtonWithTooltip>
          <ButtonWithTooltip
            variant="ghost"
            size="icon"
            tooltipContent="Update permission"
            className="w-8 h-8"
            onClick={() => {
              if (args.onOpenUpdatePermissionsDialog) {
                args.onOpenUpdatePermissionsDialog(rowData);
              }
            }}
          >
            <ShieldCheckIcon />
          </ButtonWithTooltip>
          <ButtonWithTooltip
            variant="ghost"
            size="icon"
            tooltipContent="Delete the permission"
            className="w-8 h-8 text-destructive"
            onClick={() => {
              if (args.onRemoveRole) {
                args.onRemoveRole(rowData);
              }
            }}
          >
            <Trash2Icon />
          </ButtonWithTooltip>
        </div>
      ),
    },
  ];

  return columns;
};
