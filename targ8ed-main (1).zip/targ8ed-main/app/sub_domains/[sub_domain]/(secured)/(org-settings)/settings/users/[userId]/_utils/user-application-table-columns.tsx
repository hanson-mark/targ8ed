import { DataTableActionDropdown } from '@/components/common/data-table';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Badge } from '@/components/ui/badge';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { IUserApplication } from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import { FileSymlinkIcon } from 'lucide-react';
import Link from 'next/link';

interface IParam {
  isOrgSettings?: boolean;
  onChangeRole: (rowData: IUserApplication) => void;
  onChangeStatus: (rowData: IUserApplication) => void;
  onRemoveApplication: (rowData: IUserApplication) => void;
}

export const getUserApplicationTableColumns = ({
  isOrgSettings,
  onChangeRole,
  onChangeStatus,
  // onRemoveApplication,
}: IParam) => {
  const getMenuItems = (
    rowData: IUserApplication
  ): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'change-role',
        icon: 'UserCog',
        label: 'Change Role',
        type: 'button',
        onClick: () => {
          onChangeRole(rowData);
        },
      },
      {
        id: 'change-status',
        icon: 'ToggleLeft',
        label: rowData?.isActive ? 'Inactive' : 'Active',
        type: 'button',
        onClick: () => {
          onChangeStatus(rowData);
        },
      },
      // {
      //   id: 'remove',
      //   icon: 'UserMinusIcon',
      //   label: 'Remove',
      //   type: 'button',
      //   onClick: () => {
      //     onRemoveApplication(rowData);
      //   },
      // },
    ];
  };
  const columns: ISimpleDataTableColumn<IUserApplication>[] = [
    {
      header: 'Application',
      cell: (row) => (
        <Link
          href={`${isOrgSettings ? '/settings' : ''}/applications/${row?._id}`}
          className="text-sm flex items-center gap-2 max-w-44"
        >
          <ProfileImage
            imageURL={getConvexImageURL(row?.imageId as Id<'_storage'>)}
            iconSize={7}
            iconType="application"
          />

          <span className="max-w-full truncate">{row?.name as string}</span>
          <FileSymlinkIcon className="shrink-0 w-4 h-4 -ml-1 opacity-90" />
        </Link>
      ),
    },
    {
      header: 'Roles',
      cell: (row) =>
        (row?.roles || [])?.map((item: Id<'roles'> | Doc<'roles'>) =>
          typeof item !== 'string' && '_id' in item ? (
            <Badge key={item?._id} className="rounded-full text-xs">
              {item?.name}
            </Badge>
          ) : null
        ) || '',
    },
    {
      header: 'Status',
      cell: (row) => (
        <div className={''}>
          <StatusBadge status={row?.isActive ? 'active' : 'inactive'} />
        </div>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};
