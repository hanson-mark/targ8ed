'use client';

import CustomDialog from '@/components/common/custom-dialog';
import Loader from '@/components/common/loaders/loader';
import FormDropdown from '@/components/form/form-dropdown';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IUserApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  userApplication: IUserApplication | undefined;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const ChangeApplicationUserRoleDialog = ({
  userApplication,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // Query available roles for this app
  const { data: rolesRes, isLoading: isRolesLoading } = useConvexQuery(
    api.functions.apps.global.applications.roles.readApplicationRolesByOrgAdmin,
    {
      currentOrgId,
      inputs: { applicationId: userApplication?._id as Id<'applications'> },
    }
  );

  // Mutation
  const { mutate: changeRole, isLoading: isChanging } = useConvexMutation(
    api.functions.apps.global.applications.userApplications
      .updateUserRoleInApplicationByOrgAdmin
  );

  // Validation schema
  const schema = z.object({
    roleId: z
      .string({ required_error: 'Role is required.' })
      .min(1, 'Role is required.') as unknown as z.ZodType<Id<'roles'>>,
  });

  const formMethods = useZodForm(schema, {
    defaultValues: { roleId: '' },
  });

  const onOpenChange = (open: boolean) => {
    setShowDialog(open);
    formMethods.reset();
  };

  const onSubmit = (values: z.infer<typeof schema>) => {
    if (isChanging || !userApplication) return;

    const toastId = 'change-role';
    toast.loading('Changing role...', { id: toastId });

    changeRole({
      currentOrgId,
      inputs: {
        userId: userApplication?.userId,
        applicationId: userApplication?._id,
        roleId: values.roleId,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || 'Role changed successfully.', {
            id: toastId,
          });
          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to change role.', {
            id: toastId,
          });
        }
      })
      .catch((err) => {
        toast.error(err?.message || 'Failed to change role.', { id: toastId });
      });
  };

  useEffect(() => {
    if (showDialog) {
      formMethods.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Change User Role"
      description="Select a new role for this user within the application."
    >
      {isRolesLoading ? (
        <Loader variant="minimal" message="Loading roles..." />
      ) : !rolesRes?.length ? (
        <div className="py-6 text-center text-muted-foreground">
          ⚠️ No roles found for this application.
        </div>
      ) : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormDropdown
                disabled={isChanging}
                name="roleId"
                label="Select New Role"
                placeholder="Choose a role..."
                options={rolesRes.map((role) => ({
                  value: role._id,
                  label: role.name,
                }))}
              />
            </div>
            <DialogFooter>
              <Button disabled={isChanging} type="submit">
                {isChanging ? 'Changing...' : 'Change Role'}
              </Button>
            </DialogFooter>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default ChangeApplicationUserRoleDialog;
