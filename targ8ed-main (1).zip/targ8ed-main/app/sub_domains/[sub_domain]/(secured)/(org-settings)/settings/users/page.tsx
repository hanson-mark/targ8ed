'use client';
import { SimpleDataTable } from '@/components/common/data-table';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import toast from 'react-hot-toast';
import { getOrgUsersTableColumns } from './_utils/org-users-table-columns';

const UsersPage = () => {
  const { currentOrgId } = useSubdomainStore();

  // Data fetching
  const {
    data: userListResponse,
    isLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.users.orgUsers.readOrgUsersByOrgAdmin,
    {
      currentOrgId,
      inputs: {},
    }
  );

  // [ Mutation ] - User Remove
  const { mutate: removeUser, isLoading: isRemoving } = useConvexMutation(
    api.functions.apps.global.users.orgUsers.deleteUserFromOrgByOrgAdmin
  );

  // [ Dialog ] - To take confirmation for removing user
  const [UserRemoveConfirmDialog, confirmUserRemove] = useConfirm();

  // Handles removing user from organization
  const onRemoveUser = async (rowData: IOrgUser) => {
    if (isRemoving) return;

    const isConfirmed = await confirmUserRemove(DIALOG_CONTENT.RemoveOrgUser);
    if (!isConfirmed) return;

    const toastId = 'remove-org-user';
    toast.loading('Removing user...', { id: toastId });

    removeUser({
      currentOrgId,
      inputs: { userId: rowData?.globalUser?._id as Id<'users'> },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'User removed successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to remove user.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while removing user.',
          { id: toastId }
        );
      });
  };

  if (isLoading || !currentOrgId) return <ListWithActionLoader />;

  if (error || !userListResponse) {
    return (
      <p className="text-center text-destructive py-10">
        {error?.message || 'Failed to load users for this organization.'}
      </p>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Users</h2>
        </div>
        <p className="font-light text-sm">
          List of users who has access the organization
        </p>
      </div>

      <SimpleDataTable
        data={userListResponse}
        columns={getOrgUsersTableColumns({
          onRemoveUser,
          // onChangeRoleDialogOpen,
        })}
        keyField="_id"
      />

      <UserRemoveConfirmDialog />
    </div>
  );
};

export default UsersPage;
