import { DataTableActionDropdown } from '@/components/common/data-table';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgUser } from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import { format } from 'date-fns';
import Link from 'next/link';

interface IParam {
  onRemoveUser: (rowData: IOrgUser) => void;
  // onChangeRoleDialogOpen: (rowData: IOrgUser) => void;
}

export const getOrgUsersTableColumns = ({
  onRemoveUser,
  // onChangeRoleDialogOpen,
}: IParam) => {
  const getMenuItems = (rowData: IOrgUser): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'details',
        icon: 'SquareMenuIcon',
        label: 'View Details',
        type: 'link',
        href: `/settings/users/${rowData?.globalUser?._id}/`,
      },
      {
        id: 'delete',
        icon: 'UserMinusIcon',
        label: 'Delete',
        type: 'button',
        onClick: () => {
          onRemoveUser(rowData);
        },
      },
      // {
      //   id: 'change-role',
      //   icon: 'UserCogIcon',
      //   label: 'Change Role',
      //   type: 'button',
      //   onClick: () => {
      //     onChangeRoleDialogOpen(rowData);
      //   },
      // },
    ];
  };

  const columns: ISimpleDataTableColumn<IOrgUser>[] = [
    {
      header: 'Name',
      cell: (row) => (
        <Link
          href={`/settings/users/${row?.globalUser?._id}/`}
          className="flex items-center gap-2"
        >
          <ProfileImage
            imageURL={getConvexImageURL(
              row?.globalUser?.imageId as Id<'_storage'>
            )}
            iconSize={7}
            iconType="user"
          />
          <div className="max-w-32 truncate">{row?.globalUser?.name}</div>
        </Link>
      ),
    },
    {
      header: 'Email',
      cell: (row) => (
        <div className="max-w-40 truncate">{row?.globalUser?.email}</div>
      ),
    },
    {
      header: 'Is Organization Admin',
      cell: (row) => (
        <span className="capitalize">{row?.isOrgAdmin ? 'Yes' : 'No'}</span>
      ),
    },
    {
      header: 'Status',
      cell: (row) => (
        <div className={''}>
          <StatusBadge status={(row?.status || '')?.toString()} />
        </div>
      ),
    },
    {
      header: 'Added At',
      cell: (row) =>
        row?._creationTime
          ? format(new Date(row?._creationTime), 'dd-MMM-yyyy hh:mm a')
          : '-',
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};
