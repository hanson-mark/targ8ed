import { SimpleDataTable } from '@/components/common/data-table';
import { Skeleton } from '@/components/ui/skeleton';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IUserApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getUserApplicationTableColumns } from '../../_utils/user-application-table-columns';
import ChangeApplicationUserRoleDialog from './change-application-user-role';

interface IProps {
  isOrgSettings?: boolean;
  userId: string;
}

const UserApplications = ({ isOrgSettings, userId }: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // States
  const [openChangeRoleModal, setOpenChangeRoleModal] = useState(false);
  const [selectedUserApplication, setSelectedUserApplication] =
    useState<IUserApplication>();

  // Fetching user applications
  const {
    data: userApplicationListResponse,
    isLoading: isUserApplicationListLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.userApplications
      .readUserApplicationListByOrgAdmin,
    { currentOrgId, inputs: { userId: userId as Id<'users'> } }
  );

  // [ Mutation ] - Application Remove
  const { mutate: removeApplicationAccess, isLoading: isRemovingAccess } =
    useConvexMutation(
      api.functions.apps.global.applications.userApplications
        .deleteUserApplicationByOrgAdmin
    );

  // [ Mutation ] - User Status Change
  const { mutate: changeUserStatus, isLoading: isUserStatusChanging } =
    useConvexMutation(
      api.functions.apps.global.applications.userApplications
        .updateUserApplicationStatusByOrgAdmin
    );

  // [ Dialog ] - To take confirmation for removing application
  const [ApplicationRemoveConfirmDialog, confirmApplicationRemove] =
    useConfirm();
  const [ApplicationStatusChangeDialog, confirmApplicationStatusChange] =
    useConfirm();

  // Change application user's status
  const onChangeStatus = async (userApplication: IUserApplication) => {
    if (isUserStatusChanging) return;

    const isConfirmed = await confirmApplicationStatusChange(
      DIALOG_CONTENT[
        userApplication?.isActive
          ? 'InactiveUserApplication'
          : 'ActiveUserApplication'
      ]
    );
    if (!isConfirmed) return;

    const toastId = 'change-user-status';
    toast.loading('Changing user status...', { id: toastId });

    changeUserStatus({
      currentOrgId,
      inputs: {
        userId: userApplication?.userId,
        applicationId: userApplication?._id,
        isActive: !userApplication?.isActive,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || 'Successfully changed user status.', {
            id: toastId,
          });
        } else {
          toast.error('Failed to change user status', { id: toastId });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change user status', {
          id: toastId,
        });
      });
  };

  // Handles to open change user role modal
  const onOpenChangeUserRoleModal = (userApplication: IUserApplication) => {
    if (userApplication) {
      setOpenChangeRoleModal(true);
      setSelectedUserApplication(userApplication);
    }
  };

  // Remove application handler
  const onRemoveApplication = async (rowData: IUserApplication) => {
    if (isRemovingAccess) return;

    const isConfirmed = await confirmApplicationRemove(
      DIALOG_CONTENT.RemoveUserApplication
    );
    if (!isConfirmed) return;

    const toastId = 'remove-user-application';
    toast.loading('Removing application...', { id: toastId });

    removeApplicationAccess({
      currentOrgId,
      inputs: { userId: userId as Id<'users'>, applicationId: rowData?._id },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'Application removed successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to remove application.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while removing application.',
          { id: toastId }
        );
      });
  };

  if (isUserApplicationListLoading) {
    return (
      <div className="border rounded-md p-3 space-y-4">
        {[...Array(3)].map((_, idx) => (
          <div key={idx} className="grid grid-cols-6 gap-4">
            <Skeleton className="h-7 w-full col-span-3" />
            <Skeleton className="h-7 w-full col-span-2" />
            <Skeleton className="h-7 w-full col-span-1" />
          </div>
        ))}
      </div>
    );
  }

  // Showing errors if happens
  if (error || !userApplicationListResponse) {
    return (
      <p className="text-center text-destructive py-10">
        Failed to load user applications.
      </p>
    );
  }

  return (
    <>
      <SimpleDataTable
        data={(userApplicationListResponse || []) as IUserApplication[]}
        columns={getUserApplicationTableColumns({
          isOrgSettings,
          onRemoveApplication,
          onChangeStatus,
          onChangeRole: onOpenChangeUserRoleModal,
        })}
        keyField="_id"
      />

      <ApplicationRemoveConfirmDialog />
      <ApplicationStatusChangeDialog />
      {selectedUserApplication && (
        <ChangeApplicationUserRoleDialog
          userApplication={selectedUserApplication}
          showDialog={openChangeRoleModal}
          setShowDialog={setOpenChangeRoleModal}
        />
      )}
    </>
  );
};

export default UserApplications;
