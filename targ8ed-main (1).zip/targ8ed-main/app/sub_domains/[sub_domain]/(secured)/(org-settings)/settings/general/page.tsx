'use client';
import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import ProfileImageWithUploader from '@/components/common/profile-image-with-uploader';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import { SquarePenIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import { organizationDetailsFormZodSchema } from '../../../(apps)/global/organizations/[organizationId]/_utils/form-helpers';
import UpdateOrganizationNameDescriptionDialog from './update-organization-name-description-dialog';

const GeneralPage = () => {
  const { userConfig, currentOrgId } = useSubdomainStore();

  const organizationData = userConfig?.organization;

  // States
  const [updateType, setUpdateType] = useState<'name' | 'description' | null>(
    null
  );

  // [ Mutation ] - Organization's image upload
  const { isLoading: isImageUpdating, mutate: updateOrgImage } =
    useConvexMutation(
      api.functions.apps.global.organizations.index
        .updateOrganizationImageIdByOrgAdmin
    );

  // React hook form
  const formMethods = useZodForm(organizationDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      description: '',
      subdomain: '',
      status: false,
    },
  });

  // Updating form based on organization data change
  useEffect(() => {
    formMethods.reset({
      _id: organizationData?._id,
      name: organizationData?.name,
      description: organizationData?.description,
      subdomain: organizationData?.subdomain,
      status: organizationData?.status === 'active' ? true : false,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationData]);

  if (!organizationData) {
    return <ListWithActionLoader />;
  }

  return (
    <div className="space-y-4 mb-10">
      <FormProvider {...formMethods}>
        <form
          className="space-y-4 mt-4"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          {/* Profile Image  */}
          <ProfileImageWithUploader
            imageURL={getConvexImageURL(
              organizationData?.imageId as Id<'_storage'>
            )}
            imageAlt={organizationData?.name || ''}
            isImageIdUpdating={isImageUpdating}
            onUpdateImageId={(storageId) =>
              updateOrgImage({
                currentOrgId,
                inputs: { imageId: storageId },
              })
            }
            fileUploaderProps={{
              maxFileSizeInKB: 100,
              allowedFileTypes: [
                'image/x-icon',
                'image/vnd.microsoft.icon',
                'image/png',
              ],
              allowedImageDimension: {
                type: 'ratio',
                width: 1,
                height: 1,
              },
            }}
          />

          <div className="flex gap-2 items-end">
            <FormInput disabled name="subdomain" label="Subdomain" />
          </div>

          <div className="flex gap-2 items-end">
            <FormInput disabled name="name" label="Name" />{' '}
            <ButtonWithTooltip
              variant={'ghost'}
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
              tooltipContent="Update Name"
              onClick={() => setUpdateType('name')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>
          <div className="flex gap-2 items-start">
            <FormTextarea
              disabled
              name="description"
              label="Description"
              classNames={{
                input: 'resize-none',
              }}
            />{' '}
            <ButtonWithTooltip
              variant={'ghost'}
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80 mt-4.5"
              tooltipContent="Update Description"
              onClick={() => setUpdateType('description')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>
        </form>
      </FormProvider>

      <UpdateOrganizationNameDescriptionDialog
        organizationData={organizationData}
        showDialog={!!updateType}
        setShowDialog={(state) => !state && setUpdateType(null)}
        updateType={updateType}
      />
    </div>
  );
};

export default GeneralPage;
