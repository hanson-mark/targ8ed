import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import FormInput from '@/components/form/form-input';
import FormSwitch from '@/components/form/form-switch';
import FormTextarea from '@/components/form/form-textarea';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { cn } from '@/lib/utils';
import useSubdomainStore from '@/stores/subdomainStore';
import { SquarePenIcon, UserIcon } from 'lucide-react';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { applicationDetailsFormZodSchema } from '../../_utils/form-helpers';
import UpdateApplicationNameDescriptionDialog from './update-application-name-description-dialog';

interface IProps {
  applicationData?: IOrgApplication;
}

const GeneralTab = ({ applicationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // States
  const [updateType, setUpdateType] = useState<'name' | 'description' | null>(
    null
  );

  // [ Mutation ] - Application Status Change
  const { mutate: updateStatus, isLoading: isUpdatingStatus } =
    useConvexMutation(
      api.functions.apps.global.applications.orgApplications
        .updateOrgApplicationStatusByOrgAdmin
    );

  // React hook form
  const formMethods = useZodForm(applicationDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      description: '',
      key: '',
      isActive: false,
    },
  });

  // Handles global application isActive change
  const onStatusChange = async (checked: boolean) => {
    formMethods.setValue('isActive', !checked);
    if (isUpdatingStatus) return;

    const toastId = 'change-org-status';
    toast.loading('Changing application status...', { id: toastId });
    updateStatus({
      currentOrgId,
      inputs: {
        applicationId: applicationData?.applicationId as Id<'applications'>,
        isActive: checked,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed application status.',
            {
              id: toastId,
            }
          );
        } else {
          toast.error(res?.message || 'Failed to change application status', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change application status', {
          id: toastId,
        });
      });
  };

  // Updating form based on application data change
  useEffect(() => {
    formMethods.reset({
      _id: applicationData?._id,
      name: applicationData?.name,
      description: applicationData?.description,
      key: applicationData?.application?.key,
      isActive: applicationData?.isActive,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [applicationData]);

  const imageURL = getConvexImageURL(
    applicationData?.application?.imageId as Id<'_storage'>
  );

  return (
    <div className="space-y-4 mb-10">
      <FormProvider {...formMethods}>
        <form
          className="space-y-4 mt-8"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          <div
            className={cn(
              'relative w-14 h-14 flex justify-center items-center border rounded-full bg-muted overflow-hidden'
            )}
          >
            {imageURL ? (
              <Image
                src={imageURL}
                fill
                className="object-cover"
                alt={applicationData?.name || ''}
              />
            ) : (
              <UserIcon className="size-7" />
            )}
          </div>
          <FormSwitch
            disabled={isUpdatingStatus}
            name="isActive"
            size="md"
            label={'Active'}
            labels={{
              checked: 'Active',
              unchecked: 'Inactive',
            }}
            description="Controls the application status."
            onCheckedChange={onStatusChange}
          />

          <FormInput disabled name="key" label="Application Key" />
          <div className="flex gap-2 items-end">
            <FormInput disabled name="name" label="Name" />{' '}
            <ButtonWithTooltip
              variant={'ghost'}
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
              tooltipContent="Update Name"
              onClick={() => setUpdateType('name')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>

          <div className="flex gap-2 items-start">
            <FormTextarea
              disabled
              name="description"
              label="Description"
              classNames={{
                input: 'resize-none',
              }}
            />{' '}
            <ButtonWithTooltip
              variant={'ghost'}
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80 mt-4.5"
              tooltipContent="Update Description"
              onClick={() => setUpdateType('description')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>
        </form>
      </FormProvider>

      <UpdateApplicationNameDescriptionDialog
        applicationData={applicationData}
        showDialog={!!updateType}
        setShowDialog={(state) => !state && setUpdateType(null)}
        updateType={updateType}
      />
    </div>
  );
};

export default GeneralTab;
