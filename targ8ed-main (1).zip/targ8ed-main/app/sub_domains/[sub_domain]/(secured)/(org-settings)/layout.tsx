import OrgDashboardLayout from '@/components/layouts/org-dashboard-layout';
import { getSubDomainInServer } from '@/lib/app-config';
import requiredEnvVariables from '@/lib/env-variables';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const SubDomainsOrgSettingsLayout = async ({ children }: IProps) => {
  const subdomain = await getSubDomainInServer();
  const mainDomain = requiredEnvVariables.NEXT_PUBLIC_MAIN_DOMAIN;

  const subdomainURL = `${subdomain}.${mainDomain}`;

  return (
    <OrgDashboardLayout
      menuTitle="Settings"
      subdomainURL={subdomainURL}
      menuItems={[
        { id: 'general', label: 'General', href: '/settings/general' },
        {
          id: 'applications',
          label: 'Applications',
          href: '/settings/applications',
        },
        {
          id: 'invitations',
          label: 'Invitations',
          href: '/settings/invitations',
        },
        { id: 'users', label: 'Users', href: '/settings/users' },
        { id: 'theme', label: 'Theme', href: '/settings/theme' },
        {
          id: 'billing-profile',
          label: 'Billing Profile',
          href: '/settings/billing-profile',
        },
        {
          id: 'subscription',
          label: 'Subscription',
          href: '/settings/subscription',
        },
        { id: 'invoices', label: 'Invoices', href: '/settings/invoices' },
      ]}
    >
      {children}
    </OrgDashboardLayout>
  );
};

export default SubDomainsOrgSettingsLayout;
