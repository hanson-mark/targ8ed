import SharedLayoutForAllSubdomains from '@/components/layouts/shared-layout-for-all-subdomain';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const SecuredLayout = async ({ children }: IProps) => {
  return (
    <SharedLayoutForAllSubdomains>{children}</SharedLayoutForAllSubdomains>
  );
};

export default SecuredLayout;
