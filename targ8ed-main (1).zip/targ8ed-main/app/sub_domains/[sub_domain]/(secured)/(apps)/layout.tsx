'use client';
import { lastOpenedApplicationKeyName } from '@/convex/constants/common';
import useSubdomainStore from '@/stores/subdomainStore';
import { setCookie } from 'cookies-next/client';
import { usePathname } from 'next/navigation';
import { ReactNode, useEffect, useState } from 'react';

const ApplicationsLayout = ({ children }: { children: ReactNode }) => {
  // Current application key is derived from the pathname
  const pathname = usePathname();
  const currentApplicationKey = pathname.split('/')[1] || '';

  // Access the user configuration from the subdomain store
  const { userConfig } = useSubdomainStore();
  const applications = userConfig?.applications || [];
  const allApplicationKeyList = applications.map((app) => app.key);

  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    if (
      currentApplicationKey &&
      allApplicationKeyList?.includes(currentApplicationKey)
    ) {
      setCookie(lastOpenedApplicationKeyName, currentApplicationKey, {
        maxAge: 60 * 60 * 24 * 30, // 30 days in seconds
      });
    }
  }, [currentApplicationKey, allApplicationKeyList, isHydrated]);

  return children;
};

export default ApplicationsLayout;
