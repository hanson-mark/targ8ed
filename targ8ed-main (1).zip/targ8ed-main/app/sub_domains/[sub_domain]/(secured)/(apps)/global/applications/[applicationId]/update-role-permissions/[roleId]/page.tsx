import { Id } from '@/convex/_generated/dataModel';
import RoleDetails from './_components/role-details';

interface IProps {
  params: Promise<{
    roleId: Id<'roles'>;
    applicationId: Id<'applications'>;
  }>;
}

const UpdateRolePermissionsPage = async ({ params }: IProps) => {
  const { roleId, applicationId } = await params;

  return <RoleDetails roleId={roleId} applicationId={applicationId} />;
};

export default UpdateRolePermissionsPage;
