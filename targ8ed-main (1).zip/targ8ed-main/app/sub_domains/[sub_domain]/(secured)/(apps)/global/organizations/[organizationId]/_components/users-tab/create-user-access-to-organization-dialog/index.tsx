'use client';
import { createClerkUser } from '@/actions/auth/user';
import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import FormToggleButtons from '@/components/form/form-toggle-buttons';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrganization, IUser } from '@/convex/types/convex-types';
import HttpStatusCodes from '@/convex/utils/httpStatusCode';
import { emailZodSchema, nameZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { cn } from '@/lib/utils';
import useSubdomainStore from '@/stores/subdomainStore';
import { IHonoResponse } from '@/types/hono';
import { useConvex } from 'convex/react';
import { MoveLeftIcon, MoveRightIcon } from 'lucide-react';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import AddFromList from './add-from-list';
import SingleUserWithAddButton from './single-user-with-add-button';

interface IProps {
  organizationData?: IOrganization;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const CreateUserAccessToOrganizationDialog = ({
  organizationData,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const [step, setStep] = useState(0); // Tracks dialog steps
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [isCreatingClerkUser, setIsCreatingClerkUser] = useState(false);
  const [isCheckingUserByEmail, setIsCheckingUserByEmail] = useState(false);
  const [existingUser, setExistingUser] = useState<IUser | undefined>(); // If user already exists

  // Request
  const convexRequest = useConvex();

  // Mutations
  const { mutate: createUserToGlobal, isLoading: isCreatingToGlobal } =
    useConvexMutation(api.functions.apps.global.users.index.createUser);
  const { mutate: addUserRequest, isLoading: isConnecting } = useConvexMutation(
    api.functions.apps.global.users.orgUsers.createOrgUser
  );

  // Loaders
  const isCreating = isCreatingClerkUser || isCreatingToGlobal;
  const isAnyLoading = isConnecting || isCreating || isCheckingUserByEmail;

  // Define validation schema based on step
  const validationSchema = z.object({
    userAddingType: z.enum(['from-list', 'by-email']).default('from-list'),
    email: emailZodSchema,
    userId: z.string(),
    ...(step === 1
      ? {
          name: nameZodSchema,
        }
      : { name: z.string() }),
  });

  type IFormData = z.infer<typeof validationSchema>;

  // Initialize react-hook-form with validation
  const formMethods = useZodForm(validationSchema, {
    defaultValues: {
      userAddingType: 'from-list',
      email: '',
      userId: '',
      name: '',
    },
  });
  const userAddingType = formMethods.watch('userAddingType');

  // Reset state and form when modal opens/closes
  const onOpenChange = (open: boolean) => {
    formMethods.reset();
    setShowDialog(open);
    setStep(0);
    setExistingUser(undefined);
    setDebouncedSearch('');
  };

  // Handler for back button click
  const onBackButtonClick = () => {
    if (step === 1) {
      if (existingUser?._id) {
        formMethods.setValue('name', '');
        formMethods.setValue('userId', '');
        setExistingUser(undefined);
        formMethods.clearErrors();
        setStep(0);
      } else {
        // If new user, go back to step 0 only
        setStep(0);
      }
    }
  };

  // API: Check if user already exists in organization
  const getUserInOrg = async (userId: string) => {
    try {
      return await convexRequest.query(
        api.functions.apps.global.users.orgUsers.readOrgUserDetails,
        {
          currentOrgId,
          inputs: {
            userId: userId as Id<'users'>,
            organizationId: organizationData?._id as Id<'organizations'>,
          },
        }
      );
    } catch {
      return null;
    }
  };

  // API: Create new user if not found
  const createUser = async (values: IFormData, toastId: string) => {
    try {
      setIsCreatingClerkUser(true);
      const clerkUserResponse = await createClerkUser({
        email: values?.email,
        name: values?.name,
      });
      const clerkUser = clerkUserResponse as IHonoResponse<{
        id: string;
        imageUrl: string;
      }>;
      setIsCreatingClerkUser(false);

      if (!clerkUser?.success || !clerkUser?.data) {
        toast.error(clerkUser?.message, { id: toastId });
        return;
      }

      const response = await createUserToGlobal({
        currentOrgId,
        inputs: { name: values?.name, email: values?.email },
      });

      return response?.success ? response?.data || undefined : undefined;
    } catch {
      return undefined;
    }
  };

  // API: Handler to add user to organization
  const addUserToOrganization = async (
    userId: Id<'users'>,
    toastId?: string
  ) => {
    if (userId) {
      toast.loading('Connecting user to organization...', { id: toastId });

      // API: Add user to organization
      const res = await addUserRequest({
        currentOrgId,
        inputs: {
          userId,
          organizationId: organizationData?._id as Id<'organizations'>,
        },
      });
      if (res?.success) {
        toast.success(res.message || 'User connected successfully', {
          id: toastId,
        });
        formMethods.reset();

        // Close dialog
        onOpenChange(false);
      } else {
        toast.error(res?.message || 'Failed to connect user', { id: toastId });
      }
    }
  };

  // Step 1 handler: Find user by email or allow creation
  const handleFirstStep = async (email: string) => {
    const toastId = 'checking-user-by-email';
    toast.loading('Checking user availability...', { id: toastId });
    setIsCheckingUserByEmail(true);

    try {
      // API: Fetch user by email
      const userRes = await convexRequest.query(
        api.functions.apps.global.users.index.readUserDetailsByEmail,
        { currentOrgId, inputs: { email } }
      );

      // Checking if any unexpected error
      if (
        !userRes?.success &&
        userRes?.statusCode !== HttpStatusCodes.NOT_FOUND
      ) {
        console.log('Entered');

        toast.error(userRes?.message || "Failed to check user's data", {
          id: toastId,
        });
        return;
      }

      const data = 'data' in userRes ? userRes?.data : undefined;

      if (!data || !data?._id) {
        toast.success('Fill user information and add to organization', {
          id: toastId,
        });
        setStep(1);
        return;
      }

      const userInOrgRes = await getUserInOrg(data._id);

      if (
        !userInOrgRes?.success &&
        userInOrgRes?.statusCode !== HttpStatusCodes.NOT_FOUND
      ) {
        toast.error(userInOrgRes?.message || "Failed to check user's data", {
          id: toastId,
        });
        return;
      }

      const orgUserData =
        'data' in userInOrgRes ? userInOrgRes?.data : undefined;
      if (orgUserData && orgUserData?._id) {
        toast.error('User already exists in this organization', {
          id: toastId,
        });
        return;
      }

      formMethods.setValue('userId', data._id);
      formMethods.setValue('name', data.name || '');
      setExistingUser(data);
      setStep(1);

      toast.success('User found. Proceed to assign a role.', { id: toastId });
    } catch (error) {
      console.error('Error checking user by email:', error);
      toast.error(
        (error as { message: string })?.message || 'Something went wrong',
        { id: toastId }
      );
    } finally {
      setIsCheckingUserByEmail(false);
    }
  };

  // Step 2 handler: Create new user (if needed) and connect to org
  const connectUserToastId = 'connecting-user-to-organization';
  const handleSecondStep = async (values: IFormData) => {
    const toastId = connectUserToastId;

    let createdUserId: Id<'users'> | undefined = undefined;

    if (!values?.userId) {
      toast.loading('Connecting user...', { id: toastId });
      createdUserId = await createUser(values, toastId);
    }

    const userId = (createdUserId || values?.userId) as Id<'users'>;
    if (userId) {
      await addUserToOrganization(userId, toastId);
    } else {
      toast.error('Failed to connect user to the organization', {
        id: toastId,
      });
    }
  };

  // Final submit handler
  const onSubmit = async (values: IFormData) => {
    if (step === 0) return handleFirstStep(values.email);
    if (step === 1) return handleSecondStep(values);
  };

  // Reset form state when dialog opens
  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Connect User to Organization"
      description={
        step === 0 && userAddingType === 'from-list'
          ? 'Select a user from the user list to connect'
          : step === 0 && userAddingType === 'by-email'
            ? 'Enter the user email to check if they exist.'
            : 'Confirm user info and assign a role.'
      }
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div
            className={cn(
              'grid gap-4 pb-6',
              userAddingType === 'from-list' ? 'pb-0' : ''
            )}
          >
            {step === 0 && (
              <FormToggleButtons
                disabled={step > 0 || isCheckingUserByEmail || isConnecting}
                name="userAddingType"
                label=""
                options={[
                  { label: 'Connect From List', value: 'from-list' as const },
                  { label: 'Connect By Email', value: 'by-email' as const },
                ]}
                classNames={{
                  button: 'capitalize h-8',
                  group:
                    'max-w-[264px] flex flex-wrap gap-1.5 justify-between items-center border rounded-md px-1.5 py-1',
                }}
                onClick={() => {
                  formMethods.setValue('email', '');
                  formMethods.setValue('name', '');
                  formMethods.setValue('userId', '');
                  setExistingUser(undefined);
                  formMethods.clearErrors();
                  setStep(0);
                }}
              />
            )}

            {userAddingType === 'from-list' && step === 0 && showDialog && (
              <AddFromList
                disabled={isAnyLoading}
                organizationId={organizationData?._id as Id<'organizations'>}
                onUserAdd={async (userId) => {
                  await addUserToOrganization(userId, connectUserToastId);
                }}
                debouncedSearch={debouncedSearch}
                setDebouncedSearch={setDebouncedSearch}
              />
            )}

            {userAddingType === 'by-email' &&
              (step === 1 && existingUser?._id ? (
                <SingleUserWithAddButton
                  disabled={isAnyLoading}
                  user={{ ...existingUser, isInOrganization: false }}
                  onUserAdd={async (userId) => {
                    await addUserToOrganization(userId, connectUserToastId);
                  }}
                />
              ) : (
                <>
                  {/* Name input for new user */}
                  {step === 1 && (
                    <FormInput
                      disabled={
                        isCreating || isConnecting || !!existingUser?._id
                      }
                      name="name"
                      label="Name"
                      placeholder="Enter user's name"
                    />
                  )}

                  {/* Email input (always shown) */}
                  <FormInput
                    disabled={isCheckingUserByEmail || step > 0}
                    type="email"
                    name="email"
                    label="Email Address"
                    placeholder="Enter user's email address"
                  />
                </>
              ))}
          </div>

          {/* Footer actions */}
          {userAddingType === 'by-email' && (
            <DialogFooter>
              {step === 0 ? (
                <Button
                  type="button"
                  disabled={isCheckingUserByEmail || isConnecting}
                  onClick={() => onOpenChange(false)}
                  variant="outline"
                >
                  Cancel
                </Button>
              ) : (
                <Button
                  type="button"
                  disabled={isCheckingUserByEmail || isConnecting}
                  onClick={onBackButtonClick}
                  variant="outline"
                >
                  <MoveLeftIcon className="h-4 w-4" /> Back
                </Button>
              )}

              {step === 0 && (
                <Button
                  type="submit"
                  disabled={
                    isCheckingUserByEmail || formMethods.formState.isSubmitting
                  }
                >
                  {isCheckingUserByEmail ? (
                    'Checking...'
                  ) : (
                    <>
                      Next <MoveRightIcon className="h-4 w-4" />
                    </>
                  )}
                </Button>
              )}

              {step === 1 && !existingUser?._id && (
                <Button
                  type="submit"
                  disabled={isConnecting || formMethods.formState.isSubmitting}
                >
                  {isConnecting ? 'Connecting...' : 'Connect User'}
                </Button>
              )}
            </DialogFooter>
          )}
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateUserAccessToOrganizationDialog;
