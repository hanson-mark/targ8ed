import { DataTableActionDropdown } from '@/components/common/data-table';
import ProfileImage from '@/components/common/profile-image';
import { Badge } from '@/components/ui/badge';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import {
  IOrgApplication,
  IPermission,
  IRole,
} from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { ILucideIconName } from '@/types/dashboard-layout';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import { PlusIcon } from 'lucide-react';

export const getApplicationOrganizationTableColumns = ({
  hasRemoveApplicationAccess,
  onRemoveOrgFromApplication,
}: {
  hasRemoveApplicationAccess: boolean;
  onRemoveOrgFromApplication: (rowData: IOrgApplication) => void;
}) => {
  const getMenuItems = (
    rowData: IOrgApplication
  ): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'details',
        icon: 'SquareMenuIcon',
        label: 'Go to organization',
        type: 'link',
        href: `/${APPLICATION_KEYS.global}/organizations/${rowData?.organizationId}`,
      },

      ...(hasRemoveApplicationAccess
        ? [
            {
              id: 'delete',
              icon: 'TrashIcon' as ILucideIconName,
              label: 'Remove',
              type: 'button' as const,
              onClick: () => onRemoveOrgFromApplication(rowData),
            },
          ]
        : []),
    ];
  };

  const columns: ISimpleDataTableColumn<IOrgApplication>[] = [
    {
      header: 'Organization',
      cell: (row) => (
        <div className="flex items-center gap-2 max-w-44">
          <ProfileImage
            imageURL={getConvexImageURL(
              row?.organization?.imageId as Id<'_storage'>
            )}
            iconSize={7}
            iconType="organization"
          />
          <span className="max-w-full truncate">{row?.organization?.name}</span>{' '}
          {/* <FileSymlinkIcon className="shrink-0 w-4 h-4 -ml-1 opacity-90" /> */}
        </div>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};

export const getPermissionsTableColumns = (
  args: {
    hasUpdatePermissionAccess: boolean;
    hasDeletePermissionAccess: boolean;
    onRemovePermission: (permission: IPermission) => void;
    onOpenUpdateDialog: (permission: IPermission) => void;
  },
  activeColumns: string[]
) => {
  const getMenuItems = (
    rowData: IPermission
  ): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'update',
        icon: 'PenSquareIcon' as ILucideIconName,
        label: 'Update',
        type: 'button' as const,
        onClick: () => args?.onOpenUpdateDialog(rowData),
      },

      {
        id: 'delete',
        icon: 'TrashIcon' as ILucideIconName,
        label: 'Delete',
        type: 'button' as const,
        onClick: () => args?.onRemovePermission(rowData),
      },
    ];
  };

  const columns: ISimpleDataTableColumn<IPermission>[] = [
    {
      header: 'Key',
      cell: (row) => <Badge className="rounded-full">{row?.key}</Badge>,
    },
    {
      header: 'Method',
      cell: (row) => row?.method,
    },
    {
      header: 'Name',
      cell: (row) => row?.name,
    },
    {
      header: 'Description',
      cell: (row) => (
        <div className="break-all whitespace-normal">{row?.description}</div>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns?.filter((item) =>
    [...activeColumns, 'Actions']?.includes(item?.header)
  );
};

export const getRolesTableColumns = (args: {
  hasDeleteApplicationRoleAccess: boolean;
  hasUpdateApplicationRoleAccess: boolean;
  hasUpdatePermissionsOfApplicationRoleAccess: boolean;
  onRemoveRole: (permission: IRole) => void;
  onOpenUpdateDialog: (permission: IRole) => void;
}) => {
  const getMenuItems = (rowData: IRole): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'update',
        icon: 'PenSquareIcon',
        label: 'Update',
        type: 'button' as const,
        onClick: () => args?.onOpenUpdateDialog(rowData),
      },
      ...(!rowData?.isAdminRole
        ? [
            {
              id: 'update-permissions',
              icon: 'ShieldCheckIcon' as const,
              label: 'Permissions',
              type: 'link' as const,
              href: `/${APPLICATION_KEYS.global}/applications/${rowData.applicationId}/update-role-permissions/${rowData?._id}`,
            },
          ]
        : []),
      {
        id: 'delete',
        icon: 'TrashIcon',
        label: 'Delete',
        type: 'button' as const,
        onClick: () => args?.onRemoveRole(rowData),
      },
    ];
  };

  const columns: ISimpleDataTableColumn<IRole>[] = [
    {
      header: 'Role Name',
      cell: (row) => row?.name,
    },
    {
      header: 'Description',
      cell: (row) => row?.description,
    },
    {
      header: 'Is Admin Role',
      cell: (row) => (
        <Badge className="text-xs rounded-full">
          {row?.isAdminRole ? 'YES' : 'NO'}
        </Badge>
      ),
    },
    {
      header: 'Permissions',
      cell: (row) => {
        const allPermissions = row?.permissions || [];
        const sliceCount = 10;
        const remainingCount = allPermissions?.length - sliceCount;
        const slicedPermissions = allPermissions.slice(0, sliceCount);

        return (
          <div className="flex gap-2 flex-wrap">
            {allPermissions.length < 1 ? (
              <span className="text-gray-400 text-sm italic font-medium">
                No permissions
              </span>
            ) : (
              <>
                {/* Show first 10 permissions */}
                {slicedPermissions.map((permission) => (
                  <Badge key={permission?._id} className="rounded-full">
                    {permission?.method}:{permission?.name}
                  </Badge>
                ))}

                {/* If more, show hover card */}
                {remainingCount > 0 && (
                  <HoverCard>
                    <HoverCardTrigger asChild>
                      <Badge
                        variant="secondary"
                        className="rounded-full border border-border cursor-pointer"
                      >
                        <PlusIcon className="w-3 h-3" />
                        {remainingCount} permission
                      </Badge>
                    </HoverCardTrigger>

                    <HoverCardContent className="w-80 p-3">
                      <h4 className="text-sm font-semibold mb-2">
                        All Assigned Permissions ({allPermissions.length})
                      </h4>
                      <ScrollArea className="h-56 pr-2">
                        <div className="grid gap-2">
                          {allPermissions.map((permission) => (
                            <Badge
                              key={permission?._id}
                              variant="secondary"
                              className="rounded-full text-xs"
                            >
                              {permission?.method}:{permission?.name}
                            </Badge>
                          ))}
                        </div>
                      </ScrollArea>
                    </HoverCardContent>
                  </HoverCard>
                )}
              </>
            )}
          </div>
        );
      },
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};

export const getModulesTableColumns = (args: {
  hasUpdateApplicationModuleAccess: boolean;
  hasDeleteApplicationModuleAccess: boolean;
  onUpdate: (rowData: Doc<'applicationModules'>) => void;
  onRemove: (rowData: Doc<'applicationModules'>) => void;
}) => {
  const getMenuItems = (
    rowData: Doc<'applicationModules'>
  ): ITableActionDropdownMenuItems[] => {
    return [
      ...(args?.hasUpdateApplicationModuleAccess
        ? [
            {
              id: 'update',
              icon: 'PenSquareIcon' as ILucideIconName,
              label: 'Update',
              type: 'button' as const,
              onClick: () => args?.onUpdate(rowData),
            },
          ]
        : []),
      ...(args?.hasDeleteApplicationModuleAccess
        ? [
            {
              id: 'delete',
              icon: 'TrashIcon' as ILucideIconName,
              label: 'Delete',
              type: 'button' as const,
              onClick: () => args?.onRemove(rowData),
            },
          ]
        : []),
    ];
  };

  const columns: ISimpleDataTableColumn<Doc<'applicationModules'>>[] = [
    {
      header: 'Name',
      cell: (row) => <div className="max-w-44 truncate">{row?.name}</div>,
    },
    {
      header: 'Description',
      cell: (row) => <div className=" ">{row?.description}</div>,
    },
    {
      header: 'Link',
      cell: (row) => <div className="">{row?.link}</div>,
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};
