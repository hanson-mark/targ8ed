import { z } from 'zod';

export const userDetailsFormZodSchema = z.object({
  _id: z.string().optional(),
  name: z.string().optional(),
  email: z.string().optional(),
  status: z.boolean().optional(),
});
