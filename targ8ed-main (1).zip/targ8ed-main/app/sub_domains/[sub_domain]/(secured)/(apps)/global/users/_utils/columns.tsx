'use client';

import {
  getActionDropdownColumnConfig,
  getSortableTextColumnConfig,
} from '@/components/common/data-table/utils/table-column-generators';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { IUser } from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { ILucideIconName } from '@/types/dashboard-layout';
import { ColumnDef } from '@tanstack/react-table';
import { format } from 'date-fns';
import Link from 'next/link';

interface IParam {
  hasUpdateUserStatusAccess?: boolean;
  onUserStatusChange: (userId: string, checked: boolean) => void;
}
export const getUserTableColumns = ({
  hasUpdateUserStatusAccess,
  onUserStatusChange,
}: IParam) => {
  const usersTableColumns: ColumnDef<IUser>[] = [
    getSortableTextColumnConfig({
      accessorKey: 'name',
      headerTitle: 'Name',
      formatter: (value, row) => (
        <Link
          href={`/${APPLICATION_KEYS.global}/users/${row?.original?._id}`}
          className="flex items-center gap-2 max-w-44"
        >
          <ProfileImage
            imageURL={getConvexImageURL(
              row?.original?.imageId as Id<'_storage'>
            )}
            iconSize={7}
            iconType="user"
          />
          <span className="max-w-full truncate">{value as string}</span>
        </Link>
      ),
    }),
    getSortableTextColumnConfig({
      accessorKey: 'email',
      headerTitle: 'Email',
    }),
    getSortableTextColumnConfig({
      accessorKey: 'status',
      headerTitle: 'Status',
      formatter: (value) => (
        <div className={''}>
          <StatusBadge status={(value || '')?.toString()} />
        </div>
      ),
    }),
    getSortableTextColumnConfig({
      accessorKey: '_creationTime',
      headerTitle: 'Added At',
      formatter: (value) => (
        <div className="text-sm">
          {value
            ? format(new Date(value as string), 'dd-MMM-yyyy hh:mm a')
            : '-'}
        </div>
      ),
    }),
    getActionDropdownColumnConfig({
      headerTitle: 'Actions',
      menuItems: (rowData) => {
        return [
          {
            id: 'view',
            icon: 'SquareMenuIcon',
            label: 'View Details',
            type: 'link',
            href: `/${APPLICATION_KEYS.global}/users/${rowData?._id}`,
          },
          ...(hasUpdateUserStatusAccess
            ? [
                {
                  id: 'active-inactive',
                  icon: (rowData?.status === 'active'
                    ? 'BanIcon'
                    : 'CheckCircleIcon') as ILucideIconName,
                  label:
                    rowData?.status === 'active'
                      ? 'Inactive User'
                      : 'Active User',
                  type: 'button' as const,
                  onClick: () => {
                    onUserStatusChange(
                      rowData?._id,
                      rowData?.status === 'active' ? false : true
                    );
                  },
                },
              ]
            : []),
        ];
      },
    }),
  ];
  return [...usersTableColumns];
};
