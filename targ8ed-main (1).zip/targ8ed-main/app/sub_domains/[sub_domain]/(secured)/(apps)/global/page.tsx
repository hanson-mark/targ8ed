const GlobalHomePage = () => {
  return <div>GlobalHomePage</div>;
};

export default GlobalHomePage;
