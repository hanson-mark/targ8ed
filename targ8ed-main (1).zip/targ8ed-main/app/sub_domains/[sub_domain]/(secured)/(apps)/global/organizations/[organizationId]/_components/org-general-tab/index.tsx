import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import ProfileImageWithUploader from '@/components/common/profile-image-with-uploader';
import TooltipWrapper from '@/components/common/tooltip-wrapper';
import FormInput from '@/components/form/form-input';
import FormSwitch from '@/components/form/form-switch';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { IOrganization } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useInputConfirm from '@/hooks/use-input-confirm';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import {
  getConvexImageURL,
  getOrganizationURL,
} from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { LinkIcon, SquarePenIcon } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { organizationDetailsFormZodSchema } from '../../_utils/form-helpers';
import UpdateOrganizationNameAndDescriptionDialog from './update-organization-name-description-dialog';

interface IProps {
  isOrgDashboard?: boolean;
  organizationData?: IOrganization;
  setIsDeleting: Dispatch<SetStateAction<boolean>>;
}

const OrgGeneralTab = ({
  isOrgDashboard,
  organizationData,
  setIsDeleting,
}: IProps) => {
  const router = useRouter();

  const isRootOrg = ROOT_CONFIG.org.subdomain === organizationData?.subdomain;

  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasImageUploadAccess = checkPermission(permissions, [
    'updateOrganizationImageId',
  ]);
  const hasStatusChangeAccess = checkPermission(permissions, [
    'updateOrganizationStatus',
  ]);
  const hasNameOrDescriptionUpdateAccess = checkPermission(permissions, [
    'updateOrganizationNameOrDescription',
  ]);
  const hasDeleteOrgAccess = checkPermission(permissions, [
    'deleteOrganization',
  ]);

  // States
  const [updateType, setUpdateType] = useState<'name' | 'description' | null>(
    null
  );

  // [ Mutation ] - Organization Status Change
  const { mutate: updateStatus, isLoading: loadingStatusChange } =
    useConvexMutation(
      api.functions.apps.global.organizations.index.updateOrganizationStatus
    );

  // [ Mutation ] - Organization's image upload
  const { isLoading: isImageUpdating, mutate: updateOrgImage } =
    useConvexMutation(
      api.functions.apps.global.organizations.index.updateOrganizationImageId
    );

  // [ Mutation ] - Remove Organization
  const { mutate: removeOrg, isLoading: isRemovingOrg } = useConvexMutation(
    api.functions.apps.global.organizations.index.deleteOrganization
  );

  // Dialog
  const [DeleteConfirmationDialog, onConfirmDelete] = useInputConfirm({
    title: 'Are you sure to delete the organization?',
    description:
      'This action can not be undone. All the related applications, subscriptions, users will be deleted.',
    icon: {
      name: 'Building',
      variant: 'error',
    },
    confirmButton: {
      label: 'Yes, Delete',
      variant: 'destructive',
    },
  });

  // React hook form
  const formMethods = useZodForm(organizationDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      description: '',
      subdomain: '',
      status: false,
    },
  });

  // Handles global organization status change
  const handleStatusChange = async (checked: boolean) => {
    formMethods.setValue('status', !checked);
    if (loadingStatusChange) return;

    const toastId = 'change-org-status';
    toast.loading('Changing organization status...', { id: toastId });
    updateStatus({
      currentOrgId,
      inputs: {
        organizationId: organizationData?._id as Id<'organizations'>,
        status: checked ? 'active' : 'inactive',
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed organization status.',
            { id: toastId }
          );
        } else {
          toast.error(res?.message || 'Failed to change organization status', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change organization status', {
          id: toastId,
        });
      });
  };

  const handleDeleteOrg = async () => {
    if (isRootOrg) return;
    if (isRemovingOrg) return;

    const requiredValue = organizationData?.subdomain || '';
    const userInputSubdomain = await onConfirmDelete({
      requiredValue,
    });
    if (!userInputSubdomain || userInputSubdomain !== requiredValue) return;

    const toastId = 'remove-org';
    toast.loading('Deleting organization...', { id: toastId });
    setIsDeleting(true);

    removeOrg({
      currentOrgId,
      inputs: { organizationId: organizationData?._id as Id<'organizations'> },
    })
      .then((response) => {
        if (response?.success) {
          router.push(`/${APPLICATION_KEYS.global}/organizations`);
          toast.success(
            response?.message || 'Successfully deleted the organization',
            { id: toastId }
          );
        } else {
          setIsDeleting(false);
          toast.error(response?.message || 'Failed to deleted organization', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to deleted the organization', {
          id: toastId,
        });
      });
  };

  // Updating form based on organization data change
  useEffect(() => {
    formMethods.reset({
      _id: organizationData?._id,
      name: organizationData?.name,
      description: organizationData?.description,
      subdomain: organizationData?.subdomain,
      status: organizationData?.status === 'active' ? true : false,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationData]);

  const organizationURL = getOrganizationURL(organizationData?.subdomain || '');

  return (
    <div className="space-y-4 mb-10">
      <FormProvider {...formMethods}>
        <form
          className="space-y-4 mt-4"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          {!isOrgDashboard && (
            <>
              <TooltipWrapper tooltipContent={organizationURL}>
                <Button
                  asChild
                  type="button"
                  variant={'secondary'}
                  className="bg-muted hover:bg-muted/80"
                >
                  <Link
                    href={organizationURL}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <LinkIcon /> Open Organization
                  </Link>
                </Button>
              </TooltipWrapper>
              <FormSwitch
                disabled={loadingStatusChange || !hasStatusChangeAccess}
                name="status"
                size="md"
                label={'Active'}
                labels={{
                  checked: 'Active',
                  unchecked: 'Inactive',
                }}
                description="Controls the organization status."
                onCheckedChange={handleStatusChange}
              />
            </>
          )}

          {/* Profile Image  */}
          <ProfileImageWithUploader
            showUploadButton={hasImageUploadAccess}
            imageURL={getConvexImageURL(
              organizationData?.imageId as Id<'_storage'>
            )}
            imageAlt={organizationData?.name || ''}
            isImageIdUpdating={isImageUpdating}
            onUpdateImageId={(storageId) =>
              updateOrgImage({
                currentOrgId,
                inputs: {
                  organizationId: organizationData?._id as Id<'organizations'>,
                  imageId: storageId,
                },
              })
            }
            fileUploaderProps={{
              maxFileSizeInKB: 100,
              allowedFileTypes: [
                'image/x-icon',
                'image/vnd.microsoft.icon',
                'image/png',
              ],
              allowedImageDimension: {
                type: 'ratio',
                width: 1,
                height: 1,
              },
            }}
          />

          <div className="flex gap-2 items-end">
            <FormInput disabled name="subdomain" label="Subdomain" />
          </div>

          <div className="flex gap-2 items-end">
            <FormInput disabled name="name" label="Name" />{' '}
            {hasNameOrDescriptionUpdateAccess && (
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
                tooltipContent="Update Name"
                onClick={() => setUpdateType('name')}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            )}
          </div>
          <div className="flex gap-2 items-start">
            <FormTextarea
              disabled
              name="description"
              label="Description"
              classNames={{
                input: 'resize-none',
              }}
            />{' '}
            {hasNameOrDescriptionUpdateAccess && (
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80 mt-4.5"
                tooltipContent="Update Description"
                onClick={() => setUpdateType('description')}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            )}
          </div>

          {!isRootOrg && !isOrgDashboard && hasDeleteOrgAccess ? (
            <>
              <Separator className="mt-5 mb-4" />

              <div className="">
                <h3 className="text-sm font-semibold text-red-600 mb-3">
                  Danger Zone
                </h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-red-700">
                      Delete Organization
                    </p>
                    <p className="text-xs text-red-600 mt-1">
                      Once deleted, this action cannot be undone.
                    </p>
                  </div>
                  <Button
                    onClick={handleDeleteOrg}
                    className="text-white bg-red-600 hover:bg-red-700 transition px-4 py-2 text-sm font-semibold rounded-md"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </>
          ) : null}
        </form>
      </FormProvider>

      <UpdateOrganizationNameAndDescriptionDialog
        organizationData={organizationData}
        showDialog={!!updateType}
        setShowDialog={(state) => !state && setUpdateType(null)}
        updateType={updateType}
      />
      <DeleteConfirmationDialog />
    </div>
  );
};

export default OrgGeneralTab;
