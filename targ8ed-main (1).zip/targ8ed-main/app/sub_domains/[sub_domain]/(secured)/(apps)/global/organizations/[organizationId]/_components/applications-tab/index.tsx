'use client';

import { SimpleDataTable } from '@/components/common/data-table';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrganization, IOrgApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { LinkIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getOrgApplicationsTableColumns } from '../../_utils/org-applications-table-columns';
import CreateApplicationAccessToOrganizationDialog from './create-application-access-to-organization-dialog';

interface IProps {
  organizationData?: IOrganization;
}

const ApplicationsTab = ({ organizationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasCreateApplicationAccessPermission = checkPermission(permissions, [
    'createApplicationAccessOrg',
  ]);
  const hasRemoveApplicationAccess = checkPermission(permissions, [
    'deleteOrgApplication',
  ]);

  const [
    showCreateApplicationAccessToOrgDialog,
    setShowCreateApplicationAccessToOrgDialog,
  ] = useState(false);

  const {
    data: appListResponse,
    isLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.orgApplications
      .readApplicationListByOrgId,
    {
      currentOrgId,
      inputs: { organizationId: organizationData?._id as Id<'organizations'> },
    }
  );

  // [ Mutation ] - Application Remove
  const { mutate: removeOrgApplication, isLoading: isRemovingApplication } =
    useConvexMutation(
      api.functions.apps.global.applications.orgApplications
        .deleteOrgApplication
    );

  // [ Dialog ] - To take confirmation for removing application
  const [ApplicationRemoveConfirmDialog, confirmApplicationRemove] =
    useConfirm();

  const onRemoveApplication = async (rowData: IOrgApplication) => {
    if (isRemovingApplication || !hasRemoveApplicationAccess) return;

    const isConfirmed = await confirmApplicationRemove(
      DIALOG_CONTENT.RemoveOrgApplication
    );
    if (!isConfirmed) return;

    const toastId = 'remove-user-application';
    toast.loading('Removing application...', { id: toastId });

    removeOrgApplication({
      currentOrgId,
      inputs: {
        applicationId: rowData?.applicationId,
        organizationId: organizationData?._id as Id<'organizations'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'Application deleted successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to delete application.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while deleting application.',
          { id: toastId }
        );
      });
  };

  if (isLoading) return <ListWithActionLoader />;
  if (error || !appListResponse) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️{' '}
        {error?.message || 'Failed to load applications for this organization.'}
      </p>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Applications</h2>
          {hasCreateApplicationAccessPermission && (
            <Button
              onClick={() => setShowCreateApplicationAccessToOrgDialog(true)}
            >
              <LinkIcon /> Application
            </Button>
          )}
        </div>
        <p className="font-light text-sm">
          List of applications where the organization has access
        </p>
      </div>

      <SimpleDataTable
        data={appListResponse}
        columns={getOrgApplicationsTableColumns({
          hasRemoveApplicationAccess,
          onRemoveApplication,
        })}
        keyField="_id"
      />

      {/* Create Application Access to Organization Dialog */}
      <CreateApplicationAccessToOrganizationDialog
        showDialog={
          hasCreateApplicationAccessPermission &&
          showCreateApplicationAccessToOrgDialog
        }
        setShowDialog={setShowCreateApplicationAccessToOrgDialog}
        organizationData={organizationData}
      />

      <ApplicationRemoveConfirmDialog />
    </div>
  );
};

export default ApplicationsTab;
