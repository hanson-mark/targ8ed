import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrganization } from '@/convex/types/convex-types';
import {
  descriptionZodSchema,
  nameZodSchema,
} from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  organizationData?: IOrganization;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
  updateType: 'name' | 'description' | null;
}

const UpdateOrganizationNameDescriptionDialog = ({
  organizationData,
  showDialog,
  setShowDialog,
  updateType,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const { mutate: updateNameOrDescription, isLoading: isChanging } =
    useConvexMutation(
      api.functions.apps.global.organizations.index
        .updateOrganizationNameOrDescription
    );

  const validationSchema = z.object({
    name: nameZodSchema.optional(),
    description: descriptionZodSchema.optional(),
  });

  const formMethods = useZodForm(validationSchema, {
    defaultValues: { name: '', description: '' },
  });

  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  const fieldName = updateType ?? 'name';
  const fieldLabel =
    updateType === 'name'
      ? 'Name'
      : updateType === 'description'
        ? 'Description'
        : '';

  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isChanging || !updateType) return;

    const toastId = `update-organization-${updateType}`;

    toast.loading(`Updating ${fieldLabel.toLowerCase()}...`, { id: toastId });

    updateNameOrDescription({
      currentOrgId,
      inputs: {
        organizationId: organizationData?._id as Id<'organizations'>,
        [updateType]: values[updateType],
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || `${fieldLabel} updated successfully.`, {
            id: toastId,
          });

          onOpenChange(false);
        } else {
          toast.error(
            res?.message || `Failed to update ${fieldLabel.toLowerCase()}`,
            {
              id: toastId,
            }
          );
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || `Failed to update ${fieldLabel.toLowerCase()}`,
          { id: toastId }
        );
      });
  };

  useEffect(() => {
    formMethods.reset({
      name: organizationData?.name || '',
      description: organizationData?.description || '',
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title={`Update ${fieldLabel}`}
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            {fieldName === 'name' ? (
              <FormInput
                disabled={isChanging}
                name={fieldName}
                label={fieldLabel}
                placeholder={`Enter organization ${fieldLabel.toLowerCase()}`}
              />
            ) : (
              <FormTextarea
                disabled={isChanging}
                name={fieldName}
                label={fieldLabel}
                placeholder={`Enter organization ${fieldLabel.toLowerCase()}`}
              />
            )}
          </div>
          <DialogFooter>
            <Button disabled={isChanging} type="submit">
              {isChanging
                ? `Updating ${fieldLabel}...`
                : `Update ${fieldLabel}`}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default UpdateOrganizationNameDescriptionDialog;
