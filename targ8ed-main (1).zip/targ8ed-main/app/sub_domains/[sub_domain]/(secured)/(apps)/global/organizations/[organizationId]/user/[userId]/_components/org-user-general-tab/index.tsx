import { IOrgUser } from '@/convex/types/convex-types';
import UserOrganization from '../../../../../../users/[userId]/organization/[organizationId]/_components/user-organization';
interface IProps {
  orgUser?: IOrgUser;
}

const OrgUserGeneralTab = ({ orgUser }: IProps) => {
  return <UserOrganization isOpen hideViewButtons userOrganization={orgUser} />;
};

export default OrgUserGeneralTab;
