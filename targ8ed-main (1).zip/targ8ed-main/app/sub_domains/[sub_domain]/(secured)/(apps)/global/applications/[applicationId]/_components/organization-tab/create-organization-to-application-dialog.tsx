'use client';

import CustomDialog from '@/components/common/custom-dialog';
import FormComboBox from '@/components/form/form-combo-box';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { orgIdZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  applicationId: Id<'applications'>;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const CreateOrganizationToApplicationDialog = ({
  applicationId,
  showDialog,
  setShowDialog,
}: IProps) => {
  const [searchInput, setSearchInput] = useState('');

  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Permissions checking
  const hasReadAvailableListAccess = checkPermission(permissions, [
    'readAvailableOrgListToAddApplication',
  ]);
  const hasCreateApplicationAccessOrgAccess = checkPermission(permissions, [
    'createApplicationAccessOrg',
  ]);

  const { data: organizations = [], isLoading: isOrgsLoading } = useConvexQuery(
    api.functions.apps.global.applications.orgApplications
      .readAvailableOrgListToAddApplication,
    {
      currentOrgId,
      inputs: { applicationId, search: searchInput },
    }
  );

  const { mutate: connectOrgToApp, isLoading: isConnecting } =
    useConvexMutation(
      api.functions.apps.global.applications.orgApplications
        .createApplicationAccessOrg
    );

  const validationSchema = z.object({
    organizationId: orgIdZodSchema,
  });

  const formMethods = useZodForm(validationSchema, {
    defaultValues: { organizationId: '' },
  });

  const onOpenChange = (open: boolean) => {
    formMethods.reset();
    setShowDialog(open);
  };

  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isConnecting || !hasCreateApplicationAccessOrgAccess) return;

    const toastId = 'connecting-org';
    toast.loading('Connecting organization...', { id: toastId });

    connectOrgToApp({
      currentOrgId,
      inputs: { applicationId, organizationId: values?.organizationId },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || 'Organization connected successfully', {
            id: toastId,
          });

          onOpenChange(false);
        } else {
          toast.error('Failed to connect organization', { id: toastId });
        }
      })
      .catch((err) => {
        console.error(err);
        toast.error(err?.message || 'Failed to connect organization', {
          id: toastId,
        });
      });
  };

  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title={
        !hasReadAvailableListAccess || !hasCreateApplicationAccessOrgAccess
          ? 'No access'
          : 'Connect Organization'
      }
      description={
        !hasReadAvailableListAccess
          ? '⚠️ You do not have access to see available organizations list to connect with applications'
          : !hasCreateApplicationAccessOrgAccess
            ? '⚠️ You do not have access to add application access for organization'
            : 'Select an organization to connect it to this application.'
      }
    >
      {!hasReadAvailableListAccess ||
      !hasCreateApplicationAccessOrgAccess ? null : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormComboBox
                disabled={isConnecting}
                isSearching={isOrgsLoading}
                name="organizationId"
                label="Select Organization"
                placeholder="Search and select organization..."
                onSearch={setSearchInput}
                searchInputDebounceDelay={500}
                options={(organizations || [])?.map((org) => ({
                  value: org._id,
                  label: org.name,
                }))}
              />
            </div>
            <DialogFooter>
              <Button type="submit" disabled={isConnecting}>
                {isConnecting ? 'Connecting...' : 'Connect'}
              </Button>
            </DialogFooter>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default CreateOrganizationToApplicationDialog;
