import {
  SimpleDataTable,
  SimpleDataTableColumnsSelector,
} from '@/components/common/data-table';
import DebouncedSearchInput from '@/components/common/debounced-search-input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { permissionMethods } from '@/convex/constants/common';
import { IPermission, IPermissionMethod } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useInputConfirm from '@/hooks/use-input-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { PlusIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getPermissionsTableColumns } from '../../_utils/table-columns';
import CreateOrUpdatePermissionDialog from './create-or-update-permission-dialog';

interface IProps {
  applicationId: Id<'applications'>;
}

const PermissionsTab = ({ applicationId }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions: userPermissions } = useUserRolesStore();

  // Check permissions
  const hasCreatePermissionAccess = checkPermission(userPermissions || [], [
    'createPermission',
  ]);
  const hasUpdatePermissionAccess = checkPermission(userPermissions || [], [
    'updatePermission',
  ]);
  const hasDeletePermissionAccess = checkPermission(userPermissions || [], [
    'deletePermission',
  ]);

  // States
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<
    IPermissionMethod | 'all'
  >('all');
  const [selectedPermission, setSelectedPermission] = useState<IPermission>();
  const [showCreatePermissionDialog, setShowCreatePermissionDialog] =
    useState(false);
  const [activeColumns, setActiveColumns] = useState<string[]>([
    'Key',
    'Method',
    'Name',
    'Description',
  ]);

  // Configuration for removing permission
  const [RemoveConfirmationDialog, onRemoveConfirm] = useInputConfirm({
    description: 'This action can not be undone.',
    icon: { name: 'Trash2Icon', variant: 'error' },
  });

  // Getting permissions for the application
  const {
    data: permissionList = [],
    isLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.permissions.readPermissions,
    {
      currentOrgId,
      inputs: {
        applicationId: applicationId,
        ...(selectedMethod !== 'all' ? { method: selectedMethod } : {}),
        ...(debouncedSearch ? { search: debouncedSearch } : {}),
      },
    }
  );

  // Mutation for removing permission
  const { mutate: removePermission, isLoading: isRemoving } = useConvexMutation(
    api.functions.apps.global.applications.permissions.deletePermission
  );

  // Handles showing the update permission dialog
  const onOpenUpdateDialog = (permission: IPermission) => {
    setSelectedPermission(permission);
    setShowCreatePermissionDialog(true);
  };

  // Handles removing the permission dialog
  const onRemovePermission = async (permission: IPermission) => {
    if (isRemoving || !hasDeletePermissionAccess) return;

    const requiredValue =
      `${permission?.method + ':' + permission?.name}` || '';

    const userInputKey = await onRemoveConfirm({
      title: (
        <>
          Delete Permission{' '}
          <span className="font-bold text-destructive">
            {permission?.method}:{permission?.name}
          </span>
          ?
        </>
      ),
      requiredValue,
    });

    if (!userInputKey || userInputKey !== requiredValue) return;

    const toastId = 'remove-permission';
    toast.loading('Deleting Permission...', { id: toastId });

    removePermission({
      currentOrgId,
      inputs: { permissionId: permission._id },
    })
      .then((response) => {
        if (response?.success) {
          toast.success(
            response?.message || 'Permission deleted successfully.',
            {
              id: toastId,
            }
          );
        } else {
          toast.error(response?.message || 'Failed to delete permission.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to delete permission.', {
          id: toastId,
        });
      });
  };

  if (!isLoading && (error || !permissionList)) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️{' '}
        {error?.message || 'Failed to load permissions for this application.'}
      </p>
    );
  }

  return (
    <div className="w-full space-y-4">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Permissions</h2>
          {hasCreatePermissionAccess && (
            <Button
              onClick={() => {
                setShowCreatePermissionDialog(true);
                setSelectedPermission(undefined);
                console.log(
                  permissionList?.map((item) => ({
                    name: item?.name,
                    key: item?.key,
                    method: item?.method,
                    description: item?.description,
                  }))
                );
              }}
            >
              <PlusIcon /> Permission
            </Button>
          )}
        </div>
        <p className="font-light text-sm">
          List of permissions available for this application.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        {/* Search Input */}
        <DebouncedSearchInput
          className="w-full max-w-72"
          placeholder="Search by name..."
          setDebouncedSearch={setDebouncedSearch}
        />

        <div className="flex gap-2">
          <SimpleDataTableColumnsSelector
            allColumns={['Key', 'Method', 'Name', 'Description']}
            activeColumns={activeColumns}
            setActiveColumns={setActiveColumns}
          />

          {/* Status Filter Dropdown */}
          <Select
            value={selectedMethod}
            onValueChange={(value) =>
              setSelectedMethod(value as (typeof permissionMethods)[number])
            }
          >
            <SelectTrigger className="w-full sm:w-40 capitalize">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Methods</SelectItem>
              {permissionMethods?.map((item) => (
                <SelectItem key={item} value={item} className="capitalize">
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="border rounded-md p-3 space-y-4">
          {[...Array(6)].map((_, idx) => (
            <div key={idx} className="grid grid-cols-5 gap-4">
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
            </div>
          ))}
        </div>
      ) : (
        <SimpleDataTable
          data={permissionList}
          columns={getPermissionsTableColumns(
            {
              hasUpdatePermissionAccess,
              hasDeletePermissionAccess,
              onOpenUpdateDialog,
              onRemovePermission,
            },
            activeColumns
          )}
          keyField="_id"
        />
      )}
      <CreateOrUpdatePermissionDialog
        accessList={{
          update: hasUpdatePermissionAccess,
          create: hasCreatePermissionAccess,
        }}
        applicationId={applicationId}
        selectedPermission={selectedPermission}
        showDialog={showCreatePermissionDialog}
        onClose={() => {
          setShowCreatePermissionDialog(false);
          setSelectedPermission(undefined);
        }}
      />
      <RemoveConfirmationDialog />
    </div>
  );
};

export default PermissionsTab;
