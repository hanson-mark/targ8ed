'use client';
import { CopyField } from '@/components/common/copy-elements';
import CustomTabs from '@/components/common/custom-tabs';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { AlertTriangleIcon, ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import ApplicationsTab from './_components/applications-tab';
import InvitationsTab from './_components/invitations-tab';
import NotificationsTab from './_components/notifications-tab';
import OrgGeneralTab from './_components/org-general-tab';
import ThemeTab from './_components/theme-tab';
import UsersTab from './_components/users-tab';

const OrganizationDetailsPageForAdmin = () => {
  const params = useParams();

  const { currentOrgId } = useSubdomainStore();

  const [isDeleting, setIsDeleting] = useState(false);

  const {
    data: organization,
    isLoading: isOrganizationLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.organizations.index.readOrganizationDetails,
    {
      currentOrgId,
      inputs: { organizationId: params?.organizationId as Id<'organizations'> },
    }
  );

  if (isOrganizationLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  if (error || !organization?._id) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load organization data.'}
      </p>
    );
  }

  return (
    <div className="px-5">
      <Button variant={'ghost'} asChild>
        <Link
          href={`/${APPLICATION_KEYS.global}/organizations`}
          className="!pl-0"
        >
          <ArrowLeftIcon /> Back to organizations
        </Link>
      </Button>
      {organization?.isDeleting || isDeleting ? (
        <div className="max-w-4/5 xl:max-w-2xl mx-auto mt-10 flex justify-center">
          <div className="flex flex-col text-center items-center gap-3 rounded-xl border border-red-300 bg-red-100 px-5 py-4 text-sm font-medium text-red-800 shadow-md dark:border-red-800 dark:bg-red-950 dark:text-red-200">
            <AlertTriangleIcon className="h-5 w-5 text-red-600 dark:text-red-300" />
            <span>
              This organization and all of its related data are being
              permanently deleted.
            </span>
          </div>
        </div>
      ) : (
        <>
          <div className="space-y-2.5 mb-5">
            <h1 className="text-3xl font-medium">{organization?.name}</h1>
            <CopyField label="Organization ID" value={organization?._id} />
          </div>
          <CustomTabs
            defaultValue="general"
            tabItems={[
              {
                label: 'General',
                value: 'general',
                content: (
                  <OrgGeneralTab
                    organizationData={organization}
                    setIsDeleting={setIsDeleting}
                  />
                ),
              },
              {
                label: 'Applications',
                value: 'applications',
                content: <ApplicationsTab organizationData={organization} />,
              },
              {
                label: 'Users',
                value: 'users',
                content: <UsersTab organizationData={organization} />,
              },
              {
                label: 'Invitations',
                value: 'invitations',
                content: <InvitationsTab organizationData={organization} />,
              },
              {
                label: 'Theme',
                value: 'theme',
                content: <ThemeTab organizationData={organization} />,
              },
              {
                label: 'Notifications',
                value: 'notifications',
                content: <NotificationsTab organizationData={organization} />,
              },
              {
                label: 'Billing Profile',
                value: 'billing_profile',
                content: <div>Billing content goes here</div>,
              },
            ]}
          />
        </>
      )}
    </div>
  );
};

export default OrganizationDetailsPageForAdmin;
