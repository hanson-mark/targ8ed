import { z } from 'zod';

export const organizationDetailsFormZodSchema = z.object({
  _id: z.string().optional(),
  name: z.string().optional(),
  description: z.string().optional(),
  subdomain: z.string().optional(),
  status: z.boolean().optional(),
});
