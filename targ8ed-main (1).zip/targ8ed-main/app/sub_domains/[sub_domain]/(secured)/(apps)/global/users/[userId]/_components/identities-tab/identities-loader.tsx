import { Skeleton } from '@/components/ui/skeleton';

const IdentitiesLoader = () => {
  return (
    <div className="grid gap-3">
      {[...Array(3)].map((_, idx) => (
        <div key={idx} className="border p-4 rounded-xl grid md:flex gap-3">
          <div className="w-full md:w-auto">
            <Skeleton className="h-20 w-20 rounded-full mx-auto" />
          </div>

          <div className="flex-1 grid gap-2">
            <div className="flex justify-between items-center gap-3 flex-wrap">
              <Skeleton className="h-7 max-w-36 w-full col-span-1" />
              <div className="w-full max-w-52 grid gap-2 grid-cols-2">
                <Skeleton className="h-5 w-full col-span-1" />
                <Skeleton className="h-5 w-full col-span-1" />
              </div>
            </div>
            <div className="w-full lg:max-w-2/3 grid gap-2">
              <Skeleton className="h-5 w-full col-span-1" />
              <Skeleton className="h-5 w-full col-span-1" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default IdentitiesLoader;
