'use client';

import DebouncedSearchInput from '@/components/common/debounced-search-input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardHeader } from '@/components/ui/card';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexPaginatedQuery } from '@/hooks/convex/use-convex-paginated-query';
import useSubdomainStore from '@/stores/subdomainStore';
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  UserXIcon,
} from 'lucide-react';
import { Dispatch, SetStateAction } from 'react';
import SingleUserWithAddButton from './single-user-with-add-button';

interface IProps {
  disabled: boolean;
  organizationId: Id<'organizations'>;
  onUserAdd: (userId: Id<'users'>) => void;

  debouncedSearch: string;
  setDebouncedSearch: Dispatch<SetStateAction<string>>;
}

export default function AddFromList({
  disabled,
  organizationId,
  onUserAdd,

  debouncedSearch,
  setDebouncedSearch,
}: IProps) {
  const { currentOrgId } = useSubdomainStore();
  const {
    data: userList = [],
    isLoading,
    error,
    pagination,
  } = useConvexPaginatedQuery(
    api.functions.apps.global.users.orgUsers.readUsersToAddToOrganization,
    {
      currentOrgId,
      inputs: { organizationId, search: debouncedSearch },
    }
  );

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error.message}</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4 -mr-2">
      <DebouncedSearchInput
        className="max-w-72 min-w-56 mb-1 [&_input]:!text-xs"
        placeholder="Search user by name..."
        setDebouncedSearch={setDebouncedSearch}
      />

      {/* Loader vs Data */}
      <ScrollArea
        type="always"
        className="h-[300px] px-3 pt-2 pb-0 border rounded-xl"
      >
        <div className="h-full grid gap-4 pt-1 pb-3">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, idx) => (
              <Card
                key={idx}
                className="flex flex-col justify-between gap-2 p-2 animate-pulse"
              >
                <CardHeader className="w-full flex items-center justify-between gap-3 px-0">
                  <div className="flex items-center gap-3 flex-1">
                    <Skeleton className="h-14 w-14 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-3/5 rounded" />
                      <Skeleton className="h-3 w-4/5 rounded" />
                    </div>
                  </div>
                  <div className="shrink-0 w-[85px]">
                    <Skeleton className="h-9 w-full rounded" />
                  </div>
                </CardHeader>
              </Card>
            ))
          ) : (userList || [])?.length === 0 ? (
            <div className="h-[270px] flex flex-col justify-center items-center text-sm text-muted-foreground">
              <UserXIcon className="w-10 h-10 mb-3 text-muted-foreground" />
              <p>No users found.</p>
            </div>
          ) : (
            (userList || [])?.map((user) => (
              <SingleUserWithAddButton
                disabled={disabled}
                key={user._id}
                user={user}
                onUserAdd={onUserAdd}
              />
            ))
          )}
        </div>
        <ScrollBar orientation="vertical" />
      </ScrollArea>

      {/* Pagination */}
      <div className="flex items-center justify-end">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={pagination.handleFirstPage}
            disabled={!pagination.hasPrevPage || isLoading}
          >
            <ChevronsLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={pagination.handlePrevPage}
            disabled={!pagination.hasPrevPage || isLoading}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={pagination.handleNextPage}
            disabled={pagination.isLastPage || isLoading}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
