'use client';

import SortableTreeMenu from '@/components/common/sortable-tree-menu';
import { api } from '@/convex/_generated/api';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { IApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { ITreeItem } from '@/types/sortable-tree-menu';
import toast from 'react-hot-toast';

interface IProps {
  applicationData?: IApplication & { modules: Doc<'applicationModules'>[] };
}

const SidebarTab = ({ applicationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // Check permissions
  const { permissions } = useUserRolesStore();
  const hasUpdateSidebarAccess = checkPermission(permissions || [], [
    'updateSidebar',
  ]);

  const { mutate: updateSidebar, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.applications.index.updateSidebar
  );

  const onSave = async (items: ITreeItem[], onSuccess?: () => void) => {
    if (!hasUpdateSidebarAccess) return;
    if (items && !isUpdating) {
      const toastId = 'updating-sidebar';
      toast.loading('Updating application sidebar...', { id: toastId });

      updateSidebar({
        currentOrgId,
        inputs: {
          applicationId: applicationData?._id as Id<'applications'>,
          sidebar: items,
        },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(res?.message || 'Successfully updated sidebar', {
              id: toastId,
            });
            if (onSuccess) {
              onSuccess();
            }
          } else {
            toast.error(res?.message || 'Failed to update sidebar', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to update sidebar', {
            id: toastId,
          });
        });
    }
  };

  return (
    <div className="w-full flex gap-2">
      <div className="max-w-96 w-full mx-auto">
        <SortableTreeMenu
          title="Sidebar"
          hrefPrefix={`/${applicationData?.key}`}
          disabled={isUpdating}
          collapsible
          indicator
          removable
          initialItems={(applicationData?.sidebar || []) as ITreeItem[]}
          applicationData={applicationData}
          applicationModules={applicationData?.modules || []}
          hasUpdateSidebarAccess={hasUpdateSidebarAccess}
          onSave={onSave}
        />
      </div>
    </div>
  );
};

export default SidebarTab;
