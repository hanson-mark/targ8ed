import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import ProfileImageWithUploader from '@/components/common/profile-image-with-uploader';
import FormInput from '@/components/form/form-input';
import FormSwitch from '@/components/form/form-switch';
import FormTextarea from '@/components/form/form-textarea';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { IApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useInputConfirm from '@/hooks/use-input-confirm';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { SquarePenIcon } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { applicationDetailsFormZodSchema } from '../../_utils/form-helpers';
import UpdateApplicationNameDescriptionDialog from './update-application-name-description-dialog';

interface IProps {
  applicationData?: IApplication;
  setIsDeleting: Dispatch<SetStateAction<boolean>>;
}

const ApplicationGeneralTab = ({ applicationData, setIsDeleting }: IProps) => {
  const router = useRouter();

  const isRootApplication =
    ROOT_CONFIG.application.key === applicationData?.key;

  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Check permissions
  const hasUpdateApplicationStatusAccess = checkPermission(permissions || [], [
    'updateApplicationStatus',
  ]);
  const hasUpdateApplicationImageIdAccess = checkPermission(permissions || [], [
    'updateApplicationImageId',
  ]);
  const hasUpdateApplicationNameOrDescriptionAccess = checkPermission(
    permissions || [],
    ['updateApplicationNameOrDescription']
  );

  // States
  const [updateType, setUpdateType] = useState<'name' | 'description' | null>(
    null
  );

  // Dialog
  const [DeleteConfirmationDialog, onConfirmDelete] = useInputConfirm({
    title: 'Are you sure you want to delete this application?',
    description:
      'This action cannot be undone. All related data — including organization subscriptions and associated users — will be permanently deleted or unlinked.',

    icon: {
      name: 'Building',
      variant: 'error',
    },
    confirmButton: {
      label: 'Yes, Delete',
      variant: 'destructive',
    },
  });

  // [ Mutation ] - Application Status Change
  const { mutate: updateStatus, isLoading: loadingStatusChange } =
    useConvexMutation(
      api.functions.apps.global.applications.index.updateApplicationStatus
    );

  // [ Mutation ] - application's image upload
  const { isLoading: isImageUpdating, mutate: updateApplicationImage } =
    useConvexMutation(
      api.functions.apps.global.applications.index.updateApplicationImageId
    );

  // [ Mutation ] - Remove application
  const { mutate: removeApplication, isLoading: isRemovingApplication } =
    useConvexMutation(
      api.functions.apps.global.applications.index.deleteApplication
    );

  // React hook form
  const formMethods = useZodForm(applicationDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      description: '',
      key: '',
      isActive: false,
    },
  });

  // Handles global application isActive change
  const handleStatusChange = async (checked: boolean) => {
    if (!hasUpdateApplicationStatusAccess) return;

    formMethods.setValue('isActive', !checked);
    if (loadingStatusChange) return;

    const toastId = 'change-org-status';
    toast.loading('Changing application status...', { id: toastId });
    updateStatus({
      currentOrgId,
      inputs: {
        applicationId: applicationData?._id as Id<'applications'>,
        isActive: checked,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed application status.',
            {
              id: toastId,
            }
          );
        } else {
          toast.error(res?.message || 'Failed to change application status', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change application status', {
          id: toastId,
        });
      });
  };

  // Handles global application deletion
  const handleDeleteApplication = async () => {
    if (isRootApplication) return;
    if (isRemovingApplication) return;

    const requiredValue = applicationData?.key || '';
    const userInputKey = await onConfirmDelete({
      requiredValue,
    });

    if (!userInputKey || userInputKey !== requiredValue) return;

    const toastId = 'remove-org';
    toast.loading('Deleting application...', { id: toastId });
    setIsDeleting(true);

    removeApplication({
      currentOrgId,
      inputs: { applicationId: applicationData?._id as Id<'applications'> },
    })
      .then((response) => {
        if (response?.success) {
          router.push(`/${APPLICATION_KEYS.global}/applications`);
          toast.success(
            response?.message || 'Successfully deleted the application',
            { id: toastId }
          );
        } else {
          setIsDeleting(false);
          toast.error(
            response?.message || 'Failed to delete the root application',
            { id: toastId }
          );
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to deleted the application', {
          id: toastId,
        });
      });
  };

  // Updating form based on application data change
  useEffect(() => {
    formMethods.reset({
      _id: applicationData?._id,
      name: applicationData?.name,
      description: applicationData?.description,
      key: applicationData?.key,
      isActive: applicationData?.isActive,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [applicationData]);

  return (
    <div className="space-y-4 mb-10">
      <FormProvider {...formMethods}>
        <form
          className="space-y-4 mt-8"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          <FormSwitch
            disabled={loadingStatusChange || !hasUpdateApplicationStatusAccess}
            name="isActive"
            size="md"
            label={'Active'}
            labels={{
              checked: 'Active',
              unchecked: 'Inactive',
            }}
            description="Controls the application status."
            onCheckedChange={handleStatusChange}
          />
          {/* Application logo  */}
          <ProfileImageWithUploader
            showUploadButton={hasUpdateApplicationImageIdAccess}
            imageURL={getConvexImageURL(
              applicationData?.imageId as Id<'_storage'>
            )}
            imageAlt={applicationData?.name || ''}
            isImageIdUpdating={isImageUpdating}
            onUpdateImageId={(storageId) =>
              updateApplicationImage({
                currentOrgId,
                inputs: {
                  applicationId: applicationData?._id as Id<'applications'>,
                  imageId: storageId,
                },
              })
            }
            fileUploaderProps={{
              maxFileSizeInKB: 100,
              allowedFileTypes: [
                'image/x-icon',
                'image/vnd.microsoft.icon',
                'image/png',
              ],
              allowedImageDimension: {
                type: 'ratio',
                width: 1,
                height: 1,
              },
            }}
          />
          <FormInput disabled name="key" label="Application Key" />
          <div className="flex gap-2 items-end">
            <FormInput disabled name="name" label="Name" />{' '}
            {hasUpdateApplicationNameOrDescriptionAccess && (
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
                tooltipContent="Update Name"
                onClick={() => setUpdateType('name')}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            )}
          </div>
          <div className="flex gap-2 items-start">
            <FormTextarea
              disabled
              name="description"
              label="Description"
              classNames={{
                input: 'resize-none',
              }}
            />{' '}
            {hasUpdateApplicationNameOrDescriptionAccess && (
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80 mt-4.5"
                tooltipContent="Update Description"
                onClick={() => setUpdateType('description')}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            )}
          </div>

          {!isRootApplication && (
            <PermissionGuard fnNames={['deleteApplication']}>
              <Separator className="mt-5 mb-4" />
              <div className="">
                <h3 className="text-sm font-semibold text-red-600 mb-3">
                  Danger Zone
                </h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-red-700">
                      Delete Application
                    </p>
                    <p className="text-xs text-red-600 mt-1">
                      Once deleted, this action cannot be undone.
                    </p>
                  </div>
                  <Button
                    onClick={handleDeleteApplication}
                    className="text-white bg-red-600 hover:bg-red-700 transition px-4 py-2 text-sm font-semibold rounded-md"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </PermissionGuard>
          )}
        </form>
      </FormProvider>

      <UpdateApplicationNameDescriptionDialog
        applicationData={applicationData}
        showDialog={hasUpdateApplicationNameOrDescriptionAccess && !!updateType}
        setShowDialog={(state) => !state && setUpdateType(null)}
        updateType={updateType}
      />
      <DeleteConfirmationDialog />
    </div>
  );
};

export default ApplicationGeneralTab;
