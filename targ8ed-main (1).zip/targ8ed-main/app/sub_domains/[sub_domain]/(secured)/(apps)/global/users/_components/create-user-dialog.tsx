import { createClerkUser } from '@/actions/auth/user';
import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { emailZodSchema, nameZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { IHonoResponse } from '@/types/hono';
import { useRouter } from 'next/navigation';
import { Dispatch, SetStateAction, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  showCreateUserDialog: boolean;
  setShowCreateUserDialog: Dispatch<SetStateAction<boolean>>;
}

const CreateUserDialog = ({
  showCreateUserDialog,
  setShowCreateUserDialog,
}: IProps) => {
  const router = useRouter();

  // Get user config from subdomain store
  const { currentOrgId } = useSubdomainStore();

  const [isCreatingClerkUser, setIsCreatingClerkUser] = useState(false);
  const { mutate: createUser, isLoading: isCreatingConvexUser } =
    useConvexMutation(api.functions.apps.global.users.index.createUser);

  const isCreating = isCreatingClerkUser || isCreatingConvexUser;

  // Validation schema
  const validationSchema = z.object({
    name: nameZodSchema,
    email: emailZodSchema,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { name: '', email: '' },
  });

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowCreateUserDialog(state);
  };

  // Submit handler
  const onSubmit = async (values: z.infer<typeof validationSchema>) => {
    if (isCreating) return;

    const toastId = 'create-user';
    toast.loading('Adding user in clerk...', { id: toastId });

    setIsCreatingClerkUser(true);
    const clerkUserResponse = await createClerkUser({
      email: values?.email,
      name: values?.name,
    });
    const clerkUser = clerkUserResponse as IHonoResponse<{
      id: string;
      imageUrl: string;
    }>;
    setIsCreatingClerkUser(false);

    if (!clerkUser?.success || !clerkUser?.data) {
      toast.error(clerkUser?.message, { id: toastId });
      return;
    }

    toast.loading('Adding user to the list...', { id: toastId });
    createUser({ currentOrgId, inputs: values })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || 'User added successfully.', {
            id: toastId,
          });

          router.push(`/${APPLICATION_KEYS.global}/users/${res?.data}`);
          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to add the user', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to add the user', {
          id: toastId,
        });
      });
  };

  return (
    <CustomDialog
      isOpen={showCreateUserDialog}
      onOpenChange={onOpenChange}
      title="Add User"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={isCreating}
              name="name"
              label="Name"
              placeholder="Enter your name"
            />
            <FormInput
              disabled={isCreating}
              type="email"
              name="email"
              label="Email"
              placeholder="Enter your email"
            />
          </div>
          <DialogFooter>
            <Button disabled={isCreating} type="submit">
              {isCreating ? 'Adding user...' : 'Add User'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateUserDialog;
