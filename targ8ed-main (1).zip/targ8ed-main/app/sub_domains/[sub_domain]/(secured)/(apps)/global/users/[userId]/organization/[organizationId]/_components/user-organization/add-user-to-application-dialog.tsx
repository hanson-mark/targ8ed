import CustomDialog from '@/components/common/custom-dialog';
import Loader from '@/components/common/loaders/loader';
import FormDropdown from '@/components/form/form-dropdown';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  userId: Id<'users'>;
  organizationId: Id<'organizations'>;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const AddUserToApplicationDialog = ({
  userId,
  organizationId,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // Check permissions
  const { permissions } = useUserRolesStore();
  const hasCreateApplicationAccessForUserAccess = checkPermission(
    permissions || [],
    ['createApplicationAccessForUser']
  );

  // Queries
  const {
    data: applicationsRes,
    error,
    isLoading: isApplicationsLoading,
  } = useConvexQuery(
    api.functions.apps.global.applications.userApplications
      .readAvailableApplicationsToAddUser,
    {
      currentOrgId,
      inputs: {
        userId,
        organizationId: organizationId as Id<'organizations'>,
      },
    }
  );

  // Mutations
  const { mutate: addUserToApplication, isLoading: isAdding } =
    useConvexMutation(
      api.functions.apps.global.applications.userApplications
        .createApplicationAccessForUser
    );

  // Validation schema
  const validationSchema = z.object({
    applicationId: z
      .string({ required_error: 'Application is required.' })
      .min(1, 'Application is required.') as unknown as z.ZodType<
      Id<'applications'>
    >,
    roleId: z
      .string({ required_error: 'Role is required.' })
      .min(1, 'Role is required.') as unknown as z.ZodType<Id<'roles'>>,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { applicationId: '', roleId: '' },
  });

  // Form Values
  const applicationId = formMethods.watch('applicationId');
  const selectedApplication = (applicationsRes || [])?.find(
    (item) => item?.applicationId === applicationId
  );

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isAdding || !hasCreateApplicationAccessForUserAccess) return;

    const toastId = 'connecting-user-to-application';
    toast.loading('Connecting to a application...', { id: toastId });
    addUserToApplication({
      currentOrgId,
      inputs: {
        roleId: values?.roleId,
        userId: userId as Id<'users'>,
        organizationId: organizationId as Id<'organizations'>,
        applicationId: values?.applicationId as Id<'applications'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully connected the user with application',
            { id: toastId }
          );

          onOpenChange(false);
        } else {
          toast.error(
            res?.message || 'Failed to connect user with application',
            {
              id: toastId,
            }
          );
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Failed to connect user with application',
          {
            id: toastId,
          }
        );
      });
  };

  // Reset form when dialog opens
  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Connect User to Application"
      description="Select an application to connect with the user. They will gain access to the application."
    >
      {isApplicationsLoading ? (
        <Loader
          variant="minimal"
          message="Loading available applications for the user..."
        />
      ) : (applicationsRes || [])?.length === 0 ? (
        <div className="py-6 text-center text-muted-foreground">
          {error?.message
            ? `⚠️ ${error?.message}`
            : '🎉 No applications in the organization. Or, the user is already connected to all available applications in the organization.'}
        </div>
      ) : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormDropdown
                disabled={isAdding || isApplicationsLoading}
                name="applicationId"
                label="Select Application"
                placeholder="Select an application..."
                options={(applicationsRes || [])?.map((application) => ({
                  value: application?.applicationId || '',
                  label: application?.name || '',
                }))}
              />

              {applicationId && selectedApplication ? (
                <FormDropdown
                  disabled={isAdding || isApplicationsLoading}
                  name="roleId"
                  label="Select Role"
                  placeholder="Select a role..."
                  noOptionsMessage="No roles found"
                  options={(selectedApplication?.roles || [])?.map((role) => ({
                    value: role?._id || '',
                    label: role?.name || '',
                  }))}
                />
              ) : null}
            </div>
            <DialogFooter>
              <Button
                disabled={
                  !hasCreateApplicationAccessForUserAccess ||
                  isAdding ||
                  !applicationId ||
                  !selectedApplication
                }
                type="submit"
              >
                {isAdding ? 'Connecting...' : 'Connect'}
              </Button>
            </DialogFooter>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default AddUserToApplicationDialog;
