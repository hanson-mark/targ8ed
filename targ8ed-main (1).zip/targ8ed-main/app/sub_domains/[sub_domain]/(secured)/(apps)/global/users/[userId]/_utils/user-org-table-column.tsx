import { DataTableActionDropdown } from '@/components/common/data-table';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { IOrgUser } from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { ILucideIconName } from '@/types/dashboard-layout';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import Link from 'next/link';

export const getUserOrgTableColumns = (args: {
  hasRemoveOrgAccess: boolean;
  onRemoveUserOrg: (rowData: IOrgUser) => void;
}) => {
  const getMenuItems = (rowData: IOrgUser): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'details',
        icon: 'SquareMenuIcon',
        label: 'View Details',
        type: 'link',
        href: `/${APPLICATION_KEYS.global}/users/${rowData?.userId}/organization/${rowData?.organizationId}`,
      },
      {
        id: 'go-to-organization',
        icon: 'SquareMenuIcon',
        label: 'Go to organization',
        type: 'link',
        href: `/${APPLICATION_KEYS.global}/organizations/${rowData?.organizationId}`,
      },
      ...(args.hasRemoveOrgAccess
        ? [
            {
              id: 'delete',
              icon: 'TrashIcon' as ILucideIconName,
              label: 'Remove',
              type: 'button' as const,
              onClick: () => {
                args.onRemoveUserOrg(rowData);
              },
            },
          ]
        : []),
    ];
  };

  const columns: ISimpleDataTableColumn<IOrgUser>[] = [
    {
      header: 'Organization',
      cell: (row) => (
        <Link
          href={`/${APPLICATION_KEYS.global}/users/${row?.userId}/organization/${row?.organizationId}`}
          className="text-sm flex items-center gap-2 max-w-44"
        >
          <ProfileImage
            imageURL={getConvexImageURL(
              row?.organization?.imageId as Id<'_storage'>
            )}
            iconSize={7}
            iconType="application"
          />

          <span className="max-w-full truncate">
            {row?.organization?.name as string}
          </span>
        </Link>
      ),
    },
    {
      header: 'Is Org Admin?',
      cell: (row) => (row?.isOrgAdmin ? 'YES' : 'NO'),
    },
    {
      header: 'Status',
      cell: (row) => (
        <div className={''}>
          <StatusBadge status={row?.status ? 'active' : 'inactive'} />
        </div>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};
