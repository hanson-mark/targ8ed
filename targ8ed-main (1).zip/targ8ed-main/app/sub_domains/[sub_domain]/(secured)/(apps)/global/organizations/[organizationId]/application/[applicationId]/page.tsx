'use client';
import CustomTabs from '@/components/common/custom-tabs';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import OrgApplicationGeneralTab from './_components/org-application-general-tab';
import OrgApplicationName from './_components/org-application-name';

const OrgApplicationPage = () => {
  // Getting params, applicationId will be there
  const params = useParams();

  const { currentOrgId } = useSubdomainStore();

  // Application data fetching
  const {
    data: applicationResponse,
    isLoading: isApplicationLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.orgApplications.readOrgApplication,
    {
      currentOrgId,
      inputs: {
        organizationId: params?.organizationId as Id<'organizations'>,
        applicationId: params?.applicationId as Id<'applications'>,
      },
    }
  );

  // Showing loader
  if (isApplicationLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  // Showing errors if happens
  if (error || !applicationResponse?._id) {
    return (
      <p className="text-center text-destructive py-10">
        {error?.message || 'Failed to load application data.'}
      </p>
    );
  }

  const backLink = `/${APPLICATION_KEYS.global}/organizations/${applicationResponse?.organizationId}?tab=applications`;
  return (
    <div>
      <div className="space-y-2.5 mb-5">
        <Button variant={'ghost'} asChild>
          <Link href={backLink} className="!pl-0">
            <ArrowLeftIcon /> Back to organization
          </Link>
        </Button>
        <OrgApplicationName
          backLink={backLink}
          applicationData={applicationResponse}
        />
        <p className="text-sm">Manage {"Organization's"} Application</p>
      </div>
      <CustomTabs
        defaultValue="general"
        tabItems={[
          {
            label: 'General',
            value: 'general',
            content: (
              <OrgApplicationGeneralTab applicationData={applicationResponse} />
            ),
          },
        ]}
      />
    </div>
  );
};

export default OrgApplicationPage;
