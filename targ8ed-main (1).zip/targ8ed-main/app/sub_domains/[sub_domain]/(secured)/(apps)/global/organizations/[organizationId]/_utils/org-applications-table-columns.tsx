import { DataTableActionDropdown } from '@/components/common/data-table';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { IOrgApplication } from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { ILucideIconName } from '@/types/dashboard-layout';
import {
  ISimpleDataTableColumn,
  ITableActionDropdownMenuItems,
} from '@/types/data-table';
import Link from 'next/link';

interface IParam {
  hasRemoveApplicationAccess: boolean;
  onRemoveApplication: (rowData: IOrgApplication) => void;
}

export const getOrgApplicationsTableColumns = ({
  hasRemoveApplicationAccess,
  onRemoveApplication,
}: IParam) => {
  const getMenuItems = (
    rowData: IOrgApplication
  ): ITableActionDropdownMenuItems[] => {
    return [
      {
        id: 'details',
        icon: 'SquareMenuIcon',
        label: 'View Details',
        type: 'link',
        href: `/${APPLICATION_KEYS.global}/organizations/${rowData?.organizationId}/application/${rowData?.applicationId}`,
      },
      {
        id: 'go-to-application',
        icon: 'SquareMenuIcon',
        label: 'Go to application',
        type: 'link',
        href: `/${APPLICATION_KEYS.global}/applications/${rowData?.applicationId}`,
      },
      ...(hasRemoveApplicationAccess
        ? [
            {
              id: 'delete',
              icon: 'TrashIcon' as ILucideIconName,
              label: 'Remove',
              type: 'button' as const,
              onClick: () => {
                onRemoveApplication(rowData);
              },
            },
          ]
        : []),
    ];
  };

  const columns: ISimpleDataTableColumn<IOrgApplication>[] = [
    {
      header: 'Application',
      cell: (row) => (
        <Link
          href={`/${APPLICATION_KEYS.global}/organizations/${row?.organizationId}/application/${row?.applicationId}`}
          className="text-sm flex items-center gap-2 max-w-44"
        >
          <ProfileImage
            imageURL={getConvexImageURL(
              row?.application?.imageId as Id<'_storage'>
            )}
            iconSize={7}
            iconType="application"
          />
          <span className="max-w-full truncate"> {row?.name}</span>
        </Link>
      ),
    },
    {
      header: 'Status',
      cell: (row) => (
        <div className={''}>
          <StatusBadge status={row?.isActive ? 'active' : 'inactive'} />
        </div>
      ),
    },
    {
      header: 'Actions',
      className: 'w-20',
      cell: (rowData) => (
        <DataTableActionDropdown items={getMenuItems(rowData)} />
      ),
    },
  ];

  return columns;
};
