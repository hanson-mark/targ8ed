import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import FormInput from '@/components/form/form-input';
import FormSwitch from '@/components/form/form-switch';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { IOrganization } from '@/convex/types/convex-types';
import useZodForm from '@/hooks/use-zod-form';
import { SquarePenIcon } from 'lucide-react';
import { useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import { z } from 'zod';

interface IProps {
  organizationData?: IOrganization;
}

const NotificationsTab = ({ organizationData }: IProps) => {
  const validationSchema = z.object({
    isCustomEmail: z.boolean().optional(),
    senderName: z.string().optional(),
    senderEmail: z.string().optional(),
    replyToEmail: z.string().optional(),
  });

  const formMethods = useZodForm(validationSchema, {
    defaultValues: {
      isCustomEmail: false,
      senderName: '',
      senderEmail: '',
      replyToEmail: '',
    },
  });

  // Optional: if isCustomEmail switch is meant to trigger organization status update
  const onCustomEmailToggle = async () =>
    // checked: boolean
    {};

  useEffect(() => {
    if (!organizationData) return;
    // Populate sender fields only
    formMethods
      .reset
      // {
      // senderName: organizationData.senderName || '',
      // senderEmail: organizationData.senderEmail || '',
      // replyToEmail: organizationData.replyToEmail || '',
      // isCustomEmail: !!organizationData.isCustomEmail,
      // }
      ();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationData]);

  const isCustomEmail = formMethods.watch().isCustomEmail;

  return (
    <div className="space-y-4 mb-10">
      <FormProvider {...formMethods}>
        <form
          className="space-y-4 mt-4"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          <FormSwitch
            name="isCustomEmail"
            size="md"
            label="Custom Email"
            labels={{
              checked: 'Custom Email',
              unchecked: 'Default Email',
            }}
            description="Transactional emails configuration"
            onCheckedChange={onCustomEmailToggle}
          />

          <FormInput
            disabled={!isCustomEmail}
            name="senderName"
            label="Sender Name"
            placeholder={`${ROOT_CONFIG.site.name} Invitations`}
          />

          <div className="flex gap-2 items-end">
            <FormInput
              disabled
              name="senderEmail"
              label="Sender Email"
              placeholder={`invitations@${process.env.NEXT_PUBLIC_RESEND_DOMAIN}`}
            />
            <ButtonWithTooltip
              variant="ghost"
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
              tooltipContent="Update Sender Email"
              // onClick={() => setUpdateType('senderEmail')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>

          <div className="flex gap-2 items-end">
            <FormInput
              disabled
              name="replyToEmail"
              label="Reply To Email"
              placeholder={`invitations@${process.env.NEXT_PUBLIC_RESEND_DOMAIN}`}
            />
            <ButtonWithTooltip
              variant="ghost"
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
              tooltipContent="Update Reply-to Email"
              // onClick={() => setUpdateType('replyToEmail')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>
        </form>
      </FormProvider>
    </div>
  );
};

export default NotificationsTab;
