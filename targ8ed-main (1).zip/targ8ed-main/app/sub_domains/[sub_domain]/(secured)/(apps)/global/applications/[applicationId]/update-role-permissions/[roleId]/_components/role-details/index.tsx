'use client';

import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import ApplicationName from './applcation-name';
import UpdateRolePermissions from './update-role-permissions';

interface IProps {
  roleId: Id<'roles'>;
  applicationId: Id<'applications'>;
}

const RoleDetails = ({ roleId, applicationId }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const {
    isLoading: isRoleLoading,
    data: roleDetails,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.roles.readApplicationRoleDetails,
    {
      currentOrgId,
      inputs: { roleId, applicationId },
    }
  );

  // Showing loader
  if (isRoleLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  // Showing errors if happens
  if (error || !roleDetails?._id) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load role data.'}
      </p>
    );
  }

  const backLink = `/${APPLICATION_KEYS.global}/applications/${roleDetails?.application?._id}/?tab=roles`;

  return (
    <div>
      <div className="space-y-2.5 mb-5">
        <Button variant={'ghost'} asChild>
          <Link href={backLink} className="!pl-0">
            <ArrowLeftIcon /> Back to roles tab
          </Link>
        </Button>
        <ApplicationName
          application={roleDetails?.application}
          role={roleDetails}
          backLink={backLink}
        />
        {roleDetails?.isAdminRole ? (
          <h3 className="text-sm">
            <span className="text-primary">{roleDetails?.name}</span> is an
            admin role of the application. All the permissions of the
            application are automatically assigned to it.{' '}
            {"It's permissions can't changed."}
          </h3>
        ) : (
          <h3 className="text-sm font-medium">
            Update permissions of{' '}
            <span className="text-primary">{roleDetails?.name}</span> role
          </h3>
        )}
      </div>

      <UpdateRolePermissions backLink={backLink} roleDetails={roleDetails} />
    </div>
  );
};

export default RoleDetails;
