import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { IUser } from '@/convex/types/convex-types';
import { nameZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
interface IProps {
  userData?: IUser;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const UpdateUserNameDialog = ({
  userData,
  showDialog,
  setShowDialog,
}: IProps) => {
  // Get user config from subdomain store
  const { currentOrgId } = useSubdomainStore();

  // [ Mutation ] Update user name
  const { mutate: updateName, isLoading: isChanging } = useConvexMutation(
    api.functions.apps.global.users.index.updateUserName
  );

  // Validation schema
  const validationSchema = z.object({
    name: nameZodSchema,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { name: '' },
  });

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isChanging || !userData?._id) return;

    const toastId = 'update-user-name';
    toast.loading('Updating name...', { id: toastId });
    updateName({
      currentOrgId,
      inputs: { userId: userData?._id, name: values?.name },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || 'Name updated successfully.', {
            id: toastId,
          });

          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to update name', { id: toastId });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to update name', {
          id: toastId,
        });
      });
  };

  useEffect(() => {
    formMethods.reset({
      name: userData?.name,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Update Name"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={isChanging}
              name="name"
              label="Name"
              placeholder="Enter your name"
            />
          </div>
          <DialogFooter>
            <Button disabled={isChanging} type="submit">
              {isChanging ? 'Updating Name...' : 'Update Name'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default UpdateUserNameDialog;
