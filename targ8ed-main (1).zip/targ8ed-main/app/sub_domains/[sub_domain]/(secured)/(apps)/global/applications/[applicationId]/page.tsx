'use client';
import { CopyField } from '@/components/common/copy-elements';
import CustomTabs from '@/components/common/custom-tabs';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { AlertTriangleIcon, ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import ApplicationGeneralTab from './_components/general-tab';
import ModulesTab from './_components/modules-tab';
import OrganizationTab from './_components/organization-tab';
import PermissionsTab from './_components/permissions-tab';
import RolesTab from './_components/roles-tab';
import SidebarTab from './_components/sidebar-tab';

const ApplicationDetailsPageForAdmin = () => {
  // Getting params, applicationId will be there
  const params = useParams();

  const { currentOrgId } = useSubdomainStore();

  const [isDeleting, setIsDeleting] = useState(false);

  // Application data fetching
  const {
    data: applicationResponse,
    isLoading: isApplicationLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.index.readApplicationDetails,
    {
      currentOrgId,
      inputs: { applicationId: params?.applicationId as Id<'applications'> },
    }
  );

  // Showing loader
  if (isApplicationLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  // Showing errors if happens
  if (error || !applicationResponse?._id) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load application data.'}
      </p>
    );
  }

  return (
    <div className="px-5">
      <Button variant={'ghost'} asChild>
        <Link
          href={`/${APPLICATION_KEYS.global}/applications`}
          className="!pl-0"
        >
          <ArrowLeftIcon /> Back to applications
        </Link>
      </Button>
      {applicationResponse?.isDeleting || isDeleting ? (
        <div className="max-w-4/5 xl:max-w-2xl mx-auto mt-10 flex justify-center">
          <div className="flex flex-col text-center items-center gap-3 rounded-xl border border-red-300 bg-red-100 px-5 py-4 text-sm font-medium text-red-800 shadow-md dark:border-red-800 dark:bg-red-950 dark:text-red-200">
            <AlertTriangleIcon className="h-5 w-5 text-red-600 dark:text-red-300" />
            <span>
              This application and all of its related data are being permanently
              deleted.
            </span>
          </div>
        </div>
      ) : (
        <>
          <div className="space-y-2.5 mb-5">
            <h1 className="text-3xl font-medium">
              {applicationResponse?.name}
            </h1>
            <CopyField
              label="Application ID"
              value={applicationResponse?._id}
            />
          </div>
          <CustomTabs
            defaultValue="general"
            tabItems={[
              {
                label: 'General',
                value: 'general',
                content: (
                  <ApplicationGeneralTab
                    applicationData={applicationResponse}
                    setIsDeleting={setIsDeleting}
                  />
                ),
              },
              {
                label: 'Organizations',
                value: 'organizations',
                content: (
                  <OrganizationTab applicationId={applicationResponse?._id} />
                ),
              },
              {
                label: 'Modules',
                value: 'modules',
                content: <ModulesTab applicationData={applicationResponse} />,
              },
              {
                label: 'Sidebar',
                value: 'sidebar',
                content: <SidebarTab applicationData={applicationResponse} />,
              },
              {
                label: 'Permissions',
                value: 'permissions',
                content: (
                  <PermissionsTab applicationId={applicationResponse?._id} />
                ),
              },
              {
                label: 'Roles',
                value: 'roles',
                content: <RolesTab applicationId={applicationResponse?._id} />,
              },
            ]}
          />
        </>
      )}
    </div>
  );
};

export default ApplicationDetailsPageForAdmin;
