'use client';

import { SimpleDataTable } from '@/components/common/data-table';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { LinkIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getApplicationOrganizationTableColumns } from '../../_utils/table-columns';
import CreateOrganizationToApplicationDialog from './create-organization-to-application-dialog';

interface IProps {
  applicationId: string;
}

const OrganizationTab = ({ applicationId }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  const hasRemoveApplicationAccess = checkPermission(permissions, [
    'deleteOrgApplication',
  ]);

  const [showCreateOrgModal, setShowCreateOrgModal] = useState(false);

  const {
    data: orgList = [],
    isLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.orgApplications
      .readOrgListByApplicationId,
    {
      currentOrgId,
      inputs: { applicationId: applicationId as Id<'applications'> },
    }
  );

  // [ Mutation ] - Application Remove
  const { mutate: removeOrgApplication, isLoading: isRemovingApplication } =
    useConvexMutation(
      api.functions.apps.global.applications.orgApplications
        .deleteOrgApplication
    );

  // [ Dialog ] - To take confirmation for removing application
  const [OrgApplicationRemoveConfirmDialog, confirmOrgApplicationRemove] =
    useConfirm();

  const onRemoveOrgFromApplication = async (rowData: IOrgApplication) => {
    console.log({ rowData });

    if (isRemovingApplication || !hasRemoveApplicationAccess) return;

    const isConfirmed = await confirmOrgApplicationRemove({
      ...DIALOG_CONTENT.RemoveOrgApplication,
      title: 'Remove This Organization From The Application?',
    });
    if (!isConfirmed) return;

    const toastId = 'remove-user-application';
    toast.loading('Removing application...', { id: toastId });

    removeOrgApplication({
      currentOrgId,
      inputs: {
        applicationId: rowData?.applicationId,
        organizationId: rowData?.organizationId as Id<'organizations'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'Application removed successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to delete application.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while deleting application.',
          { id: toastId }
        );
      });
  };

  if (isLoading) return <ListWithActionLoader />;

  if (error || !orgList) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️{' '}
        {error?.message || 'Failed to load organizations for this application.'}
      </p>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Organizations</h2>
          <Button
            onClick={() => {
              setShowCreateOrgModal(true);
            }}
          >
            <LinkIcon /> Organization
          </Button>
        </div>
        <p className="font-light text-sm">
          List of organizations where the application has access
        </p>
      </div>

      <SimpleDataTable
        data={orgList}
        columns={getApplicationOrganizationTableColumns({
          hasRemoveApplicationAccess,
          onRemoveOrgFromApplication,
        })}
        keyField="_id"
      />
      <CreateOrganizationToApplicationDialog
        applicationId={applicationId as Id<'applications'>}
        showDialog={showCreateOrgModal}
        setShowDialog={setShowCreateOrgModal}
      />
      <OrgApplicationRemoveConfirmDialog />
    </div>
  );
};

export default OrganizationTab;
