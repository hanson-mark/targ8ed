'use client';

import { SimpleDataTable } from '@/components/common/data-table';
import ListWithActionLoader from '@/components/common/loaders/list-with-action-loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrganization, IOrgUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { LinkIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getOrgUsersTableColumns } from '../../_utils/org-users-table-columns';
import CreateUserAccessToOrganizationDialog from './create-user-access-to-organization-dialog';

interface IProps {
  organizationData: IOrganization;
}

const UsersTab = ({ organizationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasCreateOrgUserAccess = checkPermission(permissions, [
    'createOrgUser',
  ]);
  const hasRemoveOrgUserAccess = checkPermission(permissions, [
    'deleteUserFromOrg',
  ]);

  const [showCreateUserAccessToOrgDialog, setShowCreateUserAccessToOrgDialog] =
    useState(false);

  // Data fetching
  const {
    data: userListResponse,
    isLoading,
    error,
  } = useConvexQuery(api.functions.apps.global.users.orgUsers.readOrgUsers, {
    currentOrgId,
    inputs: { organizationId: organizationData._id as Id<'organizations'> },
  });

  // [ Mutation ] - User Remove
  const { mutate: removeUserFromOrg, isLoading: loadingUserRemoval } =
    useConvexMutation(
      api.functions.apps.global.users.orgUsers.deleteUserFromOrg
    );

  // [ Dialog ] - To take confirmation for removing user
  const [UserRemoveConfirmDialog, confirmUserRemove] = useConfirm();

  // Handles removing user from organization
  const onRemoveUser = async (rowData: IOrgUser) => {
    if (loadingUserRemoval || !hasRemoveOrgUserAccess) return;

    const isConfirmed = await confirmUserRemove(DIALOG_CONTENT.RemoveOrgUser);
    if (!isConfirmed) return;

    const toastId = 'remove-org-user';
    toast.loading('Removing user...', { id: toastId });

    removeUserFromOrg({
      currentOrgId,
      inputs: {
        userId: rowData?.globalUser?._id as Id<'users'>,
        organizationId: organizationData?._id as Id<'organizations'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'User removed successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to remove user.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while removing user.',
          { id: toastId }
        );
      });
  };

  if (isLoading) return <ListWithActionLoader />;
  if (error || !userListResponse) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load users for this organization.'}
      </p>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Users</h2>{' '}
          {hasCreateOrgUserAccess && (
            <Button onClick={() => setShowCreateUserAccessToOrgDialog(true)}>
              <LinkIcon /> User
            </Button>
          )}
        </div>
        <p className="font-light text-sm">
          List of users who has access the organization
        </p>
      </div>

      <SimpleDataTable
        data={userListResponse}
        columns={getOrgUsersTableColumns({
          hasRemoveOrgUserAccess,
          onRemoveUser,
          // onChangeRoleDialogOpen,
        })}
        keyField="_id"
      />

      <UserRemoveConfirmDialog />

      <CreateUserAccessToOrganizationDialog
        showDialog={hasCreateOrgUserAccess && showCreateUserAccessToOrgDialog}
        setShowDialog={setShowCreateUserAccessToOrgDialog}
        organizationData={organizationData}
      />
    </div>
  );
};

export default UsersTab;
