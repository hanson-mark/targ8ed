'use client';
import { CopyField } from '@/components/common/copy-elements';
import CustomTabs from '@/components/common/custom-tabs';
import { Button } from '@/components/ui/button';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { IUser } from '@/convex/types/convex-types';
import { AlertTriangleIcon, ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import GeneralTab from '../general-tab';
import IdentitiesTab from '../identities-tab';
import OrganizationsTab from '../organizations-tab';

interface IProps {
  userData: IUser;
}

const UserDetails = ({ userData }: IProps) => {
  const [isDeleting, setIsDeleting] = useState(false);
  return (
    <div className="px-5">
      <Button variant={'ghost'} asChild>
        <Link href={`/${APPLICATION_KEYS.global}/users`} className="!pl-0">
          <ArrowLeftIcon /> Back to users
        </Link>
      </Button>
      {userData?.isDeleting || isDeleting ? (
        <div className="max-w-4/5 xl:max-w-2xl mx-auto mt-10 flex justify-center">
          <div className="flex flex-col text-center items-center gap-3 rounded-xl border border-red-300 bg-red-100 px-5 py-4 text-sm font-medium text-red-800 shadow-md dark:border-red-800 dark:bg-red-950 dark:text-red-200">
            <AlertTriangleIcon className="h-5 w-5 text-red-600 dark:text-red-300" />
            <span>
              This user and all of its related data are being permanently
              deleted.
            </span>
          </div>
        </div>
      ) : (
        <>
          {' '}
          <div className="space-y-2.5 mb-5">
            <h1 className="text-3xl font-medium">{userData?.name}</h1>
            <CopyField label="User ID" value={userData?._id} />
          </div>
          <CustomTabs
            defaultValue="general"
            tabItems={[
              {
                label: 'General',
                value: 'general',
                content: (
                  <GeneralTab
                    userData={userData}
                    setIsDeleting={setIsDeleting}
                  />
                ),
              },
              {
                label: 'Organizations',
                value: 'organizations',
                content: <OrganizationsTab userData={userData} />,
              },
              {
                label: 'Identities',
                value: 'identities',
                content: <IdentitiesTab email={userData?.email} />,
              },
            ]}
          />
        </>
      )}
    </div>
  );
};

export default UserDetails;
