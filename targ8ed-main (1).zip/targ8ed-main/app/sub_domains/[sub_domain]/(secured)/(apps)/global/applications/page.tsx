'use client';
import {
  DataTable,
  DataTableColumnsSelector,
  DataTableConvexPagination,
  DataTableSearchableInput,
} from '@/components/common/data-table';
import useDataTable from '@/components/common/data-table/hooks/use-data-table';
import DataTableLoader from '@/components/common/loaders/data-table-loader';
import Loader from '@/components/common/loaders/loader';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexPaginatedQuery } from '@/hooks/convex/use-convex-paginated-query';
import { downloadCSVFromObjects } from '@/lib/data-formatters/csv-file';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { FileIcon, PlusIcon } from 'lucide-react';
import { useState } from 'react';
import CreateApplicationDialog from './_components/create-application-dialog';
import { applicationTableColumns } from './_utils/columns';

const ApplicationsPage = () => {
  const { currentOrgId } = useSubdomainStore();

  // Checking permissions
  const { permissions } = useUserRolesStore();
  const hasCreateApplicationAccess = checkPermission(permissions || [], [
    'createApplication',
  ]);

  const [showCreateApplicationDialog, setCreateApplicationDialog] =
    useState(false);
  const {
    data: applications = [],
    isLoading: isApplicationsLoading,
    error,
    pagination,
  } = useConvexPaginatedQuery(
    api.functions.apps.global.applications.index.readApplications,
    { currentOrgId, inputs: {} }
  );

  const { table } = useDataTable({
    columns: applicationTableColumns,
    data: applications,
  });

  const handleDownload = () => {
    const exportableData = (applications || [])?.map((item) => ({
      _id: item?._id,
      name: item?.name,
      description: item?.description,
      image: getConvexImageURL(item?.imageId as Id<'_storage'>),
      key: item?.key,
      status: item?.isActive ? 'active' : 'inactive',
      _creationTime: item?._creationTime
        ? new Date(item?._creationTime).toISOString()
        : '',
    }));
    downloadCSVFromObjects({
      data: exportableData,
      selectedKeys: [
        { key: '_id', title: 'ID' },
        { key: 'key', title: 'Key' },
        { key: 'name', title: 'Name' },
        { key: 'description', title: 'Description' },
        { key: 'image', title: 'Image' },
        { key: 'status', title: 'Status' },
        { key: '_creationTime', title: 'Created At' },
      ],
      filenamePrefix: `applications`,
      extension: 'csv',
    });
  };

  if (isApplicationsLoading) {
    return (
      <Loader variant="dashboard">
        <DataTableLoader />
      </Loader>
    );
  }

  if (error) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load applications.'}
      </p>
    );
  }

  return (
    <div>
      <div className="flex items-center py-4 gap-4 justify-between">
        <DataTableSearchableInput filterableColumn="name" table={table} />
        <div className="flex gap-2 items-center text-sm">
          <DataTableColumnsSelector table={table} />
          <Button variant="outline" onClick={handleDownload}>
            <FileIcon className="h-4 w-4" />
            Export
          </Button>
          <PermissionGuard fnNames={['createApplication']}>
            <Button onClick={() => setCreateApplicationDialog(true)}>
              <PlusIcon className="h-4 w-4" />
              Application
            </Button>
          </PermissionGuard>
        </div>
      </div>

      <DataTable columns={applicationTableColumns} table={table} />

      <DataTableConvexPagination table={table} {...pagination} />

      <CreateApplicationDialog
        showDialog={hasCreateApplicationAccess && showCreateApplicationDialog}
        setShowDialog={setCreateApplicationDialog}
      />
    </div>
  );
};

export default ApplicationsPage;
