'use client';
import {
  DataTable,
  DataTableColumnsSelector,
  DataTableConvexPagination,
  DataTableSearchableInput,
} from '@/components/common/data-table';
import useDataTable from '@/components/common/data-table/hooks/use-data-table';
import DataTableLoader from '@/components/common/loaders/data-table-loader';
import Loader from '@/components/common/loaders/loader';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import { useConvexPaginatedQuery } from '@/hooks/convex/use-convex-paginated-query';
import { downloadCSVFromObjects } from '@/lib/data-formatters/csv-file';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { FileIcon, PlusIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import CreateUserDialog from './_components/create-user-dialog';
import { getUserTableColumns } from './_utils/columns';

const GlobalUsersPage = () => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Check permissions
  const hasCreateUserAccess = checkPermission(permissions || [], [
    'createUser',
  ]);
  const hasUpdateUserStatusAccess = checkPermission(permissions || [], [
    'updateUserStatus',
  ]);

  const [showCreateUserDialog, setShowCreateUserDialog] = useState(false);
  const { data, isLoading, error, pagination } = useConvexPaginatedQuery(
    api.functions.apps.global.users.index.readUsers,
    { currentOrgId, inputs: {} }
  );

  const users = data || [];
  const isUsersLoading = isLoading || (!error && !data);

  // [ Mutation ] - User Status Change
  const {
    mutate: requestUserStatusChange,
    isLoading: loadingUserStatusChange,
  } = useConvexMutation(api.functions.apps.global.users.index.updateUserStatus);

  // Handles global user status change
  const onUserStatusChange = async (userId: string, checked: boolean) => {
    if (loadingUserStatusChange || !hasUpdateUserStatusAccess) return;

    const toastId = 'change-global-user-status';
    toast.loading('Changing global user status...', { id: toastId });
    requestUserStatusChange({
      currentOrgId,
      inputs: {
        userId: userId as Id<'users'>,
        status: checked ? 'active' : 'inactive',
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed global user status.',
            {
              id: toastId,
            }
          );
        } else {
          toast.error(res?.message || 'Failed to change global user status', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change global user status', {
          id: toastId,
        });
      });
  };

  // Table columns
  const tableColumns = getUserTableColumns({
    hasUpdateUserStatusAccess,
    onUserStatusChange,
  });

  // Table
  const { table } = useDataTable({
    columns: tableColumns,
    data: users,
  });

  const handleDownload = () => {
    const exportableData = (users || [])?.map((item) => ({
      _id: item?._id,
      name: item?.name,
      email: item?.email,
      image: getConvexImageURL(item?.imageId as Id<'_storage'>),
      status: item?.status,
      _creationTime: item?._creationTime
        ? new Date(item?._creationTime).toISOString()
        : '',
    }));
    downloadCSVFromObjects({
      data: exportableData,
      selectedKeys: [
        { key: '_id', title: 'ID' },
        { key: 'name', title: 'Name' },
        { key: 'email', title: 'Email' },
        { key: 'image', title: 'Image' },
        { key: 'status', title: 'Status' },
        { key: '_creationTime', title: 'Added At' },
      ],
      filenamePrefix: `users`,
      extension: 'csv',
    });
  };

  if (isUsersLoading) {
    return (
      <Loader variant="dashboard">
        <DataTableLoader />
      </Loader>
    );
  }

  if (error) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load users.'}
      </p>
    );
  }

  return (
    <div>
      <div className="flex items-center py-4 gap-4 justify-between">
        <DataTableSearchableInput filterableColumn="name" table={table} />
        <div className="flex gap-2 items-center text-sm">
          <DataTableColumnsSelector table={table} />
          <Button variant="outline" onClick={handleDownload}>
            <FileIcon className="h-4 w-4" />
            Export
          </Button>
          <PermissionGuard fnNames={['createUser']}>
            <Button onClick={() => setShowCreateUserDialog(true)}>
              <PlusIcon className="h-4 w-4" />
              User
            </Button>
          </PermissionGuard>
        </div>
      </div>

      <DataTable columns={tableColumns} table={table} />

      <DataTableConvexPagination table={table} {...pagination} />

      <CreateUserDialog
        showCreateUserDialog={hasCreateUserAccess && showCreateUserDialog}
        setShowCreateUserDialog={setShowCreateUserDialog}
      />
    </div>
  );
};

export default GlobalUsersPage;
