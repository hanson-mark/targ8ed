'use client';

import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import CustomDialog from '@/components/common/custom-dialog';
import FormDropdown from '@/components/form/form-dropdown';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { permissionMethods } from '@/convex/constants/common';
import { addPermissionZodSchema } from '@/convex/functions/apps/global/applications/applications.validations';
import { IPermission } from '@/convex/types/convex-types';

import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { startCase } from 'lodash';
import { LockIcon, PencilLineIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  accessList: { update: boolean; create: boolean };
  showDialog: boolean;
  onClose: () => void;
  applicationId: Id<'applications'>;
  selectedPermission?: IPermission;
}

const CreateOrUpdatePermissionDialog = ({
  accessList,
  showDialog,
  onClose,
  applicationId,
  selectedPermission,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const [isUpdatingKey, setIsUpdatingKey] = useState(false);

  // [ Mutations ]
  const { mutate: createPermission, isLoading: isCreating } = useConvexMutation(
    api.functions.apps.global.applications.permissions.createPermission
  );

  const { mutate: updatePermission, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.applications.permissions.updatePermission
  );

  const isLoading = isCreating || isUpdating;

  // Validation schema
  const validationSchema = addPermissionZodSchema.omit({
    applicationId: true,
  });

  type IForm = z.infer<typeof validationSchema>;

  // Form
  const defaultValues = { key: '', method: '', name: '', description: '' };
  const formMethods = useZodForm(validationSchema, {
    defaultValues: defaultValues as IForm,
  });

  const onOpenChange = () => {
    formMethods.reset(defaultValues as IForm);
    onClose();
  };

  const generatePermissionKeyAndName = (name: string, method: string) => {
    const finalName = name
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_')
      .replace(/_+/g, '_');

    const pascalName = startCase(finalName.replace(/_/g, ' ')).replace(
      /\s/g,
      ''
    );
    const key = method + pascalName;

    return { key, finalName };
  };

  const onSubmit = (values: IForm) => {
    if (isLoading) return;

    // Handle update permission if selectedPermission is provided
    if (selectedPermission) {
      if (!accessList.update) return;

      const toastId = 'update-permission';
      toast.loading('Updating permission...', { id: toastId });

      updatePermission({
        currentOrgId,
        inputs: {
          permissionId: selectedPermission._id,
          key: values?.key,
          method: values?.method,
          name: values?.name,
          description: values?.description,
        },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(res?.message || 'Permission updated successfully.', {
              id: toastId,
            });
            onOpenChange();
          } else {
            toast.error(res?.message || 'Failed to update permission', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to update permission', {
            id: toastId,
          });
        });
    }
    // Handle create permission if no selectedPermission
    else {
      if (!accessList.create) return;

      const toastId = 'create-permission';
      toast.loading('Adding permission...', { id: toastId });

      createPermission({
        currentOrgId,
        inputs: {
          key: values?.key,
          method: values?.method,
          name: values?.name,
          description: values?.description,
          applicationId: applicationId,
        },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(res?.message || 'Permission added successfully.', {
              id: toastId,
            });
            onOpenChange();
          } else {
            toast.error(res?.message || 'Failed to add permission', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to add permission', {
            id: toastId,
          });
        });
    }
  };

  useEffect(() => {
    if (selectedPermission) {
      formMethods.reset({
        key: selectedPermission.key || '',
        method: selectedPermission?.method,
        name: selectedPermission?.name,
        description: selectedPermission.description || '',
      });
    } else {
      formMethods.reset(defaultValues as IForm);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPermission, showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title={selectedPermission ? 'Update Permission' : 'Add Permission'}
      description={
        (accessList.create && !selectedPermission) ||
        (accessList?.update && selectedPermission)
          ? 'Permission for selected application to give access. Permissions are actually functions.'
          : `You do not have access to ${selectedPermission ? 'update' : 'add'} permissions`
      }
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormDropdown
              disabled={isLoading}
              name="method"
              label="Method"
              placeholder="Select a method"
              options={permissionMethods?.map((item) => ({
                label: item,
                value: item,
              }))}
              onSelect={(method) => {
                const name = formMethods.watch('name') || '';

                // Setting the permission key
                const permissionKey = generatePermissionKeyAndName(
                  name,
                  method
                ).key;
                formMethods.setValue('key', permissionKey, {
                  shouldValidate: true,
                });
              }}
            />
            <FormInput
              disabled={isLoading}
              name="name"
              label={
                <>
                  Name{' '}
                  <span className="text-xs text-muted-foreground">
                    (e.g., user_name)
                  </span>
                </>
              }
              placeholder="Enter permission name"
              onChange={(name) => {
                const method = formMethods.watch('method') || '';
                const { finalName, key } = generatePermissionKeyAndName(
                  name,
                  method
                );

                formMethods.setValue('name', finalName, {
                  shouldValidate: true,
                });
                if (method) {
                  formMethods.setValue('key', key, { shouldValidate: true });
                }
              }}
            />
            <div className="flex gap-2 items-start">
              <FormInput
                disabled={isLoading || !isUpdatingKey}
                name="key"
                label="Permission Key"
                placeholder="Enter permission key"
              />
              <ButtonWithTooltip
                type="button"
                className="mt-4.5 h-10 w-10"
                variant={'secondary'}
                onClick={() => setIsUpdatingKey((prev) => !prev)}
                tooltipContent={
                  isUpdatingKey ? 'Disable Key Updating' : 'Enable Key Updating'
                }
              >
                {isUpdatingKey ? <LockIcon /> : <PencilLineIcon />}
              </ButtonWithTooltip>
            </div>
            <FormTextarea
              disabled={isLoading}
              name="description"
              label="Description"
              placeholder="Enter description"
            />
          </div>
          <DialogFooter>
            <Button disabled={isLoading} type="submit">
              {isLoading
                ? `${selectedPermission ? 'Updating' : 'Adding'} Permission...`
                : `${selectedPermission ? 'Update' : 'Add'} Permission`}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateOrUpdatePermissionDialog;
