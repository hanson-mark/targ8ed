'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { IClerkIdentityUser } from '@/types/clerk';
import { format } from 'date-fns';
import {
  CheckCircleIcon,
  ShieldAlertIcon,
  ShieldCheckIcon,
  XCircleIcon,
} from 'lucide-react';

interface IProps {
  user: IClerkIdentityUser;
  hideUnblockButton?: boolean; // Optional prop to hide the unblock button
  onUnblockBruteForce?: (userId: string) => void;
}

const ClerkUserCard = ({
  user,
  onUnblockBruteForce,
  hideUnblockButton,
}: IProps) => {
  const provider = user.externalAccounts[0]?.provider ?? 'unknown';
  const name =
    `${user.firstName ?? ''} ${user.lastName ?? ''}`.trim() || 'Unknown';
  const initials =
    `${user.firstName?.charAt(0) ?? ''}${user.lastName?.charAt(0) ?? ''}`.toUpperCase() ||
    'U';
  const email = user.emailAddresses[0]?.emailAddress ?? 'No email';
  const isEmailVerified =
    user.emailAddresses[0]?.verification?.status === 'verified';
  const isLocked = user.locked;

  return (
    <Card className="w-full shadow-sm rounded-xl p-4 bg-background">
      <CardContent className="flex flex-col md:flex-row gap-4">
        {/* Avatar Section */}
        <div className="flex-shrink-0 flex justify-center md:justify-start">
          <Avatar className="w-16 h-16">
            <AvatarImage src={user.imageUrl} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
        </div>

        {/* User Info Section */}
        <div className="flex-1 space-y-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <h2 className="font-semibold text-lg">{name}</h2>
            <div className="mt-1 sm:mt-0 flex flex-wrap gap-2 max-w-full sm:max-w-[60%]">
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap
                  ${
                    isEmailVerified
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-destructive text-destructive-foreground'
                  }
                `}
              >
                {isEmailVerified ? (
                  <>
                    <CheckCircleIcon className="w-3.5 h-3.5" />
                    Verified
                  </>
                ) : (
                  <>
                    <XCircleIcon className="w-3.5 h-3.5" />
                    Not Verified
                  </>
                )}
              </span>

              <Badge className="capitalize whitespace-nowrap text-xs font-medium px-2 py-0.5 rounded-full">
                {provider}
              </Badge>
            </div>
          </div>

          <div className="text-sm text-muted-foreground">{email}</div>
          <div className="text-xs text-muted-foreground">
            Last login:{' '}
            {user.lastSignInAt
              ? format(new Date(user.lastSignInAt), 'dd-MMM-yyyy, hh:mm:ss a')
              : 'N/A'}
          </div>

          {/* Brute-force Block Section */}
          {isLocked && (
            <div className="mt-3 rounded-md border bg-destructive/10 p-3">
              <div className="flex items-center gap-2 text-sm font-medium text-destructive mb-1">
                <ShieldAlertIcon className="w-4 h-4 shrink-0" />
                Blocked due to Brute-force Protection
              </div>
              <p className="text-xs text-muted-foreground">
                This user is currently locked. You can unblock them manually.
              </p>
              {!hideUnblockButton && onUnblockBruteForce && (
                <Button
                  variant="destructive"
                  size="sm"
                  className="mt-2"
                  onClick={() => onUnblockBruteForce(user.id)}
                >
                  <ShieldCheckIcon className="w-4 h-4 mr-1" />
                  Unblock User
                </Button>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ClerkUserCard;
