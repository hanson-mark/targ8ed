import CustomDialog from '@/components/common/custom-dialog';
import FormCheckSubdomainInput from '@/components/form/form-check-subdomain-input';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import {
  descriptionZodSchema,
  nameZodSchema,
  subdomainZodSchema,
} from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { generateSubdomainFromName } from '@/lib/data-formatters/subdomain';
import useSubdomainStore from '@/stores/subdomainStore';
import { debounce } from 'lodash';
import { useRouter } from 'next/navigation';
import { Dispatch, SetStateAction, useMemo } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const CreateOrganizationDialog = ({ showDialog, setShowDialog }: IProps) => {
  const router = useRouter();

  const { currentOrgId } = useSubdomainStore();

  const { mutate: createOrg, isLoading: isCreating } = useConvexMutation(
    api.functions.apps.global.organizations.index.createOrganization
  );

  // Validation schema
  const validationSchema = z.object({
    name: nameZodSchema,
    description: descriptionZodSchema,
    subdomain: subdomainZodSchema,
    subdomain_input: subdomainZodSchema,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: {
      name: '',
      description: '',
      subdomain: '',
      subdomain_input: '',
    },
  });

  const validSubdomain = formMethods.watch('subdomain');

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isCreating) return;

    const toastId = 'create-organization';
    toast.loading('Adding organization...', { id: toastId });
    createOrg({
      currentOrgId,
      inputs: {
        name: values?.name,
        description: values?.description,
        subdomain: values?.subdomain,
      },
    })
      .then((res) => {
        if (res?.success === true && res?.data) {
          toast.success(res?.message || 'Organization added successfully.', {
            id: toastId,
          });

          router.push(`/${APPLICATION_KEYS.global}/organizations/${res?.data}`);
          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to add organization', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to add organization', {
          id: toastId,
        });
      });
  };

  const updateSubdomain = useMemo(
    () =>
      debounce((value: string) => {
        const hasValidSubdomain = (validSubdomain || '')?.length >= 3;

        if (!hasValidSubdomain) {
          const subdomain = generateSubdomainFromName(value);
          formMethods.setValue('subdomain_input', subdomain, {
            shouldValidate: true,
          });
        }
      }, 700),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [validSubdomain]
  );

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Add Organization"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={isCreating}
              name="name"
              label="Name"
              placeholder="Enter organization name"
              onChange={(value) => {
                updateSubdomain(value);
              }}
            />
            <FormCheckSubdomainInput
              inputName="subdomain_input"
              finalName="subdomain"
              label="Subdomain"
              placeholder="Enter subdomain here"
            />
            <FormTextarea
              disabled={isCreating}
              name="description"
              label="Description"
              placeholder="Enter organization description"
            />
          </div>
          <DialogFooter>
            <Button disabled={isCreating} type="submit">
              {isCreating ? 'Adding Organization...' : 'Add Organization'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateOrganizationDialog;
