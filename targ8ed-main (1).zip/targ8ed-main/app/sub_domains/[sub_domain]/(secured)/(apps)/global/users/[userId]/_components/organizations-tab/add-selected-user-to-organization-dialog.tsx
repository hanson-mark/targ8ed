import CustomDialog from '@/components/common/custom-dialog';
import FormComboBox from '@/components/form/form-combo-box';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
interface IProps {
  userData?: IUser;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const AddSelectedUserToOrganizationDialog = ({
  userData,
  showDialog,
  setShowDialog,
}: IProps) => {
  // Get user config from subdomain store
  const { currentOrgId } = useSubdomainStore();

  // Check permissions
  const { permissions } = useUserRolesStore();
  const hasCreateOrgUserAccess = checkPermission(permissions || [], [
    'createOrgUser',
  ]);
  const hasReadAvailableOrgListToAddUserAccess = checkPermission(
    permissions || [],
    ['readAvailableOrgListToAddUser']
  );

  const [searchInput, setSearchInput] = useState<string>('');

  // Fetching searched organizations
  const { data: organizations = [], isLoading: isOrganizationsLoading } =
    useConvexQuery(
      api.functions.apps.global.users.orgUsers.readAvailableOrgListToAddUser,
      {
        currentOrgId,
        inputs: { userId: userData?._id as Id<'users'>, search: searchInput },
      }
    );

  // Mutation
  const { mutate: createOrgUser, isLoading: isAdding } = useConvexMutation(
    api.functions.apps.global.users.orgUsers.createOrgUser
  );

  // Validation schema
  const validationSchema = z.object({
    organizationId: z
      .string({
        required_error: 'Please select an organization',
      })
      .min(1, 'Please select an organization'),
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { organizationId: '' },
  });

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isAdding || !hasCreateOrgUserAccess) return;

    const toastId = 'adding-user-to-org';
    toast.loading('Connecting user to a organization...', { id: toastId });
    createOrgUser({
      currentOrgId, // Request from org
      inputs: {
        userId: userData?._id as Id<'users'>,
        organizationId: values?.organizationId as Id<'organizations'>, // Creating user to org
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully connected user to organization',
            { id: toastId }
          );

          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to connect user', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to connect user', {
          id: toastId,
        });
      });
  };

  // Reset form when dialog opens
  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Connect User to Organization"
      description={
        !hasReadAvailableOrgListToAddUserAccess
          ? 'You do not have permission to see available organizations for connecting users.'
          : 'Select an organization and assign a role to connect this user. They will gain access based on the assigned role.'
      }
    >
      {!hasReadAvailableOrgListToAddUserAccess ? null : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormComboBox
                disabled={isAdding}
                isSearching={isOrganizationsLoading}
                name="organizationId"
                label="Select Organization"
                placeholder="Select an organization..."
                onSearch={(value) => setSearchInput(value)}
                searchInputDebounceDelay={600}
                options={(organizations || [])?.map((org) => ({
                  value: org._id,
                  label: org.name,
                }))}
              />
            </div>
            <PermissionGuard fnNames={['createOrgUser']}>
              <DialogFooter>
                <Button disabled={isAdding} type="submit">
                  {isAdding ? 'Connecting...' : 'Connect'}
                </Button>
              </DialogFooter>
            </PermissionGuard>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default AddSelectedUserToOrganizationDialog;
