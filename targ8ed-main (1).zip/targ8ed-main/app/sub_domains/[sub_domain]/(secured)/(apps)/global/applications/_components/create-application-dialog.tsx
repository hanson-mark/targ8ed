'use client';

import CustomDialog from '@/components/common/custom-dialog';
import FormCheckApplicationKeyInput from '@/components/form/form-check-application-key-input';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import {
  applicationKeyZodSchema,
  descriptionZodSchema,
  nameZodSchema,
} from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { generateApplicationKeyFromName } from '@/lib/data-formatters/application-key';
import useSubdomainStore from '@/stores/subdomainStore';
import { debounce } from 'lodash';
import { useRouter } from 'next/navigation';
import { Dispatch, SetStateAction, useMemo } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const CreateApplicationDialog = ({ showDialog, setShowDialog }: IProps) => {
  const router = useRouter();
  const { currentOrgId } = useSubdomainStore();

  const { mutate: createApplication, isLoading: isCreating } =
    useConvexMutation(
      api.functions.apps.global.applications.index.createApplication
    );

  // Validation schema
  const validationSchema = z.object({
    name: nameZodSchema,
    description: descriptionZodSchema,
    key: applicationKeyZodSchema,
    key_input: applicationKeyZodSchema,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { name: '', description: '', key: '', key_input: '' },
  });

  const validKey = formMethods.watch('key');

  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isCreating) return;

    const toastId = 'create-application';
    toast.loading('Adding application...', { id: toastId });
    createApplication({
      currentOrgId,
      inputs: {
        name: values?.name,
        key: values?.key,
        description: values?.description,
      },
    })
      .then((res) => {
        if (res?.success && res?.data) {
          toast.success(res?.message || 'Application added successfully.', {
            id: toastId,
          });

          router.push(`/${APPLICATION_KEYS.global}/applications/${res?.data}`);
          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to add application', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to add application', {
          id: toastId,
        });
      });
  };

  const updateKey = useMemo(
    () =>
      debounce((value: string) => {
        const hasValidKey = (validKey || '')?.length >= 3;

        if (!hasValidKey) {
          const generatedKey = generateApplicationKeyFromName(value); // Generates key from name
          formMethods.setValue('key_input', generatedKey, {
            shouldValidate: true,
          });
        }
      }, 700),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [validKey]
  );

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Add Application"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={isCreating}
              name="name"
              label="Name"
              placeholder="Enter application name"
              onChange={(value) => {
                updateKey(value);
              }}
            />
            <FormCheckApplicationKeyInput
              inputName="key_input"
              finalName="key"
              label="Key"
              placeholder="Enter key here"
            />
            <FormTextarea
              disabled={isCreating}
              name="description"
              label="Description"
              placeholder="Enter description"
            />
          </div>
          <DialogFooter>
            <Button disabled={isCreating} type="submit">
              {isCreating ? 'Adding Application...' : 'Add Application'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateApplicationDialog;
