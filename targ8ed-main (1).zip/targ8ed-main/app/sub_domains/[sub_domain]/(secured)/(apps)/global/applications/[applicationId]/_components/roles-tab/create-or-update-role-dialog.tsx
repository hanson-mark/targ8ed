'use client';

import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IRole } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';

import FormSwitch from '@/components/form/form-switch';
import FormTextarea from '@/components/form/form-textarea';
import { createRoleZodSchema } from '@/convex/functions/apps/global/applications/applications.validations';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  showDialog: boolean;
  onClose: () => void;
  applicationId: Id<'applications'>;
  selectedRole?: IRole;
}

const CreateOrUpdateRoleDialog = ({
  showDialog,
  onClose,
  applicationId,
  selectedRole,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasCreateApplicationRoleAccess = checkPermission(permissions || [], [
    'createApplicationRole',
  ]);
  const hasUpdateApplicationRoleAccess = checkPermission(permissions || [], [
    'updateApplicationRole',
  ]);

  const { mutate: createRole, isLoading: isCreating } = useConvexMutation(
    api.functions.apps.global.applications.roles.createApplicationRole
  );

  const { mutate: updateRole, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.applications.roles.updateApplicationRole
  );

  const isLoading = isCreating || isUpdating;

  // Validation schema
  const validationSchema = createRoleZodSchema.omit({ applicationId: true });

  // Form
  const defaultValues = {
    name: '',
    description: '',
    isAdminRole: false,
    permissions: [],
  };
  const formMethods = useZodForm(validationSchema, {
    defaultValues: defaultValues,
  });

  const onOpenChange = () => {
    formMethods.reset(defaultValues);
    onClose();
  };

  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isLoading) return;

    // Handle update role if selectedRole is provided
    if (selectedRole) {
      if (!hasUpdateApplicationRoleAccess) return;

      const toastId = 'update-role';
      toast.loading('Updating role...', { id: toastId });

      updateRole({
        currentOrgId,
        inputs: {
          roleId: selectedRole._id,
          name: values?.name,
          description: values?.description,
          isAdminRole: !!values?.isAdminRole,
        },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(res?.message || 'Role updated successfully.', {
              id: toastId,
            });
            onOpenChange();
          } else {
            toast.error(res?.message || 'Failed to update role', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to update role', {
            id: toastId,
          });
        });
    }
    // Handle create role if no selectedRole
    else {
      if (!hasCreateApplicationRoleAccess) return;
      const toastId = 'create-role';
      toast.loading('Adding role...', { id: toastId });

      createRole({
        currentOrgId,
        inputs: {
          name: values?.name,
          description: values?.description,
          applicationId: applicationId,
          isAdminRole: values?.isAdminRole || false,
        },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(res?.message || 'Role created successfully.', {
              id: toastId,
            });
            onOpenChange();
          } else {
            toast.error(res?.message || 'Failed to create role', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to create role', {
            id: toastId,
          });
        });
    }
  };

  useEffect(() => {
    if (selectedRole) {
      formMethods.reset({
        name: selectedRole.name || '',
        description: selectedRole.description || '',
        isAdminRole: selectedRole?.isAdminRole,
      });
    } else {
      formMethods.reset(defaultValues);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedRole, showDialog]);

  return (
    <CustomDialog
      includeScrollbar
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title={selectedRole ? 'Update Role' : 'Add Role'}
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-4 pb-3">
            <FormSwitch
              name="isAdminRole"
              size="md"
              label={'Is Admin Role?'}
              labels={{
                checked: 'Is Admin Role? (YES)',
                unchecked: 'Is Admin Role? (NO)',
              }}
              description="Granted access to all permissions"
              // onCheckedChange={onStatusChange}
            />

            <FormInput
              disabled={isLoading}
              name="name"
              label="Role Name"
              placeholder="Enter role name"
            />
            <FormTextarea
              disabled={isLoading}
              name="description"
              label="Description"
              placeholder="Enter the description"
            />
          </div>
          <DialogFooter>
            <Button disabled={isLoading} type="submit">
              {isLoading
                ? `${selectedRole ? 'Updating' : 'Adding'} Role...`
                : `${selectedRole ? 'Update' : 'Add'} Role`}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateOrUpdateRoleDialog;
