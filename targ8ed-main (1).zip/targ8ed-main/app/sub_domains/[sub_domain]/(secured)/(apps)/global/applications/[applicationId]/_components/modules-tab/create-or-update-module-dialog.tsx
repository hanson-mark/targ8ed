import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Doc, Id } from '@/convex/_generated/dataModel';
import {
  descriptionZodSchema,
  nameZodSchema,
  treeItemLinkZodSchema,
} from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { RefreshCwIcon } from 'lucide-react';
import { useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  isOpen: boolean;
  applicationId: Id<'applications'>;
  moduleData?: Doc<'applicationModules'>;
  onClose: () => void;
}

const CreateOrUpdateModuleDialog = ({
  isOpen,
  applicationId,
  moduleData,
  onClose,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const isUpdate = moduleData && moduleData?._id ? true : false;

  const { mutate: createModule, isLoading: isCreating } = useConvexMutation(
    api.functions.apps.global.applications.modules.createApplicationModule
  );
  const { mutate: updateModule, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.applications.modules.updateApplicationModule
  );

  const isLoading = isCreating || isUpdating;

  const validationSchema = z.object({
    name: nameZodSchema,
    description: descriptionZodSchema,
    link: treeItemLinkZodSchema,
  });
  type IFormValues = z.infer<typeof validationSchema>;

  const defaultValues: IFormValues = { name: '', description: '', link: '' };
  const formMethods = useZodForm(validationSchema, {
    defaultValues: defaultValues,
  });
  const formValues = formMethods.watch();

  const handleDialogClose = () => {
    onClose();
    formMethods.reset(defaultValues);
  };

  const generateModuleLinkFromName = ({
    name,
    link,
  }: {
    name: string;
    link: string;
  }) => {
    if (link) return link;

    let generatedLink = name.trim().toLowerCase();

    // replace spaces with -
    generatedLink = generatedLink.replace(/\s+/g, '-');

    // --- handle query separately ---
    const spittedLink = generatedLink.split('?');
    let path = spittedLink?.[0] || '';
    const queryAndHash = spittedLink?.[1] || '';
    let query = '';
    let hash = '';

    if (queryAndHash) {
      // split off hash if exists
      const [q, h] = queryAndHash.split('#');
      if (q) {
        // allow only a-z0-9, =, &, -
        query = '?' + q.replace(/[^a-z0-9=&\-]/g, '');
      }
      if (h) {
        // allow only a-z0-9 and -
        hash = '#' + h.replace(/[^a-z0-9\-]/g, '');
      }
    }

    // clean path (remove invalid chars except a-z, 0-9, /, -)
    path = path.replace(/[^a-z0-9\/\-]/g, '');

    // collapse multiple / and -
    path = path.replace(/\/{2,}/g, '/');
    path = path.replace(/-{2,}/g, '-');

    // clean segments
    path = path
      .split('/')
      .map((seg) => seg.replace(/^-+/, '').replace(/-+$/, ''))
      .filter(Boolean)
      .join('/');

    // ensure it starts with a single /
    path = '/' + path;

    return path + query + hash;
  };

  const onSubmit = async (values: IFormValues) => {
    if (isLoading || !isOpen) return;

    const toastId = 'module-create-or-update';
    toast.loading(`${isUpdate ? 'Updating' : 'Adding'} application module...`, {
      id: toastId,
    });

    try {
      const response =
        isUpdate && moduleData?._id
          ? await updateModule({
              currentOrgId,
              inputs: { moduleId: moduleData?._id, ...values },
            })
          : await createModule({
              currentOrgId,
              inputs: { applicationId, ...values },
            });

      if (response?.success) {
        toast.success(
          response?.message ||
            `Module data ${isUpdate ? 'updated' : 'added'} successfully.`,
          { id: toastId }
        );
        handleDialogClose();
      } else {
        toast.error(
          response?.message ||
            `Failed to ${isUpdate ? 'update' : 'add'} module data.`,
          { id: toastId }
        );
      }
    } catch (error) {
      toast.error(
        (error as Error)?.message ||
          `Failed to ${isUpdate ? 'update' : 'add'} module data.`,
        { id: toastId }
      );
    }
  };

  useEffect(() => {
    if (isOpen && moduleData) {
      formMethods.reset({
        name: moduleData?.name,
        description: moduleData?.description,
        link: moduleData?.link,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, moduleData]);

  return (
    <CustomDialog
      isOpen={isOpen}
      title={isUpdate ? 'Update Module' : 'Add Module'}
      description={
        isUpdate
          ? 'Update the module details below.'
          : 'Fill in the module information to add it to the application.'
      }
      onOpenChange={handleDialogClose}
    >
      <FormProvider {...formMethods}>
        <form
          onSubmit={formMethods.handleSubmit(onSubmit)}
          className="space-y-4"
        >
          <FormInput
            disabled={!isOpen || isLoading}
            name="name"
            label="Module Name"
            placeholder="Enter module name.."
          />
          <FormInput
            disabled={!isOpen || isLoading}
            name="description"
            label="Description"
            placeholder="Enter description of the module..."
          />
          <FormInput
            disabled={!isOpen || isLoading}
            name="link"
            label={
              <>
                Module Link{' '}
                <span className="text-xs text-muted-foreground">
                  {"(e.g., '/example' or '#section')"}
                </span>
              </>
            }
            placeholder="Enter module link"
            suffix={
              <ButtonWithTooltip
                disabled={!formValues?.name}
                type="button"
                variant={'outline'}
                className="h-full bg-inherit"
                tooltipContent="Generate link from name"
                onClick={() => {
                  const generatedLink = generateModuleLinkFromName({
                    name: formValues.name,
                    link: '',
                  });
                  formMethods.setValue('link', generatedLink, {
                    shouldValidate: true,
                  });
                }}
              >
                <RefreshCwIcon /> Generate
              </ButtonWithTooltip>
            }
          />

          <div className="flex justify-end">
            <Button disabled={!isOpen || isLoading} type="submit">
              {isUpdate
                ? `${isLoading ? 'Updating' : 'Update'} `
                : `${isLoading ? 'Adding' : 'Add'} `}
              {isLoading ? 'Module...' : 'Module'}
            </Button>
          </div>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default CreateOrUpdateModuleDialog;
