'use client';
import {
  DataTable,
  DataTableColumnsSelector,
  DataTableConvexPagination,
  DataTableSearchableInput,
} from '@/components/common/data-table';
import useDataTable from '@/components/common/data-table/hooks/use-data-table';
import DataTableLoader from '@/components/common/loaders/data-table-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { useConvexPaginatedQuery } from '@/hooks/convex/use-convex-paginated-query';
import { downloadCSVFromObjects } from '@/lib/data-formatters/csv-file';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import { FileIcon, PlusIcon } from 'lucide-react';
import { useState } from 'react';
import CreateOrganizationDialog from './_components/create-organization-dialog';
import { organizationTableColumns } from './_utils/columns';

const OrganizationsPage = () => {
  const { currentOrgId } = useSubdomainStore();

  const [showCreateOrganizationDialog, setCreateOrganizationDialog] =
    useState(false);

  const {
    data: organizations,
    isLoading: isOrganizationsLoading,
    error,
    pagination,
  } = useConvexPaginatedQuery(
    api.functions.apps.global.organizations.index.readOrganizations,
    { currentOrgId, inputs: {} }
  );

  const { table } = useDataTable({
    columns: organizationTableColumns,
    data: organizations,
  });

  const handleDownload = () => {
    const exportableData = (organizations || [])?.map((item) => ({
      _id: item?._id,
      name: item?.name,
      description: item?.description,
      image: getConvexImageURL(item?.imageId as Id<'_storage'>),
      subdomain: item?.subdomain,
      status: item?.status,
      _creationTime: item?._creationTime
        ? new Date(item?._creationTime).toISOString()
        : '',
    }));

    downloadCSVFromObjects({
      data: exportableData,
      selectedKeys: [
        { key: '_id', title: 'ID' },
        { key: 'subdomain', title: 'Subdomain' },
        { key: 'name', title: 'Name' },
        { key: 'description', title: 'Description' },
        { key: 'image', title: 'Image' },
        { key: 'status', title: 'Status' },
        { key: '_creationTime', title: 'Added At' },
      ],
      filenamePrefix: `organizations`,
      extension: 'csv',
    });
  };

  if (isOrganizationsLoading) {
    return (
      <Loader variant="dashboard">
        <DataTableLoader />
      </Loader>
    );
  }

  if (error) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load organizations.'}
      </p>
    );
  }

  return (
    <div>
      <div className="flex flex-wrap md:flex-nowrap items-center py-4 gap-4 justify-between">
        <DataTableSearchableInput filterableColumn="name" table={table} />
        <div className="flex gap-2 items-center text-sm">
          <DataTableColumnsSelector table={table} />
          <Button variant="outline" onClick={handleDownload}>
            <FileIcon className="h-4 w-4" />
            Export
          </Button>
          <Button onClick={() => setCreateOrganizationDialog(true)}>
            <PlusIcon className="h-4 w-4" />
            Organization
          </Button>
        </div>
      </div>

      <DataTable columns={organizationTableColumns} table={table} />

      <DataTableConvexPagination table={table} {...pagination} />

      <CreateOrganizationDialog
        showDialog={showCreateOrganizationDialog}
        setShowDialog={setCreateOrganizationDialog}
      />
    </div>
  );
};

export default OrganizationsPage;
