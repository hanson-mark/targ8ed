'use client';

import { SimpleDataTable } from '@/components/common/data-table';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { IApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useInputConfirm from '@/hooks/use-input-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { PlusIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getModulesTableColumns } from '../../_utils/table-columns';
import CreateOrUpdateModuleDialog from './create-or-update-module-dialog';

interface IProps {
  applicationData?: IApplication & { modules: Doc<'applicationModules'>[] };
}

const ModulesTab = ({ applicationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // Check permissions
  const { permissions } = useUserRolesStore();
  const hasUpdateApplicationModuleAccess = checkPermission(permissions || [], [
    'updateApplicationModule',
  ]);
  const hasDeleteApplicationModuleAccess = checkPermission(permissions || [], [
    'deleteApplicationModule',
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedModule, setSelectedModule] =
    useState<Doc<'applicationModules'>>();

  // Configuration for removing module
  const [RemoveConfirmationDialog, onRemoveConfirm] = useInputConfirm({
    icon: { name: 'Trash2Icon', variant: 'error' },
  });

  // Mutation for removing module
  const { mutate: removeModule, isLoading: isRemoving } = useConvexMutation(
    api.functions.apps.global.applications.modules.deleteApplicationModule
  );

  const onUpdate = (rowData: Doc<'applicationModules'>) => {
    setIsDialogOpen(true);
    setSelectedModule(rowData);
  };

  const onRemove = async (rowData: Doc<'applicationModules'>) => {
    if (isRemoving || !hasDeleteApplicationModuleAccess) return;

    const requiredValue = rowData?.link || '';
    const userInputKey = await onRemoveConfirm({
      requiredValue,
      title: (
        <>
          Delete Module{' '}
          <span className="font-bold text-destructive">{rowData?.name}</span>?
        </>
      ),
      description: (
        <div>
          <div className="">
            You are going to delete the module with link{' '}
            <span className="text-destructive">{`("${rowData?.link}")`}</span>
          </div>
          This action can not be undone.
        </div>
      ),
    });

    if (!userInputKey || userInputKey !== requiredValue) return;

    const toastId = 'remove-module';
    toast.loading('Deleting module...', { id: toastId });

    removeModule({
      currentOrgId,
      inputs: { moduleId: rowData?._id as Id<'applicationModules'> },
    })
      .then((response) => {
        if (response?.success) {
          toast.success(response?.message || 'Module deleted successfully.', {
            id: toastId,
          });
        } else {
          toast.error(response?.message || 'Failed to deleted module.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to delete module.', {
          id: toastId,
        });
      });
  };

  return (
    <div className="w-full space-y-6">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Modules</h2>
          <PermissionGuard fnNames={['createApplicationModule']}>
            <Button onClick={() => setIsDialogOpen(true)}>
              <PlusIcon className="mr-1" /> Module
            </Button>
          </PermissionGuard>
        </div>
        <p className="font-light text-sm">
          List of modules those are available in the application
        </p>
      </div>

      <SimpleDataTable
        data={applicationData?.modules || []}
        columns={getModulesTableColumns({
          hasUpdateApplicationModuleAccess,
          hasDeleteApplicationModuleAccess,
          onUpdate,
          onRemove,
        })}
        keyField="_id"
      />

      {applicationData?._id && (
        <CreateOrUpdateModuleDialog
          isOpen={isDialogOpen}
          applicationId={applicationData?._id}
          moduleData={selectedModule}
          onClose={() => {
            setIsDialogOpen(false);
            setSelectedModule(undefined);
          }}
        />
      )}

      <RemoveConfirmationDialog />
    </div>
  );
};

export default ModulesTab;
