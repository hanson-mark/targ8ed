import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardHeader } from '@/components/ui/card';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { CheckIcon, LinkIcon } from 'lucide-react';

interface IProps {
  disabled: boolean;
  user: Doc<'users'> & { isInOrganization: boolean };
  onUserAdd: (userId: Id<'users'>) => void;
}

const SingleUserWithAddButton = ({ user, disabled, onUserAdd }: IProps) => {
  return (
    <Card key={user._id} className="flex flex-col justify-between gap-2 p-2">
      <CardHeader className="w-full flex items-center justify-between gap-3 px-0">
        <div className="max-w-[calc(100%-85px-12px)] flex items-center gap-3">
          <Avatar className="h-14 w-14 border">
            <AvatarImage
              src={getConvexImageURL(user?.imageId as Id<'_storage'>)}
              alt={user.name}
            />
            <AvatarFallback>{user.name.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="max-w-[calc(100%-56px-12px)]">
            <h3 className="font-semibold text-sm truncate">{user.name}</h3>
            <p className="text-xs text-muted-foreground truncate">
              {user.email}
            </p>
          </div>
        </div>
        <div className="shrink-0 w-[116px]">
          <Button
            disabled={disabled || user.isInOrganization}
            size="sm"
            variant={user.isInOrganization ? 'secondary' : 'default'}
            className="shrink-0 w-full"
            onClick={() => onUserAdd(user._id as Id<'users'>)}
          >
            {user.isInOrganization ? <CheckIcon /> : <LinkIcon />}{' '}
            {user.isInOrganization ? 'Connected' : 'Connect'}
          </Button>
        </div>
      </CardHeader>
    </Card>
  );
};

export default SingleUserWithAddButton;
