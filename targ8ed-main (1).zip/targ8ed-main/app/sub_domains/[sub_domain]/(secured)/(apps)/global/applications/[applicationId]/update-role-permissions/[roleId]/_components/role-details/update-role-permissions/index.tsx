'use client';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { api } from '@/convex/_generated/api';
import { IPermissionMethod, IRole } from '@/convex/types/convex-types';
import { permissionIdZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { LoaderIcon, SaveIcon } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import PermissionsSelector from './permissions-selector';

interface IProps {
  backLink: string;
  roleDetails: IRole;
}

const UpdateRolePermissions = ({ backLink, roleDetails }: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  const router = useRouter();

  const [actionType, setActionType] = useState<'save' | 'update'>();
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<
    IPermissionMethod | 'all'
  >('all');

  const { data: allPermissions, isLoading: isAllPermissionsLoading } =
    useConvexQuery(
      api.functions.apps.global.applications.permissions.readPermissions,
      {
        currentOrgId,
        inputs: {
          applicationId: roleDetails?.applicationId,
        },
      }
    );

  const { data: filteredPermissions, isLoading: isFilteredPermissionsLoading } =
    useConvexQuery(
      api.functions.apps.global.applications.permissions.readPermissions,
      {
        currentOrgId,
        inputs: {
          applicationId: roleDetails?.applicationId,
          ...(selectedMethod !== 'all' ? { method: selectedMethod } : {}),
          ...(debouncedSearch ? { search: debouncedSearch } : {}),
        },
      }
    );

  const { mutate: updateRole, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.applications.roles
      .updatePermissionsOfApplicationRole
  );

  const isLoading =
    isUpdating || (roleDetails ? isFilteredPermissionsLoading : false);

  // Validation schema
  const validationSchema = z.object({
    name: z.string(),
    permissions: z.array(permissionIdZodSchema),
  });

  // Form
  const defaultValues = { name: '', permissions: [] };
  const formMethods = useZodForm(validationSchema, {
    defaultValues: defaultValues,
  });

  const onResetAndRedirect = () => {
    formMethods.reset(defaultValues);
    setDebouncedSearch('');
    setSelectedMethod('all');

    if (actionType === 'save') {
      setActionType(undefined);
    } else if (actionType === 'update') {
      router.push(backLink);
    }
  };

  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isLoading || roleDetails.isAdminRole) return;

    // Handle update role if selectedRole is provided
    if (roleDetails && Array.isArray(values?.permissions)) {
      const toastId = 'update-role';
      toast.loading('Updating role...', { id: toastId });

      updateRole({
        currentOrgId,
        inputs: { roleId: roleDetails._id, permissions: values?.permissions },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(res?.message || 'Role updated successfully.', {
              id: toastId,
            });
            onResetAndRedirect();
          } else {
            toast.error(res?.message || 'Failed to update role', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to update role', {
            id: toastId,
          });
        });
    }
  };

  useEffect(() => {
    if (roleDetails) {
      formMethods.reset({
        name: roleDetails?.name,
        permissions: roleDetails?.permissions?.map((item) => item?._id),
      });
    } else {
      formMethods.reset(defaultValues);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleDetails]);

  // Showing loader
  if (isAllPermissionsLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  return (
    <FormProvider {...formMethods}>
      <form
        onSubmit={formMethods.handleSubmit(onSubmit)}
        className="relative -mb-3"
      >
        <div className="flex justify-between gap-3">
          <Label asChild className="mb-2 font-medium text-lg">
            <p className="">
              {roleDetails?.isAdminRole && 'View '} Permissions
            </p>
          </Label>{' '}
        </div>
        <div className="grid gap-4 pb-3">
          {roleDetails ? (
            <PermissionsSelector
              name="permissions"
              roleDetails={roleDetails}
              allPermissions={allPermissions || []}
              isFilteredPermissionsLoading={isFilteredPermissionsLoading}
              filteredPermissions={filteredPermissions || []}
              selectedMethod={selectedMethod}
              setSelectedMethod={setSelectedMethod}
              debouncedSearch={debouncedSearch}
              setDebouncedSearch={setDebouncedSearch}
            />
          ) : null}
        </div>

        {!roleDetails?.isAdminRole && (
          <div className="sticky bottom-0 left-0 right-0 bg-background border-t pt-3 flex gap-2 justify-end items-center pb-3 px-1">
            <Button
              disabled={isLoading}
              type="submit"
              variant={'outline'}
              onClick={() => setActionType('save')}
              className="w-28"
            >
              {isUpdating && actionType === 'save' ? (
                <>
                  <LoaderIcon className="animate-spin" /> Saving...
                </>
              ) : (
                <>
                  <SaveIcon /> Save
                </>
              )}
            </Button>
            <Button
              disabled={isLoading}
              type="submit"
              onClick={() => setActionType('update')}
              className="w-36"
            >
              {isUpdating && actionType === 'update' ? (
                <>
                  <LoaderIcon className="animate-spin" /> Updating...
                </>
              ) : (
                <>
                  <SaveIcon /> Update
                </>
              )}
            </Button>
          </div>
        )}
      </form>
    </FormProvider>
  );
};

export default UpdateRolePermissions;
