'use client';

import CustomTabs from '@/components/common/custom-tabs';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { ArrowLeftIcon } from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import UserOrgName from './_components/user-org-name';
import UserOrganization from './_components/user-organization';

const UserOrganizationPage = () => {
  // Getting params, userId will be there
  const params = useParams();

  const { currentOrgId } = useSubdomainStore();

  // User data fetching
  const {
    data: userResponse,
    isLoading: isUserLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.users.orgUsers.readOrgUserDetails,
    {
      currentOrgId,
      inputs: {
        organizationId: params?.organizationId as Id<'organizations'>,
        userId: params?.userId as Id<'users'>,
      },
    }
  );

  // Showing loader
  if (isUserLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  // Showing errors if happens
  if (error || !userResponse?._id) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load user data.'}
      </p>
    );
  }

  const backLink = `/${APPLICATION_KEYS.global}/users/${userResponse?.userId}?tab=organizations`;

  return (
    <div>
      <div className="space-y-2.5 mb-5">
        <Button variant={'ghost'} asChild>
          <Link href={backLink} className="!pl-0">
            <ArrowLeftIcon /> Back to user details
          </Link>
        </Button>
        <UserOrgName orgUser={userResponse} backLink={backLink} />
        <p className="text-sm">Manage {"Organization's"} User</p>
      </div>
      <CustomTabs
        defaultValue="org-access"
        tabItems={[
          {
            label: 'Organization Access',
            value: 'org-access',
            content: (
              <UserOrganization isOpen={true} userOrganization={userResponse} />
            ),
          },
        ]}
      />
    </div>
  );
};

export default UserOrganizationPage;
