import { SimpleDataTable } from '@/components/common/data-table';
import DebouncedSearchInput from '@/components/common/debounced-search-input';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IRole } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useInputConfirm from '@/hooks/use-input-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { PlusIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getRolesTableColumns } from '../../_utils/table-columns';
import CreateOrUpdateRoleDialog from './create-or-update-role-dialog';

interface IProps {
  applicationId: Id<'applications'>;
}

const RolesTab = ({ applicationId }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasUpdateApplicationRoleAccess = checkPermission(permissions || [], [
    'updateApplicationRole',
  ]);
  const hasUpdatePermissionsOfApplicationRoleAccess = checkPermission(
    permissions || [],
    ['updatePermissionsOfApplicationRole']
  );
  const hasDeleteApplicationRoleAccess = checkPermission(permissions || [], [
    'deleteApplicationRole',
  ]);

  // States
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedRole, setSelectedRole] = useState<IRole>();
  const [showCreateOrUpdateDialog, setShowCreateOrUpdateDialog] =
    useState(false);

  // Configuration for removing role
  const [RemoveConfirmationDialog, onRemoveConfirm] = useInputConfirm({
    description: 'This action can not be undone.',
    icon: { name: 'Trash2Icon', variant: 'error' },
  });

  // Getting roles for the application
  const {
    data: roleList = [],
    isLoading,
    error: rolesError,
  } = useConvexQuery(
    api.functions.apps.global.applications.roles.readApplicationRoles,
    {
      currentOrgId,
      inputs: {
        applicationId,
        ...(debouncedSearch ? { search: debouncedSearch } : {}),
      },
    }
  );

  // Mutation for removing role
  const { mutate: removeRole, isLoading: isRemoving } = useConvexMutation(
    api.functions.apps.global.applications.roles.deleteApplicationRole
  );

  // Handles showing the update role dialog
  const onOpenUpdateDialog = (role: IRole) => {
    setSelectedRole(role);
    setShowCreateOrUpdateDialog(true);
  };

  // Handles removing the role dialog
  const onRemoveRole = async (role: IRole) => {
    if (isRemoving || !hasDeleteApplicationRoleAccess) return;

    const requiredValue = role?.name || '';
    const userInputKey = await onRemoveConfirm({
      requiredValue,
      title: (
        <>
          Delete Role{' '}
          <span className="font-bold text-destructive">{role.name}</span>?
        </>
      ),
    });

    if (!userInputKey || userInputKey !== requiredValue) return;

    const toastId = 'remove-role';
    toast.loading('Deleting Role...', { id: toastId });

    removeRole({
      currentOrgId,
      inputs: { roleId: role._id },
    })
      .then((response) => {
        if (response?.success) {
          toast.success(response?.message || 'Role deleted successfully.', {
            id: toastId,
          });
        } else {
          toast.error(response?.message || 'Failed to delete role.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to delete role.', {
          id: toastId,
        });
      });
  };

  if (!isLoading && (rolesError || !roleList)) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {rolesError?.message || 'Failed to load roles for this application.'}
      </p>
    );
  }

  return (
    <div className="w-full space-y-3">
      <div>
        <div className="flex justify-between items-center">
          <h2 className="text-base font-medium">Roles</h2>
          <PermissionGuard fnNames={['createApplicationRole']}>
            <Button
              onClick={() => {
                setShowCreateOrUpdateDialog(true);
                setSelectedRole(undefined);
              }}
            >
              <PlusIcon /> Role
            </Button>
          </PermissionGuard>
        </div>
        <p className="font-light text-sm">
          List of roles available for this application.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        {/* Search Input */}
        <DebouncedSearchInput
          className="w-full max-w-72"
          placeholder="Search by name..."
          setDebouncedSearch={setDebouncedSearch}
        />
      </div>

      {isLoading ? (
        <div className="border rounded-md p-3 space-y-4">
          {[...Array(6)].map((_, idx) => (
            <div key={idx} className="grid grid-cols-5 gap-4">
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
              <Skeleton className="h-7 w-full col-span-1" />
            </div>
          ))}
        </div>
      ) : (
        <SimpleDataTable
          data={roleList || []}
          columns={getRolesTableColumns({
            hasDeleteApplicationRoleAccess,
            hasUpdateApplicationRoleAccess,
            hasUpdatePermissionsOfApplicationRoleAccess,
            onRemoveRole,
            onOpenUpdateDialog,
          })}
          keyField="_id"
        />
      )}
      <CreateOrUpdateRoleDialog
        applicationId={applicationId}
        selectedRole={selectedRole}
        showDialog={showCreateOrUpdateDialog}
        onClose={() => {
          setShowCreateOrUpdateDialog(false);
          setSelectedRole(undefined);
        }}
      />

      <RemoveConfirmationDialog />
    </div>
  );
};

export default RolesTab;
