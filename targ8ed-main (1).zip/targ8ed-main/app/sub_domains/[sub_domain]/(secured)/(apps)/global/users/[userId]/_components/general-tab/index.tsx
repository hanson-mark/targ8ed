import { deleteClerkUser } from '@/actions/auth/user';
import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import { CopyButton } from '@/components/common/copy-elements';
import ProfileImageWithUploader from '@/components/common/profile-image-with-uploader';
import FormInput from '@/components/form/form-input';
import FormSwitch from '@/components/form/form-switch';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { IUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useInputConfirm from '@/hooks/use-input-confirm';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { SquarePenIcon } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { userDetailsFormZodSchema } from '../../_utils/form-helpers';
import UpdateUserEmailDialog from './update-user-email-dialog';
import UpdateUserNameDialog from './update-user-name-dialog';

interface IProps {
  userData?: IUser;
  setIsDeleting: Dispatch<SetStateAction<boolean>>;
}

const GeneralTab = ({ userData, setIsDeleting }: IProps) => {
  const router = useRouter();

  // Get user config from subdomain store
  const { currentOrgId, userConfig } = useSubdomainStore();

  const isCurrentUser = userData?._id === userConfig?.globalUser?._id;

  // Check permissions
  const { permissions } = useUserRolesStore();
  const hasUpdateUserStatusAccess = checkPermission(permissions || [], [
    'updateUserStatus',
  ]);
  const hasUpdateUserImageIdAccess = checkPermission(permissions || [], [
    'updateUserImageId',
  ]);
  const hasUpdateUserNameAccess = checkPermission(permissions || [], [
    'updateUserName',
  ]);
  const hasUpdateUserEmailAccess = checkPermission(permissions || [], [
    'updateUserEmail',
  ]);
  const hasDeleteUserAccess = checkPermission(permissions || [], [
    'deleteUser',
  ]);

  // States
  const [showUpdateNameDialog, setShowUpdateNameDialog] = useState(false);
  const [showUpdateEmailDialog, setShowUpdateEmailDialog] = useState(false);

  // [ Mutation ] - Profile image update
  const { isLoading: isImageUpdating, mutate: updateUserImage } =
    useConvexMutation(api.functions.apps.global.users.index.updateUserImageId);

  // [ Mutation ] - User Status Change
  const {
    mutate: requestUserStatusChange,
    isLoading: loadingUserStatusChange,
  } = useConvexMutation(api.functions.apps.global.users.index.updateUserStatus);

  // [ Mutation ] - Remove user
  const { mutate: removeUser, isLoading: isRemovingUser } = useConvexMutation(
    api.functions.apps.global.users.index.deleteUser
  );

  // [ Dialog ] - To take confirmation of deleting user globally
  const [DeleteConfirmationDialog, onConfirmDelete] = useInputConfirm({
    title: 'Are you sure you want to delete this user?',
    description:
      'This action cannot be undone. All related data — including the user’s access to organizations, applications, and other associated records — will be permanently removed.',
    icon: {
      name: 'Building',
      variant: 'error',
    },
    confirmButton: {
      label: 'Yes, Delete',
      variant: 'destructive',
    },
  });

  // React hook form
  const formMethods = useZodForm(userDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      email: '',
      status: false,
    },
  });

  const userId = userData?._id;

  // Handles global user status change
  const onUserStatusChange = async (checked: boolean) => {
    formMethods.setValue('status', !checked);
    if (loadingUserStatusChange || !hasUpdateUserStatusAccess) return;

    const toastId = 'change-global-user-status';
    toast.loading('Changing global user status...', { id: toastId });

    requestUserStatusChange({
      currentOrgId,
      inputs: {
        userId: userId as Id<'users'>,
        status: checked ? 'active' : 'inactive',
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed global user status.',
            {
              id: toastId,
            }
          );
        } else {
          toast.error(res?.message || 'Failed to change global user status', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change global user status', {
          id: toastId,
        });
      });
  };

  // Handles global user deletion
  const handleDeleteUser = async () => {
    if (isRemovingUser || !hasDeleteUserAccess) return;

    const requiredValue = userData?.email || '';
    const userInputEmail = await onConfirmDelete({ requiredValue });

    if (!userInputEmail || userInputEmail !== requiredValue) return;

    const toastId = 'remove-user';
    toast.loading('Deleting user...', { id: toastId });
    setIsDeleting(true);

    removeUser({
      currentOrgId,
      inputs: { userId: userData?._id as Id<'users'> },
    })
      .then(async (response) => {
        if (response?.success) {
          await deleteClerkUser(userData?.email || '');

          router.push(`/${APPLICATION_KEYS.global}/users`);
          toast.success(response?.message || 'Successfully delete the user', {
            id: toastId,
          });
        } else {
          setIsDeleting(false);
          toast.error(response?.message || 'Failed to delete the user', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to delete the user', {
          id: toastId,
        });
      });
  };

  // Updating form based on user data change
  useEffect(() => {
    formMethods.reset({
      _id: userData?._id,
      name: userData?.name,
      email: userData?.email,
      status: userData?.status === 'active' ? true : false,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userData]);

  return (
    <div className="space-y-4 mb-10">
      {/* Profile Image  */}
      <ProfileImageWithUploader
        showUploadButton={hasUpdateUserImageIdAccess}
        imageURL={getConvexImageURL(userData?.imageId as Id<'_storage'>)}
        imageAlt={userData?.name || ''}
        isImageIdUpdating={isImageUpdating}
        onUpdateImageId={(storageId) =>
          updateUserImage({
            currentOrgId,
            inputs: {
              userId: userData?._id as Id<'users'>,
              imageId: storageId,
            },
          })
        }
        fileUploaderProps={{
          maxFileSizeInKB: 300,
        }}
      />
      {/* <Separator className="my-8" /> */}

      <FormProvider {...formMethods}>
        <form
          className="space-y-4"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          {/* Name Input Field  */}
          <div className="flex gap-2 items-end">
            <FormInput disabled name="name" label="Name" />{' '}
            {hasUpdateUserNameAccess && (
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
                tooltipContent="Update Name"
                onClick={() => setShowUpdateNameDialog(true)}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            )}
          </div>

          {/* Email Input Field  */}
          <div className="flex gap-2 items-end">
            <FormInput disabled name="email" label="Email" />
            <CopyButton
              value={userData?.email || ''}
              className="bg-muted hover:bg-muted/80"
            />
            {hasUpdateUserEmailAccess && (
              <ButtonWithTooltip
                variant={'ghost'}
                className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
                tooltipContent="Update Email"
                onClick={() => setShowUpdateEmailDialog(true)}
              >
                <SquarePenIcon />
              </ButtonWithTooltip>
            )}
          </div>

          <Separator className="my-8" />

          <FormSwitch
            disabled={!hasUpdateUserStatusAccess}
            name="status"
            size="md"
            label={'Active'}
            labels={{
              checked: 'Active',
              unchecked: 'Inactive',
            }}
            description="Controls the user's global status. Globally inactive users can't access any organization."
            onCheckedChange={onUserStatusChange}
          />

          {!isCurrentUser && hasDeleteUserAccess && (
            <>
              <Separator className="mt-5 mb-4" />
              <div className="">
                <h3 className="text-sm font-semibold text-red-600 mb-3">
                  Danger Zone
                </h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-red-700">
                      Delete User
                    </p>
                    <p className="text-xs text-red-600 mt-1">
                      Once deleted, this action cannot be undone.
                    </p>
                  </div>
                  <Button
                    onClick={handleDeleteUser}
                    className="text-white bg-red-600 hover:bg-red-700 transition px-4 py-2 text-sm font-semibold rounded-md"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </>
          )}
        </form>
      </FormProvider>
      <UpdateUserNameDialog
        userData={userData}
        showDialog={hasUpdateUserNameAccess && showUpdateNameDialog}
        setShowDialog={setShowUpdateNameDialog}
      />
      <UpdateUserEmailDialog
        userData={userData}
        showDialog={hasUpdateUserEmailAccess && showUpdateEmailDialog}
        setShowDialog={setShowUpdateEmailDialog}
      />
      <DeleteConfirmationDialog />
    </div>
  );
};

export default GeneralTab;
