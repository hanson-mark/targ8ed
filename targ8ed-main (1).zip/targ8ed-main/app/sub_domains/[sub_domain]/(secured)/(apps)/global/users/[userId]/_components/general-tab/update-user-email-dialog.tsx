import { updateClerkUserEmail } from '@/actions/auth/user';
import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { IUser } from '@/convex/types/convex-types';
import { emailZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
interface IProps {
  userData?: IUser;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const UpdateUserEmailDialog = ({
  userData,
  showDialog,
  setShowDialog,
}: IProps) => {
  // Get user config from subdomain store
  const { currentOrgId } = useSubdomainStore();

  const [isUpdatingClerkUser, setIsUpdatingClerkUser] = useState(false);

  // [ Mutation ] Update user email
  const { mutate: updateEmail, isLoading: isChanging } = useConvexMutation(
    api.functions.apps.global.users.index.updateUserEmail
  );

  // Validation schema
  const validationSchema = z.object({
    email: emailZodSchema,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { email: '' },
  });

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    const oldEmailAddress = userData?.email?.trim()?.toLowerCase();
    const newEmailAddress = values?.email?.trim()?.toLowerCase();

    if (isChanging || !userData?._id || !oldEmailAddress || !newEmailAddress) {
      return;
    }

    if (oldEmailAddress === newEmailAddress) {
      toast.error('You did not changed email address');

      return;
    }

    const toastId = 'update-user-email';
    toast.loading('Updating email in convex...', { id: toastId });

    updateEmail({
      currentOrgId,
      inputs: {
        userId: userData?._id,
        email: values?.email?.trim()?.toLowerCase(),
      },
    })
      .then(async (res) => {
        if (res?.success) {
          toast.loading('Updated in convex. Now, updating email in clerk...', {
            id: toastId,
          });
          setIsUpdatingClerkUser(true);
          const clerkEmailUpdateRes = await updateClerkUserEmail({
            oldEmail: oldEmailAddress,
            newEmail: newEmailAddress,
            name: userData?.name,
          });

          if (clerkEmailUpdateRes?.success) {
            toast.success(res?.message || 'Email updated successfully.', {
              id: toastId,
            });

            onOpenChange(false);
          } else {
            toast.error(
              'Email updated in convex but failed to update in clerk. Contact with technical team.',
              { id: toastId, duration: 5000 }
            );
          }
        } else {
          toast.error(res?.message || 'Failed to update email', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        console.log({ error });

        toast.error(error?.message || 'Failed to update email', {
          id: toastId,
        });
      })
      .finally(() => {
        setIsUpdatingClerkUser(false);
      });
  };

  useEffect(() => {
    formMethods.reset({
      email: userData?.email,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Update Email"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={isChanging || isUpdatingClerkUser}
              name="email"
              label="Email"
              placeholder="Enter new email address"
            />
          </div>
          <DialogFooter>
            <Button disabled={isChanging || isUpdatingClerkUser} type="submit">
              {isChanging ? 'Updating Email...' : 'Update Email'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default UpdateUserEmailDialog;
