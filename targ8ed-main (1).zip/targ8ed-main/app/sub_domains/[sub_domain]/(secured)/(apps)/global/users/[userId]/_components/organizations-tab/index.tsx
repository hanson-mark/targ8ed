'user client';
import { SimpleDataTable } from '@/components/common/data-table';
import TooltipWrapper from '@/components/common/tooltip-wrapper';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgUser, IUser } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useConfirm from '@/hooks/use-confirm';
import { checkPermission } from '@/lib/data-formatters/permissions';
import { DIALOG_CONTENT } from '@/lib/default-data/dialog-content';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { DoorOpenIcon, LinkIcon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { getUserOrgTableColumns } from '../../_utils/user-org-table-column';
import AddSelectedUserToOrganizationDialog from './add-selected-user-to-organization-dialog';
import OrganizationsTabLoader from './organizations-tab-loader';
interface IProps {
  userData?: IUser;
}

const OrganizationsTab = ({ userData }: IProps) => {
  // Get user config from subdomain store
  const { currentOrgId } = useSubdomainStore();

  // Check permissions
  const { permissions } = useUserRolesStore();
  const hasCreateOrgUserAccess = checkPermission(permissions || [], [
    'createOrgUser',
  ]);
  const hasRemoveOrgAccess = checkPermission(permissions, [
    'deleteUserFromOrg',
  ]);

  const [showAddUserToOrgDialog, setShowAddUserToOrgDialog] = useState(false);

  // Fetching organizations list by user
  const {
    data: userOrgList,
    isLoading: isUserOrgListLoading,
    error,
  } = useConvexQuery(api.functions.apps.global.users.orgUsers.readUserOrgList, {
    currentOrgId,
    inputs: { userId: userData?._id as Id<'users'> },
  });

  // [ Mutation ] - User Remove
  const { mutate: removeUserFromOrg, isLoading: loadingUserRemoval } =
    useConvexMutation(
      api.functions.apps.global.users.orgUsers.deleteUserFromOrg
    );

  // [ Dialog ] - To take confirmation for removing user
  const [UserRemoveConfirmDialog, confirmUserRemove] = useConfirm();

  // Handles removing user from organization
  const onRemoveUserOrg = async (rowData: IOrgUser) => {
    if (loadingUserRemoval || !hasRemoveOrgAccess) return;

    const isConfirmed = await confirmUserRemove(DIALOG_CONTENT.RemoveOrgUser);
    if (!isConfirmed) return;

    const toastId = 'remove-org-user';
    toast.loading('Removing user...', { id: toastId });

    removeUserFromOrg({
      currentOrgId,
      inputs: {
        userId: userData?._id as Id<'users'>,
        organizationId: rowData?.organization?._id as Id<'organizations'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res.message || 'User removed successfully.', {
            id: toastId,
          });
        } else {
          toast.error(res.message || 'Failed to remove user.', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(
          error?.message || 'Something went wrong while removing user.',
          { id: toastId }
        );
      });
  };

  if (isUserOrgListLoading) {
    return <OrganizationsTabLoader />;
  }

  // Showing errors if happens
  if (error || !userOrgList) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load user organizations.'}
      </p>
    );
  }

  return (
    <div className="space-y-3 mb-10">
      {/* Top section  */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-medium">Organizations</h2>
          {hasCreateOrgUserAccess && (
            <TooltipWrapper tooltipContent="Create user access to an organization">
              <Button
                variant="default"
                onClick={() => {
                  setShowAddUserToOrgDialog(true);
                }}
              >
                <LinkIcon /> Organization
              </Button>
            </TooltipWrapper>
          )}
        </div>
        <p className="font-light text-sm">
          List of organizations, where the user have access
        </p>
      </div>

      {/* Accordion with organization list  */}
      {(userOrgList || []).length < 1 ? (
        <div className="flex flex-col items-center justify-center h-40">
          <div className="w-10 h-10 flex items-center justify-center rounded">
            <DoorOpenIcon className="w-6 h-6 text-muted-foreground" />
          </div>
          <span className="text-sm text-muted-foreground">
            No organizations found
          </span>
        </div>
      ) : (
        <SimpleDataTable
          data={userOrgList || []}
          columns={getUserOrgTableColumns({
            hasRemoveOrgAccess,
            onRemoveUserOrg,
          })}
          keyField="_id"
        />
      )}
      <AddSelectedUserToOrganizationDialog
        userData={userData}
        showDialog={hasCreateOrgUserAccess && showAddUserToOrgDialog}
        setShowDialog={setShowAddUserToOrgDialog}
      />
      <UserRemoveConfirmDialog />
    </div>
  );
};

export default OrganizationsTab;
