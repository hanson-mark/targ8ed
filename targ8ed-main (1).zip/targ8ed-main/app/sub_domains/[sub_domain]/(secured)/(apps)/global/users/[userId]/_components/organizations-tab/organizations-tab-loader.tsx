import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';

const OrganizationsTabLoader = () => {
  return (
    <div className="w-full space-y-4">
      <div className="w-full flex justify-between gap-14">
        <div className="max-w-2xl w-full space-y-2">
          <Skeleton className="h-8 w-3/5 lg:w-1/2" />
          <Skeleton className="h-5 w-3/4" />
        </div>
        <Skeleton className="h-9 w-44" />
      </div>

      <Separator className="mt-4 mb-7" />

      <div className="border rounded-md p-3 space-y-4">
        {[...Array(4)].map((_, idx) => (
          <div key={idx} className="grid grid-cols-6 gap-4">
            <Skeleton className="h-12 w-full col-span-3" />
            <Skeleton className="h-12 w-full col-span-2" />
            <Skeleton className="h-12 w-full col-span-1" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrganizationsTabLoader;
