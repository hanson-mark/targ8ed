'use client';
import CustomDropdown from '@/components/common/custom-dropdown';
import DebouncedSearchInput from '@/components/common/debounced-search-input';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Id } from '@/convex/_generated/dataModel';
import { permissionMethods } from '@/convex/constants/common';
import {
  IPermission,
  IPermissionMethod,
  IRole,
} from '@/convex/types/convex-types';
import { cn } from '@/lib/utils';
import { XIcon } from 'lucide-react';
import { Dispatch, SetStateAction, useMemo, useState } from 'react';
import { useFormContext } from 'react-hook-form';

interface IProps {
  name: string;
  roleDetails: IRole;
  allPermissions: IPermission[];
  isFilteredPermissionsLoading: boolean;
  filteredPermissions: IPermission[];
  selectedMethod: IPermissionMethod | 'all';
  setSelectedMethod: Dispatch<SetStateAction<IPermissionMethod | 'all'>>;
  debouncedSearch: string;
  setDebouncedSearch: Dispatch<SetStateAction<string>>;
}
type ICheckedState = 'all' | 'selected' | 'unselected';

export const PermissionsSelector = ({
  name,
  roleDetails,
  allPermissions,
  isFilteredPermissionsLoading,
  filteredPermissions,
  selectedMethod,
  setSelectedMethod,
  debouncedSearch,
  setDebouncedSearch,
}: IProps) => {
  const [selectedState, setSelectedState] = useState<ICheckedState>('all');

  const { watch, setValue } = useFormContext();
  const selected: Id<'permissions'>[] = watch(name) || [];

  const allPermissionsMap = useMemo(() => {
    return new Map(allPermissions.map((p) => [p._id, p]));
  }, [allPermissions]);

  const togglePermission = (id: Id<'permissions'>) => {
    const newValue = selected.includes(id)
      ? selected.filter((pid: Id<'permissions'>) => pid !== id)
      : [...selected, id];
    setValue(name, newValue, { shouldDirty: true });
  };

  const isSelected = (id: Id<'permissions'>) => selected.includes(id);

  const getVisiblePermissions = () => {
    if (selectedState === 'selected') {
      return filteredPermissions.filter((p) => selected.includes(p._id));
    }
    if (selectedState === 'unselected') {
      return filteredPermissions.filter((p) => !selected.includes(p._id));
    }
    return filteredPermissions; // 'all'
  };
  const visiblePermissions = getVisiblePermissions();

  return (
    <div>
      <div className="grid w-full gap-1 min-h-10 border rounded-md bg-background border-input py-2 shadow-sm text-sm">
        <div className="grid gap-1 px-3">
          {selected.length > 0 && (
            <p className="text-xs font-medium text-muted-foreground mb-1">
              Selected ({selected.length})
            </p>
          )}

          <ScrollArea
            type="always"
            className="pr-1"
            style={{
              maxHeight: roleDetails?.isAdminRole ? '100%' : `170px`,
            }}
          >
            <div
              className={cn(
                'gap-1',
                roleDetails?.isAdminRole ? 'grid' : 'flex flex-wrap'
              )}
            >
              {selected.length === 0 ? (
                <p className="text-xs text-muted-foreground py-1.5">
                  No permissions selected.
                </p>
              ) : (
                selected.map((pid: Id<'permissions'>) => {
                  const permission = allPermissionsMap.get(pid);
                  if (!permission) return null;

                  const permissionNameComponent = (
                    <div
                      key={pid}
                      className="inline-flex items-center gap-1 bg-primary text-primary-foreground px-2 py-0.5 rounded-full text-xs border border-primary"
                    >
                      {permission.method}:{permission.name}
                      {!roleDetails?.isAdminRole && (
                        <button
                          onClick={() => togglePermission(pid)}
                          className="hover:text-red-200 hover:cursor-pointer"
                          type="button"
                        >
                          <XIcon className="h-3 w-3" />
                        </button>
                      )}
                    </div>
                  );
                  return !roleDetails?.isAdminRole ? (
                    permissionNameComponent
                  ) : (
                    <div className="">{permissionNameComponent}</div>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </div>

        {!roleDetails?.isAdminRole && (
          <>
            <Separator className="my-2" />

            <div className="grid gap-1 px-3">
              <p className="text-xs font-medium text-muted-foreground mb-1">
                Filtering
              </p>
              <div className="flex gap-2 items-center justify-start">
                <CustomDropdown
                  disabled={isFilteredPermissionsLoading}
                  value={selectedState}
                  onSelect={(value) => setSelectedState(value as ICheckedState)}
                  placeholder="Select..."
                  classNames={{
                    main: 'w-28 md:w-36',
                    button: '!text-xs h-9',
                  }}
                  options={[
                    { label: 'All States', value: 'all' },
                    { label: 'Selected', value: 'selected' },
                    { label: 'Unselected', value: 'unselected' },
                  ]}
                />{' '}
                <CustomDropdown
                  disabled={isFilteredPermissionsLoading}
                  value={selectedMethod}
                  onSelect={(value) =>
                    setSelectedMethod(value as IPermissionMethod)
                  }
                  placeholder="Select..."
                  classNames={{
                    main: 'w-28 md:w-36',
                    button: '!text-xs h-9',
                  }}
                  options={[
                    { label: 'All Method', value: 'all' },
                    ...permissionMethods?.map((item) => ({
                      label: item,
                      value: item,
                    })),
                  ]}
                />
                <DebouncedSearchInput
                  disabled={isFilteredPermissionsLoading}
                  className="max-w-72 min-w-56 mb-1 [&_input]:!text-xs"
                  placeholder="Search permission by name..."
                  setDebouncedSearch={setDebouncedSearch}
                />
              </div>
              <p className="text-xs font-medium text-muted-foreground mb-1">
                {selectedMethod === 'all' &&
                selectedState === 'all' &&
                debouncedSearch === ''
                  ? 'All'
                  : 'Filtered'}{' '}
                permissions ({visiblePermissions?.length})
              </p>

              <ScrollArea
                type="always"
                className="pr-1"
                style={{
                  height: `${Math.max(110, Math.min(visiblePermissions.length * 55, 300))}px`,
                }}
              >
                {isFilteredPermissionsLoading ? (
                  <div className="grid gap-2 pr-2">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <div
                        key={i}
                        className="flex items-start gap-2 p-2 border rounded-md"
                      >
                        <Skeleton className="h-4 w-4 rounded" />
                        <div className="flex flex-col gap-2 flex-1">
                          <Skeleton className="h-3 w-32" />
                          <Skeleton className="h-2.5 w-48" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid gap-1 pr-2">
                    {visiblePermissions?.length < 1 ? (
                      <div className="text-xs text-muted-foreground text-center py-6">
                        No permissions found{' '}
                        {selectedState !== 'all' ? (
                          <>
                            in{' '}
                            <span className="text-primary">
                              {selectedState}
                            </span>{' '}
                            state
                          </>
                        ) : (
                          ''
                        )}
                      </div>
                    ) : (
                      visiblePermissions?.map((perm) => (
                        <label
                          key={perm._id}
                          className="flex items-start gap-2 p-2 border rounded-md hover:bg-accent/50 transition-colors cursor-pointer"
                        >
                          <Checkbox
                            checked={isSelected(perm._id)}
                            onCheckedChange={() => togglePermission(perm._id)}
                            className="mt-0.5"
                          />
                          <div className="text-xs space-y-0.5">
                            <p className="font-medium">
                              {perm.method}:{perm.name}
                            </p>
                            <p className="text-muted-foreground">
                              {perm.description}
                            </p>
                          </div>
                        </label>
                      ))
                    )}
                  </div>
                )}
              </ScrollArea>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default PermissionsSelector;
