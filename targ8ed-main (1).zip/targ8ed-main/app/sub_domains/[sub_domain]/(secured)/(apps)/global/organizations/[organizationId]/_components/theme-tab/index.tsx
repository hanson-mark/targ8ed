'use client';

import ThemeColorInput from '@/components/common/theme/theme-color-input';
import ThemeModeInput from '@/components/common/theme/theme-mode-input';
import ThemeRadiusInput from '@/components/common/theme/theme-radius-input';
import { api } from '@/convex/_generated/api';
import { IOrganization } from '@/convex/types/convex-types';
import {
  IThemeBorderRadius,
  IThemeColor,
  IThemeMode,
} from '@/convex/types/theme';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import toast from 'react-hot-toast';

interface IProps {
  organizationData?: IOrganization;
}

interface IChangeThemeInputParam {
  themeColor?: IThemeColor;
  themeMode?: IThemeMode;
  themeBorderRadius?: IThemeBorderRadius;
}

const ThemeTab = ({ organizationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasUpdateThemeAccess = checkPermission(permissions, [
    'updateOrgThemeConfig',
  ]);

  const { mutate: changeTheme, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.global.organizations.index.updateOrgThemeConfig
  );

  // Handler
  const changeThemeInputs = async (params: IChangeThemeInputParam) => {
    if (!hasUpdateThemeAccess) return;
    if (organizationData && params) {
      // Final config
      const finalThemeConfig: Required<IChangeThemeInputParam> = {
        themeColor: organizationData?.themeColor,
        themeMode: organizationData?.themeMode,
        themeBorderRadius: organizationData?.themeBorderRadius,
        ...(params || {}),
      };

      const toastId = 'changing-application-theme';
      toast.loading('Changing theme config...', { id: toastId });

      changeTheme({
        currentOrgId,
        inputs: { organizationId: organizationData?._id, ...finalThemeConfig },
      })
        .then((res) => {
          if (res?.success) {
            toast.success(
              res?.message || 'Successfully changed the theme config',
              { id: toastId }
            );
          } else {
            toast.error(res?.message || 'Failed to change the theme config', {
              id: toastId,
            });
          }
        })
        .catch((error) => {
          toast.error(error?.message || 'Failed to change the theme config', {
            id: toastId,
          });
        });
    }
  };

  return (
    <div className="space-y-7 mb-10">
      <ThemeColorInput
        disabled={isUpdating}
        label="Theme Color"
        selected={organizationData?.themeColor || 'default'}
        onSelect={(themeColor) => changeThemeInputs({ themeColor })}
      />

      <ThemeModeInput
        disabled={isUpdating}
        selected={organizationData?.themeMode || 'light'}
        onSelect={(themeMode) => changeThemeInputs({ themeMode })}
      />

      <ThemeRadiusInput
        disabled={isUpdating}
        label="Border Radius"
        selected={organizationData?.themeBorderRadius || 'default'}
        onSelect={(themeBorderRadius) =>
          changeThemeInputs({ themeBorderRadius })
        }
      />
    </div>
  );
};

export default ThemeTab;
