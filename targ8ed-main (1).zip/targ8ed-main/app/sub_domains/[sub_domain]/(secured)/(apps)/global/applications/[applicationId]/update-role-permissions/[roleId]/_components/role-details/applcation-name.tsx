'use client';
import { IApplication, IRole } from '@/convex/types/convex-types';
import { ChevronRightIcon } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';

interface IProps {
  application: IApplication;
  role: IRole;
  backLink: string;
}

const ApplicationName = ({ application, role, backLink }: IProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  const [nameMaxWidth, setNameMaxWidth] = useState(0);

  useEffect(() => {
    const calculateWidths = () => {
      if (containerRef?.current) {
        const containerWidth = containerRef?.current?.offsetWidth;
        const totalGap = 2 * 4; // 2 gaps * 4 (as using class gap-1)
        const chevronIconWidth = 24;
        const singleNameWidth =
          (containerWidth - totalGap - chevronIconWidth) / 2;
        setNameMaxWidth(singleNameWidth - 10);
      }
    };

    window.addEventListener('resize', calculateWidths);
    return () => window.removeEventListener('resize', calculateWidths);
  }, []);
  return (
    <div
      ref={containerRef}
      className="flex items-center gap-1 text-2xl font-medium"
    >
      <Link
        href={backLink}
        style={{ maxWidth: nameMaxWidth || '100%' }}
        className="truncate text-muted-foreground hover:text-foreground"
      >
        {application?.name}
      </Link>
      <ChevronRightIcon className="w-6 h-6" />{' '}
      <h1 style={{ maxWidth: nameMaxWidth || '100%' }} className="truncate">
        {role?.name}
      </h1>
    </div>
  );
};

export default ApplicationName;
