'use client';

import {
  getActionDropdownColumnConfig,
  getSortableTextColumnConfig,
} from '@/components/common/data-table/utils/table-column-generators';
import ProfileImage from '@/components/common/profile-image';
import StatusBadge from '@/components/common/status-badge';
import { Id } from '@/convex/_generated/dataModel';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { IApplication } from '@/convex/types/convex-types';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import { ColumnDef } from '@tanstack/react-table';
import { format } from 'date-fns';
import Link from 'next/link';

export const applicationTableColumns: ColumnDef<IApplication>[] = [
  getSortableTextColumnConfig({
    accessorKey: 'name',
    headerTitle: 'Name',
    formatter: (value, row) => (
      <Link
        href={`/${APPLICATION_KEYS.global}/applications/${row?.original?._id}`}
        className="flex items-center gap-2 max-w-44 truncate"
      >
        <ProfileImage
          imageURL={getConvexImageURL(row?.original?.imageId as Id<'_storage'>)}
          iconSize={7}
          iconType="application"
        />
        <span className="max-w-full truncate">{value as string}</span>
      </Link>
    ),
  }),
  getSortableTextColumnConfig({
    accessorKey: 'key',
    headerTitle: 'Key',
  }),
  getSortableTextColumnConfig({
    accessorKey: 'isActive',
    headerTitle: 'Status',
    formatter: (value) => (
      <div className={''}>
        <StatusBadge status={value === true ? 'active' : 'inactive'} />
      </div>
    ),
  }),
  getSortableTextColumnConfig({
    accessorKey: '_creationTime',
    headerTitle: 'Added At',
    formatter: (value) => (
      <div className="text-sm">
        {value ? format(new Date(value as string), 'dd-MMM-yyyy hh:mm a') : '-'}
      </div>
    ),
  }),
  getActionDropdownColumnConfig({
    headerTitle: 'Actions',
    menuItems: (rowData) => {
      return [
        {
          id: 'view',
          icon: 'SquareMenuIcon',
          label: 'View Details',
          type: 'link',
          href: `/${APPLICATION_KEYS.global}/applications/${rowData?._id}`,
        },
      ];
    },
  }),
];
