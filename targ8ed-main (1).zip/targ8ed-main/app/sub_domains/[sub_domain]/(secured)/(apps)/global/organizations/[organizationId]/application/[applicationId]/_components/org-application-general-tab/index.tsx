import ButtonWithTooltip from '@/components/common/button-with-tooltip';
import FormInput from '@/components/form/form-input';
import FormSwitch from '@/components/form/form-switch';
import FormTextarea from '@/components/form/form-textarea';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrgApplication } from '@/convex/types/convex-types';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { SquarePenIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import UpdateOrgApplicationNameDescriptionDialog from './update-org-application-name-description-dialog';

interface IProps {
  applicationData?: IOrgApplication;
}

const OrgApplicationGeneralTab = ({ applicationData }: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Checking permissions
  const hasUpdateStatusAccess = checkPermission(permissions, [
    'updateOrgApplicationStatus',
  ]);

  // States
  const [updateType, setUpdateType] = useState<'name' | 'description' | null>(
    null
  );

  // [ Mutation ] - Application Status Change
  const { mutate: updateStatus, isLoading: isUpdatingStatus } =
    useConvexMutation(
      api.functions.apps.global.applications.orgApplications
        .updateOrgApplicationStatus
    );

  const applicationDetailsFormZodSchema = z.object({
    _id: z.string().optional(),
    name: z.string().optional(),
    description: z.string().optional(),
    key: z.string().optional(),
    isActive: z.boolean().optional(),
  });

  // React hook form
  const formMethods = useZodForm(applicationDetailsFormZodSchema, {
    defaultValues: {
      _id: '',
      name: '',
      description: '',
      key: '',
      isActive: false,
    },
  });

  // Handles global application isActive change
  const onStatusChange = async (checked: boolean) => {
    formMethods.setValue('isActive', !checked);
    if (isUpdatingStatus) return;

    const toastId = 'change-org-status';
    toast.loading('Changing application status...', { id: toastId });
    updateStatus({
      currentOrgId,
      inputs: {
        applicationId: applicationData?.applicationId as Id<'applications'>,
        organizationId: applicationData?.organizationId as Id<'organizations'>,
        isActive: checked,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(
            res?.message || 'Successfully changed application status.',
            { id: toastId }
          );
        } else {
          toast.error(res?.message || 'Failed to change application status', {
            id: toastId,
          });
        }
      })
      .catch((error) => {
        toast.error(error?.message || 'Failed to change application status', {
          id: toastId,
        });
      });
  };

  // Updating form based on application data change
  useEffect(() => {
    formMethods.reset({
      _id: applicationData?._id,
      name: applicationData?.name,
      description: applicationData?.description,
      key: applicationData?.application?.key,
      isActive: applicationData?.isActive,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [applicationData]);

  return (
    <div className="space-y-4 mb-10">
      <FormProvider {...formMethods}>
        <form
          className="space-y-4 mt-8"
          onSubmit={formMethods.handleSubmit(() => {})}
        >
          <FormSwitch
            disabled={isUpdatingStatus || !hasUpdateStatusAccess}
            name="isActive"
            size="md"
            label={'Active'}
            labels={{
              checked: 'Active',
              unchecked: 'Inactive',
            }}
            description="Controls the application status."
            onCheckedChange={onStatusChange}
          />

          <FormInput disabled name="key" label="Key" />

          <div className="flex gap-2 items-end">
            <FormInput disabled name="name" label="Name" />
            <ButtonWithTooltip
              variant={'ghost'}
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80"
              tooltipContent="Update Name"
              onClick={() => setUpdateType('name')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>

          <div className="flex gap-2 items-start">
            <FormTextarea
              disabled
              name="description"
              label="Description"
              classNames={{
                input: 'resize-none',
              }}
            />
            <ButtonWithTooltip
              variant={'ghost'}
              className="hover:text-primary h-10 w-10 px-0 bg-muted hover:bg-muted/80 mt-4.5"
              tooltipContent="Update Description"
              onClick={() => setUpdateType('description')}
            >
              <SquarePenIcon />
            </ButtonWithTooltip>
          </div>
        </form>
      </FormProvider>
      <UpdateOrgApplicationNameDescriptionDialog
        applicationData={applicationData}
        showDialog={!!updateType}
        setShowDialog={(state) => !state && setUpdateType(null)}
        updateType={updateType}
      />
    </div>
  );
};

export default OrgApplicationGeneralTab;
