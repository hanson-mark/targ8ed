'use client';
import GlobalItemDetailsLoader from '@/components/common/loaders/global-item-details-loader';
import Loader from '@/components/common/loaders/loader';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useSubdomainStore from '@/stores/subdomainStore';
import { useParams } from 'next/navigation';
import UserDetails from './_components/user-details';

const UserDetailsPageForAdmin = () => {
  const params = useParams();

  // Get user config from subdomain store
  const { currentOrgId } = useSubdomainStore();

  const {
    data: userData,
    isLoading,
    error,
  } = useConvexQuery(api.functions.apps.global.users.index.readUserDetails, {
    currentOrgId,
    inputs: { userId: params?.userId as Id<'users'> },
  });

  if (isLoading) {
    return (
      <Loader variant="dashboard">
        <GlobalItemDetailsLoader />
      </Loader>
    );
  }

  if (error || !userData?._id) {
    return (
      <p className="text-center text-destructive py-10">
        ⚠️ {error?.message || 'Failed to load user details.'}
      </p>
    );
  }

  return <UserDetails userData={userData} />;
};

export default UserDetailsPageForAdmin;
