import { z } from 'zod';

export const applicationDetailsFormZodSchema = z.object({
  _id: z.string().optional(),
  name: z.string().optional(),
  description: z.string().optional(),
  key: z.string().optional(),
  isActive: z.boolean().optional(),
});
