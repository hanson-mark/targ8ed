'use client';

import CustomDialog from '@/components/common/custom-dialog';
import FormComboBox from '@/components/form/form-combo-box';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import { IOrganization } from '@/convex/types/convex-types';
import { applicationIdZodSchema } from '@/convex/validations/common';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface IProps {
  organizationData?: IOrganization;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
}

const CreateApplicationAccessToOrganizationDialog = ({
  organizationData,
  showDialog,
  setShowDialog,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();
  const { permissions } = useUserRolesStore();

  // Permissions checking
  const hasReadAvailableListAccess = checkPermission(permissions, [
    'readAvailableApplicationListToAddInOrg',
  ]);
  const hasCreateOrgApplicationAccess = checkPermission(permissions, [
    'createApplicationAccessOrg',
  ]);

  const [searchInput, setSearchInput] = useState('');

  const {
    data: applications = [],
    isLoading: isAppsLoading,
    error,
  } = useConvexQuery(
    api.functions.apps.global.applications.orgApplications
      .readAvailableApplicationListToAddInOrg,
    {
      currentOrgId,
      inputs: {
        organizationId: organizationData?._id as Id<'organizations'>,
        search: searchInput,
      },
    }
  );

  const { mutate: connectAppToOrg, isLoading: isConnecting } =
    useConvexMutation(
      api.functions.apps.global.applications.orgApplications
        .createApplicationAccessOrg
    );

  const validationSchema = z.object({
    applicationId: applicationIdZodSchema,
  });

  const formMethods = useZodForm(validationSchema, {
    defaultValues: { applicationId: '' },
  });

  const onOpenChange = (open: boolean) => {
    formMethods.reset();
    setShowDialog(open);
  };

  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    if (isConnecting) return;

    const toastId = 'connecting-application';
    toast.loading('Connecting application...', { id: toastId });

    connectAppToOrg({
      currentOrgId,
      inputs: {
        applicationId: values.applicationId,
        organizationId: organizationData?._id as Id<'organizations'>,
      },
    })
      .then((res) => {
        if (res?.success) {
          toast.success(res?.message || 'Application connected successfully', {
            id: toastId,
          });

          onOpenChange(false);
        } else {
          toast.error(res?.message || 'Failed to connect application', {
            id: toastId,
          });
        }
      })
      .catch((err) => {
        console.error(err);
        toast.error(err?.message || 'Failed to connect application', {
          id: toastId,
        });
      });
  };

  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Connect Application"
      description={
        error
          ? `⚠️ ${error?.message}`
          : !hasReadAvailableListAccess
            ? '⚠️ You do not have access to see available application list to connect with organizations'
            : !hasCreateOrgApplicationAccess
              ? '⚠️ You do not have access to add application access for organization'
              : 'Select an application to connect it to this organization.'
      }
    >
      {!hasReadAvailableListAccess || !hasCreateOrgApplicationAccess ? null : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormComboBox
                disabled={isConnecting}
                isSearching={isAppsLoading}
                name="applicationId"
                label="Select Application"
                placeholder="Search and select application..."
                onSearch={setSearchInput}
                searchInputDebounceDelay={500}
                options={(applications || [])?.map((app) => ({
                  value: app._id,
                  label: app.name,
                }))}
              />
            </div>
            <DialogFooter>
              <Button type="submit" disabled={isConnecting}>
                {isConnecting ? 'Connecting...' : 'Connect'}
              </Button>
            </DialogFooter>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default CreateApplicationAccessToOrganizationDialog;
