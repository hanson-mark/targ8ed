import CustomDialog from '@/components/common/custom-dialog';
import Loader from '@/components/common/loaders/loader';
import FormDropdown from '@/components/form/form-dropdown';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import useZodForm from '@/hooks/use-zod-form';
import { getConvexImageURL } from '@/lib/data-formatters/url-formatter';
import useSubdomainStore from '@/stores/subdomainStore';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { IInvitedOrgApplication } from './invite-user-to-organization-dialog';

interface IProps {
  organizationId: Id<'organizations'>;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
  invitedApplications: IInvitedOrgApplication[];
  onAssignNewApplication: (invitedApp: IInvitedOrgApplication) => void;
}

const AssignApplicationToInvitationDialog = ({
  organizationId,
  showDialog,
  setShowDialog,
  invitedApplications,
  onAssignNewApplication,
}: IProps) => {
  const { currentOrgId } = useSubdomainStore();

  // Queries
  const {
    data: applicationsRes,
    error,
    isLoading: isApplicationsLoading,
  } = useConvexQuery(
    api.functions.apps.global.users.orgUserInvitations
      .readAvailableApplicationsToInviteUser,
    {
      currentOrgId,
      inputs: { organizationId: organizationId as Id<'organizations'> },
    }
  );

  // Formatting few data
  const getAvailableApplications = () => {
    if (!applicationsRes) return [];

    const invitedApplicationIDs = invitedApplications?.map(
      (item) => item?.application?._id
    );
    const availableApplicationList = applicationsRes.filter(
      (item) => !invitedApplicationIDs.includes(item?.applicationId)
    );

    return availableApplicationList;
  };
  const availableApplications = getAvailableApplications();
  const applicationOptions = (availableApplications || [])?.map(
    (application) => {
      const option = {
        value: application?.applicationId || '',
        label: application?.name || '',
      };
      return option;
    }
  );

  // Validation schema
  const validationSchema = z.object({
    applicationId: z
      .string({ required_error: 'Application is required.' })
      .min(1, 'Application is required.') as unknown as z.ZodType<
      Id<'applications'>
    >,
    roleId: z
      .string({ required_error: 'Role is required.' })
      .min(1, 'Role is required.') as unknown as z.ZodType<Id<'roles'>>,
  });

  // Form
  const formMethods = useZodForm(validationSchema, {
    defaultValues: { applicationId: '', roleId: '' },
  });

  // Form Values
  const applicationId = formMethods.watch('applicationId');
  const selectedApplication = (availableApplications || [])?.find(
    (item) => item?.applicationId === applicationId
  );

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: z.infer<typeof validationSchema>) => {
    const toastId = 'assign-application';

    toast.loading('Assigning application access...', { id: toastId });

    const assignedApplication = (availableApplications || [])?.find(
      (item) => item?.applicationId === values?.applicationId
    );
    const application = {
      _id: assignedApplication?.applicationId as Id<'applications'>,
      name: assignedApplication?.name as string,
      image:
        getConvexImageURL(
          assignedApplication?.application?.imageId as Id<'_storage'>
        ) || '',
    };
    const role = assignedApplication?.roles?.find(
      (item) => item?._id === values?.roleId
    );

    if (application?._id && role) {
      setTimeout(() => {
        onAssignNewApplication({ application, role });
        toast.success('Assigned application access', { id: toastId });
        onOpenChange(false);
      }, 300);
    } else {
      toast.success('Failed to assign application access', { id: toastId });
    }
  };

  // Reset form when dialog opens
  useEffect(() => {
    formMethods.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Assign An Application Access to User"
      description="Select an application to assign this user. They will gain access to the application after accepting invitation."
    >
      {isApplicationsLoading ? (
        <Loader
          variant="minimal"
          message="Loading available applications for the user..."
        />
      ) : error ? (
        <div className="py-6 text-center  text-destructive">
          ⚠️ {error?.message || 'Failed to get available applications'}
        </div>
      ) : (availableApplications || [])?.length === 0 ? (
        <div className="py-6 text-center text-muted-foreground">
          🎉 No applications in the organization. Or, the user is already
          invited to all available applications in the organization.
        </div>
      ) : (
        <FormProvider {...formMethods}>
          <form onSubmit={formMethods.handleSubmit(onSubmit)}>
            <div className="grid gap-4 pb-6">
              <FormDropdown
                disabled={isApplicationsLoading}
                name="applicationId"
                label="Select Application"
                placeholder="Select an application..."
                options={applicationOptions}
              />

              {applicationId && selectedApplication ? (
                <FormDropdown
                  disabled={isApplicationsLoading}
                  name="roleId"
                  label="Select Role"
                  placeholder="Select a role..."
                  noOptionsMessage="No roles found"
                  options={(selectedApplication?.roles || [])?.map((role) => ({
                    value: role?._id || '',
                    label: role?.name || '',
                  }))}
                />
              ) : null}
            </div>
            <DialogFooter>
              <Button
                disabled={!applicationId || !selectedApplication}
                type="submit"
              >
                {'Assign Application Access'}
              </Button>
            </DialogFooter>
          </form>
        </FormProvider>
      )}
    </CustomDialog>
  );
};

export default AssignApplicationToInvitationDialog;
