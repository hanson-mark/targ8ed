import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { api } from '@/convex/_generated/api';
import { Doc } from '@/convex/_generated/dataModel';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import useSubdomainStore from '@/stores/subdomainStore';
import { useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedQuickNote?: Doc<'quickNote'>;
}

const schema = z.object({
  title: z
    .string()
    .min(1, 'Title is required')
    .min(3, 'Minimum 3 characters are required.'),
  content: z
    .string()
    .min(1, 'Content is required')
    .min(3, 'Minimum 3 characters are required.'),
});

export default function CreateOrUpdateNoteDialog({
  open,
  onOpenChange,
  selectedQuickNote,
}: Props) {
  const { currentOrgId } = useSubdomainStore();
  const isUpdatingMode = selectedQuickNote && '_id' in selectedQuickNote;

  const { mutate: createNote, isLoading: isCreating } = useConvexMutation(
    api.functions.apps.quickNote.index.createNote
  );
  const { mutate: updateNote, isLoading: isUpdating } = useConvexMutation(
    api.functions.apps.quickNote.index.updateNote
  );

  const formMethods = useZodForm(schema, {
    defaultValues: {
      title: selectedQuickNote?.title || '',
      content: selectedQuickNote?.content || '',
    },
  });

  const isSubmitting = isCreating || isUpdating;

  const handleSubmit = async (values: z.infer<typeof schema>) => {
    try {
      const toastId = 'create-update-note';
      toast.loading(
        isUpdatingMode ? 'Creating a note...' : 'Updating the note...',
        {
          id: toastId,
        }
      );
      if (isUpdatingMode) {
        const response = await updateNote({
          currentOrgId,
          inputs: {
            noteId: selectedQuickNote!._id!,
            title: values.title,
            content: values.content,
          },
        });
        if (response?.success) {
          toast.success(response?.message || 'Note updated', { id: toastId });
          onOpenChange(false);
        } else {
          toast.error(response?.message || 'Failed to update', { id: toastId });
        }
      } else {
        const response = await createNote({
          currentOrgId,
          inputs: { title: values.title, content: values.content },
        });
        if (response?.success) {
          toast.success(response?.message || 'Note created', { id: toastId });
          onOpenChange(false);
        } else {
          toast.error(response?.message || 'Failed to create', { id: toastId });
        }
      }
    } catch {
      toast.error('Something went wrong');
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    formMethods.reset({ title: '', content: '' });
  };

  useEffect(() => {
    if (selectedQuickNote && '_id' in selectedQuickNote) {
      formMethods.reset({
        title: selectedQuickNote?.title,
        content: selectedQuickNote?.content,
      });
    }
  }, [formMethods, selectedQuickNote]);

  return (
    <CustomDialog
      isOpen={open}
      onOpenChange={handleClose}
      title={isUpdatingMode ? 'Update Note' : 'Create Note'}
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(handleSubmit)}>
          <div className="space-y-4 pb-6">
            <FormInput name="title" label="Title" disabled={isSubmitting} />
            <FormTextarea
              name="content"
              label="Content"
              disabled={isSubmitting}
            />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting
                ? isUpdatingMode
                  ? 'Updating...'
                  : 'Creating...'
                : isUpdatingMode
                  ? 'Update Note'
                  : 'Create Note'}
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
}
