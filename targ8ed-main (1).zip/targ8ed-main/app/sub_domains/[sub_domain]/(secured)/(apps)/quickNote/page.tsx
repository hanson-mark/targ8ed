'use client';

import Loader from '@/components/common/loaders/loader';
import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import PermissionGuard from '@/components/permissions/permission-guard';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card';
import { api } from '@/convex/_generated/api';
import { Doc, Id } from '@/convex/_generated/dataModel';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useConvexQuery from '@/hooks/convex/use-convex-query';
import { checkPermission } from '@/lib/data-formatters/permissions';
import useSubdomainStore from '@/stores/subdomainStore';
import useUserRolesStore from '@/stores/useUserRolesStore';
import { formatDistanceToNow } from 'date-fns';
import { PencilIcon, PlusCircleIcon, Trash2Icon } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import CreateOrUpdateNoteDialog from './_components/create-or-update-note-dialog';

const QuickNotePage = () => {
  // Stores
  const { userConfig, currentOrgId } = useSubdomainStore();
  const userId = userConfig?.globalUser?._id as Id<'users'>;

  // States
  const [dialogData, setDialogData] = useState<Doc<'quickNote'> | null>(null);
  const [showNoteDialog, setShowNoteDialog] = useState(false);

  // Checking permissions
  const { permissions } = useUserRolesStore();
  const hasUpdateNoteAccess = checkPermission(permissions || [], [
    'updateNote',
  ]);
  const hasRemoveNoteAccess = checkPermission(permissions || [], [
    'deleteNote',
  ]);

  const {
    data: notes = [],
    isLoading,
    error,
  } = useConvexQuery(api.functions.apps.quickNote.index.readAllNotes, {
    currentOrgId,
    inputs: {},
  });

  const { mutate: deleteNote, isLoading: isRemoving } = useConvexMutation(
    api.functions.apps.quickNote.index.deleteNote
  );

  const handleAddNote = () => {
    setDialogData(null);
    setShowNoteDialog(true);
  };

  const handleUpdate = (note: Doc<'quickNote'>) => {
    setDialogData(note);
    setShowNoteDialog(true);
  };

  const handleDelete = async (noteId: Id<'quickNote'>) => {
    if (!userId || !currentOrgId) {
      toast.error('Missing user or organization information.');
      return;
    }

    const toastId = 'removing';
    try {
      toast.loading('Deleting the note...', { id: toastId });
      const response = await deleteNote({
        currentOrgId,
        inputs: { noteId },
      });

      if (response?.success) {
        toast.success(response.message || 'Note deleted successfully', {
          id: toastId,
        });
      } else {
        toast.error(response?.message || 'Failed to delete note', {
          id: toastId,
        });
      }
    } catch (err) {
      toast.error((err as Error).message || 'Failed to delete note', {
        id: toastId,
      });
    }
  };

  if (isLoading) return <Loader variant="dashboard" />;
  if (error) {
    return (
      <UnauthorizedWarning
        message={error?.message || 'Failed to load quick notes.'}
      />
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between gap-4 py-4">
        <h2 className="text-2xl font-semibold">Quick Notes</h2>
        <PermissionGuard fnNames={['createNote', 'updateNote']}>
          <Button onClick={handleAddNote}>
            <PlusCircleIcon className="mr-2 h-4 w-4" />
            Create Note
          </Button>
        </PermissionGuard>
      </div>

      {notes.length === 0 ? (
        <div className="py-20 text-center text-muted-foreground">
          No notes found.
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {notes.map((note) => (
            <Card
              key={note._id}
              className="flex flex-col justify-between shadow-sm"
            >
              <CardHeader>
                <h3 className="line-clamp-1 text-lg font-semibold">
                  {note.title}
                </h3>
              </CardHeader>
              <CardContent>
                <p className="line-clamp-4 whitespace-pre-wrap text-sm text-muted-foreground">
                  {note.content}
                </p>
              </CardContent>
              <CardFooter className="flex justify-between items-center gap-2 text-xs text-muted-foreground">
                <span>
                  {note.updatedAt
                    ? `Updated ${formatDistanceToNow(new Date(note.updatedAt), {
                        addSuffix: true,
                      })}`
                    : `Created ${formatDistanceToNow(
                        new Date(note._creationTime),
                        {
                          addSuffix: true,
                        }
                      )}`}
                </span>

                <div className="flex gap-1">
                  {hasUpdateNoteAccess && (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleUpdate(note)}
                      className="text-muted-foreground"
                    >
                      <PencilIcon className="h-4 w-4" />
                    </Button>
                  )}
                  {hasRemoveNoteAccess && (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => handleDelete(note._id)}
                      className="text-destructive"
                      disabled={isRemoving}
                    >
                      <Trash2Icon className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <PermissionGuard fnNames={['createNote', 'updateNote']}>
        <CreateOrUpdateNoteDialog
          open={showNoteDialog}
          selectedQuickNote={dialogData || undefined}
          onOpenChange={(open) => {
            setShowNoteDialog(open);
            if (!open) {
              setDialogData(null);
            }
          }}
        />
      </PermissionGuard>
    </div>
  );
};

export default QuickNotePage;
