import { getAuthToken } from '@/actions/auth/user';
import ApplicationDashboardLayout from '@/components/layouts/application-dashboard-layout';
import { api } from '@/convex/_generated/api';
import { APPLICATION_KEYS } from '@/convex/constants/applicationKey';
import { getSubDomainInServer } from '@/lib/app-config';
import { preloadQuery } from 'convex/nextjs';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const QuickNoteLayout = async ({ children }: IProps) => {
  const token = await getAuthToken();
  const currentOrgSubdomain = await getSubDomainInServer();
  const preloadedUserApplication = await preloadQuery(
    api.functions.apps.global.applications.userApplications
      .readUserApplicationByKey,
    { currentOrgSubdomain, inputs: { key: APPLICATION_KEYS.quickNote } },
    { token }
  );
  return (
    <ApplicationDashboardLayout
      preloadedUserApplication={preloadedUserApplication}
    >
      {children}
    </ApplicationDashboardLayout>
  );
};

export default QuickNoteLayout;
