import { getAuthToken } from '@/actions/auth/user';
import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import { api } from '@/convex/_generated/api';
import { getSubDomainInServer } from '@/lib/app-config';
import { preloadQuery } from 'convex/nextjs';
import FallbackPage from './_components/fallback-page';

interface IProps {
  params: Promise<{
    fallback_applications: string[];
    subdomain: string;
  }>;
}

const FallbackApplicationsPage = async (props: IProps) => {
  const params = await props.params;
  const applicationKey = Array.isArray(params?.fallback_applications)
    ? params.fallback_applications[0]
    : '';

  const token = await getAuthToken();
  const currentOrgSubdomain = await getSubDomainInServer();

  if (!currentOrgSubdomain || !applicationKey) {
    return (
      <UnauthorizedWarning
        title="Invalid Page URL"
        message="Your entered page URL is invalid. Please check your URL or contact support."
      />
    );
  }

  const preloadedUserApplication = await preloadQuery(
    api.functions.apps.global.applications.userApplications
      .readUserApplicationByKey,
    { currentOrgSubdomain, inputs: { key: applicationKey } },
    { token }
  );

  return <FallbackPage preloadedUserApplication={preloadedUserApplication} />;
};

export default FallbackApplicationsPage;
