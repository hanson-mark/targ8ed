'use client';
import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import ApplicationDashboardLayout from '@/components/layouts/application-dashboard-layout';
import { api } from '@/convex/_generated/api';
import { Preloaded } from 'convex/react';
import { useRouter } from 'next/navigation';

const FallbackPage = ({
  preloadedUserApplication,
}: {
  preloadedUserApplication: Preloaded<
    typeof api.functions.apps.global.applications.userApplications.readUserApplicationByKey
  >;
}) => {
  const router = useRouter();

  return (
    <ApplicationDashboardLayout
      preloadedUserApplication={preloadedUserApplication}
    >
      <UnauthorizedWarning
        title="Pages are not ready"
        buttonText="Go home"
        onButtonClick={() => router.push('/')}
      />
    </ApplicationDashboardLayout>
  );
};

export default FallbackPage;
