import { lastOpenedApplicationKeyName } from '@/convex/constants/common';
import { cookies } from 'next/headers';
import OrgHomePage from './_components/org-home-page';

const HomePage = async () => {
  const lastOpenedApplicationKey = (await cookies()).get(
    lastOpenedApplicationKeyName
  )?.value;

  return (
    <OrgHomePage lastOpenedApplicationKey={lastOpenedApplicationKey || ''} />
  );
};

export default HomePage;
