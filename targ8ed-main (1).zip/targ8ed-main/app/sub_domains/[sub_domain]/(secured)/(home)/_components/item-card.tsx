import { Card, CardContent } from '@/components/ui/card';
import { ChevronRight, UserIcon } from 'lucide-react';
import Link from 'next/link';

interface IProps {
  id: string;
  title: string;
  subtitle: string;
  link: string;
}

const ItemCard = ({ id, title, subtitle, link }: IProps) => {
  return (
    <Link key={id} href={link || '/'}>
      <Card className="w-72 cursor-pointer hover:shadow-md transition py-0  shadow-none">
        <CardContent className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-3 overflow-hidden flex-1">
            <div className="bg-primary text-muted-foreground p-2 rounded-md">
              <UserIcon className="w-5 h-5 text-background" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{title}</p>
              <p className="text-xs font-medium text-muted-foreground truncate">
                {subtitle}
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 flex-shrink-0" />
        </CardContent>
      </Card>
    </Link>
  );
};

export default ItemCard;
