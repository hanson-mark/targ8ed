'use client';
import Loader from '@/components/common/loaders/loader';
import useSubdomainStore from '@/stores/subdomainStore';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

interface IProps {
  lastOpenedApplicationKey: string;
}

const OrgHomePage = ({ lastOpenedApplicationKey }: IProps) => {
  const router = useRouter();
  const { userConfig } = useSubdomainStore();

  const applications = userConfig?.applications || [];
  const lastOpenedApplication = lastOpenedApplicationKey
    ? applications.find((app) => app.key === lastOpenedApplicationKey)
    : null;
  const activeApplication =
    lastOpenedApplication || (applications.length > 0 ? applications[0] : null);

  useEffect(() => {
    if (!userConfig) return;
    if (activeApplication) {
      router.push(`/${activeApplication.key}`);
    } else {
      if (userConfig?.isOrgAdmin) {
        router.push('/settings/general');
      } else {
        router.push('/profile');
      }
    }
  }, [activeApplication, router, userConfig]);

  return <Loader variant="dashboard" />;
};

export default OrgHomePage;
