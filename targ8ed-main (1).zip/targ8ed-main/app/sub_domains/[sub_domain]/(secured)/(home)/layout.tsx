'use client';
import Loader from '@/components/common/loaders/loader';
import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import { useDashboardAccessControl } from '@/components/layouts/dashboard-layout/hooks/use-dashboard-access-control';
import useThemeConfig from '@/components/layouts/dashboard-layout/hooks/use-theme-config';
import useSubdomainStore from '@/stores/subdomainStore';
import { ReactNode } from 'react';

interface IProps {
  children: ReactNode;
}

const OrgLandingPageLayout = ({ children }: IProps) => {
  const { userConfig } = useSubdomainStore();
  const { isLoading, hasAnyWarning, warningContent } =
    useDashboardAccessControl('subdomain-dashboard', userConfig);

  // Theme configuration
  useThemeConfig();

  if (isLoading) {
    return <Loader variant="screen" />;
  }

  if (hasAnyWarning) {
    return <UnauthorizedWarning {...warningContent} />;
  }

  return children;
};

export default OrgLandingPageLayout;
