import LoginWithClerk from '@/components/common/auth/login';

export default function SignInPage() {
  return <LoginWithClerk />;
}
