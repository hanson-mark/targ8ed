import { decryptEmail } from '@/actions/resend/encode-decode-email';
import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import { api } from '@/convex/_generated/api';
import { emailZodSchema } from '@/convex/validations/common';
import { getSubDomainInServer } from '@/lib/app-config';
import { auth } from '@clerk/nextjs/server';
import { preloadQuery } from 'convex/nextjs';
import InvitationConfirmation from './_components/invitation-confirmation';
import SignedInWarning from './_components/signed-in-warning';

interface IProps {
  searchParams: Promise<{
    token?: string;
    e?: string;
  }>;
}

const InvitationPage = async ({ searchParams }: IProps) => {
  const params = await searchParams;

  const subdomain = await getSubDomainInServer();
  const token = params?.token;
  const tempEmail = await decryptEmail(params?.e || '');
  const { data: email, success: hasEmail } =
    emailZodSchema.safeParse(tempEmail);

  if (!subdomain || !email || !hasEmail || !token) {
    return (
      <UnauthorizedWarning
        title="Invalid Link"
        message="This invitation link is either broken or invalid."
      />
    );
  }

  const { userId } = await auth();

  // If already logged in
  if (userId) {
    return <SignedInWarning />;
  }

  const preloadedInvitation = await preloadQuery(
    api.functions.apps.global.users.orgUserInvitations.readInvitationDetails,
    { subdomain, email, token }
  );

  return <InvitationConfirmation preloadedInvitation={preloadedInvitation} />;
};

export default InvitationPage;
