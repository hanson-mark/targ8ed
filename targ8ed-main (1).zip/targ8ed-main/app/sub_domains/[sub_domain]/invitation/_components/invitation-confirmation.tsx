'use client';

import { createClerkUser } from '@/actions/auth/user';
import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import { IHonoResponse } from '@/types/hono';
import { Preloaded, usePreloadedQuery } from 'convex/react';
import { CheckCircle2Icon, XCircleIcon } from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';

interface IProps {
  preloadedInvitation: Preloaded<
    typeof api.functions.apps.global.users.orgUserInvitations.readInvitationDetails
  >;
}

const InvitationConfirmation = ({ preloadedInvitation }: IProps) => {
  const invitation = usePreloadedQuery(preloadedInvitation);

  const {
    mutate: acceptInvitation,
    isLoading,
    isSuccess,
  } = useConvexMutation(
    api.functions.apps.global.users.orgUserInvitations
      .updateInvitationStatusToAccepted
  );

  const handleAccept = async () => {
    const invitationData = 'data' in invitation ? invitation.data : undefined;
    if (!invitationData) return;

    const toastId = toast.loading('Accepting invitation...');
    try {
      // 1. Create Clerk user first
      const clerkUserResponse = await createClerkUser({
        email: invitationData.email,
        name: invitationData.name,
      });

      const clerkUser = clerkUserResponse as IHonoResponse<{
        id: string;
        imageUrl: string;
      }>;

      if (!clerkUser?.success || !clerkUser?.data) {
        toast.error(clerkUser?.message || 'Failed to add user in Clerk.', {
          id: toastId,
        });
        return;
      }

      // 2. Accept the invitation (Convex mutation)
      await acceptInvitation({
        invitationId: invitationData._id,
        organizationId: invitationData.organizationId,
        email: invitationData.email,
        token: invitationData.token,
      });

      toast.success('Invitation accepted! You can now sign in.', {
        id: toastId,
      });
    } catch (error) {
      toast.error((error as Error)?.message || 'Something went wrong.', {
        id: toastId,
      });
    }
  };

  const isAccepted = (invitation?.message || '')
    .toLowerCase()
    .includes('accepted');

  if (!('data' in invitation) && !isAccepted && !isSuccess) {
    return (
      <UnauthorizedWarning
        title="Invalid or Expired Link"
        message={
          invitation?.message ||
          'Your invitation link is not valid or may have expired.'
        }
      />
    );
  }

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-muted flex items-center justify-center p-3 sm:p-6">
        <div className="bg-background rounded-2xl shadow-xl p-5 sm:p-12 max-w-lg w-full text-center space-y-5">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <CheckCircle2Icon className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            Invitation Accepted!
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            You&apos;ve successfully accepted the invitation. You can now sign
            in to your account.
          </p>
          <Link href="/sign-in">
            <Button className="px-6 py-3 shadow-md hover:shadow-lg">
              Go to Sign In
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  if (!('data' in invitation) || isAccepted) {
    return (
      <div className="min-h-screen bg-muted flex items-center justify-center p-3 sm:p-6">
        <div className="bg-background rounded-2xl shadow-xl p-5 sm:p-12 max-w-lg w-full text-center space-y-5">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <XCircleIcon className="w-10 h-10 text-destructive" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            {isAccepted
              ? 'The link is already used or invalid!'
              : 'Invalid link'}
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            {invitation?.message}
          </p>
          {isAccepted && (
            <Link href="/sign-in">
              <Button className="px-6 py-3 shadow-md hover:shadow-lg">
                Go to Sign In
              </Button>
            </Link>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted flex items-center justify-center p-3 sm:p-6">
      <div className="bg-background rounded-2xl shadow-xl p-5 sm:p-12 max-w-lg w-full text-center space-y-5">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
          <CheckCircle2Icon className="w-10 h-10 text-green-600" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
          You&apos;re Invited!
        </h1>
        <p className="text-muted-foreground text-sm sm:text-base ">
          You&apos;ve been invited to join{' '}
          <span className="font-semibold">
            {invitation?.data?.organization?.name}
          </span>{' '}
          as <span className="font-semibold">{invitation?.data?.name}</span> (
          {invitation?.data?.email})
        </p>
        <Button
          onClick={handleAccept}
          disabled={isLoading || isSuccess}
          className="w-full max-w-xs mx-auto mt-2 py-3 shadow-md hover:shadow-lg"
        >
          {isLoading ? 'Accepting...' : 'Accept Invitation'}
        </Button>
      </div>
    </div>
  );
};

export default InvitationConfirmation;
