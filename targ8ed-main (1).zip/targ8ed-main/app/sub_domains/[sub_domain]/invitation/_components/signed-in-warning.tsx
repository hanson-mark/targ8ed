'use client';

import UnauthorizedWarning from '@/components/common/unauthorized-warning';
import { useClerk } from '@clerk/nextjs';
import { useRouter } from 'next/navigation';

const SignedInWarning = () => {
  const { signOut } = useClerk();
  const router = useRouter();

  return (
    <UnauthorizedWarning
      title="You're Already Signed In"
      message="You are already signed in and cannot accept this invitation. Please log out and try again with the correct invitation link."
      buttonText="Logout"
      onButtonClick={async () => {
        await signOut();
        router.push('/sign-in');
      }}
    />
  );
};

export default SignedInWarning;
