export { DELETE, GET, PATCH, POST, PUT } from '@/hono-app';

export const runtime = 'edge';
