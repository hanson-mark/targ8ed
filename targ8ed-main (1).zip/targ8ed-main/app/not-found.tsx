import NotFoundWarning from '@/components/common/not-found-warning';

const NotFound = () => {
  return <NotFoundWarning />;
};

export default NotFound;
