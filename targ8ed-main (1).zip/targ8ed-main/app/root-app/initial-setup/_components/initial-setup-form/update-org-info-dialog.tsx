import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import useZodForm from '@/hooks/use-zod-form';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import { z } from 'zod';
import { orgDataValidationSchema } from '../../utils/validation-schema';

type IOrgInputs = z.infer<typeof orgDataValidationSchema>;
interface IProps {
  disabled: boolean;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
  defaultValues: IOrgInputs;
  onUpdate: (values: IOrgInputs) => void;
}

const UpdateOrgInfoDialog = ({
  disabled,
  showDialog,
  defaultValues,
  setShowDialog,
  onUpdate,
}: IProps) => {
  // Validation schema

  // Form
  const formMethods = useZodForm(orgDataValidationSchema, {
    defaultValues: {
      organizationName: '',
      organizationDescription: '',
      organizationSubdomain: '',
    },
  });

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: IOrgInputs) => {
    if (disabled) return;
    onUpdate(values);
    onOpenChange(false);
  };

  useEffect(() => {
    formMethods.reset(defaultValues);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Update Organization Info"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={disabled}
              name="organizationName"
              label="Organization Name"
              placeholder="Enter organization name"
            />
            <FormInput
              disabled
              name="organizationSubdomain"
              label="Subdomain"
              placeholder="Enter subdomain here"
              description={
                <>
                  {' '}
                  The subdomain is fixed as{' '}
                  <span className="text-primary font-semibold">
                    {ROOT_CONFIG.org.subdomain}
                  </span>{' '}
                  and cannot be changed.
                </>
              }
            />
            <FormTextarea
              disabled={disabled}
              name="organizationDescription"
              label="Description"
              placeholder="Enter organization description"
            />
          </div>
          <DialogFooter>
            <Button disabled={disabled} type="submit">
              Update
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default UpdateOrgInfoDialog;
