'use client';

import { createClerkUser } from '@/actions/auth/user';
import { sendInitialSetupOTP } from '@/actions/resend/otp-manages';
import Loader from '@/components/common/loaders/loader';
import FormInput from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from '@/components/ui/input-otp';
import { api } from '@/convex/_generated/api';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { useConvexMutation } from '@/hooks/convex/use-convex-mutation';
import useZodForm from '@/hooks/use-zod-form';
import { cn } from '@/lib/utils';
import { Preloaded, usePreloadedQuery } from 'convex/react';
import { REGEXP_ONLY_DIGITS } from 'input-otp';
import { ArrowLeftIcon, EditIcon, LoaderIcon, SendIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import { FormProvider } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import {
  defaultValuesOfInitialSetupForm,
  getInitialSetupDataValidationSchema,
  initialSetupDataValidationSchema,
} from '../../utils/validation-schema';
import { InfoCard } from './info-card';
import InitialSetupSuccess from './initial-setup-success';
import UpdateAppInfoDialog from './update-app-info-dialog';
import UpdateOrgInfoDialog from './update-org-info-dialog';

interface IProps {
  globalOrgLink: string;
  preloadedInitialSetupCheck: Preloaded<
    typeof api.functions.apps.global.initialSetup.index.checkHasInitialSetup
  >;
}
type IFormValues = z.infer<typeof initialSetupDataValidationSchema>;

const RESEND_TIMEOUT = 120; // 2 minutes

const InitialSetupForm = ({
  globalOrgLink,
  preloadedInitialSetupCheck,
}: IProps) => {
  const preloadedData = usePreloadedQuery(preloadedInitialSetupCheck);

  // States of Dialog
  const [showOrgInfoDialog, setShowOrgInfoDialog] = useState(false);
  const [showAppInfoDialog, setShowAppInfoDialog] = useState(false);

  // States of clerk
  const [isCreatingClerkUser, setIsCreatingClerkUser] = useState(false);
  const [isClerkUserCreationSuccess, setIsClerkUserCreationSuccess] =
    useState(false);

  // States of
  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [resendTimer, setResendTimer] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  // [ Mutation ] - For sending OTP
  const { isLoading: isGeneratingOTP, mutate: startGeneratingOTP } =
    useConvexMutation(
      api.functions.apps.global.initialSetup.index
        .generateOtpToVerifyEmailForInitialSetup
    );

  // [ Mutation ] - For initial setup
  const {
    isLoading: isStartedInitialSetup,
    mutate: startInitialSetup,
    isSuccess,
  } = useConvexMutation(
    api.functions.apps.global.initialSetup.index.startInitialSetup
  );

  const formMethods = useZodForm(getInitialSetupDataValidationSchema(step), {
    defaultValues: defaultValuesOfInitialSetupForm,
  });
  console.log('ERROR', formMethods.formState.errors);

  const formValues = formMethods.watch();
  const isDisabled =
    isProcessing ||
    isGeneratingOTP ||
    isStartedInitialSetup ||
    isCreatingClerkUser ||
    isClerkUserCreationSuccess ||
    isSuccess;

  // --- Handle Send OTP ---
  const handleSendOtp = async (values: IFormValues) => {
    setIsProcessing(true);
    formMethods.setValue('otp', '');

    const toastId = 'send-otp';
    toast.loading('Sending OTP...', { id: toastId });

    try {
      const res = await startGeneratingOTP({ email: values.userEmail });

      if (res?.success) {
        setStep('otp');
        const emailRes = await sendInitialSetupOTP({
          name: values?.userName,
          encryptedData: res?.data || '',
        });
        if (emailRes) {
          setResendTimer(RESEND_TIMEOUT);
          toast.success('OTP sent successfully!', { id: toastId });
        } else {
          toast.error('Failed to send OTP', { id: toastId });
        }
      } else {
        toast.error(res?.message || 'Failed to send OTP', { id: toastId });
      }
    } catch (err) {
      toast.error((err as Error)?.message || 'Failed to send OTP', {
        id: toastId,
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // --- Handle Start Initial Setup --
  const handleStartInitialSetup = async (values: IFormValues) => {
    if (isStartedInitialSetup || isCreatingClerkUser) return;

    const toastId = 'initial-setup';
    try {
      // Clerk user creation
      setIsClerkUserCreationSuccess(false);
      setIsCreatingClerkUser(true);
      toast.loading('Creating user in clerk...', { id: toastId });
      const clerkUserRes = await createClerkUser({
        email: values?.userEmail,
        name: values?.userName,
      });

      if (!clerkUserRes?.success) {
        toast.error('Failed to create clerk user', { id: toastId });
        setIsCreatingClerkUser(false);
      } else {
        setIsClerkUserCreationSuccess(true);

        toast.loading('Started initial setup...', { id: toastId });
        const res = await startInitialSetup({
          userName: values?.userName,
          userEmail: values?.userEmail,
          otp: values?.otp || '',

          applicationName: values?.applicationName,
          applicationKey: ROOT_CONFIG?.application?.key,
          applicationDescription: values?.applicationDescription,

          organizationName: values?.organizationName,
          organizationSubdomain: ROOT_CONFIG?.org?.subdomain,
          organizationDescription: values?.organizationDescription,
        });

        if (res?.success) {
          // Finally success message
          toast.success('Successfully completed the setup', {
            id: toastId,
          });
        } else {
          toast.error(res?.message || 'Failed to complete initial setup', {
            id: toastId,
          });
        }
      }
    } catch (error) {
      console.error(error); // helpful for debugging
      setIsClerkUserCreationSuccess(false);
      toast.error((error as Error)?.message || 'Failed the initial setup', {
        id: toastId,
      });
    } finally {
      setIsCreatingClerkUser(false);
    }
  };

  // --- Form Submit Handler ---
  const onSubmit = async (values: IFormValues) => {
    if (step === 'email') {
      handleSendOtp(values);
    } else {
      handleStartInitialSetup(values);
    }
  };

  // Countdown for resend
  useEffect(() => {
    if (resendTimer <= 0) return;
    const interval = setInterval(() => {
      setResendTimer((t) => (t > 0 ? t - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [resendTimer]);

  const isCompletedSetup =
    (preloadedData?.hasInitialSetup && !isCreatingClerkUser) ||
    (isSuccess && isClerkUserCreationSuccess);
  if (isCompletedSetup) {
    return <InitialSetupSuccess globalOrgLink={globalOrgLink} />;
  }

  if (isCreatingClerkUser || isStartedInitialSetup) {
    return (
      <Loader
        variant="screen"
        title="Initial Setup in Progress..."
        message="We’re setting up your organization and application. This may take a few moments — please wait until the setup is complete."
      />
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-10 space-y-4 px-2">
      {/* Intro */}
      <div className="text-center space-y-3">
        <h1 className="text-3xl font-bold tracking-tight">Initial Setup</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Welcome! Let’s complete the initial setup for your{' '}
          <strong>multi-tenant framework</strong>.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {/* Organization Section */}
        <InfoCard
          disabled={isDisabled}
          label="Organization"
          icon="Building"
          name={formValues?.organizationName}
          description={formValues?.organizationDescription}
          onClick={() => setShowOrgInfoDialog(true)}
        />
        <InfoCard
          disabled={isDisabled}
          label="Application"
          icon="AppWindow"
          name={formValues?.applicationName}
          description={formValues?.applicationDescription}
          onClick={() => setShowAppInfoDialog(true)}
        />
      </div>

      <FormProvider {...formMethods}>
        <form
          onSubmit={formMethods.handleSubmit(onSubmit)}
          className="space-y-6"
        >
          <Card className="py-5 gap-4">
            <CardHeader className="px-5">
              <CardTitle>First User</CardTitle>
              <p className="text-sm text-muted-foreground">
                This user will get{' '}
                <span className="font-medium">Org-Admin</span> and{' '}
                <span className="font-medium">Application Admin</span> access.
              </p>
            </CardHeader>
            <CardContent className="grid gap-3 px-5">
              {step === 'email' ? (
                <div className="grid sm:grid-cols-2 gap-3">
                  <FormInput
                    disabled={isDisabled}
                    name="userName"
                    label="Full Name"
                    placeholder="Enter user's name"
                  />
                  <FormInput
                    disabled={isDisabled}
                    name="userEmail"
                    label="Email"
                    placeholder="Enter user's email"
                  />
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-3 text-sm">
                  <div className="p-3 border rounded-md bg-gray-50 flex flex-col">
                    <span className="text-sm text-muted-foreground">
                      Full Name
                    </span>
                    <span className="font-medium text-gray-900">
                      {formValues?.userName}
                    </span>
                  </div>
                  <div className="p-3 border rounded-md bg-gray-50 flex flex-col">
                    <span className="text-sm text-muted-foreground">Email</span>
                    <span className="font-medium text-gray-900">
                      {formValues?.userEmail}
                    </span>
                  </div>
                </div>
              )}

              {step === 'otp' && (
                <div className="flex flex-col items-center gap-2 mt-2">
                  <p className="text-sm text-center">
                    We sent a 6-digit OTP to{' '}
                    <span className="font-semibold text-primary">
                      {formValues?.userEmail}
                    </span>
                    <Button
                      disabled={isDisabled}
                      type="submit"
                      size="icon"
                      variant="ghost"
                      onClick={() => setStep('email')}
                      className="ml-1 size-6 p-1"
                    >
                      <EditIcon className="w-4 h-4" />
                    </Button>
                  </p>
                  <InputOTP
                    disabled={isDisabled}
                    maxLength={6}
                    value={formValues.otp}
                    pattern={REGEXP_ONLY_DIGITS}
                    onChange={(val) => formMethods.setValue('otp', val)}
                  >
                    {[0, 1, 2].map((i) => (
                      <InputOTPGroup key={i}>
                        <InputOTPSlot index={i} />
                      </InputOTPGroup>
                    ))}
                    <InputOTPSeparator />
                    {[3, 4, 5].map((i) => (
                      <InputOTPGroup key={i}>
                        <InputOTPSlot index={i} />
                      </InputOTPGroup>
                    ))}
                  </InputOTP>

                  <div className="flex gap-2 mt-2">
                    <Button
                      type="button"
                      variant="link"
                      size="sm"
                      onClick={() => handleSendOtp(formValues)}
                      disabled={isDisabled || isProcessing || resendTimer > 0}
                    >
                      {resendTimer > 0
                        ? `Resend in ${resendTimer}s`
                        : 'Resend OTP'}
                    </Button>
                  </div>
                </div>
              )}

              <div className="w-full flex justify-end">
                {step === 'email' && (
                  <Button type="submit" disabled={isDisabled}>
                    {isProcessing ? (
                      <>
                        <LoaderIcon className="animate-spin" /> Send OTP{' '}
                      </>
                    ) : (
                      <>
                        <SendIcon /> Send OTP{' '}
                      </>
                    )}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div
            className={cn(
              'bg-background p-4 border-t flex justify-end space-x-4',
              { hidden: step !== 'otp' }
            )}
          >
            <Button
              disabled={isDisabled}
              type="button"
              size="lg"
              variant={'outline'}
              onClick={() => setStep('email')}
            >
              <ArrowLeftIcon /> Back to Edit
            </Button>
            <Button disabled={isDisabled} type="submit" size="lg">
              Save & Continue
            </Button>
          </div>
        </form>
      </FormProvider>

      <UpdateOrgInfoDialog
        disabled={isDisabled}
        showDialog={showOrgInfoDialog}
        setShowDialog={setShowOrgInfoDialog}
        defaultValues={formValues}
        onUpdate={(values) => {
          const currentFormValues = formMethods.getValues();
          formMethods.reset({
            ...currentFormValues,
            ...values,
          });
        }}
      />

      <UpdateAppInfoDialog
        disabled={isDisabled}
        showDialog={showAppInfoDialog}
        setShowDialog={setShowAppInfoDialog}
        defaultValues={formValues}
        onUpdate={(values) => {
          const currentFormValues = formMethods.getValues();
          formMethods.reset({
            ...currentFormValues,
            ...values,
          });
        }}
      />
    </div>
  );
};

export default InitialSetupForm;
