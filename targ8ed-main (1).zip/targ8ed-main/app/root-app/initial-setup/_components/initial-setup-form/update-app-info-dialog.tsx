import CustomDialog from '@/components/common/custom-dialog';
import FormInput from '@/components/form/form-input';
import FormTextarea from '@/components/form/form-textarea';
import { Button } from '@/components/ui/button';
import { DialogFooter } from '@/components/ui/dialog';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import useZodForm from '@/hooks/use-zod-form';
import { Dispatch, SetStateAction, useEffect } from 'react';
import { FormProvider } from 'react-hook-form';
import { z } from 'zod';
import { applicationDataValidationSchema } from '../../utils/validation-schema';

type IAppInputs = z.infer<typeof applicationDataValidationSchema>;

interface IProps {
  disabled: boolean;
  showDialog: boolean;
  setShowDialog: Dispatch<SetStateAction<boolean>>;
  defaultValues: IAppInputs;
  onUpdate: (values: IAppInputs) => void;
}

const UpdateAppInfoDialog = ({
  disabled,
  showDialog,
  defaultValues,
  setShowDialog,
  onUpdate,
}: IProps) => {
  // Form
  const formMethods = useZodForm(applicationDataValidationSchema, {
    defaultValues: {
      applicationName: '',
      applicationDescription: '',
      applicationKey: '',
    },
  });

  // Handles on dialog open change
  const onOpenChange = (state: boolean) => {
    formMethods.reset();
    setShowDialog(state);
  };

  // Submit handler
  const onSubmit = (values: IAppInputs) => {
    if (disabled) return;
    onUpdate(values);
    onOpenChange(false);
  };

  useEffect(() => {
    formMethods.reset(defaultValues);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDialog]);

  return (
    <CustomDialog
      isOpen={showDialog}
      onOpenChange={onOpenChange}
      title="Update Application Info"
    >
      <FormProvider {...formMethods}>
        <form onSubmit={formMethods.handleSubmit(onSubmit)}>
          <div className="grid gap-6 pb-6">
            <FormInput
              disabled={disabled}
              name="applicationName"
              label="Application Name"
              placeholder="Enter application name"
            />
            <FormInput
              disabled
              name="applicationKey"
              label="Application Key"
              placeholder="Enter application key"
              description={
                <>
                  The application key is fixed as{' '}
                  <span className="text-primary font-semibold">
                    {ROOT_CONFIG.application.key}
                  </span>{' '}
                  and cannot be changed.
                </>
              }
            />
            <FormTextarea
              disabled={disabled}
              name="applicationDescription"
              label="Description"
              placeholder="Enter application description"
            />
          </div>
          <DialogFooter>
            <Button disabled={disabled} type="submit">
              Update
            </Button>
          </DialogFooter>
        </form>
      </FormProvider>
    </CustomDialog>
  );
};

export default UpdateAppInfoDialog;
