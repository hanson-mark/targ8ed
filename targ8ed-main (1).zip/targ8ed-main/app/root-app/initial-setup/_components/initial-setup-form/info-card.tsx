import LucideIcon from '@/components/common/lucide-icon/lucide-icon';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ILucideIconName } from '@/types/dashboard-layout';

interface IProps {
  disabled: boolean;
  label: string;
  icon: ILucideIconName;
  name: string;
  description: string;
  onClick: () => void;
}

export const InfoCard = ({
  disabled,
  label,
  icon,
  name,
  description,
  onClick,
}: IProps) => {
  return (
    <div className="space-y-1">
      {/* Label outside the card */}
      <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
        {label}
      </h2>

      <Card className="transition-shadow rounded-xl border border-muted/40 py-3">
        <CardContent className="flex items-center gap-3 px-3">
          {/* Icon on the left */}
          <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors">
            <LucideIcon name={icon} className="w-6 h-6" />
          </div>

          {/* Content on the right */}
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-semibold text-foreground truncate">
              {name}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-1">
              {description}
            </p>
          </div>

          {/* Action button */}
          <Button
            disabled={disabled}
            onClick={onClick}
            size="sm"
            variant="secondary"
            className="shrink-0 hover:bg-primary hover:text-primary-foreground"
          >
            Edit
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
