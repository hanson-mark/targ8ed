import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckIcon } from 'lucide-react';
import Link from 'next/link';

interface IProps {
  globalOrgLink: string;
}

const InitialSetupSuccess = ({ globalOrgLink }: IProps) => {
  return (
    <div className="w-full h-screen flex justify-center items-center">
      <div className="max-w-lg w-full mx-auto py-20 px-4">
        <Card className="text-center py-10">
          <CardHeader>
            <div className="flex justify-center mb-2">
              <div className="w-16 h-16 flex justify-center items-center bg-green-100 text-green-600  rounded-full">
                <CheckIcon className="w-10 h-10" />
              </div>
            </div>
            <CardTitle className="text-2xl font-semibold">
              Initial Setup Complete
            </CardTitle>
            <p className="text-muted-foreground mt-2">
              Your system has already been successfully initialized.
            </p>
          </CardHeader>
          <CardContent className="mt-2">
            <Button size="lg" asChild>
              <Link href={globalOrgLink}>Go to Global Organization</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InitialSetupSuccess;
