'use client';
import { Button } from '@/components/ui/button';
import { api } from '@/convex/_generated/api';
import { useConvex } from 'convex/react';

const GenerateInitialData = () => {
  const convexClient = useConvex();

  const getInitialData = async () => {
    const initialData = await convexClient.query(
      api.functions.apps.global.initialSetup.index
        .generateGlobalApplicationInitialData
    );

    console.log('INITIAL DATA ---> ', initialData);
  };

  return (
    <div>
      <Button onClick={getInitialData}>Generate Initial Data</Button>
    </div>
  );
};

export default GenerateInitialData;
