import { api } from '@/convex/_generated/api';
import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { getGlobalOrgLinkInServer } from '@/lib/app-config';
import { preloadQuery } from 'convex/nextjs';
import InitialSetupForm from './_components/initial-setup-form';

const InitialSetupPage = async () => {
  // Fetch data from convex using preload query and pass the data to the component
  const preloadedInitialSetupCheck = await preloadQuery(
    api.functions.apps.global.initialSetup.index.checkHasInitialSetup
  );

  const globalOrgLink = await getGlobalOrgLinkInServer();

  return (
    <>
      {/* <GenerateInitialData /> */}
      <InitialSetupForm
        globalOrgLink={globalOrgLink + `/${ROOT_CONFIG.application.key}`}
        preloadedInitialSetupCheck={preloadedInitialSetupCheck}
      />
    </>
  );
};

export default InitialSetupPage;
