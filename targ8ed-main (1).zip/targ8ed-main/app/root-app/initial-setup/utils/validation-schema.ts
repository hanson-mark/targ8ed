import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import {
  applicationKeyZodSchema,
  descriptionZodSchema,
  emailZodSchema,
  nameZodSchema,
  otpZodSchema,
  subdomainZodSchema,
} from '@/convex/validations/common';
import { z } from 'zod';

export const orgDataValidationSchema = z.object({
  organizationName: nameZodSchema,
  organizationSubdomain: subdomainZodSchema,
  organizationDescription: descriptionZodSchema,
});

export const applicationDataValidationSchema = z.object({
  applicationName: nameZodSchema,
  applicationKey: applicationKeyZodSchema,
  applicationDescription: descriptionZodSchema,
});

export const getInitialSetupDataValidationSchema = (step: 'email' | 'otp') => {
  return z.object({
    userName: nameZodSchema,
    userEmail: emailZodSchema,
    ...(step === 'email'
      ? { otp: z.string().optional() }
      : { otp: otpZodSchema }),

    applicationName: nameZodSchema,
    applicationKey: applicationKeyZodSchema,
    applicationDescription: descriptionZodSchema,

    organizationName: nameZodSchema,
    organizationSubdomain: subdomainZodSchema,
    organizationDescription: descriptionZodSchema,
  });
};

export const initialSetupDataValidationSchema =
  getInitialSetupDataValidationSchema('otp');

export const defaultValuesOfInitialSetupForm: z.infer<
  typeof initialSetupDataValidationSchema
> = {
  userName: '',
  userEmail: '',
  otp: '',

  applicationName: ROOT_CONFIG.application.initialName,
  applicationKey: ROOT_CONFIG.application.key,
  applicationDescription: ROOT_CONFIG.application.description,

  organizationName: ROOT_CONFIG.org.initialName,
  organizationSubdomain: ROOT_CONFIG.org.subdomain,
  organizationDescription: ROOT_CONFIG.org.description,
};
