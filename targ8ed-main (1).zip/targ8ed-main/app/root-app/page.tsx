'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import Link from 'next/link';

export default function AppHomePage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="max-w-xl w-full text-center">
        <Card className="shadow-xl p-6 bg-card text-card-foreground">
          <h1 className="text-2xl font-bold mb-4">
            Welcome to Your Multi-Tenant Applications
          </h1>
          <p className="text-lg text-muted-foreground mb-6">
            This is the home page of your multi-tenant application. You can
            easily manage tenants and navigate across various sections with
            ease.
          </p>
          <div className="flex justify-center">
            <Button asChild className="mt-4">
              <Link href="/create-organization">Get Started</Link>
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
