'use client';

const TestPage = () => {
  return <div className="">Test component</div>;
};

export default TestPage;
