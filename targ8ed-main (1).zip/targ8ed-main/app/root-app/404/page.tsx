import NotFoundWarning from '@/components/common/not-found-warning';

const AppNotFoundPage = () => {
  return <NotFoundWarning />;
};

export default AppNotFoundPage;
