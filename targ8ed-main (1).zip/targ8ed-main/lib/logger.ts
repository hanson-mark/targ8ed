import { ILogger } from '@/types/logger';

const logger: ILogger = {
  info: (...args: unknown[]) => console.log(`\x1b[32m[INFO]\x1b[0m`, ...args), // Green
  debug: (...args: unknown[]) => console.log(`\x1b[34m[DEBUG]\x1b[0m`, ...args), // Blue
  warn: (...args: unknown[]) => console.log(`\x1b[33m[WARN]\x1b[0m`, ...args), // Yellow
  error: (...args: unknown[]) =>
    console.error(`\x1b[31m[ERROR]\x1b[0m`, ...args), // Red
  fatal: (...args: unknown[]) => console.log(`\x1b[35m[FATAL]\x1b[0m`, ...args), // Magenta
  trace: (...args: unknown[]) => console.log(`\x1b[36m[TRACE]\x1b[0m`, ...args), // Cyan
  silent: () => {}, // No output
};

export default logger;
