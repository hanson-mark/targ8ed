import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { headers } from 'next/headers';
import requiredEnvVariables from './env-variables';

// Gets the sub domain in server
export const getSubDomainInServer = async () => {
  // Main domain (e.g. your-domain.com)
  const mainDomain = appConfig.mainDomain;

  // Wildcard version of the domain (e.g. .your-domain.com)
  const wildcardDomain = `.${mainDomain}`;

  // Get the requested hostname (e.g. demo.your-domain.com)
  const headersList = await headers();
  const hostname = headersList.get('host') || mainDomain;
  const currentHost = hostname.replace(wildcardDomain, '');

  const isMainDomain = hostname === mainDomain;

  const subDomain = isMainDomain ? '' : currentHost;

  return (subDomain || '')?.toLowerCase();
};

export const getProtocolInServer = async () => {
  const headersList = await headers();

  const serverProtocol = headersList.get('x-forwarded-proto') || '';

  const fallbackProtocol =
    requiredEnvVariables.NODE_ENV === 'production' ? 'https' : 'http';
  const protocol = serverProtocol || fallbackProtocol;

  return protocol;
};

export const getGlobalOrgLinkInServer = async () => {
  const protocol = await getProtocolInServer();

  // Main domain (e.g. your-domain.com)
  const mainDomain = appConfig.mainDomain;

  return `${protocol}://${ROOT_CONFIG.org.subdomain}.${mainDomain}`;
};

// Builds the full base URL (protocol + host) on the server
export const getAppBaseUrlInServer = async () => {
  const headersList = await headers();

  const protocol = await getProtocolInServer();

  const hostname = headersList.get('host') || '';

  const baseURL = `${protocol}://${hostname}`;

  return !hostname ? '' : baseURL;
};

// i18n configurations
const i18nConfig = {
  locales: ['en', 'ro'] as const,
  defaultLocale: 'en',
};

// Infisical

const infisicalEnvironments = ['prod', 'dev'] as const;

// App configuration
const appConfig = {
  mainDomain: requiredEnvVariables.NEXT_PUBLIC_MAIN_DOMAIN || '',
  i18n: i18nConfig,
  infisical: {
    environments: infisicalEnvironments,
  },
};

export default appConfig;
