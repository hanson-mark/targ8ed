import { Metadata } from 'next';
import { defaultMetaData } from './default-data/meta-data';

export const addImageUrlToFavicon = (image: string) => {
  if (!image) return;

  const faviconLinks = document.querySelectorAll(
    "link[rel~='icon']"
  ) as NodeListOf<HTMLLinkElement>;

  const faviconArray = Array.from(faviconLinks);

  if (faviconArray.length > 0) {
    // Update all existing favicons
    faviconArray.forEach((link) => {
      link.href = image;
    });
  } else {
    // No favicon exists — create a new one
    const newFavicon = document.createElement('link');
    newFavicon.rel = 'icon';
    newFavicon.href = image;
    document.head.appendChild(newFavicon);
  }
};

export const addMetadataToHeadIfNot = (metadata: Metadata) => {
  if (!metadata?.title) return;
  const titleElem = document.querySelector('title');

  if (!titleElem) {
    const newTitleElem = document.createElement('title');
    newTitleElem.innerText = (
      metadata?.title ||
      defaultMetaData?.title ||
      ''
    )?.toString();

    document?.head?.appendChild(newTitleElem);
  } else if (titleElem.innerText != metadata?.title) {
    titleElem.innerText = (metadata?.title || '')?.toString();
  }
};

export const addMetadataCustom = (faviconImage: string, metadata: Metadata) => {
  addImageUrlToFavicon(faviconImage);
  addMetadataToHeadIfNot(metadata);
};
