export const checkPermission = (permissions: string[], fnNames: string[]) => {
  return fnNames.some((fn) => permissions?.includes(fn));
};
