import { format } from 'date-fns';
import { get } from 'lodash';

// handle quotes inside data
const escapeCSV = (value: unknown) => {
  return `"${String(value).replace(/"/g, '""')}"`;
};

export const downloadCSVFromObjects = <T extends object>(inputs: {
  data: T[];
  selectedKeys: { key: keyof T; title: string }[];
  filenamePrefix: string;
  extension?: 'csv';
}) => {
  const {
    data,
    selectedKeys,
    filenamePrefix = 'download',
    extension = 'csv',
  } = inputs;
  if (!data?.length) return;

  const keys = selectedKeys?.map((item) => item?.key);

  // Convert rows
  const csvContent = [
    selectedKeys
      ?.map((item) => (item?.title || item?.key || '')?.toString())
      .join(','), // header
    ...data.map((row) =>
      keys.map((key) => escapeCSV(get(row, key) || '')).join(',')
    ), // each row
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.setAttribute(
    'download',
    `${filenamePrefix}_${format(new Date(), 'yyyy-MM-dd_hh-mm-ss_a')}.${extension}`
  );
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
