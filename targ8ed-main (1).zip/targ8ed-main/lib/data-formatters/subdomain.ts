import { SUBDOMAIN_MAX_LENGTH } from '@/convex/constants/subdomain';

export const generateSubdomainFromName = (text: string): string => {
  const cleaned = text
    .toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/[^a-z0-9-]/g, '') // Remove all non-alphanumerics (except hyphens)
    .replace(/-+/g, '-') // Collapse multiple hyphens into one
    .replace(/^-+|-+$/g, ''); // Trim leading/trailing hyphens

  const sliced = cleaned.slice(0, SUBDOMAIN_MAX_LENGTH);

  return sliced.replace(/^-+|-+$/g, ''); // Final trim if slicing introduced edge hyphen
};
