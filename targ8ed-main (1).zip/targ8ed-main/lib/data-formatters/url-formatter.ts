import { Id } from '@/convex/_generated/dataModel';

export const getOrganizationURL = (subdomain: string) => {
  const protocol =
    process.env.NODE_ENV === 'development' ? 'http://' : 'https://';
  const organizationURL = `${protocol}${subdomain || 'www'}.${process.env.NEXT_PUBLIC_MAIN_DOMAIN}`;

  return organizationURL;
};

// Builds a URL by appending query parameters (including arrays) to the base URL.
export function buildUrlWithQueryParams(
  baseUrl: string,
  queryParams: Record<string, unknown> = {}
): string {
  const searchParams = new URLSearchParams();

  Object.entries(queryParams).forEach(([key, value]) => {
    if (value === undefined || value === null) return;

    // Handle arrays (e.g., ?tag[]=js&tag[]=ts)
    if (Array.isArray(value)) {
      value.forEach((v) => searchParams.append(`${key}[]`, String(v)));
    } else {
      searchParams.append(key, String(value));
    }
  });

  const queryString = searchParams.toString();
  return queryString ? `${baseUrl}?${queryString}` : baseUrl;
}

// Parses a URL string into its parts and converts query parameters into a structured object (including arrays).
export function parseUrlParts(url: string) {
  const hasProtocol = /^https?:\/\//i.test(url);
  const base = hasProtocol
    ? url
    : `http://dummy${url.startsWith('/') ? '' : '/'}${url}`;

  const parsed = new URL(base);

  const params: Record<string, string | string[]> = {};

  parsed.searchParams.forEach((value, key) => {
    // Normalize key (e.g., "tags[]" → "tags")
    const normalizedKey = key.endsWith('[]') ? key.slice(0, -2) : key;

    if (params[normalizedKey]) {
      if (Array.isArray(params[normalizedKey])) {
        (params[normalizedKey] as string[]).push(value);
      } else {
        params[normalizedKey] = [params[normalizedKey] as string, value];
      }
    } else {
      params[normalizedKey] = value;
    }
  });

  return {
    origin: hasProtocol ? parsed.origin : undefined,
    pathname: parsed.pathname,
    search: parsed.search,
    searchParams: params,
    hash: parsed.hash,
  };
}

// Get convex image url
export function getConvexImageURL(storageId: Id<'_storage'>) {
  if (!storageId) {
    return '';
  }
  const getImageUrl = new URL(
    `${process.env.NEXT_PUBLIC_CONVEX_ACTION_URL}/getImage`
  );
  getImageUrl.searchParams.set('storageId', storageId);

  return getImageUrl?.href;
}
