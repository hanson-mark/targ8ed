import { add, Duration, isBefore } from 'date-fns';

export function isStoredTimeExpired(
  storedAt?: number,
  duration?: string
): boolean {
  if (!storedAt || !duration) return true;

  const unit = duration.slice(-1);
  const value = parseInt(duration.slice(0, -1), 10);
  if (isNaN(value)) throw new Error('Invalid duration value');

  const storedDate = new Date(storedAt);

  const durationMap: Record<string, keyof Duration> = {
    s: 'seconds',
    m: 'minutes',
    h: 'hours',
    d: 'days',
    w: 'weeks',
    M: 'months',
  };

  const durationKey = durationMap[unit];
  if (!durationKey) throw new Error(`Unsupported duration unit: ${unit}`);

  const expiryDate = add(storedDate, { [durationKey]: value });

  return isBefore(expiryDate, new Date());
}
