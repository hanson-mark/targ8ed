import { Id } from '@/convex/_generated/dataModel';
import {
  ICurrentApplication,
  IOrganization,
  IUserApplication,
} from '@/convex/types/convex-types';
import { ICurrentOrgUser } from '@/stores/subdomainStore';
import {
  IGlobalLayoutProps,
  IOrgApplicationLayoutProps,
  IOrgLayoutProps,
  ISdebarGroupItem,
  ISidebarData,
  ISidebarHeaderSwitcherItem,
  ISidebarHomePage,
} from '@/types/dashboard-layout';
import { ITreeItem } from '@/types/sortable-tree-menu';
import { getConvexImageURL } from './url-formatter';

export const getSelectedSidebarMenuItem = (
  groupedMenu: ISdebarGroupItem[],
  pathname: string
) => {
  for (const group of groupedMenu) {
    for (const item of group.items) {
      // Match main group item
      if (item.link && pathname.startsWith(item.link)) {
        return item;
      }

      // Match sub-items if any
      if (item.items) {
        for (const subItem of item.items) {
          if (pathname.startsWith(subItem.link || '')) {
            return subItem;
          }
        }
      }
    }
  }
};

export const userApplicationToSwitcherItem = (
  userApplication: IUserApplication
): ISidebarHeaderSwitcherItem => {
  return {
    id: userApplication?._id,
    icon: 'Users',
    image:
      userApplication?.image ||
      getConvexImageURL(userApplication?.imageId as Id<'_storage'>),
    title: userApplication?.name,
    subtitle: userApplication?.description || '-',
    type: 'link',
    link: `/${userApplication?.key}`,
  };
};

export const userOrgToSwitcherItem = (
  organization?: IOrganization
): ISidebarHomePage => {
  return {
    id: organization?._id as Id<'organizations'>,
    icon: 'Users',
    image:
      organization?.image ||
      getConvexImageURL(organization?.imageId as Id<'_storage'>),
    title: organization?.name as string,
    subtitle: organization?.description || '-',
    link: `/`,
  };
};

export const generateApplicationSidebar = (
  items: ITreeItem[] = [],
  applicationKey?: string
): ISdebarGroupItem[] => {
  return (items || []).map((item) => {
    return {
      id: (item?.id || '')?.toString(),
      // Icon
      ...(item?.type !== 'group' ? { icon: item.icon } : {}),
      // Link
      ...(item?.type === 'link' || item?.type === 'split-button'
        ? {
            link: `/${applicationKey || ''}${item?.module?.link === '/' ? '' : item?.module?.link || ''}`,
          }
        : {}),
      title: item.label,
      isOpen: !item.collapsed,
      type: item?.type,
      items: item.children
        ? generateApplicationSidebar(
            item.children as ITreeItem[],
            applicationKey
          )
        : [],
    };
  });
};

// [Org Application - Sidebar]
const getSubdomainApplicationSidebarData = (
  userConfig: ICurrentOrgUser | null,
  application: ICurrentApplication
): ISidebarData => {
  const sidebarData: ISidebarData = {
    isGlobal: false,
    homePage: userOrgToSwitcherItem(userConfig?.organization),
    headerSwitcherItems:
      userConfig?.applications?.map((item) =>
        userApplicationToSwitcherItem(item)
      ) || [],
    groupedMenu: generateApplicationSidebar(
      (application?.sidebar || []) as ITreeItem[],
      application?.key
    ),
  };
  return sidebarData;
};

// [Organization - Sidebar]
const getSubdomainDashboardSidebarData = (
  userConfig: ICurrentOrgUser | null
): ISidebarData => {
  const sidebarData: ISidebarData = {
    isGlobal: false,
    homePage: userOrgToSwitcherItem(userConfig?.organization),
    headerSwitcherItems:
      userConfig?.applications?.map((item) =>
        userApplicationToSwitcherItem(item)
      ) || [],
    groupedMenu: [
      {
        id: 'platform',
        title: 'Platform',
        type: 'group',
        items: [
          {
            id: 'applications',
            title: 'Applications',
            link: '/applications',
            icon: 'AppWindowIcon',
            type: 'link',
            items: [],
          },
          {
            id: 'users',
            title: 'Users',
            link: '/users',
            icon: 'UsersIcon',
            type: 'link',
            items: [],
          },
        ],
      },
    ],
  };
  return sidebarData;
};

export const getSidebarData = (
  param:
    | Omit<IGlobalLayoutProps, 'children'>
    | Omit<IOrgLayoutProps, 'children'>
    | Omit<IOrgApplicationLayoutProps, 'children'>
) => {
  const { type, userConfig } = param;
  if (type === 'subdomain-application') {
    return getSubdomainApplicationSidebarData(userConfig, param?.application);
  } else if (type === 'subdomain-dashboard') {
    return getSubdomainDashboardSidebarData(userConfig);
  }
};
