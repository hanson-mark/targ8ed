import { APPLICATION_KEY_MAX_LENGTH } from '@/convex/constants/applicationKey';

export const generateApplicationKeyFromName = (text: string): string => {
  const tempText = text.replace(/^\d+/, ''); // ensure it doesn’t start with digit
  const firstLetter =
    tempText?.length > 0 ? tempText.slice(0, 1)?.toLowerCase() : '';
  const restLetters = tempText?.length > 1 ? tempText.slice(1) : '';
  let cleaned = (firstLetter + restLetters).replace(/[^a-zA-Z0-9]/g, ''); // remove anything not alphanumeric

  cleaned = cleaned.slice(0, APPLICATION_KEY_MAX_LENGTH);

  return cleaned;
};
