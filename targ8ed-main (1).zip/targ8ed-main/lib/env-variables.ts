import { z, ZodError } from 'zod';

// expand(config());

const envSchema = z.object({
  // App
  NODE_ENV: z.string().default('development'),
  NEXT_PUBLIC_MAIN_DOMAIN: z.string({
    required_error: 'NEXT_PUBLIC_MAIN_DOMAIN is required',
  }),

  // Resend & Email encryption related
  RESEND_API_KEY: z.string({
    required_error: 'RESEND_API_KEY is required',
  }),
  NEXT_PUBLIC_RESEND_DOMAIN: z
    .string({
      required_error: 'NEXT_PUBLIC_RESEND_DOMAIN is required',
    })
    .refine((val) => !val.includes('localhost'), {
      message:
        'NEXT_PUBLIC_RESEND_DOMAIN cannot use localhost. Use your verified domain.',
    }),

  ENCRYPTION_SECRET: z.string({
    required_error: 'ENCRYPTION_SECRET is required',
  }),

  // Clerk - Publishable key & secret keys
  CLERK_SECRET_KEY: z.string({
    required_error: 'CLERK_SECRET_KEY is required',
  }),
  NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY: z.string({
    required_error: 'NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY is required',
  }),

  // Clerk - Frontend API URL
  NEXT_PUBLIC_CLERK_FRONTEND_API_URL: z.string({
    required_error: 'NEXT_PUBLIC_CLERK_FRONTEND_API_URL is required',
  }),

  // Convex
  CONVEX_DEPLOYMENT: z.string({
    required_error: 'CONVEX_DEPLOYMENT is required',
  }),
  NEXT_PUBLIC_CONVEX_URL: z.string({
    required_error: 'NEXT_PUBLIC_CONVEX_URL is required',
  }),
  NEXT_PUBLIC_CONVEX_ACTION_URL: z.string({
    required_error: 'NEXT_PUBLIC_CONVEX_ACTION_URL is required',
  }),
});

type IEnv = z.infer<typeof envSchema>;

let requiredEnvVariables: IEnv;

try {
  requiredEnvVariables = envSchema.parse(process.env);
} catch (e) {
  const error = e as ZodError;
  console.error('❌ Invalid env:');
  console.error(error.flatten().fieldErrors);

  // Otherwise, throw an error to fail gracefully in Edge runtime
  throw new Error('Invalid environment variables.');
}

export default requiredEnvVariables;
