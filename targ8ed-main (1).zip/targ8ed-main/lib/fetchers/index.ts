import {
  DEFAULT_PAGE_LIMIT,
  DEFAULT_SORT_ORDER,
} from '../default-data/default-pagination';

export const fetcher = (url: string) => fetch(url).then((res) => res.json());
export const paginationOptions = {
  limit: DEFAULT_PAGE_LIMIT,
  cursor: '',
  sortOrder: DEFAULT_SORT_ORDER,
};
