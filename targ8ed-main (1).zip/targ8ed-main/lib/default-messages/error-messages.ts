const defaultErrorMessages = {
  USER_ALREADY_EXISTS_WITH_EMAIL: 'User with this email already exists',
} as const;

export default defaultErrorMessages;
