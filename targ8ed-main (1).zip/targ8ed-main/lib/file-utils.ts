// 🧠 Helper to get image width and height
export const getImageDimensions = (
  file: File
): Promise<{ width: number; height: number } | null> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    const image = new Image();

    reader.onload = (e) => {
      if (!e.target?.result) return resolve(null);
      image.src = e.target.result as string;
    };

    image.onload = () => {
      resolve({
        width: image.width,
        height: image.height,
      });
    };

    image.onerror = () => resolve(null);

    reader.readAsDataURL(file);
  });
};
