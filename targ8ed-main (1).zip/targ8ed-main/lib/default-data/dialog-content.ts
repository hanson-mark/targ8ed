import { IUseConfirmProps } from '@/hooks/use-confirm';

const ActiveUserGlobally: IUseConfirmProps = {
  title: 'Active This User?',
  description:
    'Once activated, the user will regain access to the organizations they belong to. You can inactive them again anytime from the global users panel.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const InactiveUserGlobally: IUseConfirmProps = {
  title: 'Inactive This User Globally?',
  description:
    'Once inactive, the user will no longer be able to access any organization. You can always active them later from the global users panel.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Inactive', variant: 'destructive' },
};

const ActiveOrganizationUser: IUseConfirmProps = {
  title: 'Active This User?',
  description:
    'Once activated, this user will regain access to this organization. You can inactive them again anytime from the members panel.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const InactiveOrganizationUser: IUseConfirmProps = {
  title: 'Inactive This User?',
  description:
    'Once inactive, this user will no longer be able to access this organization. You can active them later from the members panel.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Inactive', variant: 'destructive' },
};

const ActiveOrgApplication: IUseConfirmProps = {
  title: 'Active This Organization Application?',
  description:
    'Once active, the organization will regain access to this application and its functionalities.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const InactiveOrgApplication: IUseConfirmProps = {
  title: 'Inactive This Organization Application?',
  description:
    'Once inactive, the organization will no longer be able to access this application. You can active it again anytime.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Inactive', variant: 'destructive' },
};

const ActiveUserApplication: IUseConfirmProps = {
  title: 'Active This User Application?',
  description:
    'Once active, the user will regain access to this application and its features.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const InactiveUserApplication: IUseConfirmProps = {
  title: 'Inactive This User Application?',
  description:
    'Once disabled, the user will no longer be able to access this application. You can active it again anytime.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Inactive', variant: 'destructive' },
};

const EnableApplication: IUseConfirmProps = {
  title: 'Enable This Application?',
  description:
    'Once enabled, organizations with access to this application can start using its features again.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const DisableApplication: IUseConfirmProps = {
  title: 'Disable This Application?',
  description:
    'Once disabled, all organizations will lose access to this application. You can re-enable it anytime from the admin panel.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Disable', variant: 'destructive' },
};

const RemoveUserApplication: IUseConfirmProps = {
  title: 'Remove This User From The Application?',
  description:
    'Once removed, the user will lose access to this application. This action cannot be undone.',
  icon: { name: 'Trash2', variant: 'error' },
  confirmButton: { label: 'Yes, Remove', variant: 'destructive' },
};

const RemoveOrgApplication: IUseConfirmProps = {
  title: 'Remove This Application From The Organization?',
  description:
    'Once removed, the users of the organization will lose access to this application. This action cannot be undone.',
  icon: { name: 'Trash2', variant: 'error' },
  confirmButton: { label: 'Yes, remove', variant: 'destructive' },
};

const RemoveOrgUser: IUseConfirmProps = {
  title: 'Remove This User from Organization?',
  description:
    'Once removed, this user will lose all access to the organization. This action cannot be undone.',
  icon: { name: 'UserX', variant: 'error' },
  confirmButton: { label: 'Yes, remove', variant: 'destructive' },
};

const RemoveInvitationConfirm: IUseConfirmProps = {
  title: 'Delete This Invitation?',
  description:
    'Once deleted, the invitee will no longer be able to join the organization using this invitation. This action cannot be undone.',
  icon: { name: 'MailX', variant: 'error' },
  confirmButton: { label: 'Yes, Delete Invitation', variant: 'destructive' },
};

const ActiveApplication: IUseConfirmProps = {
  title: 'Activate This Application?',
  description:
    'Activating this application will allow users to access it again. You can inactive it at any time from the global application panel.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const InactiveApplication: IUseConfirmProps = {
  title: 'Inactive This Application?',
  description:
    'Inactivating this application will prevent users from accessing it. You can active it anytime later from the global application panel.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Inactive', variant: 'destructive' },
};

const ActiveOrganization: IUseConfirmProps = {
  title: 'Activate This Organization?',
  description:
    'Activating this organization will restore user access to all organizations they are part of. You can inactive it again anytime from the global organizations panel.',
  icon: { name: 'CheckCircle2', variant: 'success' },
};

const InactiveOrganization: IUseConfirmProps = {
  title: 'Inactive This Organization?',
  description:
    'Inactivating this organization will revoke user access to all associated organizations. You can active it anytime later from the global organizations panel.',
  icon: { name: 'AlertCircle', variant: 'error' },
  confirmButton: { label: 'Yes, Inactive', variant: 'destructive' },
};

export const DIALOG_CONTENT = {
  ActiveUserGlobally,
  InactiveUserGlobally,
  ActiveOrganizationUser,
  InactiveOrganizationUser,

  ActiveOrgApplication,
  InactiveOrgApplication,

  ActiveUserApplication,
  InactiveUserApplication,

  EnableApplication,
  DisableApplication,

  RemoveUserApplication,
  RemoveOrgApplication,
  RemoveOrgUser,
  RemoveInvitationConfirm,

  ActiveApplication,
  InactiveApplication,

  ActiveOrganization,
  InactiveOrganization,
};
