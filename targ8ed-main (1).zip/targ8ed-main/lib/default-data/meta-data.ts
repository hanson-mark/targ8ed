import { ROOT_CONFIG } from '@/convex/constants/rootConfig';
import { Metadata } from 'next';

export const defaultMetaData: Metadata = {
  title: ROOT_CONFIG.site.title,
  description: ROOT_CONFIG.site.description,
  other: {
    'google-site-verification': 'NlL5M5mC5kDoK9Gf-A8EOqrF0d8uGRs7JrV73dAOQt4',
  },
};
